# Qwen Studio 0.7.2 — deployment readiness

## What this package is

This is a **single-user local self-hosted application**, not a multi-tenant SaaS. There is no account system: no registration, login, sessions, roles, or password recovery. It includes one local workspace with a SQLite project index and cached storage accounting, a model gateway, a private Docker runner, isolated project containers, static build/publish, quotas, bounded chat concurrency, and an Nginx deployment template for optional network exposure.

## Before exposing the studio beyond loopback

1. Use a dedicated Linux VPS/worker host. Do not run the Docker-socket runner on a machine containing personal files, unrelated services, or valuable secrets.
2. Configure a model endpoint — an external OpenAI-compatible server or the bundled local weights mode (`LOCAL_INFERENCE=true`).
3. Configure three different origin groups: `studio.<domain>`, `*.preview.<domain>`, and `*.sites.<domain>`. Obtain TLS certificates for the studio host, wildcard preview host, and wildcard published-sites host (plus the publish apex if serving its explicit 404 TLS server). A wildcard certificate normally requires DNS validation.
4. Generate a long random `SANDBOX_RUNNER_TOKEN` (internal app-to-runner authentication only; there is no account secret), enter all real values in `.env`, and run `python3 deploy/preflight.py`.
5. Keep `APP_BIND_ADDRESS=127.0.0.1` and `ALLOW_REMOTE_ACCESS=false`. The shipped quota/concurrency defaults are `0` = unlimited because the operator owns the machine; on any shared or remote exposure set explicit caps (for example `MAX_CONCURRENT_CHATS=4`, daily quotas, `MAX_FILE_BYTES`). Keep `SANDBOX_ALLOW_NETWORK_INSTALL=false` unless the internal Verdaccio proxy profile is deliberately enabled with `SANDBOX_NPM_REGISTRY_URL=http://npm-proxy:4873`.
6. Install and validate the Nginx configuration in `deploy/nginx-qwen-studio.conf`, then run `deploy/deploy.sh`.
7. Open the studio, run a sample prompt, test file creation, run a sandbox check, start a preview, and publish a static site — all without any sign-in step.
8. Configure backups, monitor disk and memory, and test restoration before any shared exposure.

Because the application itself has no login wall, anyone who can reach the app port can use
the workspace. Network exposure is therefore an explicit, security-reviewed decision: keep
loopback binding for personal use and require an authenticating TLS reverse proxy plus server
access controls for anything wider.

## Hard blockers for a true public SaaS

- The Runner controls Docker through `/var/run/docker.sock`. That socket is effectively host-level control. For anything beyond a personal deployment, move it to a dedicated disposable worker host or replace it with microVM/gVisor/Kata-backed execution and a narrowly scoped control plane.
- The model endpoint must support the configured Qwen model and native tool calling.
- The single-user workspace has no multi-user controls. Passwords/MFA/OAuth/team features/admin console/billing/payments/abuse-reporting workflow and legally reviewed privacy/terms documents are not included; if you need them, add them at a proxy layer or fork the project for a multi-user design.
- SQLite and in-memory rate limits are single-instance choices. Move to PostgreSQL and Redis before multi-replica production.
- The preview/publish service is hosted on this same host. It is not a global CDN or managed deployment platform. Add external object storage/CDN or a hosting provider for scale.
- No live Docker-engine integration or GPU inference test was possible in the build environment. Unit tests do not prove container containment or model quality.

## Safe rollout recommendation

Keep the studio on loopback for personal use. For a small group on a dedicated host, add an authenticating reverse proxy first and keep dependency downloads disabled. Do not advertise it as globally launch-ready until the runner has been isolated from critical infrastructure and independently security-tested.


## Internal npm dependency proxy

The optional Verdaccio proxy is the only service with upstream registry egress. It joins the
internal `qwen_npm_install` network and a separate egress network. Short-lived npm lockfile
and dependency-install containers join only `qwen_npm_install`; the app, runner, and project build/preview containers
are not members. Enable with `SANDBOX_ALLOW_NETWORK_INSTALL=true`,
`SANDBOX_NPM_REGISTRY_URL=http://npm-proxy:4873`, and
`docker compose --profile npm-proxy up -d npm-proxy`. When a dependency-bearing project has no
`package-lock.json`, the runner first creates one in the temporary isolated volume using
`npm install --package-lock-only --ignore-scripts --no-audit --no-fund`, then runs
`npm ci --ignore-scripts`. The generated lockfile stays in that temporary volume and is not
written into the shared project. Both containers join only the internal install network.
Packages relying on install scripts may not be usable.
Projects with an empty dependency declaration skip installation and skip checking for
`node_modules`. Docker network behavior and upstream registry access require live verification.

## Per-deployment published origins

Set `PUBLISH_BASE_URL=https://sites.example.com` and `PUBLISH_DOMAIN=sites.example.com`.
The URL's hostname must differ from both `PUBLIC_BASE_URL` (the studio) and
`PREVIEW_BASE_URL` (the project previews). Each deployment is served on
`https://<slug>.sites.example.com/` where the slug is `site-` followed by 32 hex characters.
Path-based publish routes are not supported. The bare `sites.example.com` apex and
invalid publish subdomains return 404 without exposing the studio UI or API.

Configure wildcard DNS for `*.sites.example.com` and a wildcard TLS certificate covering that
wildcard (the apex certificate used for the intentional 404 server should also cover
`sites.example.com`). The published CSP keeps `connect-src 'self'` and does not use the CSP
`sandbox` directive; the per-slug origin is the isolation boundary. Verify this with real Nginx
routing, wildcard DNS, and TLS before publishing user-generated code publicly.

## Version 0.6.1 notes

- npm projects without a lockfile can generate one inside their temporary install volume using the internal npm proxy, then install with `npm ci --ignore-scripts`. The generated file is not written into the shared source project.
- `FORWARDED_ALLOW_IPS` defaults to the single app-net gateway IP `172.28.0.1`; change it if the Compose subnet/gateway is overridden. Production preflight rejects wildcard and broad IPv4 trusted-proxy ranges.
- Each published site has an individual slug subdomain origin. Configure wildcard DNS and TLS for `*.sites.example.com`; the bare domain returns 404.
- Authenticated app-origin preview file routes use a restrictive sandbox CSP and `Cross-Origin-Resource-Policy: same-origin`. Separate preview and publish origins intentionally omit CSP sandbox.
- Invalid JSON tool-call retries are capped at two, and JSON code samples inside prose are not treated as tool calls.
- The agent supports `edit_file` (exactly one match), `append_file`, and `delete_file`; storage bytes are cached for the workspace and updated on writes/deletes/project create/delete. Project listings use a SQLite index with one-time legacy import.
- Chat execution is limited by `MAX_CONCURRENT_CHATS` (default 4), with immediate 429 responses when busy. Production dependencies are exact-pinned; tests are kept in `requirements-dev.txt`.
- Preview and publish hosts must remain distinct from the application origin. Keep the app-origin authenticated preview route sandboxed; the separate preview and per-publish origins intentionally omit the CSP sandbox directive.


## Validation boundary

The test suite and static checks do not prove Docker network isolation, Nginx host routing, container escape resistance, package-registry egress controls, or the model's real tool-call behavior. Docker Engine, Nginx deployment, DNS/TLS, and a GPU/model endpoint were not available in the build/test environment. The repository is suitable for a **closed technical beta after its deployment prerequisites are configured and live-tested**, not a claim of public-production certification.

## Origin isolation

Qwen Studio sets no cookies (no accounts, no sessions). Origin isolation still matters because
generated project code must never share the application origin. Use a separate registered domain
for preview and published code rather than sibling subdomains of the studio's parent domain.
Production preflight and startup log a warning when the studio, preview, and publish origins
share the same registrable domain according to a built-in, partial set of common multi-label
public suffixes. This list is not a full Public Suffix List, so the warning is best-effort;
separate registered domains provide a stronger boundary for untrusted project code.


## Version 0.6.2 notes

- Restored `.env.example` to the release and added a dotfile-aware packaging precheck before deployment builds.
- Replaced the proxy-header heuristic with detection of forwarded headers that Uvicorn did not apply; system status exposes `proxy_headers`.
- Runtime and preflight warn when studio, preview, and publish hosts share the same last-two-label parent domain (origin-isolation guidance for generated project code).
- The agent's best-effort text fallback supports Qwen `<tool_call>` blocks, multiple sequential blocks, one complete fenced JSON object, and compatible bare JSON tool/name calls. Native vLLM tool parsing remains preferred.


## Version 0.7.2 notes

- The account system was removed entirely: registration, login, logout, sessions, user roles,
  password recovery, account operator scripts (`create_user.py`, `reset_password.py`,
  `revoke_sessions.py`), and the `/api/auth/*` endpoints no longer exist.
- The database uses a single-workspace schema. Upgrading from a multi-user database creates a
  file backup, merges all projects/chat/deployments/usage into the workspace, drops the
  credentials table, and strips `owner_id` from project metadata.
- The app binds to loopback by default; non-loopback binds are rejected unless
  `ALLOW_REMOTE_ACCESS=true` is set explicitly.
- Workspace-wide guard rails replaced per-user quotas (`MAX_PROJECTS`,
  `MAX_WORKSPACE_STORAGE_BYTES`).

## Version 0.7.0 notes

- Invalid Qwen text `<tool_call>` blocks now receive up to two retries and are sanitized before a terminal error is returned.
- Runtime and preflight now share `backend/domains.py` for registrable-domain comparisons; the built-in multi-label suffix list is explicitly partial.
