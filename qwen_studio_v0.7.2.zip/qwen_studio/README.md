# Qwen Studio v0.7.2 — self-hosted coding-agent beta (local weights mode)

Qwen Studio is a self-hostable starter for a Replit/Bolt-style AI coding workspace built around **Qwen2.5-Coder-14B-Instruct**. It does not alter or fine-tune the model weights.

Qwen Studio is a **single-user local workspace**: there are no accounts, no registration and no login. Install it, start it, and the studio opens directly on the workspace. It includes a model gateway, a tool-using coding agent, a private Docker execution runner, per-project preview containers, and local static publishing. Exposing it beyond loopback requires your GPU endpoint, three isolated hostnames, TLS, a dedicated worker, and an explicit network security setup (see `PRODUCTION_READINESS.md`).

## What is implemented

- **No accounts:** the studio opens directly on a single local workspace; there is no login, registration, logout, profile or password anywhere in the product. Loopback-only default binding, Origin and Fetch Metadata checks on browser mutations, and strict production secret checks remain.
- **Single local workspace:** one workspace per installation; SQLite project index backs list queries, with `.qwen-project.json` as the legacy import/fallback; project workspaces are separate directories. A safe migration converts an older multi-user database into the single-workspace schema after creating an automatic file backup.
- **AI coding agent:** OpenAI-compatible inference gateway; native function/tool calling plus JSON-text fallback; file listing/reading/writing/editing/appending/deleting; project-scoped context; bounded tool loop.
- **Usage limits:** daily chat, tool-call and deployment quotas; cached workspace storage accounting updated on file/project write and deletion; project-count limits; prompt/completion token accounting; bounded concurrent chat requests. These are machine-guard rails for a single local user, not tenant limits.
- **Editor:** project tree, file viewer/editor, save action, persisted project chat history.
- **Terminal (sandbox exec log):** a Terminal panel runs whitelisted sandbox profiles only (`auto`, `python_compile`, `pytest`, `npm_test`, `npm_build` — `auto` picks a build for npm projects, compileall otherwise) and shows the real exit code, stdout/stderr, and the isolation summary of each run. There is no arbitrary shell by design: project code never executes on the host or through the API.
- **Preview:** optional app preview in a disposable container per project and a separate preview hostname. The iframe uses `allow-scripts allow-same-origin` only because preview code is served from a distinct origin; never place previews on the studio hostname.
- **Execution:** fixed test/build profiles only; temporary project volume; no network for build/test/runtime execution; CPU, memory, process and filesystem limits. Preview startup is serialized to avoid concurrent container/volume races.
- **Publishing:** HTML projects can be published directly; package-based projects are built in an isolated runner and only static artifacts are published on the separate `PUBLISH_BASE_URL` / `PUBLISH_DOMAIN` hostname.
- **Local weights mode (0.7.1):** the studio can load Qwen safetensors weights from a local `models/` directory and run inference in-process on loopback, so no external model server is contacted (`LOCAL_INFERENCE=true`).
- **Model manager (0.7.2):** a Model button in the UI downloads the official `Qwen/Qwen2.5-Coder-14B-Instruct` checkpoint from the Hugging Face Hub on explicit user request only — resumable across connection drops (`.part` + HTTP Range, finished files are never re-downloaded), with progress (percent, speed, remaining, ETA), disk-space precheck, SHA-256 verification of every shard against the repository manifest, automatic `LOCAL_INFERENCE=true` binding after successful verification, an existing-checkpoint path override, retry, and delete-with-confirmation. The installers and startup never download weights.
- **Operational status:** UI displays whether the model endpoint and sandbox runner are reachable.

## Architecture

```text
Browser (loopback by default)
  |
  v
FastAPI application --------------------> OpenAI-compatible model endpoint
  | projects, quotas, DB                           (GPU host / vLLM / local weights)
  |
  +---- private runner API (shared internal Docker network)
              |
              +---- temporary execution containers (network=none)
              +---- one internal Docker network per live preview
              +---- static build + artifact copy to shared workspace volume
```

The application container does **not** receive the Docker socket. The runner does. In production, the runner refuses to start unless the Docker daemon advertises the gVisor `runsc` runtime, and every workload container is launched with `--runtime runsc`. This reduces kernel attack surface but does not remove the runner's host-level Docker authority: deploy it only on a dedicated disposable worker host with no unrelated workloads or secrets. The runner uses a fixed command allowlist and does not accept arbitrary shell commands from the public API. Preview containers use separate per-project internal Docker networks; the runner is not attached to those networks and fetches preview responses using `docker exec` into that project's container.

## Requirements

- Linux host recommended for a persistent deployment; Docker Engine and Docker Compose plugin.
- Python 3.11+ for running tests outside containers.
- A model to talk to. Either option works:
  - **Option A (external):** an independently hosted GPU inference endpoint compatible with the OpenAI Chat Completions API.
  - **Option B (bundled, default goal of this release):** the model weights themselves, placed in `models/` — see below. No external API or key needed.
- Enough GPU/CPU memory for the model/precision/quantization you select (see `docs/GPU_GUIDE.md` / `docs/CPU_GUIDE.md`).
- A domain and TLS certificates for a public deployment (not needed for a personal local run).

Qwen Studio does not include the Qwen weights in its repository or Docker images, and nothing
is downloaded at install time or on startup. Press **Model → Download model** in the UI to
fetch `Qwen/Qwen2.5-Coder-14B-Instruct` into `models/Qwen2.5-Coder-14B-Instruct/` on your
explicit request (resumable + SHA-256 verified), or copy the safetensors files there yourself
(one-time). The studio never modifies the weights and claims no ownership of the model
(see `LICENSES.md` — the checkpoint is Apache-2.0 by Alibaba/Qwen; the app stays MIT).

## Quick start with Docker Compose

### 1. Configure secrets

```bash
cp .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Put the generated value in `SANDBOX_RUNNER_TOKEN`. There is no `AUTH_SECRET`: Qwen Studio has no user accounts or session cookies. `SANDBOX_RUNNER_TOKEN` authenticates only the internal Backend-to-Runner connection. Never commit `.env`.

On Windows PowerShell, copy the environment file with:

```powershell
Copy-Item .env.example .env
```

### 2. Configure your model endpoint

Set:

- `MODEL_BASE_URL`: OpenAI-compatible base URL, normally ending in `/v1`.
- `MODEL_NAME`: the exact model name served by your inference server.
- `MODEL_API_KEY`: the API key configured on that server, or `EMPTY` if no key is required.

For public production, use a private HTTPS endpoint from your GPU host (or an explicitly secured private network endpoint). For local development only, you can use `http://host.docker.internal:8000/v1`; Compose adds the host-gateway mapping for Linux.

The preferred vLLM setup enables its Hermes tool parser and automatic tool choice. For the
Qwen2.5-Coder-14B-Instruct model, a typical command is:

```bash
vllm serve Qwen/Qwen2.5-Coder-14B-Instruct \
  --enable-auto-tool-choice \
  --tool-call-parser hermes
```

Check these flags against the exact vLLM version you install. The agent also includes a
best-effort text fallback for Qwen `<tool_call>...</tool_call>` blocks, one whole-message
fenced JSON object, and the legacy bare JSON format. This fallback is compatibility assistance,
not a replacement for native tool calling; use the native parser for production.

### Option B: Local weights mode — bundled inference, no external model server

If you do not want to run a separate model server, Qwen Studio can load the weights itself.
The backend starts a loopback-only, OpenAI-compatible inference service (`inference/`)
backed by Hugging Face `transformers`, and points the model gateway at it automatically.

Fast path on a personal machine (no Docker):

```bash
bash scripts/install.sh --with-model --cuda   # NVIDIA host: CUDA torch build + real verification
# or: bash scripts/install.sh --with-model --cpu    (CPU-only host)
# or: bash scripts/install.sh --with-model          (auto-detect; still verified for real)
python3 scripts/check_torch.py --cuda         # real torch.cuda.is_available() verification
bash scripts/start.sh                         # Windows: scripts\start.bat — stop with scripts/stop.sh
# then in the UI: press the Model button → Download model. The manager fetches the official
# checkpoint into models/Qwen2.5-Coder-14B-Instruct/ (resumable, SHA-256-verified, disk-checked)
# and enables LOCAL_INFERENCE automatically after verification succeeds.
```

The weights can also be placed manually (next section) — the Model window's **Verify files**
button or `scripts/verify_weights.py` then confirms completeness, and **Use this folder**
binds an existing checkpoint directory without re-downloading.

Manual path:

1. Install the model extra on the GPU host (PyTorch CUDA build first — uninstall any CPU
   build before switching so two conflicting torch versions never coexist; the pin is
   torch 2.6.0, the newest release on the official cu124 wheel index, valid for
   Python 3.11–3.13 on Windows and Linux):

```bash
pip uninstall -y torch
pip install "torch==2.6.0" --index-url https://download.pytorch.org/whl/cu124
pip install -r requirements-local-model.txt
python scripts/check_torch.py --cuda --check-model-extra   # must print PASS
```

2. Put the safetensors weights in `models/<LOCAL_MODEL_NAME>/` (default
   `models/Qwen2.5-Coder-14B-Instruct/`): `config.json`, all `*.safetensors` shards,
   `model.safetensors.index.json`, and the tokenizer files. See `models/README.md`.
   Files are loaded with `local_files_only=True`; nothing is fetched at runtime.

3. Set in `.env`:

```bash
LOCAL_INFERENCE=true
# optional overrides:
# LOCAL_MODEL_NAME=Qwen2.5-Coder-14B-Instruct
# LOCAL_MODEL_DIR=models/Qwen2.5-Coder-14B-Instruct
# LOCAL_INFERENCE_HOST=127.0.0.1   # loopback only; the engine has no auth
# LOCAL_INFERENCE_PORT=8100
# LOCAL_MODEL_DEVICE=auto          # auto | cuda | cpu
# LOCAL_MODEL_QUANTIZATION=auto    # auto | none | bf16 | fp16 | int8 | int4
# LOCAL_MODEL_MAX_CONTEXT_TOKENS=32768
```

`MODEL_BASE_URL` may stay on its placeholder: with `LOCAL_INFERENCE=true` the gateway
defaults to `http://127.0.0.1:8100/v1` (loopback only, no authentication, never exposed).
`/api/system/status` reports the engine state (`loaded`, `loading`, `device`,
`quantization`) in `model.local`.

Sizing guidance (operational estimates, not per-card guarantees): bf16 weights alone
are 14.7B params x 2 bytes ~= 29.4 GB (~27.4 GiB) BEFORE CUDA runtime, KV cache and
activation buffers. `auto` therefore measures FREE VRAM at startup: bf16 only when the
full plan fits (40GB+ cards at the default 32K context), otherwise 4-bit NF4 INT4
(~8 GiB weights — fits 24GB cards). 32GB cards: bf16 is conditional on free memory and
context, not guaranteed. 10-12GB cards: INT4 may require reducing
`LOCAL_MODEL_MAX_CONTEXT_TOKENS`. When even INT4 cannot fit, startup fails with a clear
error instead of silently OOM-ing. CPU-only hosts work but a 14B model is
impractically slow; prefer a GPU. Tool calling uses the Qwen chat template with the same
tool schemas, and native tool calls are returned to the agent in OpenAI format.

### 3. Configure gVisor and validate production settings

Production runner execution requires gVisor. Install gVisor `runsc` on the Linux Docker host using the official gVisor installation instructions, register it with Docker, then verify:

```bash
runsc --version
docker info --format '{{json .Runtimes}}'
```

The Docker runtime list must contain `runsc`. The runner will fail closed in production if `SANDBOX_CONTAINER_RUNTIME` is not `runsc` or if Docker does not report the runtime. `.env.example` sets `SANDBOX_CONTAINER_RUNTIME=runsc`; development can use `runc`. gVisor is defense in depth, not a substitute for a dedicated worker host, resource limits, patching, monitoring, and independent escape testing.

### 4. Validate production settings and deploy services

The sample `.env.example` deliberately contains placeholder domains and secrets. Replace them with real values before continuing. Run:

```bash
python3 deploy/preflight.py
```

It checks production settings without printing secret values. After services start, the workspace is ready to use immediately — no account setup step exists:

```bash
./deploy/deploy.sh
```

The script builds the isolated execution image, starts Compose services, and checks the local API health endpoint. It does not create DNS records, issue certificates, or configure Nginx for you.

The app port is bound to `127.0.0.1` by default: open `http://localhost:8080` and start creating projects immediately — no sign-in, no account creation. For a shared-host deployment, use `PUBLIC_BASE_URL` for the studio, `PREVIEW_BASE_URL` for project previews, and `PUBLISH_BASE_URL` / `PUBLISH_DOMAIN` for published sites; these must be three different HTTPS hostnames after DNS, reverse proxy, and TLS are configured. Use `/api/system/status` or the UI status indicator to verify the model and runner connections. Exposing the app beyond loopback is rejected at startup unless `ALLOW_REMOTE_ACCESS=true` is set explicitly, and even then it needs a properly configured TLS proxy/firewall — this product is designed for one local user, not for open hosting.

For a local test without a GPU, set `APP_ENV=development` and local HTTP `PUBLIC_BASE_URL` / `PREVIEW_BASE_URL` in `.env`; the web app and project flows start immediately, but AI requests will fail until `MODEL_BASE_URL` points to a live compatible endpoint — or until local weights mode is enabled (Option B). Do not use development mode on a public server.

### Running the app container with a GPU (local weights mode)

The `app-gpu` service (compose profile `gpu`) is the same app with CUDA torch preinstalled
and NVIDIA GPU passthrough. Weights are mounted read-only from `${LOCAL_MODEL_HOST_DIR:-./models}`
— they are never copied into the image:

```bash
docker compose --profile gpu build \
  --build-arg INSTALL_LOCAL_MODEL=true \
  --build-arg TORCH_INDEX_URL=https://download.pytorch.org/whl/cu124 app-gpu
docker compose --profile gpu up -d app-gpu
bash scripts/docker_check.sh app-gpu   # verify weights visibility + torch.cuda inside the container
docker compose --profile gpu exec app-gpu python scripts/check_torch.py --cuda   # real GPU check inside the container
```

The CPU/base `app` service stays the default (`docker compose up`). Verify the model files
are visible inside a running container with `bash scripts/docker_check.sh app`.

### Evaluate the model before launch

`MODEL_NAME` is a deployment setting; it can be changed to the exact model identifier served
by your OpenAI-compatible inference endpoint. `MODEL_MAX_TOKENS` caps the output budget per
model response; `0` (the shipped default) means unlimited — the reply may use the whole
remaining context window — while a positive value (256–131072) re-enables the cap. The model
endpoint must support OpenAI-style tool calling for the agent's native function-call path.

Before launch, run the 20-task agent evaluation against the configured `MODEL_BASE_URL`:

```bash
python scripts/eval_agent.py
```

The script runs 20 fixed coding tasks covering landing pages, a to-do app, repair of a
failing pytest suite, edits to existing files, and multi-file projects. The pytest-repair
tasks require the isolated sandbox runner.
This is an operational model evaluation, not part of the automated unit-test suite; it makes
real calls to the configured model and creates/removes temporary projects.

### Trusted reverse-proxy addresses and rate limits

Nginx must overwrite, not append, `X-Forwarded-For` with `$remote_addr` in every proxied
location. Compose gives `app-net` the default subnet `172.28.0.0/24` and gateway
`172.28.0.1`; when host Nginx connects to the app's published loopback port, the app sees
that gateway as the proxy source. Therefore the default `FORWARDED_ALLOW_IPS` is the single
trusted gateway IP `172.28.0.1`, never `*` or a broad Docker subnet. If you change
`APP_NET_SUBNET` or `APP_NET_GATEWAY`, set `FORWARDED_ALLOW_IPS` to the actual source IP seen
by the app. Confirm it with `docker inspect` or the startup diagnostic warning. Production
preflight accepts a specific IP or a CIDR with IPv4 prefix length /24 or narrower. Do not trust
the whole internet or a client-supplied forwarded header. The in-process limits are per app
process; use Redis before multi-replica scale.

The live smoke test also verifies that the studio opens without any login step: it checks
that `index.html` contains no account UI and that every former `/api/auth/*` endpoint now
answers 404. Proxy trust is checked separately through `/api/system/status` and its
`proxy_headers: "ok"` value. The in-process API rate limiter (still active against runaway
loops) is covered by the pytest suite rather than a live 429 probe.


### First real deployment checklist

- [ ] Run `python3 scripts/verify_pins.py` before `docker compose build`; a network-unavailable result is a warning, a confirmed missing pin is a failure.
- [ ] Complete `.env`, wildcard DNS, TLS, and Nginx configuration, then run `./deploy/deploy.sh`.
- [ ] Run the automated live smoke test as the first post-deployment verification:

  ```bash
  python3 scripts/smoke_test.py \
    --app-url https://studio.example.com \
    --preview-domain preview.example.com \
    --publish-domain sites.example.com
  ```

  Use `--skip-model` or `--skip-npm` only when intentionally postponing those checks. For local-only HTTP development, use `--insecure-local` with a localhost app URL. It resolves preview/publish hostnames through normal DNS and clearly identifies missing wildcard records.
- [ ] Open the studio, create a React project through the agent, and ask it to build a working Vite/React application.
- [ ] Run the project's `npm_build` check, then build and publish the project.
- [ ] Open both the isolated preview URL and the published site URL in a browser; verify assets and module scripts load.
- [ ] Open `/api/system/status` and confirm `proxy_headers` is `ok`.
- [ ] Run `python3 scripts/eval_agent.py` against the deployed model and review all five task results.

The smoke script is an operator-run live check and is not part of the normal pytest suite. Its unit tests use a local fake HTTP server; passing them does not prove Docker, Nginx, Verdaccio, DNS/TLS, or the model works on the target server.

Do not treat a successful local pytest run as a substitute for this live checklist. Docker,
Nginx, Verdaccio, wildcard DNS/TLS, the real proxy source IP observed inside the app container,
and GPU/model behavior must be verified on the target host.

### 5. Dependency installation for JavaScript projects

By default, `SANDBOX_ALLOW_NETWORK_INSTALL=false`; npm dependency installation is disabled.
Production can optionally enable dependency installation only through the internal Verdaccio
proxy. Set `SANDBOX_ALLOW_NETWORK_INSTALL=true` and
`SANDBOX_NPM_REGISTRY_URL=http://npm-proxy:4873`, then start the proxy profile:

```bash
docker compose --profile npm-proxy up -d npm-proxy
```

The `qwen_npm_install` Docker network is internal. Only the Verdaccio proxy and the short-lived
npm install container join it; the Runner, app, build, test, and preview containers do not.
The proxy itself also joins a separate egress network to fetch upstream packages from npmjs.
The install container uses `npm ci --ignore-scripts`. If a project declares dependencies but
has no `package-lock.json`, the runner first generates one with `npm install --package-lock-only
--ignore-scripts --no-audit --no-fund` against the internal proxy, then runs `npm ci`. Both
steps happen inside a temporary isolated volume; the generated lockfile is discarded with that
volume and is never copied back to the user's project. Projects with no declared dependencies
skip installation and the `node_modules` check completely. Packages requiring lifecycle scripts
or native build hooks may not work because scripts are deliberately disabled. Keep the feature
off unless you intentionally enable the npm proxy profile.

## Local development without Docker

You can run project/editor/static-preview tests without Docker:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements-dev.txt
```

The production image installs only the exact-pinned `requirements.txt`; pytest is isolated in `requirements-dev.txt`.

Set `APP_ENV=development`, local HTTP app/preview URLs, and a local workspace, then run:

```bash
uvicorn backend.app:app --host 127.0.0.1 --port 8080
```

The Docker sandbox runner will show as unavailable unless separately configured. Do not turn local execution of untrusted user code on as a substitute for a real sandbox.

## Public-domain and reverse-proxy setup

For a real hosted instance, use two separate origins:

- Application: `https://studio.example.com`
- Preview base: `https://preview.example.com`; create wildcard DNS `*.preview.example.com` pointing to the reverse proxy.
- Published sites: `https://site-<32 hex>.sites.example.com/`; configure wildcard DNS and TLS for `*.sites.example.com` (plus the bare apex certificate, which returns 404).

Set in `.env`:

```env
APP_ENV=production
APP_BIND_ADDRESS=127.0.0.1
ALLOW_REMOTE_ACCESS=false
SANDBOX_RUNNER_TOKEN=<random 32+ char value>
PUBLIC_BASE_URL=https://studio.example.com
PREVIEW_BASE_URL=https://preview.example.com
PREVIEW_DOMAIN=preview.example.com
PUBLISH_BASE_URL=https://sites.example.com
PUBLISH_DOMAIN=sites.example.com
SANDBOX_ALLOW_NETWORK_INSTALL=false
```

Configure the reverse proxy to preserve the incoming `Host` header for the app host, `*.preview.example.com`, and `*.sites.example.com`, forward to the application port, and terminate TLS with certificates covering both wildcard domains. Configure wildcard DNS for both preview and publish domains. The app derives a project preview URL as `<project-id>.preview.example.com` and each published deployment URL as `https://<slug>.sites.example.com/`. Every published deployment therefore has its own browser origin; path-based deployment URLs are not served. The bare `sites.example.com` host returns 404 and serves no UI or API. Preview URLs and published URLs are capability links: anyone who receives one can view that project's content. The preview and each publish origin are separate from the application origin so generated project code never shares the origin that serves the studio UI and API.

A maintained Nginx configuration template is provided at [`deploy/nginx-qwen-studio.conf`](deploy/nginx-qwen-studio.conf). It includes an HTTP-to-HTTPS redirect, wildcard preview host routing, API rate limiting, proxy headers, and preview WebSocket upgrade forwarding. Install it in the Nginx `http {}` context and replace the example hostnames and certificate paths.

Use certificates that actually cover `studio.example.com`, `*.preview.example.com`, and `*.sites.example.com` (the publish certificate should also cover the bare `sites.example.com` apex for its 404 TLS server); generic example certificate paths are not enough. Do not expose the runner port publicly.

## Backups and recovery

Run `./deploy/backup.sh` during maintenance. It briefly stops the app and runner so the SQLite database, project files, and published artifacts can be archived consistently; it also copies `.env` into the backup folder with restrictive permissions. Store backups encrypted and off the server. `./deploy/restore.sh <archive>` replaces the entire named workspace volume and requires an explicit confirmation. Test restoration before relying on backups.

## Model evaluation

Before enabling public access, run `python scripts/eval_agent.py` against the configured inference endpoint. The script runs 20 fixed coding tasks (editing, debugging, tests, safety, Arabic, honesty, loop resistance) and reports pass/fail; use `--list`, `--only TEXT`, and `--json-out FILE` to compare runs before and after a change; it is deliberately excluded from automated tests because it requires a live model endpoint. Configure `MODEL_NAME`, `MODEL_BASE_URL`, and `MODEL_MAX_TOKENS` per deployment.

## Configuration

Copy `.env.example` to `.env` and set the deployment-specific values. Configuration keys read by the application, runner, and operator scripts include: `APP_ENV`, `SANDBOX_RUNNER_TOKEN`, `APP_BIND_ADDRESS`, `ALLOW_REMOTE_ACCESS`, `APP_PORT`, `FORWARDED_ALLOW_IPS`, `APP_NET_SUBNET`, `APP_NET_GATEWAY`, `MODEL_BASE_URL`, `MODEL_NAME`, `MODEL_API_KEY`, `MODEL_MAX_TOKENS`, `MODEL_TEMPERATURE`, `MODEL_CONTEXT_CHAR_BUDGET`, `MAX_CONCURRENT_CHATS`, `MAX_TOOL_TURNS`, `MAX_FILE_BYTES`, `MAX_PROJECTS`, `MAX_DAILY_CHAT_REQUESTS`, `MAX_DAILY_TOOL_CALLS`, `MAX_DAILY_DEPLOYMENTS`, `MAX_WORKSPACE_STORAGE_BYTES`, `DATABASE_PATH`, `WORKSPACE_DIR`, `PUBLISH_DIR`, `PUBLIC_BASE_URL`, `PREVIEW_BASE_URL`, `PREVIEW_DOMAIN`, `PUBLISH_BASE_URL`, `PUBLISH_DOMAIN`, `SANDBOX_RUNNER_URL`, `SANDBOX_VOLUME_NAME`, `SANDBOX_ALLOW_NETWORK_INSTALL`, `SANDBOX_NPM_REGISTRY_URL`, `SANDBOX_MEMORY_LIMIT`, `SANDBOX_PIDS_LIMIT`, `SANDBOX_CPU_LIMIT`, `SANDBOX_TIMEOUT_SECONDS`, `SANDBOX_MAX_OUTPUT_BYTES`, and `SANDBOX_INSTALL_MEMORY_LIMIT`, `SANDBOX_IMAGE`, `SANDBOX_CONTAINER_RUNTIME`, `SANDBOX_MAX_ACTIVE_PREVIEWS`, `SANDBOX_MAX_CONCURRENT_RUNS`, `SANDBOX_NPM_NETWORK`, and `SANDBOX_SHARED_VOLUME_NAME`. Local weights inference adds `LOCAL_INFERENCE`, `LOCAL_MODEL_NAME`, `LOCAL_MODEL_DIR`, `LOCAL_INFERENCE_HOST`, `LOCAL_INFERENCE_PORT`, `LOCAL_MODEL_DEVICE`, `LOCAL_MODEL_QUANTIZATION`, and `LOCAL_MODEL_MAX_CONTEXT_TOKENS`, plus the model downloader's `QWEN_MODEL_REPO_ID` (override the downloaded repository; default `Qwen/Qwen2.5-Coder-14B-Instruct`; the official Hub endpoint can also be mirrored via `HF_ENDPOINT`) (see "Option B: Local weights mode"). Keep secrets out of source control.

## API routes

- `GET /`, `GET /health`
- `GET /api/usage`, `GET /api/system/status` (includes `proxy_headers: "ok" | "suspect"`)
- `GET /api/model/status`, `GET /api/model/remote`, `POST /api/model/download`, `POST /api/model/cancel`, `POST /api/model/verify`, `POST /api/model/path`, `POST /api/model/delete` (local model download / verify / bind / delete — user-triggered only)

There are no account endpoints: `/api/auth/*` was removed entirely and answers 404.
- `GET /api/projects`, `POST /api/projects`, `GET /api/projects/{project_id}`, `DELETE /api/projects/{project_id}`
- `GET /api/projects/{project_id}/files`, `PUT /api/projects/{project_id}/file`, `GET /api/projects/{project_id}/file`
- `GET /api/projects/{project_id}/preview`, `GET /api/projects/{project_id}/preview-url`, `GET /api/projects/{project_id}/preview/status`, `GET /api/projects/{project_id}/preview/{relative_path:path}`
- `POST /api/projects/{project_id}/preview/start`, `POST /api/projects/{project_id}/preview/restart`, `POST /api/projects/{project_id}/preview/stop`
- `POST /api/projects/{project_id}/run` with `python_compile`, `pytest`, `npm_test`, or `npm_build`
- `POST /api/projects/{project_id}/publish`, `GET /api/deployments`, `GET /api/projects/{project_id}/messages`
- `POST /api/chat`

Published sites use isolated origins `https://<site-slug>.<PUBLISH_DOMAIN>/`. Path-based publishing is not supported; the bare publish domain returns 404. The runner's internal API is authenticated with `SANDBOX_RUNNER_TOKEN` and should only be reachable over its private Compose network.

## Limits and important constraints

- Guard rails are controlled through `.env.example` and every quota ships **disabled by default (`0` = unlimited)**: unlimited projects, AI requests/day, tool calls/day, publishes/day, workspace storage, and file size — the operator owns the local machine and the model context window is the physical limit. Positive values re-enable each guard (for example `MAX_PROJECTS=100`, `MAX_DAILY_CHAT_REQUESTS=40`) to protect against runaway agent loops or accidental disk fills.
- Rate limiting is in-memory and per application process. `/api/chat` has a non-waiting concurrency cap (`MAX_CONCURRENT_CHATS`, default `0` = effectively unlimited with a 256-slot safety ceiling); for multiple app replicas, use shared Redis rate limits and distributed chat slots.
- SQLite is suitable for a single small instance / prototype. Before multi-instance production, migrate to PostgreSQL and configure backups, migrations, and restore tests.
- Published sites are static files on this server, not Vercel/Netlify/Cloudflare deployments. No external hosting provider or CDN is connected.
- Vite/React build output such as `dist/index.html` is supported if the project has a working `build` script. Static HTML projects are supported directly. Next.js requires an explicit static export producing `out/index.html`; server-rendered Next.js projects are not hosted by this static publisher.
- Live preview starts a project process in a constrained container. It has no external network. WebSocket-based hot-module reload may not pass through the HTTP-only preview proxy; refresh the page if HMR does not update.
- Qwen Studio has **no account system by design**: no registration, login, roles, password recovery, email verification, or user profiles exist anywhere in the codebase. Billing/subscriptions, payment processing, organization/team features, OAuth, admin UI, external cloud deploy providers, custom domains, and usage-based model billing are also **not implemented**. Quotas here are limits, not a payment system.

## Security: do not skip this

This code includes important guardrails, but it is not a security certification. Qwen Studio is designed as a single-user local application; it is not a hardened public multi-tenant SaaS, and removing the login wall means network-level controls are the boundary.

1. **Docker socket risk:** the Runner mounts `/var/run/docker.sock`. Access to this socket is effectively privileged access to the Docker host. Run the Runner on a dedicated disposable VM/worker machine with no production secrets or important host data. For a commercial public service, replace this design with remote sandbox workers using gVisor, Kata Containers, or microVMs, with a control plane that does not expose the host Docker socket to the web app.
2. **Runner token:** keep it long and random, and never put it in the frontend. Keep Runner on the private network.
3. **Network exposure:** keep `APP_BIND_ADDRESS=127.0.0.1` and `ALLOW_REMOTE_ACCESS=false`. Any remote exposure requires a TLS-authenticating reverse proxy plus server-level access control, because the app itself has no login wall: anyone who can reach the port can use the workspace.
4. **Runner limits:** build/test/preview containers have resource caps, dropped Linux capabilities, read-only root filesystems, no-new-privileges, and per-project isolated volumes/networks. These controls reduce risk; they do not guarantee containment of a kernel/container-runtime exploit.
5. **Network install:** enabling npm downloads increases attack surface. Keep disabled unless needed; restrict outbound registries using firewall policy on dedicated workers.
6. **Shared exposure:** if you intentionally host the studio for more than one person, add an authenticating reverse proxy (SSO/TLS client certificates), audit logs, privacy/retention policy, and abuse reporting. The application itself provides no multi-user controls.
7. **Scale:** use PostgreSQL, Redis, object storage, background queues, concurrency limits, metrics, logs, backups, and tested incident response before scaling.
8. **Security assessment:** perform threat modeling, container escape testing, dependency scanning, and an independent penetration test before accepting untrusted projects.

## Tests

```bash
python -m pytest -q
node --check frontend/app.js
```

The automated tests cover the no-login workspace flows, the legacy multi-user database migration (with backup), file/path protections, quota-facing routes, runner input validation, and the preview-proxy helper syntax. They do not exercise Docker Engine, a real inference endpoint, browser wildcard DNS, TLS, model tool-call quality, or production isolation.

## Build validation report

See [`VALIDATION.md`](VALIDATION.md) for automated checks and unverified infrastructure items. Read [`PRODUCTION_READINESS.md`](PRODUCTION_READINESS.md) before exposing the studio beyond loopback.

### Release archive packaging and dotfiles

Use `./scripts/make_release.sh` to create `qwen_studio_vX.Y.Z.zip` next to the repository
(or set `OUTPUT_DIR` to choose another directory). It stages a clean copy, validates it with
`scripts/check_release.py`, and prints the final archive contents and size. The ZIP is kept
outside the repository tree so it cannot be mistaken for a nested release artifact.
Release archives must include repository dotfiles, especially `.env.example`, `.gitignore`, and
`.dockerignore`. The release script uses `git archive` for a clean committed Git checkout or a
`zip -r` fallback with runtime-artifact exclusions. Do not use file-selection tools or GUI archive
actions that silently omit hidden files. The deploy script also runs `scripts/check_release.py`
before building and fails if a required dotfile is missing or runtime data is present.

### Preview/publish origin isolation

Qwen Studio sets no cookies, so there is no session-cookie configuration. What remains important
is browser-origin isolation between the studio and generated code: use a **separate registered
domain** for previews and published sites, not merely sibling subdomains of the studio's parent
domain. For example, host the studio at `studio.example.com`, previews under
`*.preview.example.net`, and published sites under `*.sites.example.org`. The runtime and
production preflight emit a non-fatal warning when the three configured origins share the same
registrable parent domain. The application uses a small built-in set of common multi-label public
suffixes (including `com.dz`, `co.uk`, and `com.au`) to avoid treating those suffixes themselves
as registrable domains. This list is partial and is not a full Public Suffix List; treat its
warning as best-effort only. Separate registered domains remain the recommended boundary for
untrusted code.

### Legacy data migration (0.7.0/0.7.1 multi-user databases)

On first start after upgrading, the app detects an old multi-user SQLite schema, creates a
timestamped file backup next to the database (`qwen_studio.sqlite3.backup-<UTC timestamp>`),
then in one transaction rewrites the tables into the single-workspace schema: all projects,
chat history, deployments, and usage counters are kept and merged; the `users` table
(credentials) is dropped; and `owner_id` fields are removed from `.qwen-project.json` files.
If the migration fails mid-way it rolls back completely and the original database stays
untouched. Multi-user installations merge every account's projects into the one local
workspace; restore from the automatic backup if that is not what you want.


## Open-source project

This repository is licensed under the MIT License; see `LICENSE`. The license applies to this repository's code only, not to Qwen model weights, third-party dependencies, or other separately licensed assets. Qwen Studio is an **independent open-source project: it is not affiliated with, endorsed by, or officially connected to Alibaba Group or the Qwen team in any way** — the Qwen2.5-Coder-14B-Instruct weights remain the property of their original authors and are used and redistributed (when the operator chooses to download them) under their own Apache-2.0 license. See `CONTRIBUTING.md` for development and pull-request requirements, `CODE_OF_CONDUCT.md` for community expectations, and `SECURITY.md` for private vulnerability reporting and critical sandbox warnings. Model serving and license separation are documented in `docs/MODEL_DEPLOYMENT.md`.

GitHub Actions runs the automated verification suite on pushes and pull requests. Before making a repository public, review dependency and asset licenses, inspect the full Git history for secrets, configure maintainers and private security reporting, and complete `OPEN_SOURCE_RELEASE_CHECKLIST.md`.
