# Contributor Covenant Code of Conduct

## Our pledge

We pledge to make participation in this project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

## Our standards

Examples of behavior that contributes to a positive environment include being respectful, giving and accepting constructive feedback, focusing on what is best for the community, and showing empathy.

Examples of unacceptable behavior include harassment, insults, personal attacks, discriminatory language, publishing private information without permission, and sustained disruptive conduct.

## Enforcement

Project maintainers are responsible for clarifying and enforcing this standard and may remove, edit, or reject contributions that violate it. Report conduct issues privately to the repository maintainer using the contact configured in the hosting platform. Maintainers will review reports and may take action they consider appropriate.

This policy applies within project spaces and when an individual is officially representing the project.
