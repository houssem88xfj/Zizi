# Licenses & Attribution

This document records the licenses of everything shipped in or used by Qwen Studio.
It is an informational summary, **not legal advice** — verify each component's license
text in the upstream repository before redistributing.

## 1) Qwen Studio application code

- License: **MIT** — see `LICENSE` in the project root.
- The studio code is an **independent product** — it is not affiliated with,
  endorsed by, or officially connected to Alibaba Group or the Qwen team.
- It does **not** contain, modify, or claim ownership of any Qwen model weights,
  tokenizer, or training assets.

## 2) Qwen2.5-Coder-14B-Instruct (the bundled/referenced model)

- Upstream: https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct (Alibaba/Qwen team)
- License: **Apache License 2.0** — verified against the official model repository
  LICENSE file and the official Qwen2.5-Coder release blog, which states the Coder
  series 0.5B/1.5B/7B/14B/32B are Apache-2.0 (only the 3B variant uses the Qwen
  Research license).
- Redistribution terms that apply when you ship the weights (including inside a
  download bundle): keep the Apache-2.0 license text and copyright notices
  ("Copyright 2024 The Qwen Team, Alibaba Group"), retain NOTICE files if present,
  and state significant changes. This project ships the weights **unmodified**.
- **Practical rule for this repository:** the weights are *not* committed to git and
  *not* baked into Docker images (`.dockerignore` excludes `*.safetensors`). They live
  in `models/` or a mounted volume. If you build a downloadable bundle that includes
  them, include the model's LICENSE file next to the weight files.

## 3) Python dependencies

| Component | License | Role |
| --- | --- | --- |
| PyTorch | BSD-style (PyTorch license) | tensor compute / inference |
| transformers | Apache 2.0 | model loading, chat template |
| accelerate | Apache 2.0 | device map / large model loading |
| safetensors | Apache 2.0 | weight file format |
| bitsandbytes | Apache 2.0 | int8 / nf4 4-bit quantization |
| sentencepiece | Apache 2.0 | tokenizer support |
| FastAPI | MIT | HTTP API |
| Uvicorn | BSD 3-Clause | ASGI server |
| Pydantic | MIT | request validation |
| httpx | BSD 3-Clause | sandbox-runner client |
| requests | Apache 2.0 | model downloader (HF Hub resolve/Range requests) |
| huggingface_hub | Apache 2.0 | model manifest via the official Hub API |
| python-dotenv | BSD 3-Clause | .env loading |
| openai (python client) | Apache 2.0 | OpenAI-compatible gateway client |

Exact pinned versions are in `requirements.txt` / `requirements-local-model.txt`;
each package's own license text ships inside its wheel (`*.dist-info/LICENSE`).

## 4) Infrastructure components

| Component | License | Role |
| --- | --- | --- |
| Docker Engine / Compose | Apache 2.0 | container runtime (sandbox runner) |
| gVisor (runsc) | Apache 2.0 | userspace sandbox for project execution |
| Verdaccio (optional npm proxy) | MIT | internal npm registry |
| Nginx (deploy configs) | 2-clause BSD | reverse proxy / static hosting |

## 5) Frontend assets

The frontend (`frontend/`) uses system font stacks and inline SVG-free CSS only;
no third-party JavaScript libraries are bundled.

## 6) Attribution requirements summary

1. Keep this file, `LICENSE`, and the model LICENSE file intact in any redistribution.
2. Do not remove the Qwen/Alibaba attribution from model metadata files.
3. If you modify the studio code, state that it is modified and keep the MIT notice.
4. If you redistribute the weights, comply with Apache-2.0 §4 (notice files) and §6
   (trademarks: "Qwen" name/mark ownership stays with Alibaba).
