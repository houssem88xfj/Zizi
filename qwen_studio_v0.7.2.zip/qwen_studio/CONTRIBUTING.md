# Contributing to Qwen Studio

Thanks for considering a contribution. This project is a self-hosted coding-agent workspace; changes that affect authentication, project isolation, model tool calls, execution, preview, or publishing require particular care.

## Before you start

1. Open an issue describing the bug or proposed change before large changes.
2. Check existing issues and the `README.md`, `PRODUCTION_READINESS.md`, and `docs/RUNBOOK.md`.
3. Do not include secrets, private user projects, model weights, generated credentials, or production data in issues or pull requests.
4. For security vulnerabilities, do not open a public issue. Follow `SECURITY.md`.

## Development

- Python 3.11 or newer.
- Install dependencies with `python -m pip install -r requirements.txt -r requirements-dev.txt`.
- Copy `.env.example` to `.env` and use development-only credentials.
- Run the app using the commands in `README.md`.

## Pull requests

- Keep changes focused and explain the user-visible impact.
- Add or update tests for behavior changes, especially authorization and isolation boundaries.
- Update documentation and `.env.example` when configuration changes.
- Never weaken production fail-closed checks to make tests pass.
- Run `bash scripts/verify_all.sh` and include the result in the PR.
- Do not claim a Docker, gVisor, GPU, DNS, TLS, or provider integration was tested unless it was actually tested in a matching environment.

## Review expectations

A maintainer may request threat-model notes, test evidence, compatibility details, or a smaller patch. Contributions are reviewed; submitting a PR does not guarantee acceptance.
