const state = { projects: [], project: null, selectedFile: null, history: [], busy: false, busyTerminal: false, previewActive: false, previewUrl: null };
const $ = (id) => document.getElementById(id);
const api = async (url, options = {}) => {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status})`);
  return payload;
};
function toast(message) {
  const node = $('toast'); node.textContent = message; node.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.remove('show'), 3200);
}
function setProjectControls(enabled) {
  ['refresh-preview','refresh-files','save-file','chat-input','send-button','open-preview','sandbox-check','publish-project','start-preview','stop-preview','delete-project','terminal-run','terminal-command'].forEach(id => $(id).disabled = !enabled);
}
async function checkHealth() {
  try {
    const result = await api('/health');
    $('connection-dot').classList.add('online');
    $('connection-label').textContent = `API online · ${result.version}`;
  } catch { $('connection-label').textContent = 'API offline'; }
}
async function loadUsage() {
  const usage = await api('/api/usage');
  $('usage-pill').hidden = false;
  const chatLimit = usage.limits.chat_requests, toolLimit = usage.limits.tool_calls;
  $('usage-pill').textContent = (chatLimit != null && toolLimit != null)
    ? `AI ${usage.chat_requests}/${chatLimit} · Tools ${usage.tool_calls}/${toolLimit}`
    : `AI ${usage.chat_requests} · Tools ${usage.tool_calls} · unlimited`;
}
async function initializeWorkspaceApp() {
  // One failed boot call must not abort the rest: each panel loads independently.
  for (const step of [loadUsage, () => loadProjects(true), loadDeployments, checkSystemStatus]) {
    try { await step(); } catch (error) { toast(error.message); }
  }
  startSystemStatusPolling();
}
let modelStatusTimer = null;
let systemStatusTimer = null;
function startSystemStatusPolling() {
  // Model/sandbox connectivity can recover (or degrade) while the tab is open;
  // a slow poll keeps the header truthful without hammering the API.
  if (systemStatusTimer) clearInterval(systemStatusTimer);
  systemStatusTimer = setInterval(() => { checkSystemStatus(); }, 30000);
}
function stopStatusTimers() {
  if (systemStatusTimer) { clearInterval(systemStatusTimer); systemStatusTimer = null; }
  if (modelStatusTimer) { clearTimeout(modelStatusTimer); modelStatusTimer = null; }
}
function describeLocalModel(local) {
  if (!local) return null;
  if (local.error) return { state: 'error', text: `Model error: ${local.error}` };
  if (local.loaded) return { state: 'ok', text: `${local.model} · ${local.device} · ${local.quantization}` };
  if (local.loading) return { state: 'loading', text: `Loading weights (${local.model})…` };
  if (local.weights_present === false) return { state: 'error', text: `No weights in ${local.model_dir || 'models/'} — upload safetensors files` };
  return { state: 'loading', text: 'Local model initializing…' };
}
function renderModelPill(info) {
  const pill = $('model-status-pill');
  if (!pill) return;
  if (!info) { pill.hidden = true; pill.className = 'model-pill'; return; }
  pill.hidden = false;
  pill.textContent = info.text;
  pill.className = `model-pill model-${info.state}`;
}
async function pollLocalModelStatus() {
  try {
    const status = await api('/api/system/status');
    const info = describeLocalModel(status.model?.local);
    renderModelPill(info);
    if (info && (info.state === 'ok' || info.state === 'error')) {
      if (info.state === 'ok') {
        $('connection-label').textContent = `Model connected · ${info.text}`;
        $('connection-dot').classList.add('online');
        const chatPill = $('chat-model-pill');
        if (chatPill) chatPill.textContent = status.model?.name || 'Qwen Coder';
      }
      if (modelStatusTimer) { clearTimeout(modelStatusTimer); modelStatusTimer = null; }
      return;
    }
  } catch { /* transient network errors are retried on the next tick */ }
  modelStatusTimer = setTimeout(pollLocalModelStatus, 3000);
}
async function checkSystemStatus() {
  try {
    const status = await api('/api/system/status');
    const localInfo = describeLocalModel(status.model?.local);
    renderModelPill(localInfo);
    const m = status.model?.connected ? 'Model connected' : 'Model not connected';
    const s = status.sandbox?.connected ? 'Sandbox ready' : 'Sandbox offline';
    $('connection-label').textContent = `${m} · ${s}`;
    $('connection-dot').classList.toggle('online', !!status.model?.connected);
    const proxyBanner = $('proxy-warning-banner');
    if (proxyBanner) proxyBanner.hidden = status.proxy_headers !== 'suspect';
    if (localInfo && (localInfo.state === 'loading')) {
      if (modelStatusTimer) clearTimeout(modelStatusTimer);
      modelStatusTimer = setTimeout(pollLocalModelStatus, 3000);
    }
  } catch { /* API health is still shown separately. */ }
}
async function loadProjects(selectFirst = false) {
  const result = await api('/api/projects'); state.projects = result.projects || [];
  const list = $('projects-list'); list.replaceChildren();
  if (!state.projects.length) {
    const empty = document.createElement('div'); empty.className = 'muted small'; empty.textContent = 'No projects yet.'; list.append(empty);
  }
  for (const project of state.projects) {
    const button = document.createElement('button'); button.className = 'project-item' + (state.project?.id === project.id ? ' active' : '');
    button.innerHTML = '<span class="project-icon">▧</span><span class="project-label"></span>';
    button.querySelector('.project-label').textContent = project.name;
    button.addEventListener('click', () => selectProject(project.id)); list.append(button);
  }
  if (selectFirst && state.projects.length) await selectProject(state.projects[0].id);
}
async function loadDeployments() {
  try {
    const result = await api('/api/deployments');
    const list = $('deployments-list'); list.replaceChildren();
    if (!result.deployments?.length) { const empty = document.createElement('div'); empty.className = 'muted small'; empty.textContent = 'No deployments yet.'; list.append(empty); return; }
    for (const deployment of result.deployments.slice(0, 12)) {
      const link = document.createElement('a'); link.className = 'deployment-item';
      // Published sites are served on <slug>.<PUBLISH_DOMAIN> subdomains; the app origin has no legacy published path.
      link.href = deployment.url || deployment.slug;
      link.target = '_blank'; link.rel = 'noopener noreferrer';
      link.textContent = deployment.slug; list.append(link);
    }
  } catch (error) { toast(error.message); }
}
async function loadChatHistory() {
  if (!state.project) return;
  try {
    const result = await api(`/api/projects/${state.project.id}/messages`);
    $('chat-messages').replaceChildren();
    if (!result.messages?.length) {
      addMessage('assistant', `Project loaded. I can inspect and modify files in “${state.project.name}”. What should we build?`);
      return;
    }
    for (const message of result.messages) addMessage(message.role === 'user' ? 'user' : 'assistant', message.content);
  } catch (error) { toast(error.message); }
}
async function selectProject(id) {
  try {
    const previousId = state.project?.id;
    if (previousId && previousId !== id && state.previewActive) {
      try { await api(`/api/projects/${previousId}/preview/stop`, { method: 'POST', body: '{}' }); } catch { /* Best-effort cleanup. */ }
    }
    state.previewActive = false;
    state.project = await api(`/api/projects/${id}`); state.history = []; state.selectedFile = null;
    $('project-name').textContent = state.project.name;
    $('project-description').textContent = state.project.description || 'No description';
    $('chat-messages').replaceChildren();
    setProjectControls(true); $('stop-preview').disabled = true; $('editor-title').textContent = 'Editor'; $('file-editor').value = ''; $('file-editor').disabled = true;
    $('editor-status').textContent = 'No file selected'; await loadProjects(false); await loadFiles(); await loadChatHistory(); await updatePreviewStatus(); await refreshPreview();
  } catch (error) { toast(error.message); }
}
async function loadFiles(path = '.') {
  if (!state.project) return;
  try {
    const data = await api(`/api/projects/${state.project.id}/files?path=${encodeURIComponent(path)}`);
    const list = $('file-list'); list.replaceChildren();
    for (const item of data.items) {
      const row = document.createElement('button'); row.className = 'file-row' + (item.type === 'directory' ? ' directory' : '') + (state.selectedFile === item.path ? ' selected' : '');
      const icon = document.createElement('span'); icon.className = 'file-kind'; icon.textContent = item.type === 'directory' ? '▸' : '·';
      const name = document.createElement('span'); name.textContent = item.name;
      row.append(icon, name);
      row.addEventListener('click', () => item.type === 'directory' ? loadFiles(item.path) : openFile(item.path));
      list.append(row);
    }
    if (!data.items.length) { const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'This folder is empty.'; list.append(empty); }
    if (path !== '.') {
      const up = document.createElement('button'); up.className = 'file-row'; up.textContent = '← Project root'; up.addEventListener('click', () => loadFiles('.')); list.prepend(up);
    }
  } catch (error) { toast(error.message); }
}
async function openFile(path) {
  try {
    const data = await api(`/api/projects/${state.project.id}/file?path=${encodeURIComponent(path)}`);
    state.selectedFile = path; $('editor-title').textContent = path; $('file-editor').value = data.content;
    $('file-editor').disabled = false; $('save-file').disabled = false; $('editor-status').textContent = `${new Blob([data.content]).size} bytes`;
    await loadFiles(path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '.');
  } catch (error) { toast(error.message); }
}
async function saveFile() {
  if (!state.project || !state.selectedFile) return;
  try {
    await api(`/api/projects/${state.project.id}/file`, { method: 'PUT', body: JSON.stringify({ path: state.selectedFile, content: $('file-editor').value }) });
    $('editor-status').textContent = 'Saved'; toast('File saved'); await (state.previewActive ? restartLivePreview() : refreshPreview()); await loadFiles(state.selectedFile.includes('/') ? state.selectedFile.slice(0, state.selectedFile.lastIndexOf('/')) : '.');
  } catch (error) { toast(error.message); }
}
async function updatePreviewStatus() {
  if (!state.project) return;
  try {
    const result = await api(`/api/projects/${state.project.id}/preview/status`);
    state.previewActive = !!result.running;
    $('stop-preview').disabled = !state.previewActive;
  } catch {
    state.previewActive = false; $('stop-preview').disabled = true;
  }
}
async function restartLivePreview() {
  if (!state.project || !state.previewActive) return refreshPreview();
  try {
    const result = await api(`/api/projects/${state.project.id}/preview/restart`, { method: 'POST', body: '{}' });
    const frame = $('preview-frame'); frame.hidden = false; $('preview-empty').hidden = true;
    frame.src = `${result.preview_url}?t=${Date.now()}`; $('preview-status').textContent = 'Preview refreshed';
    state.previewUrl = result.preview_url;
  } catch (error) { toast(`Preview restart failed: ${error.message}`); await updatePreviewStatus(); await refreshPreview(); }
}
async function refreshPreview() {
  if (!state.project) return;
  const frame = $('preview-frame'); frame.hidden = false; $('preview-empty').hidden = true;
  try {
    const data = await api(`/api/projects/${state.project.id}/preview-url`);
    const url = `${data.preview_url}?t=${Date.now()}`;
    frame.src = url; $('preview-status').textContent = 'Project preview';
    state.previewUrl = data.preview_url;
  } catch (error) { toast(error.message); }
}
function addMessage(role, text) {
  const holder = $('chat-messages');
  const node = document.createElement('div'); node.className = `message ${role}`; node.textContent = text;
  holder.append(node); holder.scrollTop = holder.scrollHeight; return node;
}
async function sendMessage(event) {
  event?.preventDefault();
  const input = $('chat-input'); const message = input.value.trim();
  if (!message || !state.project || state.busy) return;
  state.busy = true; $('send-button').disabled = true; input.value = '';
  addMessage('user', message); const pending = addMessage('system', 'Agent is working…');
  try {
    const result = await api('/api/chat', { method: 'POST', body: JSON.stringify({ project_id: state.project.id, message }) });
    pending.remove(); addMessage('assistant', result.reply || 'No text response.');
    if (result.warning) addMessage('system', `Warning: ${result.warning}`);
    for (const event of result.tool_events || []) {
      const detail = event.arguments?.path || event.arguments?.target || '';
      const failed = event.result && typeof event.result === 'object' && 'error' in event.result;
      addMessage('system', `${failed ? '⚠' : '✓'} ${event.tool}${detail ? ` → ${detail}` : ''}${failed ? ` — ${String(event.result.error).slice(0, 140)}` : ''}`);
    }
    await loadFiles(); await (state.previewActive ? restartLivePreview() : refreshPreview()); await loadUsage();
  } catch (error) { pending.remove(); addMessage('system', `Error: ${error.message}`); }
  finally { state.busy = false; $('send-button').disabled = !state.project; input.focus(); }
}
async function createProject(event) {
  event.preventDefault(); const name = $('new-project-name').value.trim();
  if (!name) return;
  try {
    const project = await api('/api/projects', { method: 'POST', body: JSON.stringify({ name, description: $('new-project-description').value.trim() }) });
    $('new-project-dialog').close(); $('new-project-form').reset(); await loadProjects(false); await selectProject(project.id); toast('Project created');
  } catch (error) { toast(error.message); }
}
async function runCheck() {
  runTerminalCommand('auto');
}
async function runTerminalCommand(profile) {
  if (!state.project || state.busyTerminal) return;
  const chosen = profile || $('terminal-command').value || 'auto';
  state.busyTerminal = true;
  $('terminal-run').disabled = true; $('sandbox-check').disabled = true;
  const output = $('terminal-output');
  const header = document.createElement('div'); header.className = 'terminal-line terminal-meta';
  header.textContent = `$ sandbox run ${chosen}`;
  output.append(header);
  $('terminal-status').textContent = 'Executing inside the isolated sandbox…';
  output.scrollTop = output.scrollHeight;
  try {
    const result = await api(`/api/projects/${state.project.id}/run`, { method: 'POST', body: JSON.stringify({ check: chosen, target: '.' }) });
    const text = [result.stdout, result.stderr].filter(Boolean).join('\n').trim() || '(no output)';
    const body = document.createElement('div');
    body.className = 'terminal-line ' + (result.status === 'passed' ? 'terminal-ok' : 'terminal-fail');
    body.textContent = text;
    output.append(body);
    const tail = document.createElement('div'); tail.className = 'terminal-line terminal-meta';
    tail.textContent = `exit ${result.return_code ?? '?'} · profile ${result.profile} · ${result.status}`;
    output.append(tail);
    $('terminal-status').textContent = `${result.profile}: ${result.status}`;
    toast(`Sandbox ${result.profile}: ${result.status}`);
    await loadUsage();
  } catch (error) {
    const body = document.createElement('div'); body.className = 'terminal-line terminal-fail';
    body.textContent = `error: ${error.message}`;
    output.append(body);
    $('terminal-status').textContent = `Sandbox error: ${error.message}`;
    toast(error.message);
  } finally {
    state.busyTerminal = false;
    $('terminal-run').disabled = !state.project;
    $('sandbox-check').disabled = !state.project;
    output.scrollTop = output.scrollHeight;
  }
}
async function startPreview() {
  if (!state.project) return;
  $('start-preview').disabled = true; $('preview-status').textContent = 'Starting isolated preview…';
  try {
    const result = await api(`/api/projects/${state.project.id}/preview/start`, { method: 'POST', body: '{}' });
    const frame = $('preview-frame'); frame.hidden = false; $('preview-empty').hidden = true;
    frame.src = result.preview_url; $('preview-status').textContent = 'Live sandbox preview';
    state.previewActive = true; $('stop-preview').disabled = false;
    state.previewUrl = result.preview_url;
    addMessage('system', `Isolated app preview started: ${result.preview_url}`);
    await loadUsage();
  } catch (error) { toast(error.message); $('preview-status').textContent = 'Static preview'; }
  finally { $('start-preview').disabled = !state.project; }
}
async function stopPreview() {
  if (!state.project) return;
  $('stop-preview').disabled = true;
  try {
    await api(`/api/projects/${state.project.id}/preview/stop`, { method: 'POST', body: '{}' });
    state.previewActive = false; await refreshPreview(); $('preview-status').textContent = 'Sandbox stopped · static preview'; toast('Preview stopped');
  } catch (error) { toast(error.message); $('stop-preview').disabled = false; }
}
async function publishProject() {
  if (!state.project) return;
  $('publish-project').disabled = true;
  try {
    const deployment = await api(`/api/projects/${state.project.id}/publish`, { method: 'POST' });
    addMessage('system', `Site published: ${deployment.url}\n${deployment.note || 'Hosted by this server.'}`);
    toast(`Published: ${deployment.url}`); await loadUsage(); await loadDeployments(); window.open(deployment.url, '_blank', 'noopener,noreferrer');
  } catch (error) { toast(error.message); }
  finally { $('publish-project').disabled = !state.project; }
}
async function deleteProject() {
  if (!state.project) return;
  const project = state.project;
  if (!window.confirm(`Delete “${project.name}” and its project files? Published copies remain public.`)) return;
  $('delete-project').disabled = true;
  try {
    await api(`/api/projects/${project.id}`, { method: 'DELETE' });
    state.project = null; state.selectedFile = null; state.previewActive = false; setProjectControls(false);
    $('project-name').textContent = 'Select a project'; $('project-description').textContent = 'Create a project to start building.';
    $('file-list').replaceChildren(); $('chat-messages').replaceChildren(); $('file-editor').value = ''; $('file-editor').disabled = true;
    $('preview-frame').hidden = true; $('preview-frame').src = 'about:blank'; $('preview-empty').hidden = false;
    await loadProjects(true); toast('Project deleted');
  } catch (error) { toast(error.message); $('delete-project').disabled = !state.project; }
}
$('new-project').addEventListener('click', () => $('new-project-dialog').showModal());
$('close-dialog').addEventListener('click', () => $('new-project-dialog').close());
$('new-project-form').addEventListener('submit', createProject);
$('chat-form').addEventListener('submit', sendMessage);
$('save-file').addEventListener('click', saveFile);
$('refresh-files').addEventListener('click', () => loadFiles());
$('refresh-preview').addEventListener('click', refreshPreview);
$('sandbox-check').addEventListener('click', runCheck);
$('terminal-run').addEventListener('click', () => runTerminalCommand());
$('publish-project').addEventListener('click', publishProject);
$('delete-project').addEventListener('click', deleteProject);
$('refresh-deployments').addEventListener('click', loadDeployments);
$('start-preview').addEventListener('click', startPreview);
$('stop-preview').addEventListener('click', stopPreview);
// “Open preview ↗” is wired once at startup and always opens the last known
// preview URL; assigning onclick per request left a window where the enabled
// button had no handler yet (e.g. right after selecting a project).
$('open-preview').addEventListener('click', () => {
  if (state.previewUrl) window.open(state.previewUrl, '_blank', 'noopener,noreferrer');
});

// --- Local model manager -----------------------------------------------
// Talks to /api/model/*: user-triggered download, pause, verify, existing
// path binding and deletion. Polls while the dialog is open.
const MODEL_STATE_BADGE = {
  not_installed: ['model-badge-off', 'Not installed'],
  paused: ['model-badge-loading', 'Paused — resume available'],
  incomplete: ['model-badge-error', 'Incomplete'],
  downloading: ['model-badge-loading', 'Downloading…'],
  verifying: ['model-badge-loading', 'Verifying files…'],
  present: ['model-badge-idle', 'Files present — run Verify'],
  loading: ['model-badge-loading', 'Loading weights…'],
  ready: ['model-badge-ready', 'Ready'],
  load_failed: ['model-badge-error', 'Load failed'],
};
const MODEL_BUSY_PHASES = ['fetching_manifest', 'downloading', 'verifying'];
let modelDialogTimer = null;
function formatBytes(bytes) {
  if (bytes == null || Number.isNaN(bytes)) return '—';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KiB', 'MiB', 'GiB', 'TiB'];
  let value = bytes; let unit = 'B';
  for (const next of units) { if (value < 1024) break; value /= 1024; unit = next; }
  return `${value.toFixed(value >= 100 ? 0 : 1)} ${unit}`;
}
function formatDuration(seconds) {
  if (seconds == null || !Number.isFinite(seconds) || seconds < 0) return '—';
  if (seconds < 60) return `${Math.round(seconds)}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
  return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
}
function setModelMessage(kind, text) {
  const node = $('model-message');
  node.hidden = !text;
  node.className = `model-message${kind ? ` ${kind}` : ''}`;
  node.textContent = text || '';
}
async function refreshModelStatus() {
  try {
    renderModelStatus(await api('/api/model/status'));
  } catch { /* dialog stays on the last snapshot; the next tick retries */ }
}
async function refreshModelRemote() {
  try {
    const info = await api('/api/model/remote');
    $('model-remote-size').textContent = `${formatBytes(info.total_bytes)} · ${info.files.length} files`
      + (info.disk_ok ? '' : ' · not enough free disk space');
  } catch (error) {
    $('model-remote-size').textContent = 'Repository not reachable right now';
  }
}
function renderModelStatus(s) {
  const [badgeClass, badgeText] = MODEL_STATE_BADGE[s.state] || ['model-badge-off', s.state];
  const badge = $('model-state-badge');
  badge.className = `model-badge ${badgeClass}`;
  badge.textContent = badgeText;
  $('model-repo').textContent = s.progress.repo_id;
  $('model-path').textContent = s.target_dir;
  $('model-size').textContent = `${formatBytes(s.bytes_on_disk)} · ${s.files_on_disk} file(s)`;
  $('model-disk').textContent = `${formatBytes(s.disk_free_bytes)} free`;
  const engine = s.engine;
  $('model-engine').textContent = engine
    ? (engine.error ? `Load failed: ${engine.error}`
       : engine.loaded ? `Loaded · ${engine.device} · ${engine.quantization}`
       : engine.loading ? `Loading weights (${engine.device || 'auto'})…`
       : `Enabled, waiting (${engine.weights_present ? 'weights present' : 'weights missing'})`)
    : (s.model_extra_installed
        ? 'Not enabled yet — it turns on automatically after verification'
        : 'Off — install the model extra (requirements-local-model.txt) to load weights');
  const phase = s.progress.phase;
  const busy = MODEL_BUSY_PHASES.includes(phase);
  const showProgress = busy || phase === 'paused' || phase === 'done';
  $('model-progress').hidden = !showProgress;
  if (showProgress) {
    $('model-progress-fill').style.width = `${Math.min(100, s.progress.percent)}%`;
    $('model-progress-percent').textContent = `${s.progress.percent}%`;
    $('model-progress-speed').textContent = busy ? `${formatBytes(s.progress.speed_bps)}/s` : '';
    $('model-progress-remaining').textContent = s.progress.total_bytes
      ? `${formatBytes(Math.max(0, s.progress.total_bytes - s.progress.downloaded_bytes))} left` : '';
    $('model-progress-eta').textContent = busy ? `≈ ${formatDuration(s.progress.eta_seconds)}` : '';
    $('model-progress-file').textContent = s.progress.current_file
      ? `Current file: ${s.progress.current_file} (${s.progress.files_done}/${s.progress.files_total} files)` : '';
  }
  if (busy) setModelMessage('', '');
  else if (s.progress.error) setModelMessage('error', [s.progress.error, ...(s.progress.suggestions || [])].join('\n'));
  else if (s.binding?.restart_required) setModelMessage('', s.binding.detail);
  else if (s.binding?.runtime_activated) setModelMessage('ok', `Model bound to the local engine.\n${s.binding.detail}`);
  else if (phase === 'done') setModelMessage('ok', 'Download complete and files verified. LOCAL_INFERENCE=true was saved to .env.');
  else if (s.verify && !s.verify.valid) setModelMessage('error', ['Verification failed:', ...s.verify.reasons, '', 'Suggested fixes:', ...s.verify.suggestions].join('\n'));
  else if (s.verify?.valid) setModelMessage('ok', 'Checkpoint verified: config, tokenizer and all safetensors shards are present.');
  $('model-download').disabled = busy;
  $('model-cancel').hidden = !busy;
  $('model-verify').disabled = busy || s.files_state === 'not_installed';
  $('model-delete').disabled = busy || s.files_state === 'not_installed';
  $('model-save-path').disabled = busy;
}
async function modelDownload() {
  $('model-download').disabled = true;
  try {
    await api('/api/model/download', { method: 'POST', body: '{}' });
    toast('Model download started');
  } catch (error) { toast(error.message); }
  await refreshModelStatus();
}
async function modelPause() {
  $('model-cancel').disabled = true;
  try { await api('/api/model/cancel', { method: 'POST', body: '{}' }); toast('Pausing after the current chunk…'); }
  catch (error) { toast(error.message); }
  $('model-cancel').disabled = false;
  await refreshModelStatus();
}
async function modelVerify() {
  $('model-verify').disabled = true;
  try {
    const result = await api('/api/model/verify', { method: 'POST', body: '{}' });
    const v = result.verified;
    if (v.valid) setModelMessage('ok', 'Checkpoint verified: config, tokenizer and all safetensors shards are present.');
    else setModelMessage('error', ['Verification failed:', ...v.reasons, '', 'Suggested fixes:', ...v.suggestions].join('\n'));
  } catch (error) { setModelMessage('error', error.message); }
  await refreshModelStatus();
}
async function modelSavePath() {
  const path = $('model-existing-path').value.trim();
  if (!path) { setModelMessage('error', 'Type the folder that contains the checkpoint first.'); return; }
  $('model-save-path').disabled = true;
  try {
    const result = await api('/api/model/path', { method: 'POST', body: JSON.stringify({ path }) });
    setModelMessage('ok', `Model bound from ${path}.\n${result.binding.detail || 'LOCAL_INFERENCE=true saved to .env.'}`);
    $('model-existing-path').value = '';
  } catch (error) { setModelMessage('error', error.message); }
  await refreshModelStatus();
}
async function modelDelete() {
  const status = await api('/api/model/status').catch(() => null);
  const folder = status ? status.target_dir : 'the model folder';
  if (!window.confirm(`Delete all model files in\n${folder}\n permanently?`)) return;
  $('model-delete').disabled = true;
  try {
    const result = await api('/api/model/delete', { method: 'POST', body: JSON.stringify({ confirm: true }) });
    toast(`Deleted ${formatBytes(result.bytes_removed)}`);
    setModelMessage(result.engine_still_loaded ? '' : 'ok', result.detail || '');
  } catch (error) { setModelMessage('error', error.message); }
  await refreshModelStatus();
}
function openModelDialog() {
  $('model-dialog').showModal();
  refreshModelStatus();
  refreshModelRemote();
  if (modelDialogTimer) clearInterval(modelDialogTimer);
  modelDialogTimer = setInterval(refreshModelStatus, 1000);
}
function closeModelDialog() {
  if (modelDialogTimer) { clearInterval(modelDialogTimer); modelDialogTimer = null; }
  $('model-dialog').close();
}
$('model-manager-button').addEventListener('click', openModelDialog);
$('model-status-pill').addEventListener('click', openModelDialog);
$('close-model-dialog').addEventListener('click', closeModelDialog);
$('model-dialog').addEventListener('close', () => {
  if (modelDialogTimer) { clearInterval(modelDialogTimer); modelDialogTimer = null; }
});
$('model-download').addEventListener('click', modelDownload);
$('model-cancel').addEventListener('click', modelPause);
$('model-verify').addEventListener('click', modelVerify);
$('model-save-path').addEventListener('click', modelSavePath);
$('model-delete').addEventListener('click', modelDelete);
// Qwen Studio is a single-user local workspace: the studio opens directly on the
// workspace with no sign-in, registration or account setup step.
(async () => {
  await checkHealth();
  await initializeWorkspaceApp();
})();
