#!/usr/bin/env python3
"""Copy a built frontend artifact into public static storage safely."""
import argparse
import os
import shutil
from pathlib import Path

ALLOWED_SUFFIXES = {
    ".html", ".htm", ".css", ".js", ".mjs", ".json", ".txt", ".xml", ".webmanifest",
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico", ".woff", ".woff2",
    ".ttf", ".otf", ".mp4", ".webm", ".mp3", ".wav", ".pdf",
}
MAX_FILES = 3000
MAX_BYTES = 100 * 1024 * 1024


def _assert_inside(candidate: Path, root: Path, description: str) -> Path:
    try:
        resolved = candidate.resolve(strict=False)
        resolved.relative_to(root.resolve())
    except (OSError, ValueError) as exc:
        raise SystemExit(f"{description} resolves outside the project source.") from exc
    return resolved


def choose_output(project: Path) -> Path:
    project = project.resolve(strict=True)
    for name in ("dist", "build", "out"):
        candidate = project / name
        if candidate.is_symlink():
            raise SystemExit(f"Build output candidate {name}/ must not be a symlink.")
        _assert_inside(candidate, project, f"Build output candidate {name}/")
        if candidate.is_dir() and (candidate / "index.html").is_file():
            index = candidate / "index.html"
            if index.is_symlink():
                raise SystemExit(f"{name}/index.html must not be a symlink.")
            _assert_inside(index, project, f"{name}/index.html")
            return candidate.resolve(strict=True)
    fallback = project / "index.html"
    if fallback.is_symlink():
        raise SystemExit("Root index.html must not be a symlink.")
    _assert_inside(fallback, project, "Root index.html")
    if (project / "package.json").is_file():
        if (project / ".next").is_dir():
            raise SystemExit("Next.js needs static export configured to generate out/index.html before publishing.")
        raise SystemExit("Package project produced no dist/index.html, build/index.html, or out/index.html.")
    if fallback.is_file():
        return project
    raise SystemExit("No static build output found (expected dist/, build/, out/, or root index.html).")


def _validate_source_tree(source: Path) -> list[Path]:
    items = list(source.rglob("*"))
    # Validate all entries before creating the publish target, so a malicious link cannot
    # leave a partially copied public deployment behind.
    for item in items:
        _assert_inside(item, source, f"Source entry {item.relative_to(source)}")
    return items


def _set_publish_owner(path: Path) -> None:
    """Set the static-serving UID when permitted; retain the caller's ownership otherwise.

    The production runner creates the target as root and applies UID 10001. This fallback
    also permits local/non-root validation environments where chown is not available.
    """
    try:
        os.chown(path, 10001, 10001)
    except PermissionError:
        # Do not silently change permissions; the file remains readable only according
        # to the caller's existing ownership/mode and deployment must validate access.
        return


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--target", required=True)
    args = parser.parse_args()
    project = Path(args.source).resolve(strict=True)
    target = Path(args.target).resolve()
    source = choose_output(project)
    items = _validate_source_tree(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    _set_publish_owner(target.parent)
    target.mkdir(parents=False, exist_ok=False)
    _set_publish_owner(target)
    count = total = 0
    blocked = {".env", ".env.local", ".env.production", "credentials.json", "secrets.json",
               "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", ".qwen-project.json"}
    for item in items:
        # Repeat the check at the point of use to protect against source-tree changes
        # between pre-validation and copying.
        _assert_inside(item, source, f"Source entry {item.relative_to(source)}")
        if item.is_symlink():
            continue
        rel = item.relative_to(source)
        if any(part.startswith(".") or part.lower() in {"node_modules", ".git", "__pycache__"} for part in rel.parts):
            continue
        if item.is_dir() or not item.is_file():
            continue
        if item.name.lower() in blocked or item.name.lower().startswith(".env"):
            continue
        if item.suffix.lower() not in ALLOWED_SUFFIXES:
            continue
        size = item.stat().st_size
        count += 1
        total += size
        if count > MAX_FILES or total > MAX_BYTES:
            shutil.rmtree(target, ignore_errors=True)
            raise SystemExit("Static site exceeds file-count or 100 MB publish limit.")
        destination = target / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        _set_publish_owner(destination.parent)
        shutil.copyfile(item, destination)
        _set_publish_owner(destination)
        destination.chmod(0o644)
    if not (target / "index.html").is_file():
        shutil.rmtree(target, ignore_errors=True)
        raise SystemExit("Build output does not contain index.html.")
    print(f"published {count} files ({total} bytes)")


if __name__ == "__main__":
    main()
