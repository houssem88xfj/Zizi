#!/usr/bin/env python3
"""Copy one project into an isolated volume without symlinks or private files."""
import argparse
import os
import shutil
from pathlib import Path

BLOCKED_DIRS = {
    ".git", ".ssh", ".aws", ".azure", ".kube", ".venv", "venv",
    "node_modules", "__pycache__", ".next",
}
BLOCKED_FILES = {
    ".qwen-project.json", ".npmrc", ".pypirc", ".netrc", "credentials.json",
    "secrets.json", "id_rsa", "id_ed25519", "dockerconfig.json",
    "package-key.json", "service-account.json",
}
MAX_FILES = 3000
MAX_BYTES = 200 * 1024 * 1024


def _assert_inside(item: Path, source: Path) -> None:
    try:
        item.resolve(strict=False).relative_to(source.resolve())
    except (OSError, ValueError) as exc:
        raise SystemExit(f"project entry {item.relative_to(source)} resolves outside the source directory") from exc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--target", required=True)
    args = parser.parse_args()
    source = Path(args.source).resolve(strict=True)
    target = Path(args.target).resolve()
    if not source.is_dir():
        raise SystemExit("project source directory is missing")
    entries = list(source.rglob("*"))
    # Validate all links before copying any data; a bad link must not leave a partial volume.
    for item in entries:
        _assert_inside(item, source)
    target.mkdir(parents=True, exist_ok=True)
    count = 0
    total = 0
    for item in entries:
        _assert_inside(item, source)  # repeat containment validation immediately before use
        relative = item.relative_to(source)
        parts = relative.parts
        if any(part.lower() in BLOCKED_DIRS or part.lower() in BLOCKED_FILES
               or part.lower().startswith(".env") for part in parts):
            continue
        if item.is_symlink():
            continue
        destination = target / relative
        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            os.chown(destination, 10001, 10001)
            destination.chmod(0o755)
            continue
        if not item.is_file() or item.name.lower() in BLOCKED_FILES:
            continue
        lowered = item.name.lower()
        if lowered.startswith(".env") or item.suffix.lower() in {".pem", ".key", ".p12", ".pfx"}:
            continue
        size = item.stat().st_size
        count += 1
        total += size
        if count > MAX_FILES or total > MAX_BYTES:
            shutil.rmtree(target, ignore_errors=True)
            raise SystemExit("project copy exceeds sandbox file or storage limits")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(item, destination)
        os.chown(destination, 10001, 10001)
        destination.chmod(0o644)
    os.chown(target, 10001, 10001)
    print(f"staged {count} files ({total} bytes)")


if __name__ == "__main__":
    main()
