# Validation report — Qwen Studio 0.7.2 (pre-release verification round)

Latest round: the full pre-release audit (bottom section). Earlier rounds below are kept
for the record. Every result is from a real execution in this environment; items that
could not run here are listed explicitly, never assumed.

## Release gate (0.7.2)

`bash scripts/verify_all.sh` final table:

| Gate | Result |
|---|---|
| `python -m pytest -q` | PASS — 301 passed |
| `node --check frontend/app.js` | PASS |
| `python -m compileall -q backend runner sandbox deploy scripts` | PASS |
| `scripts/check_consistency.py` | PASS (version 0.7.2 consistent across app/health/CHANGELOG/VALIDATION/README) |
| `scripts/verify_pins.py` | PASS |
| `scripts/check_release.py .` | PASS |
| `bash -n` for every repository `.sh` file | PASS |

## Final pre-release audit round (0.7.2, this environment)

Full-repo audit before public GitHub/Hugging Face publication. Real executions in this
environment (Linux, CPU-only, no Docker daemon, no Windows, no GPU); everything else is
listed as NOT TESTED, never assumed.

**Fixes applied by the audit (all verified by tests after the change):**

1. **Weights exclusion now enforced (was the top release blocker).** `.gitignore` covers
   `models/*` (README kept) and `*.safetensors/*.bin/*.gguf/*.ckpt/*.pt/*.pth/*.onnx/*.part`;
   a project-level `.gitattributes` marks weights binary; `scripts/check_release.py` now
   REJECTS a release tree containing weight files, any `models/` artefact other than
   `models/README.md`, or a `.venv/` directory; `scripts/make_release.sh`'s non-git
   fallback excludes weights/venv too. New tests pin all of this.
2. **Runner orphan containers reaped.** Run/build/npm-install workload containers now get
   unique `--name`s and are force-removed when a docker call fails or times out (killing
   the docker CLI never stopped the daemon-side container, so a hung pytest/npm run used
   to leak its container+volume). 4 new tests.
3. **Static publish containment hardened.** `deployments._copy_public_tree` now skips any
   path resolving outside the project root (rglob can traverse a symlinked directory
   planted out of band).
4. **Timeout chain made coherent.** sandbox-client waits now out-wait the runner's worst
   case (run 720 s covers staging + 600 s max `SANDBOX_TIMEOUT_SECONDS`; preview-start
   520 s; build 520 s; fetch 20 s), smoke-test constants out-wait the client (760/560/760),
   and nginx `proxy_read_timeout` raised to 800 s. Previously the backend could report a
   misleading 503 while the runner was still working.
5. **Frontend robustness.** "Open preview ↗" is wired once at startup against the last
   known preview URL (was a per-request `onclick` assignment with a dead-button window
   right after selecting a project); the boot sequence no longer aborts all panels when
   one startup call fails.
6. **Docs truth pass.** README limits section rewritten to the shipped 0=unlimited
   defaults (was documenting the old bounded defaults), five-task → 20-task evaluation,
   INSTALL_LINUX disk sizing fixed (40 GB+), `PRODUCTION_READINESS.md` concurrency note
   updated, explicit "not affiliated with Alibaba/the Qwen team" statement added to
   README/NOTICE/LICENSES.md, `requests` + `huggingface_hub` added to the dependency
   license table, MODEL_NOTES conversation-leftover phrasing removed, AUDIT_REPORT marked
   superseded.

**Real results in this environment:**

| Check | Result |
|---|---|
| `python -m pytest -q` (full suite) | **PASS — 301 passed, 0 failed** (28 s) |
| `node --check frontend/app.js` | PASS |
| Secrets scan (whole tree) | CLEAN — no API keys/tokens/private keys; only placeholders |
| Live model-manager E2E (`scripts/live_model_download_e2e.py`, real backend + real huggingface.co) | **14/14 PASS** — tiny real Qwen2 checkpoint downloaded through the production manifest/HEAD/Range/SHA-256 path, pause kept `tokenizer.json.part` (1.3 MiB) and resumed byte-exactly, verification passed, `LOCAL_INFERENCE=true` auto-written, no token ever written, real engine loaded the weights (`device=cpu`), state `ready`, standalone generation from the downloaded weights produced tokens. 2 checks NOT RUN: in-app chat completion and the delete flow were cut by this sandbox's 3 GiB RAM limit OOM-killing the app during generation (engine loading itself passed) |
| Scripted agent E2E (real `/api/chat` + real workspace + scripted model server) | **ALL PASS (7/7)** — create project → agent writes index.html/style.css/app.js → edit_file → bug fix verified in file content. First run failed with 502: the sandbox venv was missing the pinned `openai` client (environment issue, not a code bug); after installing the pinned version the flow passes |
| Live UI check (Playwright, real app + real Hub) | PASS — Model dialog opens in a real browser, badge `Not installed`, repo `Qwen/Qwen2.5-Coder-14B-Instruct`, remote manifest **27.5 GiB · 15 files**, and the disk precheck honestly reports "not enough free disk space" (7.8 GiB free here) |
| Operator smoke test (live instance, `--skip-model --skip-npm`) | health/version PASS, workspace-without-login PASS, project create/delete PASS; sandbox-dependent steps NOT RUN (no Docker daemon here) |
| Full-14B download (~27.5 GiB) | NOT RUN — exceeds this sandbox's disk; the same production path was proven with the real tiny checkpoint above |
| Windows CMD execution of install.bat | NOT TESTED — no Windows here; 18 structural contract tests pin the CMD semantics |
| Real GPU CUDA install / load | NOT TESTED — no GPU here (`check_torch.py --cuda` honestly fails with `torch.cuda.is_available() = False`) |
| Docker runner / gVisor / live preview containers | NOT TESTED — no Docker daemon here; runner logic is pinned by 20+ unit tests |
| nginx / TLS / wildcard DNS on a real host | NOT TESTED — no host here; deploy configs checked by structural tests |

---

## Earlier round — 0.7.2 (model manager + operator tools)

## Real-engine benchmark (`scripts/bench_local_model.py`)

Run against the genuine `Qwen/Qwen2.5-0.5B-Instruct` safetensors on CPU (torch 2.15.0+cpu,
transformers 5.24.1). **CUDA reported False (no GPU here); on a GPU host the same harness
reports device name/VRAM and measures VRAM usage.** Structural gates: **11/11 PASS**.

| Measurement | Value |
|---|---|
| Weights present | 290 tensors, 0.92 GiB, `local_files_only=True` |
| Load time | 5.6 s (device=cpu, quantization=none) |
| Plain chat | 2.0 s — "A Python variable is a named storage location for storing data…" |
| Code generation | 9.9 s — emits `def is_prime(n):` code block |
| Function calling | `finish_reason=tool_calls`, `get_weather` with valid JSON arguments |
| Agent tool call | `write_file` with valid JSON arguments (path+content) |
| Malformed history | handled without crash; stream=True cleanly rejected (ValueError) |
| Long context | 1,618 prompt tokens processed in 4.0 s |
| Peak RAM | 1,603 MiB (CPU; VRAM fields empty without a GPU) |
| Engine restart | fresh engine reload + serve OK |

Raw JSON: `qwen-studio-local-runtime/bench_local_model_cpu_05b.json` (outside the repo).

## Live AI-coding-agent full cycle

**Deterministic E2E (scripted model through the REAL `/api/chat` + REAL agent tool loop +
REAL disk): ALL PASS** — project created, 3× `write_file` executed, deliberate
`getElementById("couter")` bug fixed via `edit_file`, fixed content verified on disk (not
only via API), final reply honest.

**Live quality run with the 0.5B stand-in (recorded honestly):** in one run the model
declared `write_file` and index.html/style.css were written to disk; in another run it
called `edit_file` with bad arguments and the error surfaced verbatim; in the read/edit
steps it answered without calling tools ("The JavaScript file has been read…") while
`tool_events` stayed empty — i.e. **the platform never fabricates tool activity; the small
model does claim actions it did not take.** This is the measured justification for requiring
Qwen2.5-Coder-14B-Instruct for agent work.

`scripts/eval_agent.py` subset with the 0.5B stand-in: "Missing file is reported honestly"
PASS (no fabrication, no loop); "Fix a JavaScript bug" FAIL (0.5B quality). The full
20-task evaluation must run against 14B on the GPU host.

## Terminal & live preview (runner offline — honest behavior)

All five terminal profiles (`auto`, `python_compile`, `pytest`, `npm_test`, `npm_build`)
validated through `/api/run`; without the Docker runner each returns the honest
503 "Sandbox runner is not configured…"; an invalid profile is rejected 422 (strict
whitelist regex). Static preview serves project content (200, marker match); the preview
proxy path serves files; **cross-project preview isolation verified** (project B's proxy
never leaks project A's marker); container preview start/stop return honest 503 without
Docker. Live container execution stays in the not-run list below.

## Account-removal structural scan (`scripts/account_removal_scan.py`)

**CLEAN** — no auth files, no `/api/auth/*` routes, no session/cookie/password code, no
`users`/`user_storage` tables outside the documented legacy-migration path, no auth env
vars, no account UI markers in the frontend. Live spot-checks: every `/api/auth/*` route
answers 404.

## Security spot-checks (post-account-removal)

Security-header set present (nosniff, X-Frame-Options DENY, Permissions-Policy,
Referrer-Policy); cross-origin POST with a foreign Origin → 403; `Sec-Fetch-Site:
cross-site` is rejected by design (absence of the header = non-browser client, e.g. curl);
path traversal → 404; 31 hardening/runner/projects/storage tests pass explicitly. Compose
review: the app service mounts **no Docker socket** (only the runner does, by design),
binds loopback by default, runs `no-new-privileges` with read-only rootfs, sandbox network
is `internal: true`, sandbox limits (mem/cpu/pids/time/output) are explicit, and the runner
refuses production without gVisor `runsc`.

## Smoke test & docker_check (honest environment limits)

`scripts/smoke_test.py` against a live instance: **4 PASS, 3 FAIL, 2 SKIP** — the three
failures are environmental, not regressions: sandbox.connected false and `python_compile`
503 (no Docker runner), and the model file-writing task needs a real instruction-following
model (the scripted model cannot follow "write hello.txt"; the 0.5B did not emit a valid
tool call). `scripts/docker_check.sh`: NOT RUN — `docker: command not found` in this
environment.

## Memory-aware auto quantization planner (GPU requirements correction)

`tests/test_local_model_memory.py` (19 tests, PASS): the BF16-vs-INT4 decision is proven
with synthetic numbers and a mocked CUDA surface ONLY — real-GPU behavior is NOT RUN
here. Covered: 24GB card → INT4 (never BF16, since 14.7B × 2B ≈ 27.4 GiB weights alone);
32 GiB nominal with low free memory → INT4; 40GB+ with real free VRAM → BF16; 32 GiB
bf16 conditional on context (32K → INT4, 8K → BF16 possible); INT4 insufficiency → clear
EngineNotAvailable with GiB figures and LOCAL_MODEL_MAX_CONTEXT_TOKENS guidance; reduced
context fits INT4 on 12 GiB; unknown geometry → conservative KV fallback; manual
quantization always honored (bf16 on 24GB → warning, never silent swap); no-CUDA → CPU
with zero GPU memory queries; forced cuda without GPU → clear error; mem_get_info
unavailable → discounted-total fallback with warning; begin_load never spawns multiple
threads nor retries after a failed attempt; docs/config consistency assertions (old
"32GB+ runs bf16" claims removed everywhere).

## Not executed in this environment (must run on real hardware)

- **14B quality/VRAM/latency:** place the real `Qwen/Qwen2.5-Coder-14B-Instruct` weights in
  `models/` on a GPU host (40+ GiB VRAM for bf16; 24 GiB runs INT4 NF4; 10–12 GiB needs a
  reduced context — see `docs/GPU_GUIDE.md`), then run `python scripts/verify_weights.py`,
  `python scripts/bench_local_model.py --model-dir models/Qwen2.5-Coder-14B-Instruct --json bench-14b.json`
  and `python scripts/eval_agent.py` (20 tasks).
- **Docker/gVisor live sandbox:** `docker compose build`, runner connection, container
  execution of every terminal profile, network policy enforcement, cross-project container
  isolation, container crash/restart handling (`scripts/docker_check.sh` inside the app
  container).
- Public-host topology (Nginx/TLS/wildcard DNS) and production backup/restore drills.

## Windows installer patch round (0.7.2 — CMD delayed expansion, PowerShell removal, torch pin)

Every result below is from a real execution in this environment (Linux, Python 3.12.16,
CPU only, **no Windows/wine, no GPU, no Docker daemon**). Nothing is mocked into a pass.

### What was fixed (no features added, none removed, version stays 0.7.2)

- `scripts/install.bat` rewritten with correct CMD semantics: `setlocal EnableExtensions
  DisableDelayedExpansion` protects the `cd /d "%~dp0.."` jump and the project banner from
  `!`-containing/spaced paths; delayed expansion is enabled only afterwards; EVERY read of
  `TORCH_BUILD` / `TORCH_INDEX_URL` / `TORCH_STATE` / `VALID_ARG` / `WITH_MODEL` inside
  parenthesized blocks now uses `!VAR!` (the old script expanded `%TORCH_INDEX_URL%` at
  parse time to an empty string — `pip install torch --index-url ` failed — and never saw
  the auto-detected build). Arguments are quote-stripped via `%%~a`; the FOR /F python
  probes contain no single quotes (they used to terminate the FOR command string);
  every pip operation is followed by an `if errorlevel 1 ... exit /b 1` check; a torch
  that is installed but cannot import is detected via `pip show` and replaced; the success
  banner is reachable only after the real verification passes.
- PowerShell dependency REMOVED from `install.bat` (the header always claimed
  "PowerShell-free" while the code invoked PowerShell for `.env`): `.env` creation is now
  the same pure-Python logic as `install.sh` (APP_ENV switch + `secrets.token_urlsafe(48)`
  for `SANDBOX_RUNNER_TOKEN`), with errorlevel checks on the copy and the finalize step.
- `VENV` activation is verified (`VIRTUAL_ENV` guard) so pip never installs into the
  global Python when activation fails; venv creation and pip upgrade are error-checked.
- PyTorch/CUDA compatibility audit (official sources): torch **pinned to 2.6.0** in
  `install.sh`, `install.bat` and `Dockerfile` — the newest release actually published on
  the official cu124 wheel index (2.4.0–2.6.0 only; no cu124 wheels exist for 2.7+).
  Wheels verified present for cp311/cp312/cp313 on win_amd64 and linux_x86_64 for BOTH
  build families (HTTP 200 on download.pytorch.org). Driver requirement documented from
  the NVIDIA CUDA Toolkit release notes: any CUDA 12.x wheel runs on driver ≥ 525 (minor
  version compatibility); CUDA 12.4 GA wants ≥ 550.54.14 (Linux) / ≥ 551.61 (Windows).
  BitsAndBytes official docs: PyTorch 2.4+, Python 3.10+, CUDA 11.8+, compute capability
  6.0+ (LLM.int8 7.5+, e.g. T4) — all satisfied by the pin. `requirements-local-model.txt`
  requirements themselves are unchanged (`torch>=2.4`, `bitsandbytes>=0.44`, ...).
- `scripts/check_torch.py`: reports measured VRAM per visible device
  (`get_device_properties().total_memory`) and prints an explicit hint when a GPU has no
  BF16 tensor cores (pre-Ampere, e.g. T4 → fp16/int4; the engine already picks fp16
  compute dtype automatically). The manual-fix advice now quotes the pinned command.
- Docs updated to match the installers literally: INSTALL_WINDOWS (CMD-only install,
  PowerShell claim resolved, pin), INSTALL_LINUX (pin), GPU_GUIDE (driver numbers, pin,
  T4/FP16 note, bitsandbytes compatibility), CPU_GUIDE (pin, bitsandbytes ≥0.50 optional
  `kernels` note, new tested stack), README + START_HERE_AR (pinned manual commands).

### Mandatory checks (this round)

| # | Check | Result |
|---|---|---|
| 1 | `scripts/verify_all.sh` (pytest + JS + compileall + consistency + pins + release tree + shell syntax) | PASS — all 7 gates (266 tests) |
| 2 | `scripts/account_removal_scan.py` | CLEAN (0 findings) |
| 3 | `scripts/check_torch.py --cpu --check-model-extra` | executed live: torch missing in the dev venv → honest exit 2 with install hints; the same command in the fresh install venv → PASS (see #5) |
| 4 | Windows `install.bat --with-model --cpu` / `--with-model --cuda` in real CMD | **NOT RUN — no Windows/wine/Windows-CI in this environment.** Enforced instead by 18 structural contract tests (`tests/test_install_windows_patch.py`) that model CMD block parsing (quote/escape-aware scanner: balanced blocks, zero stale `%VAR%` reads of block-mutated variables, delayed-expansion scope, pip error checks, PowerShell absence, quoting, pin consistency) |
| 5 | Linux CPU install path (REAL, end-to-end) | PASS — clean tree copy, `bash scripts/install.sh --with-model --cpu`: torch 2.6.0+cpu installed from the official CPU index, full model extra (transformers 5.24.1, tokenizers 0.23.3, regex, safetensors 0.8.0, accelerate 1.16.0, sentencepiece 0.2.3, bitsandbytes 0.50.2, huggingface_hub 2.4.0), real verification PASS, `.env` created via Python, exit 0 |
| 6 | Linux CUDA install on a real GPU | **NOT RUN — no GPU here.** The honest control still passes: `check_torch.py --cuda` fails with exit 1 and the actual cause |
| 7 | Engine smoke on the fresh install (REAL) | PASS — tiny Qwen2 checkpoint + real Qwen2.5-Coder tokenizer: weights load from disk, server up, `/v1/chat/completions` 200, tool-call parsing OK (torch 2.6.0+cpu + transformers 5.24.1 — the exact versions the pinned installer produces) |
| 8 | bitsandbytes CPU 4-bit on the fresh install (REAL) | PASS — `quantize_4bit`/`dequantize_4bit` and `Linear4bit` forward at realistic dimensions; bnb ≥ 0.50's informational `kernels` message documented in CPU_GUIDE (optional faster path, not required) |
| 9 | Docker GPU image build + `pip check` + in-container `torch.cuda.is_available()` | **NOT RUN — no Docker daemon here.** The dependency contract stays pinned by tests: no `--no-deps`, `pip check` in both stages, 9-module import smoke, `torch==2.6.0` taken from the build-arg index (never CPU torch in the GPU image), GPU reservation only on `app-gpu`, weights `:ro`, inference port unpublished, no Docker socket in the app container |
| 10 | Version consistency Linux/Windows/Docker | PASS — `torch==2.6.0` + cu124 + CPU indexes asserted identical across `install.sh` / `install.bat` / `Dockerfile` / `compose.yaml` by tests |

### Test count (real)

Full suite after this round: **266 passed, 0 failed, 0 skipped** (248 → 266; +18 new
contract tests in `tests/test_install_windows_patch.py`). `scripts/check_consistency.py`
enforces that VALIDATION quotes exactly the collected test count, so this cannot drift.

---

## Install-fix round (0.7.2 — GPU/CUDA install path, Docker model-extra deps, docs)

Every result below is from a real execution in this environment (Python 3.12.16, CPU only,
no GPU, no Docker daemon). Nothing is mocked into a pass; items that cannot run here stay
in the NOT RUN list.

### What was fixed (no features added, none removed, version stays 0.7.2)

- `scripts/install.sh` / `scripts/install.bat`: explicit `--cpu` / `--cuda` (`--gpu`) torch
  build choice with `--with-model`; auto preselection only (nvidia-smi present AND listing a
  GPU) that is never trusted; existing compatible torch build reused; build switches
  uninstall first so two conflicting torch builds never coexist; post-install REAL
  verification that fails the installer when a requested GPU install cannot see the GPU.
- New `scripts/check_torch.py`: read-only torch/CUDA verifier + `--check-model-extra`
  import verification; also used inside containers.
- `Dockerfile`: the model extra no longer installs transformers with `--no-deps`; pip
  resolves the full runtime set; `pip check` in both image stages; build-time import smoke
  test (torch, transformers, tokenizers, regex, safetensors, accelerate, sentencepiece,
  bitsandbytes, huggingface_hub). Runner image pins aligned with the application pins.
- `scripts/account_removal_scan.py`: release-tree-relative root (works from the ZIP) and
  the Arabic account-free negation false positive fixed ("لا يوجد تسجيل دخول ولا إنشاء حساب").
- Docs: MODEL_DEPLOYMENT intro corrected (local engine in-repo vs weights not bundled vs
  optional external endpoint); stale "create an account" sentence removed from
  INSTALL_LINUX; INSTALL_WINDOWS/CPU_GUIDE/GPU_GUIDE/START_HERE_AR document the CPU/CUDA
  choice and real verification; README's stale MODEL_MAX_TOKENS default fixed (0=unlimited).

### Mandatory checks (this round)

| # | Check | Result |
|---|---|---|
| 1 | `scripts/verify_all.sh` (pytest + JS + compileall + consistency + pins + release tree + shell syntax) | PASS — all 7 gates |
| 2 | `scripts/account_removal_scan.py` | CLEAN (0 findings) |
| 3 | `scripts/verify_weights.py` | tool executes; correctly FAILS with a clear message here (no 14B weights in this environment) |
| 4 | `node --check frontend/app.js` | PASS (inside verify_all) |
| 5 | `python -m compileall -q backend runner sandbox deploy scripts` | PASS |
| 6 | `bash -n` on every repository `.sh` | PASS |
| 7 | Version/env/routes consistency (`check_consistency.py`) | PASS (0.7.2 everywhere; VALIDATION count == collected count) |
| 8 | `pip check` | PASS in the dev venv AND in the fresh CPU-install venv |
| 9 | CPU install path (REAL) | PASS — fresh venv, `torch 2.15.0+cpu` installed from the official CPU wheel index, full model extra installed, `check_torch.py --cpu --check-model-extra` PASS |
| 10 | CUDA install path | CONTROL TEST ONLY — `check_torch.py --cuda` correctly FAILS (`torch.cuda.is_available() = False`, CPU-only build detected, `nvidia-smi` probed, exact fix printed). A real-GPU CUDA install is NOT RUN (no GPU here) |
| 11 | transformers/bitsandbytes imports (REAL) | PASS — transformers 5.24.1, bitsandbytes 0.50.2, tokenizers 0.23.3, safetensors 0.8.0, accelerate 1.16.0, sentencepiece 0.2.3, huggingface_hub 2.4.0 |
| 12 | Offline local weights read (REAL) | PASS — genuine `Qwen/Qwen2.5-0.5B-Instruct` safetensors (290 tensors, 0.92 GiB) fully verified offline (`local_files_only=True`); 0.5B is a structural stand-in, the 14B checkpoint stays NOT RUN |
| 13 | Full structural benchmark on the fresh install | 11/11 gates PASS (load 2.6 s CPU, chat, code generation, function calling, agent tool call, malformed-history handling, streaming rejection, 4138-token context, restart) — proves install → imports → real weights → real chat end-to-end |

### Docker (NOT RUN — `docker: command not found` in this environment)

- Image builds (app, runner, sandbox), the in-image `pip check` + import smoke test at build
  time, `torch.cuda.is_available()` inside `app-gpu`, runner connection and service-to-service
  tests, gVisor behavior. The dependency CONTRACT for the GPU image is pinned by tests
  (no `--no-deps`, `pip check` present, import smoke present, runner pins aligned, GPU
  reservation only on `app-gpu`, weights `:ro`, internal inference port unpublished, no
  Docker socket in the app container) — the actual image build must run on a Docker host.

### Test count (real)

Full suite after this round: **248 passed, 0 failed, 0 skipped** (was 228; +20 new contract
tests in `tests/test_install_gpu_choice.py` covering the installer flags, the loud CUDA
failure branch, the decision core, Dockerfile dependency resolution, runner pin alignment
and the compose GPU/security properties). `scripts/check_consistency.py` enforces that
VALIDATION quotes exactly the collected test count, so this table cannot drift.

---

## Model manager round (0.7.2 — in-app download, verify, bind)

New capability: the studio UI's **Model** button (dialog) drives `backend/model_manager.py`
through `GET/POST /api/model/{status,remote,download,cancel,verify,path,delete}`. Nothing
downloads at install time or on startup; every transfer is user-triggered.

- **New tests:** 25 in `tests/test_model_manager.py`. The byte-level downloader runs against
  a local fake Hub speaking the real wire protocol (ETag/`X-Linked-Size` HEAD metadata,
  206/Range GET resumption), and one network-gated test downloads a REAL checkpoint from
  huggingface.co through the production code path. Full suite at that round: **291** passed,
  0 failed, 0 skipped in this environment (Linux, CPU-only, no Docker).
- **Real end-to-end download (real Hub):** `trl-internal-testing/tiny-Qwen2ForCausalLM-2.5`
  (~20.7 MiB, 11 files) downloaded through the production manifest/HEAD/Range/SHA-256 path;
  files verified (config parses, tokenizer present, LFS SHA-256 match, no `.part` leftovers).
  Also verified live from a browser (Playwright): Model button always visible, dialog opens,
  badge "Not installed", real repository line "27.5 GiB · 15 files" for the 14B default,
  correct button enable/disable states, and the correct "not enough free disk space" refusal
  with 7.8 GiB free against the ~27.5 GiB 14B checkpoint.
- **Resume semantics proven byte-exact:** a first GET that dies mid-transfer (drip then
  close) leaves a `.part` file; the retry issues `Range: bytes=<persisted>-` and completes
  without re-downloading finished files; pause keeps the `.part` file and resume completes;
  a corrupted pre-existing shard with a published SHA-256 is detected and re-fetched;
  checksum mismatch deletes only the poisoned partial data. Implementation notes captured
  by the tests: 64 KiB stream chunks (small-file resume), `Accept-Encoding: identity`
  (wire bytes = disk bytes; gzip'd text files would break size/Range math), redirect-
  following HEAD metadata (the Hub returns relative Location headers), and manual
  `{endpoint}/{repo}/resolve/main/{file}` URL construction (stable across
  huggingface_hub 1.x/2.x — its `hf_hub_url` helper signature changed in 2.x).
- **Live app round-trip (real uvicorn + real engine, torch 2.6.0+cpu, transformers 5.24.1,
  huggingface_hub 2.4.0):** download → SHA-256 verification → `LOCAL_INFERENCE=true`
  written to `.env` (external `MODEL_BASE_URL` commented out, previous value kept) →
  engine started in-process → real engine loaded the downloaded weights on CPU
  (`device=cpu`) → status `ready` → no token/secret ever written. **14/14 live checks PASS,
  2 NOT RUN:** (1) an in-app agent chat completion — the 3 GiB sandbox OOM-killed the app
  process during generation (engine weight loading itself passed; engine chat round-trips
  were proven on this engine code in the CPU benchmark rounds); (2) the API delete-flow
  after that OOM (server process gone) — deletion itself is covered by the pytest suite
  (confirm gate, protected-directory refusals, `.env` reset) and the live UI.
- **Security properties (tested):** manifest filter refuses executables/scripts/archives
  (`.sh/.exe/.dll/.py/.zip/.bin/.pem/...`) and unsafe names (`..`, absolute, backslash);
  only safetensors/json/txt/jinja/md/LICENSE/NOTICE are fetched; GET/HEAD only — no user
  or project file is ever uploaded; no token is read, stored or sent; `.env` writes never
  contain secrets; deletion refuses non-model directories (models root, BASE_DIR,
  WORKSPACE_DIR, PUBLISH_DIR, filesystem root) and requires `confirm=true`.
- **Dependencies:** `huggingface_hub==2.4.0` (satisfies transformers 5.24.1's
  `huggingface-hub>=1.31,<3.0`, so app-only and model-extra installs agree) and
  `requests==2.32.5` added to `requirements.txt`; new optional `QWEN_MODEL_REPO_ID` in
  `.env.example`/README/CHANGELOG documented.
- **NOT RUN here (unchanged environment limits):** the full ~27.5 GiB 14B download
  (insufficient disk: 7.8 GiB free), Windows installers/UI (no Windows), CUDA/GPU
  execution (no GPU), Docker image build (no Docker). The downloaded-weights generation
  proof uses a genuine tiny Qwen2 checkpoint, not the 14B weights.

## UI design pass round (0.7.2 — graphite polish, CSS only)

- Scope: `frontend/app.css` rewritten in place (same class/ID hooks, same DOM); zero
  HTML/JS changes, so every behavioural contract test passes untouched.
- What changed: spacing/elevation rhythm (radius scale, layered surfaces, soft shadows),
  refined hover/active/press states, focus-visible rings, slim scrollbars, accent
  selection, accent left-rails for active project + selected file, tinted project icons,
  asymmetric chat bubbles + chip system messages, dashed empty states, dark preview empty
  state, blurred dialog backdrops with a short open animation, tabular numerals,
  `prefers-reduced-motion` support.
- Regression caught and fixed during the round: an added narrow-viewport `min-height`
  rule overrode the mobile `min-height:auto` and pushed the workspace below the fold —
  removed, re-captured, confirmed.
- Evidence: Playwright captures in `download/ui-design-round/` (empty workspace, project
  workspace with explorer/editor, Model dialog, new-project dialog, 800px narrow) before
  and after. Release gate `scripts/verify_all.sh`: all gates PASS (291 pytest tests,
  JS syntax, compileall, consistency, pins, release tree, shell syntax).

# Previous round — 0.7.1 (account removal)

Validation was performed against the Qwen Studio 0.7.1 working tree in the local test
environment. This round removed the account system; the release gate: **195 pytest tests
pass**, `node --check`, `compileall`, consistency, release and shell-syntax checks pass
(see below).

## Release gate

`bash scripts/verify_all.sh` final table:

| Gate | Result |
|---|---|
| `python -m pytest -q` | PASS (195 tests collected at that round) |
| `node --check frontend/app.js` | PASS |
| `python -m compileall -q backend runner sandbox deploy scripts inference` | PASS |
| `scripts/check_consistency.py` | PASS |
| `scripts/verify_pins.py` | result depends on network; offline runs are reported as SKIP |
| `scripts/check_release.py .` | PASS |
| `bash -n` for every repository `.sh` file | PASS |

## Environment

Linux sandbox, Python 3.12.16, CPU only (torch 2.15.0+cpu, transformers 5.24.0,
accelerate 1.16.0, bitsandbytes 0.50.2, safetensors), ~4 GiB RAM. **No GPU, no Docker
daemon, no real 14B weights in this environment.** Because the 14B checkpoint was not
provided, model-level checks ran against the **genuine Qwen/Qwen2.5-0.5B-Instruct
safetensors** (a real Apache-2.0 Qwen2.5 checkpoint with realistic tensor shapes,
downloaded only for validation, never shipped) plus a 30 MiB random-init Qwen2
stand-in. Stand-ins prove the code path, **not** 14B behavior.

## Test results (the 15 mandatory checks)

| # | Check | Result |
|---|---|---|
| 1 | Weight-file completeness | PASS — `scripts/verify_weights.py` on the real 0.5B checkpoint (config, 290 tensors, tokenizer, index coverage); unit tests cover shard/corruption cases |
| 2 | Tokenizer load | PASS — `AutoTokenizer.from_pretrained(local_files_only=True)` inside the engine; chat template with tools rendered |
| 3 | Real model load | PASS — real Qwen2.5-0.5B-Instruct bf16 on CPU (`loaded=true`, `device=cpu`, 3.4 s) loaded through the exact production engine |
| 4 | GPU detection | CODE PATH VERIFIED only — `torch.cuda.is_available()=False` → auto selects cpu. CUDA selection on physical hardware NOT tested |
| 5 | Quantization | PASS (CPU, real 0.5B shapes): int4 NF4 load + generation, int8 load + generation (with bnb bf16→fp16 cast notices). Random tiny checkpoint fails inside bnb at generation (tensor below blocksize) — a stand-in artifact. CUDA quantization NOT tested |
| 6 | Model gateway → local engine | PASS — `/api/system/status` `model.connected=true`, `model.local.loaded=true` with `MODEL_BASE_URL` auto-defaulted to `http://127.0.0.1:8100/v1` |
| 7 | Real chat with Qwen | PASS — real coherent reply from the real checkpoint ("A for-loop is a programming construct that allows you to repeat a block of code multiple times…"), correct usage accounting (56 tokens) |
| 8 | Function calling | PASS — real model emitted `list_files {"path": "."}` as `finish_reason=tool_calls` parsed to native OpenAI `tool_calls`; malformed/dangling-tag handling covered by 25 scripted agent tests |
| 9 | Project creation | PASS — live `/api/projects` request scaffolded the project folder (verified on disk) |
| 10 | File modification | PASS — scripted-model E2E through the real `/api/chat`: agent executed 3× `write_file`; files verified on disk and via the files API. Real-model caveat below |
| 11 | Bug fix | PASS — same E2E: `edit_file` replaced the buggy identifier (`couter`→`count`); fixed content verified on disk |
| 12 | Preview | NOT TESTED live — sandboxed preview requires the Docker runner; endpoint/iframe logic covered by unit tests and UI screenshot only |
| 13 | Sandbox | NOT TESTED live — no Docker daemon. Runner limits (CPU/RAM/pids/time, gVisor runtime enforcement, no docker socket in the app container, token auth) verified by unit tests and code review; the new operator limit envs have dedicated tests |
| 14 | Platform restart | PASS — SQLite persistence of projects/chat across restart; engine reloads and reconnects automatically (regression tests) |
| 15 | Clean install | PASS — fresh venv + `requirements.txt` only → app healthy; with `LOCAL_INFERENCE=true` but no model extra the engine surfaces the explicit error `pip install -r requirements-local-model.txt (missing torch)` while the app keeps running |

### Real-model caveat (measured, not hidden)

With the real 0.5B checkpoint, the full-app "create a file via chat" step is
**model-capability-limited**: at ~3.5K-token prompts (agent prompt + scaffold context)
the 0.5B fails to emit valid tool calls in most attempts (0/3 in the in-process probe;
0/4 over HTTP), while at ~1.1K-token prompts it emitted tool calls 2/3 times and wrote
`hello.txt` successfully on disk once. The platform behaved correctly in every failure
case: it detected the invalid/malformed call, retried twice, cleaned the reply,
returned `warning: invalid_tool_call` instead of leaking raw tags, and refused
escaping paths with an actionable relative-path retry hint. This is why the target is
Qwen2.5-Coder-14B-Instruct (trained for agentic tool use at long context); the 14B
generation quality remains **unmeasured** until `scripts/eval_agent.py` runs against
the deployed model.

## Round-specific verification

- Terminal: new UI panel executed `$ sandbox run auto` live and displayed the real
  backend error (runner not configured) with exit code and profile — correct behavior
  without Docker. Backend `auto` resolution has unit tests (npm project → `npm_build`,
  Python project → `python_compile`, unknown profile → 422).
- Deployment links: `/api/deployments` now returns the public `url`; frontend links it;
  regression test asserts no legacy app-origin published path is used.
- Status polling: 30-second `/api/system/status` re-check runs while the page is open.
- Runner limits: six operator env vars parsed/validated at startup (bad values abort
  startup), used in run/build/preview/install container args; compose passes them through.
- UI proof (Playwright, live engine): direct workspace open with no login screen, model pill
  (`Qwen2.5-0.5B-Instruct · cpu · none`), `Model connected · Sandbox offline`,
  explorer/editor/chat/terminal all rendered and interactive.
- Security scan: repository-wide secret scan clean (only test fixture literals);
  `.env.example` uses `REPLACE_WITH_*` placeholders; `LICENSES.md`/`NOTICE` re-checked —
  Qwen2.5-Coder-14B-Instruct license verified as Apache-2.0 against the official model
  repository LICENSE and model card.

## Account-removal round (this release)

- Full automated suite re-run after removing the account system: **195 pytest tests pass**,
  `node --check frontend/app.js` passes, all backend/runner/sandbox/deploy/scripts modules
  compile, `check_consistency.py` passes (version, env keys, API routes, stale-guidance
  tokens, VALIDATION test count), release-tree check and bash syntax checks pass.
- No-login workspace: tests assert `/api/projects`, `/api/usage`, `/api/deployments` and
  `/api/system/status` return 200 with no session/cookie, and that every former
  `/api/auth/*` endpoint answers 404 (pytest + live smoke check).
- Migration: dedicated tests build a genuine legacy multi-user SQLite database (two users,
  two projects, chat history, deployments, usage counters, storage rows) and verify that
  `init_db()` creates exactly one timestamped file backup, merges all data into the
  single-workspace schema, drops the `users` table, strips `owner_id` from project metadata,
  runs only once, and rolls back completely on an injected mid-migration failure.
- Live platform run (uvicorn on loopback, runtime workspace with a real legacy multi-user
  database): the 14 mandatory checks were executed against the running app —
  11 PASS (platform without account, UI opens directly, no login/register pages and all
  `/api/auth/*` 404, project create, save/open round-trip, real chat with the local engine,
  endpoint sweep without user-id errors, no leftover account paths/tables/files with the
  live migration verified on the real DB, security re-check including CSRF/headers/traversal/
  rate limiter, restart persistence incl. migrated legacy projects/chat and the retained
  pre-migration backup, static preview), 1 PARTIAL (agent file write with the real
  Qwen2.5-0.5B-Instruct stand-in checkpoint: the platform correctly detected and rejected
  its invalid tool calls), 2 honestly NOT RUN (terminal sandbox execution and container
  isolation require the Docker runner; no Docker daemon in this environment). Results:
  `qwen-studio-local-runtime/mandatory_test_results.json`.
- Agent E2E through the real HTTP API with a scripted OpenAI-compatible model: project →
  agent writes index.html/style.css/app.js via `write_file` → `edit_file` fixes the
  `getElementById("couter")` bug → fixed content verified on disk; all without any login
  step. UI screenshots (direct workspace open, migrated projects listed, live model status
  pill, explorer/editor/chat/terminal) captured with Playwright.
- Honest limits: Docker/gVisor sandbox, GPU inference, wildcard DNS/TLS and multi-user
  migration on real production data remain unverified in this environment (no GPU/Docker).

## Still unverified in this environment (run on a real host)

- CUDA device selection, bf16/fp16/int8/int4 on a real GPU, 14B VRAM behavior and
  14B generation quality (`scripts/eval_agent.py`).
- Docker image build, compose deployment, container weights visibility
  (`scripts/docker_check.sh`), gVisor preview isolation, live preview execution.
- Nginx/TLS topology, wildcard DNS, Verdaccio live installs, package pins (offline SKIP).

## Unlimited limits round (0.7.2)

- Every application-side limit knob now accepts **0 = unlimited**, and 0 is the shipped
  default: `MODEL_MAX_TOKENS`, `MODEL_CONTEXT_CHAR_BUDGET`, `MAX_TOOL_TURNS`,
  `MAX_CONCURRENT_CHATS` (safety ceiling 256 slots), `MAX_PROJECTS`,
  `MAX_DAILY_CHAT_REQUESTS`, `MAX_DAILY_TOOL_CALLS`, `MAX_DAILY_DEPLOYMENTS`,
  `MAX_WORKSPACE_STORAGE_BYTES`, `MAX_FILE_BYTES` (also enforced dynamically in the
  `SaveFileRequest` validator instead of the hard 500000-character body cap), and the
  12000-character chat message cap was removed. Daily counters still increment and are
  shown in the usage pill (`AI n · Tools m · unlimited`).
- `LOCAL_MODEL_MAX_CONTEXT_TOKENS=0` (auto) derives the context window from
  `max_position_embeddings` in the model's `config.json` (32768 for
  Qwen2.5-Coder-14B-Instruct); `MODEL_MAX_TOKENS=0` removes the client-side
  `max_tokens` parameter and the local engine fills the remaining context window
  dynamically (prompt budget reserves a 64-token generation floor). The loop guard
  (`_LoopGuard`) is unchanged and still stops identical repeated tool calls, and
  positive values keep the documented bounded ranges.
- 14 new tests in `tests/test_unlimited_limits.py` pin the contract (quota bypass with
  counting, positive-quota enforcement, unlimited project/file limits via the API,
  unlimited history/turns/tool-calls with the bounded variants intact, repetition still
  halted, engine auto-context and unlimited cap). Full suite: 228 passed, 0 failed,
  0 skipped in this environment.
- Honest limits: behavior identical on a real GPU host (14B engine with unlimited
  generation) and under Docker remains NOT RUN here (no GPU/Docker); the mocked-CUDA
  planner tests still cover the selection logic.
