import pytest
from backend import tools


def test_path_escape_is_rejected():
    with pytest.raises(ValueError):
        tools._safe_path("../../outside.txt")


def test_write_and_read_file(tmp_path, monkeypatch):
    monkeypatch.setattr(tools, "WORKSPACE_DIR", tmp_path)
    monkeypatch.setattr(tools, "MAX_FILE_BYTES", 1000)
    with tools.workspace_context(tmp_path):
        tools.write_file({"path": "src/main.py", "content": "print('ok')"})
        assert tools.read_file({"path": "src/main.py"})["content"] == "print('ok')"


def test_secret_paths_are_blocked():
    for candidate in (".env", ".env.production", "secrets.json", "private.pem", ".git/config"):
        with pytest.raises(ValueError):
            tools._safe_path(candidate)


def test_tool_schemas_are_valid_shape():
    names = {item["function"]["name"] for item in tools.TOOL_SCHEMAS}
    assert names == {"list_files", "read_file", "write_file", "edit_file", "append_file", "delete_file", "run_check"}


def test_project_storage_quota_enforced(tmp_path, monkeypatch):
    from backend import config
    owner_project = tmp_path / "project"
    owner_project.mkdir()
    (owner_project / "a.txt").write_text("x" * 100)
    monkeypatch.setattr(tools, "MAX_WORKSPACE_STORAGE_BYTES", 10)
    monkeypatch.setattr(tools, "_ensure_storage_quota", lambda n, p: (_ for _ in ()).throw(PermissionError("Storage quota reached")))
    with tools.workspace_context(owner_project):
        with pytest.raises(PermissionError):
            tools.write_file({"path": "b.txt", "content": "y"})


def test_symlink_access_is_rejected(tmp_path, monkeypatch):
    from backend import tools
    outside = tmp_path.parent / 'outside.txt'
    outside.write_text('private', encoding='utf-8')
    workspace = tmp_path / 'workspace'
    workspace.mkdir()
    monkeypatch.setattr(tools, 'WORKSPACE_DIR', workspace)
    (workspace / 'linked.txt').symlink_to(outside)
    with pytest.raises(ValueError, match='Symbolic links'):
        tools.read_file({'path': 'linked.txt'})


def test_edit_file_requires_exactly_one_match_and_uses_write_quota(tmp_path):
    from backend import tools
    with tools.workspace_context(tmp_path):
        tools.write_file({"path": "app.js", "content": "const title = 'old';\n"})
        result = tools.edit_file({"path": "app.js", "old_string": "'old'", "new_string": "'new'"})
        assert result["status"] == "edited"
        assert tools.read_file({"path": "app.js"})["content"] == "const title = 'new';\n"
        with pytest.raises(ValueError, match="exactly one match"):
            tools.edit_file({"path": "app.js", "old_string": "not-present", "new_string": "let"})


def test_append_file_appends_to_existing_and_creates_new_file(tmp_path):
    from backend import tools
    with tools.workspace_context(tmp_path):
        tools.write_file({"path": "notes.md", "content": "first"})
        tools.append_file({"path": "notes.md", "content": " second"})
        tools.append_file({"path": "new.txt", "content": "chunk"})
        assert tools.read_file({"path": "notes.md"})["content"] == "first second"
        assert tools.read_file({"path": "new.txt"})["content"] == "chunk"


def test_edit_and_append_respect_protected_paths(tmp_path):
    from backend import tools
    with tools.workspace_context(tmp_path):
        with pytest.raises(ValueError, match="protected"):
            tools.edit_file({"path": ".env", "old_string": "a", "new_string": "b"})
        with pytest.raises(ValueError, match="protected"):
            tools.append_file({"path": "node_modules/pkg/index.js", "content": "x"})
