"""Model manager tests: resumable download, verification, binding, deletion.

The byte-level downloader is exercised against a local fake Hub that speaks the
same wire protocol pieces the real one uses (ETag + X-Repo-Commit metadata via
HEAD, Range resumption via GET), so resume/cancel/corruption behaviour is real
HTTP behaviour, not a mock. A separate network-gated test downloads an actual
tiny Qwen2 checkpoint from the real Hugging Face Hub.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

import pytest

from backend import config as config_module
import backend.model_manager as mm
from backend.model_manager import (
    DownloadState,
    RemoteFile,
    get_manager,
    verify_local,
    _manifest_allowed,
    _sanitize_manifest_name,
)

REVISION = "cafe123deadbeef"
ETAG = '"fake-etag-1"'
# The module-level function, captured before any fixture replaces it.
REAL_ACTIVATE_RUNTIME = mm.activate_runtime
REAL_BIND_VERIFIED_MODEL = mm.bind_verified_model


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def make_fake_model() -> dict[str, bytes]:
    # Shards are sized above every TCP/buffering layer involved so that a slow
    # drip surfaces as incremental Data events client-side (small loopback
    # transfers can be delivered as one final blob, which would make an
    # artificial mid-transfer drop lose all buffered bytes at once).
    shard_a = b"A" * (2 * 1024 * 1024)
    shard_b = b"B" * (1 * 1024 * 1024)
    index = json.dumps({
        "metadata": {"total_size": len(shard_a) + len(shard_b)},
        "weight_map": {"w.a": "model-00001-of-00002.safetensors",
                       "w.b": "model-00002-of-00002.safetensors"},
    }).encode()
    files = {
        "config.json": json.dumps({
            "architectures": ["Qwen2ForCausalLM"],
            "max_position_embeddings": 1024,
            "num_hidden_layers": 1, "num_attention_heads": 2,
            "num_key_value_heads": 2, "hidden_size": 8,
        }).encode(),
        "generation_config.json": b"{}",
        "tokenizer.json": b'{"fake": true}',
        "tokenizer_config.json": b"{}",
        "vocab.json": b'{"<pad>": 0}',
        "merges.txt": b"#version\n",
        "model.safetensors.index.json": index,
        "model-00001-of-00002.safetensors": shard_a,
        "model-00002-of-00002.safetensors": shard_b,
        "LICENSE": b"Apache-2.0",
        ".gitattributes": b"should not be downloaded",
        "runme.sh": b"#!/bin/sh\nmust never be fetched",
    }
    return files


class FakeHubHandler(BaseHTTPRequestHandler):
    """Serves /resolve/main/<file> with HEAD metadata + Range-capable GET."""

    protocol_version = "HTTP/1.1"
    files: dict[str, bytes] = {}
    # behaviour overrides: {filename: ("drip", delay, step) | ("drip_drop", delay, step, drop_at)
    #                        | ("drop_after", n)}
    behaviour: dict[str, tuple] = {}
    corrupt_first: set[str] = set()
    get_counts: dict = {}
    requests: list[dict] = []
    lock = threading.Lock()

    def log_message(self, *args):  # silence the test console
        pass

    def _file_for(self, path: str) -> tuple[str, bytes] | None:
        marker = "/resolve/main/"
        if marker not in path:
            return None
        name = path.split(marker, 1)[1].split("?")[0]
        data = self.files.get(name)
        if data is None:
            return None
        return name, data

    def _absolute(self, path: str) -> str:
        host = self.headers.get("Host", "127.0.0.1")
        return f"http://{host}{path}"

    def do_HEAD(self):  # noqa: N802 - http.server API name
        found = self._file_for(self.path)
        if not found:
            self.send_error(404, "missing")
            return
        name, data = found
        self.send_response(200)
        self.send_header("ETag", ETAG)
        self.send_header("X-Repo-Commit", REVISION)
        self.send_header("X-Linked-Size", str(len(data)))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()

    def do_GET(self):  # noqa: N802 - http.server API name
        found = self._file_for(self.path)
        if not found:
            self.send_error(404, "missing")
            return
        name, data = found
        with self.lock:
            self.get_counts[name] = self.get_counts.get(name, 0) + 1
            served = data
            if name in self.corrupt_first and self.get_counts[name] == 1:
                # Same length, different bytes: the SHA-256 check must catch it.
                served = bytes(0x21 + (b % 90) for b in data)
        start = 0
        range_header = self.headers.get("Range") or ""
        if range_header.startswith("bytes="):
            start = int(range_header[6:].split("-", 1)[0] or 0)
        with self.lock:
            self.requests.append({"method": "GET", "name": name,
                                  "range": range_header, "start": start})
        behaviour = self.behaviour.get(name)
        chunk = served[start:]
        partial = start > 0
        if partial:
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{len(served) - 1}/{len(served)}")
        else:
            self.send_response(200)
        self.send_header("ETag", ETAG)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(chunk)))
        self.end_headers()
        try:
            self._emit(name, chunk, behaviour)
        except (BrokenPipeError, ConnectionResetError):
            # The client went away (pause/cancel); nothing to clean up server-side.
            self.connection.close()
            self.close_connection = True

    def _emit(self, name: str, chunk: bytes, behaviour: tuple | None) -> None:
        if behaviour and behaviour[0] == "drip_drop_once":
            # One-time outage: stream slowly (so the client persists Data events
            # as they arrive), then close mid-transfer — but only on the first
            # GET of this file. Retries get a clean, fast transfer, exactly like
            # a transient network blip.
            _, delay, step, drop_at = behaviour
            if self.get_counts.get(name, 0) > 1:
                self.wfile.write(chunk)
                return
            sent = 0
            for offset in range(0, len(chunk), step):
                piece = chunk[offset:offset + step]
                self.wfile.write(piece)
                self.wfile.flush()
                sent += len(piece)
                if sent >= drop_at:
                    self.connection.close()
                    self.close_connection = True
                    return
                time.sleep(delay)
            return
        if behaviour and behaviour[0] == "drip_drop":
            # Simulate a real connection outage: stream slowly (so the client
            # persists Data events as they arrive), then close mid-transfer.
            _, delay, step, drop_at = behaviour
            sent = 0
            for offset in range(0, len(chunk), step):
                piece = chunk[offset:offset + step]
                self.wfile.write(piece)
                self.wfile.flush()
                sent += len(piece)
                if sent >= drop_at:
                    self.connection.close()
                    self.close_connection = True
                    return
                time.sleep(delay)
            return
        if behaviour and behaviour[0] == "drop_after" and len(chunk) > behaviour[1]:
            # Emit a few bytes then slam the connection shut mid-transfer.
            self.wfile.write(chunk[:behaviour[1]])
            self.wfile.flush()
            self.connection.close()
            self.close_connection = True
            return
        if behaviour and behaviour[0] == "drip":
            _, delay, step = behaviour
            for offset in range(0, len(chunk), step):
                self.wfile.write(chunk[offset:offset + step])
                self.wfile.flush()
                time.sleep(delay)
            return
        self.wfile.write(chunk)


@pytest.fixture
def fake_hub(monkeypatch):
    """Fake Hub server + manager redirected to temp storage."""
    files = make_fake_model()
    handler = type("BoundHandler", (FakeHubHandler,), {
        "files": files, "behaviour": {}, "corrupt_first": set(),
        "get_counts": {}, "requests": [], "lock": threading.Lock(),
        "protocol_version": "HTTP/1.1",
    })
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    manifest = {
        name: RemoteFile(name=name, size=len(data),
                         sha256=_sha(data) if name.endswith(".safetensors") else None)
        for name, data in files.items()
    }

    def fake_fetch(repo_id: str) -> list[RemoteFile]:
        # The security filter must run on every manifest, exactly like the real one.
        out: list[RemoteFile] = []
        for name, entry in manifest.items():
            clean = _sanitize_manifest_name(name)
            if _manifest_allowed(clean):
                out.append(entry)
        return out

    monkeypatch.setattr(mm, "fetch_remote_manifest", fake_fetch)
    monkeypatch.setattr(mm, "HUB_ENDPOINT", base)  # unused by fake_fetch; keeps _hub_url local
    monkeypatch.setattr(mm, "MAX_ATTEMPTS_PER_FILE", 8)
    monkeypatch.setattr(mm, "RETRY_BACKOFF_SECONDS", (0.05, 0.1, 0.2, 0.4, 0.8, 1.6, 3.2, 6.4))
    yield SimpleNamespace(base=base, handler=handler, files=files, manifest=manifest,
                          filtered=[entry for name, entry in manifest.items()
                                    if _manifest_allowed(name)])
    server.shutdown()
    server.server_close()


@pytest.fixture
def model_env(tmp_path, monkeypatch):
    """Temp model dir + temp .env + reset singleton + stubbed runtime activation."""
    target = tmp_path / "models" / "Qwen2.5-Coder-14B-Instruct"
    env_file = tmp_path / ".env"
    env_file.write_text(
        "APP_ENV=development\n"
        "# app settings below\n"
        "APP_PORT=8080\n"
        "MODEL_BASE_URL=https://inference.internal:9999/v1\n"
        "MODEL_MAX_TOKENS=0\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(config_module, "LOCAL_MODEL_DIR", target)
    monkeypatch.setattr(mm, "ENV_PATH", env_file)
    monkeypatch.setattr(mm, "default_repo_id", lambda: "Qwen/Qwen2.5-Coder-14B-Instruct")
    # An explicitly configured external endpoint: binding must comment it out.
    monkeypatch.setenv("MODEL_BASE_URL", "https://inference.internal:9999/v1")
    activated: list[tuple[str, str]] = []

    def fake_activate(target_dir, model_name_value):
        activated.append((str(target_dir), model_name_value))
        return {"runtime_activated": True, "restart_required": False,
                "detail": f"stub activation for {target_dir}"}

    monkeypatch.setattr(mm, "activate_runtime", fake_activate)
    manager = get_manager()
    manager._thread = None
    manager._cancel_event.clear()
    manager._state = DownloadState(repo_id="Qwen/Qwen2.5-Coder-14B-Instruct")
    manager._last_verify = None
    manager._last_binding = None
    manager._remote_cache = None
    yield SimpleNamespace(target=target, env_file=env_file, activated=activated, manager=manager)


def wait_for_phase(manager: mm.ModelManager, phases: set[str], timeout: float = 20.0) -> str:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        phase = manager._state.phase
        if phase in phases:
            return phase
        time.sleep(0.05)
    raise AssertionError(f"download did not reach {phases}; last phase={manager._state.phase} "
                         f"error={manager._state.error}")


def place_valid_checkpoint(target: Path, files: dict[str, bytes] | None = None,
                           skip: set[str] | None = None) -> None:
    target.mkdir(parents=True, exist_ok=True)
    payload = files or make_fake_model()
    for name, data in payload.items():
        if skip and name in skip:
            continue
        if _manifest_allowed(name) and name != ".gitattributes" and name != "runme.sh":
            (target / name).write_bytes(data)


# --------------------------------------------------------------------- status

def test_status_reports_not_installed_for_empty_dir(client, model_env):
    response = client.get("/api/model/status")
    assert response.status_code == 200
    body = response.json()
    assert body["state"] == "not_installed"
    assert body["target_dir"] == str(model_env.target)
    assert body["files_state"] == "not_installed"
    assert body["engine"] is None


def test_status_detects_pre_existing_checkpoint(client, model_env):
    place_valid_checkpoint(model_env.target)
    body = client.get("/api/model/status").json()
    assert body["files_state"] == "present"
    assert body["state"] in {"present", "ready"}
    assert body["required_files_missing"] == []
    assert body["bytes_on_disk"] > 0


def test_status_reports_incomplete_when_shard_missing(client, model_env):
    place_valid_checkpoint(model_env.target, skip={"model-00002-of-00002.safetensors"})
    body = client.get("/api/model/status").json()
    assert body["state"] == "incomplete"
    assert any("model-00002" in item for item in body["required_files_missing"])


# ------------------------------------------------------------------- download

def test_download_fetches_only_model_files_and_binds(client, model_env, fake_hub):
    response = client.post("/api/model/download")
    assert response.status_code == 202
    assert response.json()["started"] is True
    wait_for_phase(model_env.manager, {"done"}, timeout=30)
    # Only allowlisted artefacts land on disk; scripts and repo metadata never do.
    present = {path.name for path in model_env.target.rglob("*") if path.is_file()}
    assert "runme.sh" not in present
    assert ".gitattributes" not in present
    assert "config.json" in present
    assert "model-00001-of-00002.safetensors" in present
    # No leftover partial files.
    assert not list(model_env.target.rglob("*.part"))
    # Auto-binding wrote .env and activated the (stubbed) runtime.
    env_text = model_env.env_file.read_text(encoding="utf-8")
    assert "LOCAL_INFERENCE=true" in env_text
    assert "MODEL_BASE_URL" in env_text  # present, but as a comment
    assert "# disabled by model manager" in env_text
    assert f"LOCAL_MODEL_DIR={model_env.target}" in env_text  # non-default dir is recorded
    assert model_env.activated and model_env.activated[0][1] == "Qwen2.5-Coder-14B-Instruct"
    state = model_env.manager._state
    assert state.total_bytes == sum(entry.size for entry in fake_hub.filtered)
    assert state.completed == {entry.name for entry in fake_hub.filtered}


def test_download_reports_not_enough_disk_space(client, model_env, fake_hub, monkeypatch):
    monkeypatch.setattr(mm, "check_disk_space", lambda path, needed: (False, 1024))
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"error"})
    state = model_env.manager._state
    assert "Not enough disk space" in state.error
    assert "GiB" in state.error
    assert "Free up space" in state.error
    assert any("Download again" in tip for tip in state.suggestions)
    if model_env.target.exists():
        assert not list(model_env.target.rglob("*"))


def test_resume_after_dropped_connection_does_not_refetch(client, model_env, fake_hub, monkeypatch):
    # A real-world outage: bytes stream for a while (several 64 KiB client
    # chunks complete), then the connection dies ONCE. The retry must resume
    # with Range from the persisted .part offset instead of restarting the file.
    big = fake_hub.files["model-00001-of-00002.safetensors"]
    fake_hub.handler.behaviour["model-00001-of-00002.safetensors"] = ("drip_drop_once", 0.002, 2_000, 200_000)
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"done"}, timeout=40)
    shard_requests = [item for item in fake_hub.handler.requests
                      if item["name"] == "model-00001-of-00002.safetensors"]
    assert len(shard_requests) >= 2
    assert shard_requests[0]["range"] == ""  # fresh start
    resumed = shard_requests[1]
    assert resumed["range"].startswith("bytes=")
    resume_offset = int(resumed["range"][6:].split("-", 1)[0])
    assert 0 < resume_offset < len(big)  # resumed mid-file, not a restart
    final = (model_env.target / "model-00001-of-00002.safetensors").read_bytes()
    assert final == big


def test_pause_keeps_partial_file_and_resume_completes(client, model_env, fake_hub):
    big = fake_hub.files["model-00001-of-00002.safetensors"]
    fake_hub.handler.behaviour["model-00001-of-00002.safetensors"] = ("drip", 0.005, 2_000)
    client.post("/api/model/download")
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        part = model_env.target / "model-00001-of-00002.safetensors.part"
        if part.exists() and part.stat().st_size > 8_000:
            break
        time.sleep(0.02)
    response = client.post("/api/model/cancel")
    assert response.status_code == 200
    wait_for_phase(model_env.manager, {"paused"}, timeout=20)
    part = model_env.target / "model-00001-of-00002.safetensors.part"
    assert part.exists() and 0 < part.stat().st_size < len(big)
    # Resume: same endpoint, the .part file is reused, download completes.
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"done"}, timeout=30)
    assert not part.exists()
    assert (model_env.target / "model-00001-of-00002.safetensors").read_bytes() == big


def test_second_download_conflicts_while_first_runs(client, model_env, fake_hub, monkeypatch):
    release = threading.Event()

    def blocked_fetch(repo_id):
        release.wait(timeout=30)
        return list(fake_hub.manifest.values())

    monkeypatch.setattr(mm, "fetch_remote_manifest", blocked_fetch)
    started = client.post("/api/model/download")
    assert started.status_code == 202
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline and model_env.manager._state.phase != "fetching_manifest":
        time.sleep(0.05)
    conflict = client.post("/api/model/download")
    assert conflict.status_code == 409
    cancel = client.post("/api/model/cancel")
    assert cancel.status_code == 200
    release.set()
    wait_for_phase(model_env.manager, {"paused"})


def test_corrupted_existing_shard_is_replaced(client, model_env, fake_hub):
    place_valid_checkpoint(model_env.target, skip={"model-00001-of-00002.safetensors"})
    (model_env.target / "model-00001-of-00002.safetensors").write_bytes(b"CORRUPT" * 100)
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"done"}, timeout=30)
    final = (model_env.target / "model-00001-of-00002.safetensors").read_bytes()
    assert final == fake_hub.files["model-00001-of-00002.safetensors"]
    verify = model_env.manager._last_verify
    assert verify["valid"] is True


def test_download_endpoint_unreachable_reports_clear_error(client, model_env, monkeypatch):
    def failing_fetch(repo_id):
        raise mm.ModelManagerError(
            "Could not reach the Hugging Face Hub for repository "
            f"{repo_id} (connection refused). Check the internet connection "
            "and that the repository name is correct, then try again.")

    monkeypatch.setattr(mm, "fetch_remote_manifest", failing_fetch)
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"error"})
    state = model_env.manager._state
    assert "Could not reach the Hugging Face Hub" in state.error
    assert "internet" in state.error
    assert any("Download again" in tip for tip in state.suggestions)


def test_checksum_mismatch_is_detected_and_retried(client, model_env, fake_hub):
    """A poisoned first GET must fail the SHA-256 gate, then heal on retry."""
    shard_b = "model-00002-of-00002.safetensors"
    fake_hub.handler.corrupt_first.add(shard_b)
    client.post("/api/model/download")
    wait_for_phase(model_env.manager, {"done"}, timeout=30)
    assert fake_hub.handler.get_counts[shard_b] >= 2  # first pass failed, retry healed
    assert (model_env.target / shard_b).read_bytes() == fake_hub.files[shard_b]
    assert model_env.manager._last_verify["valid"] is True


# ----------------------------------------------------------------- verify etc.

def test_verify_reports_missing_and_size_mismatch(client, model_env):
    place_valid_checkpoint(model_env.target, skip={"model-00002-of-00002.safetensors"})
    (model_env.target / "tokenizer.json").write_bytes(b'{"tampered": true}')
    manifest = [RemoteFile(name="tokenizer.json", size=999),
                RemoteFile(name="model-00002-of-00002.safetensors", size=48_000)]
    result = verify_local(model_env.target, manifest)
    assert result["valid"] is False
    joined = " ".join(result["reasons"])
    assert "model-00002-of-00002.safetensors" in joined   # missing shard via index.json
    assert "tokenizer.json" in joined                     # size mismatch
    assert result["suggestions"]


def test_verify_offline_passes_for_complete_manual_checkpoint(client, model_env):
    place_valid_checkpoint(model_env.target)
    result = verify_local(model_env.target, None)
    assert result["valid"] is True
    assert result["architectures"] == ["Qwen2ForCausalLM"]


def test_verify_endpoint_and_bind(client, model_env):
    place_valid_checkpoint(model_env.target)
    response = client.post("/api/model/verify?bind=true")
    assert response.status_code == 200
    body = response.json()
    assert body["verified"]["valid"] is True
    binding = body["binding"]
    assert binding["local_inference_enabled"] is True
    assert binding["runtime_activated"] is True
    env_text = model_env.env_file.read_text(encoding="utf-8")
    assert "LOCAL_INFERENCE=true" in env_text
    assert f"LOCAL_MODEL_DIR={model_env.target}" in env_text


def test_bind_existing_path_rejects_incomplete_directory(client, model_env, tmp_path):
    other = tmp_path / "elsewhere"
    other.mkdir()
    (other / "config.json").write_text("{}")
    (other / "README.md").write_text("no weights here")
    response = client.post("/api/model/path", json={"path": str(other)})
    assert response.status_code == 400
    assert "safetensors" in response.json()["detail"]
    # .env must stay untouched after the rejection.
    assert "LOCAL_INFERENCE" not in model_env.env_file.read_text(encoding="utf-8")


def test_bind_existing_path_accepts_full_checkpoint(client, model_env, tmp_path):
    other = tmp_path / "elsewhere"
    place_valid_checkpoint(other)
    response = client.post("/api/model/path", json={"path": str(other)})
    assert response.status_code == 200
    env_text = model_env.env_file.read_text(encoding="utf-8")
    assert f"LOCAL_MODEL_DIR={other}" in env_text
    assert "LOCAL_INFERENCE=true" in env_text


def test_delete_requires_confirmation_then_removes_files(client, model_env):
    place_valid_checkpoint(model_env.target)
    denied = client.post("/api/model/delete", json={"confirm": False})
    assert denied.status_code == 400
    assert model_env.target.exists()
    allowed = client.post("/api/model/delete", json={"confirm": True})
    assert allowed.status_code == 200
    assert allowed.json()["deleted"] is True
    assert allowed.json()["bytes_removed"] > 0
    assert not model_env.target.exists()
    assert "LOCAL_INFERENCE=false" in model_env.env_file.read_text(encoding="utf-8")


def test_delete_refuses_protected_directories(client, model_env, monkeypatch, tmp_path):
    monkeypatch.setattr(config_module, "LOCAL_MODEL_DIR", config_module.BASE_DIR / "models")
    response = client.post("/api/model/delete", json={"confirm": True})
    assert response.status_code == 400
    assert "Refusing to delete" in response.json()["detail"]


def test_delete_refuses_workspace_and_publish_dirs(client, model_env, monkeypatch):
    monkeypatch.setattr(config_module, "LOCAL_MODEL_DIR", config_module.WORKSPACE_DIR)
    assert client.post("/api/model/delete", json={"confirm": True}).status_code == 400
    monkeypatch.setattr(config_module, "LOCAL_MODEL_DIR", config_module.PUBLISH_DIR)
    assert client.post("/api/model/delete", json={"confirm": True}).status_code == 400


# ------------------------------------------------------------------ unit level

def test_manifest_security_filter():
    assert _manifest_allowed("config.json")
    assert _manifest_allowed("model-00001-of-00006.safetensors")
    assert _manifest_allowed("model.safetensors.index.json")
    assert _manifest_allowed("merges.txt")
    assert _manifest_allowed("chat_template.jinja")
    assert _manifest_allowed("LICENSE")
    assert not _manifest_allowed("runme.sh")
    assert not _manifest_allowed("toolkit.exe")
    assert not _manifest_allowed("pytorch_model.bin")
    assert not _manifest_allowed("payload.zip")
    assert not _manifest_allowed("helper.py")
    assert not _manifest_allowed("server.pem")
    with pytest.raises(mm.ModelManagerError):
        _sanitize_manifest_name("../escape.safetensors")
    with pytest.raises(mm.ModelManagerError):
        _sanitize_manifest_name("/absolute/path.safetensors")
    with pytest.raises(mm.ModelManagerError):
        _sanitize_manifest_name("bad\\name.safetensors")
    with pytest.raises(mm.ModelManagerError):
        _sanitize_manifest_name("a/../b.safetensors")


def test_env_editor_preserves_unrelated_content(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text(
        "APP_ENV=development\n"
        "APP_PORT=8080\n"
        "MODEL_BASE_URL=https://inference.internal:9999/v1\n"
        "# keep this comment\n"
        "LOCAL_INFERENCE=false\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(mm, "ENV_PATH", env_file)
    changes = mm._write_env_file({"LOCAL_INFERENCE": "true"}, ["MODEL_BASE_URL"])
    text = env_file.read_text(encoding="utf-8")
    assert "LOCAL_INFERENCE=true" in text
    assert "# disabled by model manager (local model enabled): MODEL_BASE_URL=https://inference.internal:9999/v1" in text
    assert "APP_PORT=8080" in text
    assert "# keep this comment" in text
    assert "APP_ENV=development" in text
    assert any("LOCAL_INFERENCE=true" in change for change in changes)
    assert any("commented out MODEL_BASE_URL" in change for change in changes)


def test_env_editor_appends_missing_keys(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text("APP_ENV=development\n", encoding="utf-8")
    monkeypatch.setattr(mm, "ENV_PATH", env_file)
    mm._write_env_file({"LOCAL_INFERENCE": "true", "LOCAL_MODEL_DIR": "/tmp/x"}, [])
    text = env_file.read_text(encoding="utf-8")
    assert text.startswith("APP_ENV=development\n")
    assert "LOCAL_INFERENCE=true" in text
    assert "LOCAL_MODEL_DIR=/tmp/x" in text


def test_real_runtime_activation_wires_config_and_agent(monkeypatch, model_env):
    """The real activate_runtime mutates config/agent modules and starts the engine."""
    import inference.server as inference_server
    import backend.agent as agent_module
    import backend.app as app_module

    recorded: dict = {}

    def fake_start(**kwargs):
        recorded.update(kwargs)

    monkeypatch.setattr(mm, "activate_runtime", REAL_ACTIVATE_RUNTIME)
    monkeypatch.setattr(inference_server, "start_local_inference", fake_start)
    saved_config = (config_module.LOCAL_INFERENCE, config_module.MODEL_BASE_URL,
                    config_module.MODEL_NAME)
    saved_agent = (agent_module.MODEL_BASE_URL, agent_module.MODEL_NAME)
    saved_client = app_module.agent.client
    saved_app_local = app_module.LOCAL_INFERENCE
    try:
        result = REAL_ACTIVATE_RUNTIME(model_env.target, "Qwen2.5-Coder-14B-Instruct")
        assert result["runtime_activated"] is True
        assert recorded["model_dir"] == str(model_env.target)
        assert recorded["model_name"] == "Qwen2.5-Coder-14B-Instruct"
        loopback = recorded["host"] and recorded["port"]
        assert loopback
        assert config_module.LOCAL_INFERENCE is True
        assert config_module.MODEL_BASE_URL == (
            f"http://{config_module.LOCAL_INFERENCE_HOST}:{config_module.LOCAL_INFERENCE_PORT}/v1")
        assert agent_module.MODEL_BASE_URL == config_module.MODEL_BASE_URL
        assert agent_module.MODEL_NAME == "Qwen2.5-Coder-14B-Instruct"
        assert app_module.LOCAL_INFERENCE is True  # /api/system/status reports model.local
        assert app_module.agent.client is None  # rebuilt lazily against the loopback engine
    finally:
        (config_module.LOCAL_INFERENCE, config_module.MODEL_BASE_URL,
         config_module.MODEL_NAME) = saved_config
        (agent_module.MODEL_BASE_URL, agent_module.MODEL_NAME) = saved_agent
        app_module.agent.client = saved_client
        app_module.LOCAL_INFERENCE = saved_app_local


def test_real_bind_verified_model_writes_env(monkeypatch, model_env):
    """The real bind_verified_model persists LOCAL_INFERENCE + comments external URLs."""
    monkeypatch.setattr(mm, "activate_runtime", REAL_ACTIVATE_RUNTIME)
    monkeypatch.setattr(mm, "bind_verified_model", REAL_BIND_VERIFIED_MODEL)
    import inference.server as inference_server
    import backend.agent as agent_module
    import backend.app as app_module

    def fake_start(**kwargs):
        pass

    monkeypatch.setattr(inference_server, "start_local_inference", fake_start)
    saved_config = (config_module.LOCAL_INFERENCE, config_module.MODEL_BASE_URL,
                    config_module.MODEL_NAME)
    saved_agent = (agent_module.MODEL_BASE_URL, agent_module.MODEL_NAME)
    saved_client = app_module.agent.client
    saved_app_local = app_module.LOCAL_INFERENCE
    try:
        binding = REAL_BIND_VERIFIED_MODEL(model_env.target, "Qwen2.5-Coder-14B-Instruct")
        assert binding["local_inference_enabled"] is True
        assert binding["external_endpoint_commented"] is True
        assert binding["previous_model_base_url"] == "https://inference.internal:9999/v1"
        text = model_env.env_file.read_text(encoding="utf-8")
        assert "LOCAL_INFERENCE=true" in text
        assert "# disabled by model manager" in text
    finally:
        (config_module.LOCAL_INFERENCE, config_module.MODEL_BASE_URL,
         config_module.MODEL_NAME) = saved_config
        (agent_module.MODEL_BASE_URL, agent_module.MODEL_NAME) = saved_agent
        app_module.agent.client = saved_client
        app_module.LOCAL_INFERENCE = saved_app_local


# ------------------------------------------------------- real Hugging Face Hub

def _hub_reachable() -> bool:
    import httpx
    try:
        response = httpx.get("https://huggingface.co/api/models/Qwen/Qwen2.5-Coder-14B-Instruct",
                             timeout=8.0)
        return response.status_code == 200
    except Exception:  # noqa: BLE001
        return False


def test_real_hub_end_to_end_download_of_tiny_qwen_checkpoint(tmp_path, monkeypatch):
    """REAL download from huggingface.co of trl-internal-testing/tiny-Qwen2ForCausalLM-2.5.

    Skipped (NOT RUN) when the Hub is unreachable from the test machine; it is
    never simulated. Uses the exact production code path (manifest API, HEAD
    metadata, Range resume, SHA-256 verification) against the real endpoint.
    """
    if not _hub_reachable():
        pytest.skip("NOT RUN: huggingface.co unreachable from this machine")
    repo_id = "trl-internal-testing/tiny-Qwen2ForCausalLM-2.5"
    target = tmp_path / "tiny-qwen2"
    monkeypatch.setattr(config_module, "LOCAL_MODEL_DIR", target)
    monkeypatch.setattr(mm, "ENV_PATH", tmp_path / ".env")
    monkeypatch.setattr(mm, "default_repo_id", lambda: repo_id)
    monkeypatch.setattr(mm, "activate_runtime", lambda *a, **k: {
        "runtime_activated": True, "restart_required": False, "detail": "stub"})
    manager = get_manager()
    manager._thread = None
    manager._cancel_event.clear()
    manager._state = DownloadState(repo_id=repo_id)
    manager._last_verify = None
    manager._last_binding = None
    manager._remote_cache = None
    remote = manager.remote_info()
    assert remote["total_bytes"] > 1_000_000  # ~20.7 MiB real checkpoint
    assert remote["files"]
    manager.start_download()
    wait_for_phase(manager, {"done"}, timeout=240)
    verify = manager._last_verify
    assert verify["valid"] is True, verify["reasons"]
    on_disk = {path.name for path in target.rglob("*") if path.is_file()}
    assert "config.json" in on_disk
    assert "model.safetensors" in on_disk
    assert "tokenizer.json" in on_disk
    assert (target / "model.safetensors").stat().st_size > 1_000_000
    assert not list(target.rglob("*.part"))
