"""FINAL PATCH contract tests - Windows installer (install.bat) CMD semantics.

The previous install.bat read %TORCH_BUILD% / %TORCH_INDEX_URL% inside parenthesized
blocks, so CMD expanded them at PARSE time with stale/empty values: the auto-detect
path installed the CPU build on NVIDIA machines and even the explicit path passed an
empty --index-url to pip. It also invoked PowerShell for .env creation while its
header claimed to be PowerShell-free. These tests pin the corrected contract.

Real cmd.exe execution is NOT RUN in this environment (Linux host, no wine/Windows CI);
the contracts below are enforced by a structural scanner that models CMD's parenthesized
block parsing (quote- and escape-aware) plus live checks of the shared Python pieces.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
INSTALL_BAT = ROOT / "scripts" / "install.bat"
INSTALL_SH = ROOT / "scripts" / "install.sh"
DOCKERFILE = ROOT / "Dockerfile"
COMPOSE = ROOT / "compose.yaml"
CHECK_TORCH = ROOT / "scripts" / "check_torch.py"
REQS_LOCAL = ROOT / "requirements-local-model.txt"
CPU_INDEX = "https://download.pytorch.org/whl/cpu"
CUDA_INDEX = "https://download.pytorch.org/whl/cu124"
TORCH_PIN = "torch==2.6.0"

# Variables that are SET inside parenthesized blocks and therefore MUST be read
# with delayed expansion (!VAR!) everywhere inside those blocks.
BLOCK_MUTATED_VARS = ("TORCH_BUILD", "TORCH_INDEX_URL", "TORCH_STATE", "VALID_ARG", "WITH_MODEL")


def bat_text() -> str:
    return INSTALL_BAT.read_text(encoding="utf-8")


def bat_lines() -> list[str]:
    return bat_text().splitlines()


# ------------------------------------------------------------------- scanner


def _strip_quotes_escapes_and_rems(line: str) -> str:
    """Remove REM comments, double-quoted strings and ^-escaped characters so the
    remaining parens are exactly the ones CMD's block parser acts upon."""
    out = []
    i = 0
    # Drop REM comment tail (REM at a command position; our file only uses full/inline REM lines)
    stripped = re.sub(r"(?:^|\s)REM\s.*$", "", line)
    while i < len(stripped):
        ch = stripped[i]
        if ch == "^" and i + 1 < len(stripped):
            i += 2  # escaped char: literal for the parser
            continue
        if ch == '"':
            i += 1
            while i < len(stripped) and stripped[i] != '"':
                i += 1
            i += 1  # skip the quoted string content
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def bat_block_depth_profile() -> list[tuple[int, str]]:
    """Return (depth, line) for every non-empty line, after block parsing normalization."""
    profile: list[tuple[int, str]] = []
    depth = 0
    for raw in bat_lines():
        stripped = _strip_quotes_escapes_and_rems(raw)
        profile.append((depth, raw))
        for ch in stripped:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                assert depth >= 0, "install.bat closes more parens than it opens"
    assert depth == 0, "install.bat parenthesized blocks are not balanced"
    return profile


# ------------------------------------------------- 1./2. CPU and CUDA choice


def test_bat_cpu_choice_maps_to_cpu_index():
    mapping = next(
        line for line in bat_lines() if "TORCH_INDEX_URL=" in line and "else" in line
    )
    assert '!TORCH_BUILD!' in mapping, "the index choice must read the RUNTIME build (delayed expansion)"
    # Order matters: cuda -> cu124 in the IF branch, cpu -> CPU index in the ELSE branch.
    cuda_pos, else_pos = mapping.find('"cuda"'), mapping.find(") else (")
    cuda_url, cpu_url = mapping.find(CUDA_INDEX), mapping.find(CPU_INDEX)
    assert 0 <= cuda_pos < cuda_url < else_pos < cpu_url


def test_bat_cuda_choice_flags_set_cuda_build():
    text = bat_text()
    assert '( set "TORCH_BUILD=cuda" & set "VALID_ARG=1" )' in text  # --cuda and --gpu
    assert text.count('set "TORCH_BUILD=cuda"') == 3  # explicit flags + NVIDIA detection
    assert text.count('set "TORCH_BUILD=cpu"') == 3  # no-nvidia-smi + no usable GPU + (--cpu counted separately)
    assert '( set "TORCH_BUILD=cpu" & set "VALID_ARG=1" )' in text


# ------------------------------- 3./4. correct passing, no stale %VAR% reads


def test_bat_passes_pinned_torch_and_runtime_index_to_pip():
    text = bat_text()
    pip_lines = [line for line in bat_lines() if "pip install" in line and "torch==" in line]
    assert len(pip_lines) == 2, "torch install happens in the missing-state and switch branches"
    for line in pip_lines:
        assert f'"{TORCH_PIN}"' in line and "--index-url !TORCH_INDEX_URL!" in line


def test_bat_checker_receives_the_runtime_build_flag():
    checker = next(line for line in bat_lines() if "check_torch.py" in line and "python" in line)
    assert "--!TORCH_BUILD!" in checker and "--check-model-extra" in checker


def test_bat_never_reads_block_mutated_vars_with_percent_inside_blocks():
    """The FINAL PATCH core fix: inside any parenthesized block, a variable that the
    block mutates must be read as !VAR!, never %VAR% (CMD expands %VAR% at parse time)."""
    for depth, raw in bat_block_depth_profile():
        if depth == 0:
            continue
        code = re.sub(r"(?:^|\s)REM\s.*$", "", raw)  # ignore comment tails
        for var in BLOCK_MUTATED_VARS:
            assert f"%{var}%" not in code, (
                f"stale %VAR% expansion of {var} inside a block (line: {raw.strip()})"
            )


def test_bat_delayed_expansion_scope_is_correct():
    lines = bat_lines()
    disable_idx = next(i for i, l in enumerate(lines) if "DisableDelayedExpansion" in l)
    cd_idx = next(i for i, l in enumerate(lines) if l.startswith('cd /d "%~dp0.."'))
    enable_idx = next(i for i, l in enumerate(lines) if "EnableDelayedExpansion" in l and "Disable" not in l)
    assert disable_idx < cd_idx < enable_idx, (
        "path handling must run WITHOUT delayed expansion (survives '!' in paths); "
        "delayed expansion is enabled only afterwards"
    )


# ------------------------------------------------------ 5. no PowerShell dependency


def test_bat_has_no_powershell_dependency():
    # No executable line may invoke PowerShell (the header REM that says
    # "PowerShell-free" documents exactly that and is allowed).
    for line in bat_lines():
        code = re.sub(r"(?:^|\s)REM\s.*$", "", line)
        assert "powershell" not in code.lower(), f"PowerShell invocation found: {line.strip()}"
    # .env creation is done with pure Python - same logic as install.sh
    env_line = next(line for line in bat_lines() if "pathlib,secrets" in line)
    for token in ("APP_ENV=production", "APP_ENV=development",
                  "REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARACTERS", "secrets.token_urlsafe"):
        assert token in env_line
    assert "copy .env.example .env" in bat_text()


# ------------------------------------------- 6. paths with spaces and quoting


def test_bat_handles_paths_with_spaces_and_quoted_arguments():
    text = bat_text()
    assert 'cd /d "%~dp0.."' in text, "project jump must be quoted (paths with spaces)"
    assert "%%~a" in text, "arguments must be quote-stripped before comparison"
    assert 'call .venv\\Scripts\\activate.bat' in text, "activate via relative path, no rescan of the path"
    assert "if not defined VIRTUAL_ENV" in text, "must refuse to install into the global Python"


# --------------------------------- 7. exit codes and no fake success message


def test_bat_every_pip_operation_is_error_checked():
    lines = bat_lines()
    for i, line in enumerate(lines):
        code = re.sub(r"(?:^|\s)REM\s.*$", "", line)
        if re.search(r"\bpip (install|uninstall)\b", code):
            window = "\n".join(lines[i + 1 : i + 3])
            abort_window = "\n".join(lines[i + 1 : i + 5])
            assert "if errorlevel 1" in window, f"unchecked pip operation: {line.strip()}"
            assert "exit /b 1" in abort_window, f"pip failure must abort with exit /b 1: {line.strip()}"


def test_bat_success_message_only_after_all_failure_exits():
    lines = bat_lines()
    complete_idx = next(i for i, l in enumerate(lines) if "Install complete" in l)
    last_error_exit = max(i for i, l in enumerate(lines) if "exit /b 1" in l)
    checker_idx = next(i for i, l in enumerate(lines) if "check_torch.py" in l and "python" in l)
    assert checker_idx < last_error_exit < complete_idx, (
        "the success banner must be reachable only after the real verification passed"
    )


def test_bat_rejects_bad_input_before_any_install_step():
    text = bat_text()
    assert "exit /b 2" in text and "Unknown option" in text
    assert "--cpu/--cuda only make sense together with --with-model" in text


# ------------------------------------- 8. version consistency across platforms


def test_versions_consistent_across_linux_windows_docker():
    for path in (INSTALL_SH, INSTALL_BAT, DOCKERFILE):
        assert TORCH_PIN in path.read_text(encoding="utf-8"), f"{path.name} must pin {TORCH_PIN}"
    for path in (INSTALL_SH, INSTALL_BAT, DOCKERFILE):
        text = path.read_text(encoding="utf-8")
        assert CUDA_INDEX in text and CPU_INDEX in text
    compose = COMPOSE.read_text(encoding="utf-8")
    assert f"TORCH_INDEX_URL: {CPU_INDEX}" in compose  # CPU service default unchanged
    assert f"TORCH_INDEX_URL: {CUDA_INDEX}" in compose  # GPU service
    local_reqs = REQS_LOCAL.read_text(encoding="utf-8")
    assert "torch>=2.4" in local_reqs, "CPU requirements must stay unchanged"
    assert "bitsandbytes>=0.44" in local_reqs and "transformers>=4.46" in local_reqs


def test_dockerfile_gpu_image_never_installs_cpu_torch():
    model_stage = next(
        line for line in DOCKERFILE.read_text(encoding="utf-8").splitlines()
        if "torch==" in line
    )
    assert "--index-url \"$TORCH_INDEX_URL\"" in model_stage, (
        "the GPU build must take torch from the build-arg index, never from PyPI/CPU"
    )


# ----------------------------------- 10. CPU install path is not regressed


def test_cpu_install_path_not_regressed():
    text = bat_text()
    sh = INSTALL_SH.read_text(encoding="utf-8")
    # Both installers still fall back to the CPU build when no NVIDIA GPU is present.
    assert text.count("no NVIDIA GPU detected - installing the CPU torch build") == 1
    assert "no usable NVIDIA GPU detected - installing the CPU torch build" in text
    assert "-> installing the CPU torch build" in sh
    # The CPU index is still the same official index, now with the same pinned version.
    assert f'"{TORCH_PIN}" --index-url !TORCH_INDEX_URL!' in text
    assert f'"torch==2.6.0" --index-url "$TORCH_INDEX_URL"' in sh
    # Existing compatible torch builds are reused, not reinstalled (CPU regression guard).
    assert "reusing the existing" in text and "reusing the existing" in sh


# ------------------------------------------------ mandatory CLI sanity (live)


def test_check_torch_cpu_with_model_extra_cli_matches_environment():
    """The exact mandatory command from the release checklist, executed here.
    Honest either way: exit 0 with PASS when torch + the extra are installed,
    exit 2 when torch is missing, exit 3 when the model extra is incomplete -
    never a fake pass."""
    result = subprocess.run(
        [sys.executable, str(CHECK_TORCH), "--cpu", "--check-model-extra"],
        capture_output=True, text=True, timeout=120,
    )
    output = result.stdout + result.stderr
    if "PASS  model-extra dependencies import cleanly" in output:
        assert result.returncode == 0
    elif "torch is not installed" in output:
        assert result.returncode == 2
    else:
        assert result.returncode == 3
        assert "the local-model extra is incomplete" in output


def test_check_torch_reports_vram_and_bf16_fields():
    """The report schema now includes measured VRAM per device and a BF16 hint line;
    validated on the synthetic decision core so the field wiring is pinned without a GPU."""
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import check_torch
    finally:
        sys.path.pop(0)
    gpu_state = {
        "torch_installed": True, "import_error": None, "torch_version": "2.6.0",
        "build_cuda": "12.4", "cuda_available": True, "device_count": 1,
        "device_names": ["NVIDIA Tesla T4"], "device_vram_gib": [15.0],
        "bf16_supported": False,
    }
    code, lines = check_torch.evaluate("cuda", gpu_state)
    assert code == 0
    joined = "\n".join(lines)
    assert "NVIDIA Tesla T4, VRAM 15.0 GiB" in joined
    assert "no BF16 tensor cores (pre-Ampere, e.g. T4)" in joined
    assert "quantization=auto picks fp16 compute dtype" in joined


@pytest.mark.parametrize("flag", ["--cpu", "--cuda"])
def test_bat_flags_are_documented_in_header(flag):
    assert flag in bat_text()
