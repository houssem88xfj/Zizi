from backend.domains import registrable_domain
from backend.config import origins_share_parent_domain
from deploy.preflight import warnings as preflight_warnings


def test_common_single_label_suffix_hosts_share_registrable_domain():
    assert origins_share_parent_domain(
        "https://studio.example.com",
        "https://preview.example.com",
        "https://sites.example.com",
    ) is True
    assert registrable_domain("studio.example.com") == "example.com"


def test_com_dz_sibling_registrable_domains_are_distinct():
    assert registrable_domain("studio.a.com.dz") == "a.com.dz"
    assert registrable_domain("x.b.com.dz") == "b.com.dz"
    assert origins_share_parent_domain(
        "https://studio.a.com.dz",
        "https://x.b.com.dz",
        "https://sites.example.com.dz",
    ) is False


def test_com_dz_same_registrable_domain_is_detected():
    assert registrable_domain("studio.example.com.dz") == "example.com.dz"
    assert origins_share_parent_domain(
        "https://studio.example.com.dz",
        "https://preview.example.com.dz",
        "https://sites.example.com.dz",
    ) is True


def test_co_uk_registrable_domains_are_distinct():
    assert registrable_domain("a.co.uk") == "a.co.uk"
    assert registrable_domain("b.co.uk") == "b.co.uk"
    assert origins_share_parent_domain(
        "https://a.co.uk",
        "https://b.co.uk",
        "https://c.co.uk",
    ) is False


def test_bare_two_label_domain_and_ip_localhost_handling():
    assert registrable_domain("example.net") == "example.net"
    assert registrable_domain("192.0.2.10") is None
    assert registrable_domain("localhost") is None
    assert origins_share_parent_domain(
        "https://192.0.2.10",
        "http://localhost:8080",
        "https://studio.example.net",
    ) is False


def test_preflight_warning_uses_registrable_domain_not_last_two_labels():
    values = {
        "APP_ENV": "production",
        "PUBLIC_BASE_URL": "https://studio.example.com.dz",
        "PREVIEW_BASE_URL": "https://preview.example.com.dz",
        "PUBLISH_BASE_URL": "https://sites.example.com.dz",
    }
    notices = preflight_warnings(values)
    assert len(notices) == 1
    assert "separate registered domain" in notices[0]

    values["PUBLIC_BASE_URL"] = "https://studio.a.com.dz"
    values["PREVIEW_BASE_URL"] = "https://x.b.com.dz"
    assert preflight_warnings(values) == []


def test_preflight_does_not_warn_for_ip_or_localhost_hosts():
    values = {
        "APP_ENV": "production",
        "PUBLIC_BASE_URL": "http://127.0.0.1:8080",
        "PREVIEW_BASE_URL": "http://localhost:8081",
        "PUBLISH_BASE_URL": "http://192.0.2.20",
    }
    assert preflight_warnings(values) == []
