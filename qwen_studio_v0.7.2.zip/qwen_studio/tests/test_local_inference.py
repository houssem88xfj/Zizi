"""Local weights inference tests: HTTP layer + tool-call parsing (no torch required)."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from inference.engine import EngineNotReady, LocalModelEngine, split_tool_calls
from inference.server import create_app


class StubEngine:
    """Duck-typed engine so the HTTP layer is testable without torch."""

    model_name = "stub-model"
    status = {"enabled": True, "loaded": True, "loading": False, "weights_present": True,
              "device": "stub", "quantization": "none", "error": None}

    def __init__(self, response=None, error: Exception | None = None) -> None:
        self._response = response or {
            "id": "chatcmpl-stub", "object": "chat.completion", "created": 0,
            "model": "stub-model",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        self._error = error
        self.calls: list[dict] = []

    def chat_completion(self, payload: dict):
        self.calls.append(payload)
        if self._error is not None:
            raise self._error
        if payload.get("stream"):
            raise ValueError("Streaming responses are not supported by the local engine.")
        return self._response


def _client(engine: StubEngine) -> TestClient:
    return TestClient(create_app(engine))  # type: ignore[arg-type]


def test_v1_models_lists_local_model():
    engine = StubEngine()
    with _client(engine) as client:
        response = client.get("/v1/models")
    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "list"
    assert body["data"][0]["id"] == "stub-model"


def test_chat_completion_round_trip_passes_tools_through():
    engine = StubEngine()
    tools = [{"type": "function", "function": {"name": "list_files", "parameters": {"type": "object"}}}]
    with _client(engine) as client:
        response = client.post("/v1/chat/completions", json={
            "model": "stub-model",
            "messages": [{"role": "user", "content": "hi"}],
            "tools": tools,
            "temperature": 0.2,
            "max_tokens": 128,
        })
    assert response.status_code == 200
    assert response.json()["choices"][0]["message"]["content"] == "ok"
    assert engine.calls[0]["tools"][0]["function"]["name"] == "list_files"
    assert engine.calls[0]["max_tokens"] == 128


def test_streaming_requests_rejected_with_400():
    engine = StubEngine()
    with _client(engine) as client:
        response = client.post("/v1/chat/completions", json={
            "messages": [{"role": "user", "content": "hi"}], "stream": True,
        })
    assert response.status_code == 400


def test_not_ready_returns_503():
    engine = StubEngine(error=EngineNotReady("Local model is still loading."))
    with _client(engine) as client:
        response = client.post("/v1/chat/completions", json={
            "messages": [{"role": "user", "content": "hi"}],
        })
    assert response.status_code == 503


# --------------------------------------------------------------- parsing

def test_split_tool_calls_extracts_native_calls():
    text = 'Sure.\n<tool_call>\n{"name":"list_files","arguments":{"path":"."}}\n</tool_call>'
    content, calls, malformed = split_tool_calls(text)
    assert calls == [{"name": "list_files", "arguments": {"path": "."}}]
    assert "tool_call" not in content and "{" not in content
    assert malformed is False


def test_split_tool_calls_multiple_ordered_blocks():
    text = ('<tool_call>\n{"name":"read_file","arguments":{"path":"a.py"}}\n</tool_call>\n'
            '<tool_call>\n{"name":"read_file","arguments":{"path":"b.py"}}\n</tool_call>')
    _, calls, malformed = split_tool_calls(text)
    assert [call["arguments"]["path"] for call in calls] == ["a.py", "b.py"]
    assert malformed is False


def test_split_tool_calls_flags_dangling_tag():
    content, calls, malformed = split_tool_calls('Working on it. <tool_call>\n{"name":"list_fil')
    assert calls == []
    assert malformed is True


def test_split_tool_calls_plain_text_untouched():
    content, calls, malformed = split_tool_calls("Just text, no tools here.")
    assert content == "Just text, no tools here."
    assert calls == [] and malformed is False


def test_split_tool_calls_string_arguments_coerced():
    text = '<tool_call>\n{"name":"write_file","arguments":"{\\"path\\":\\"x.txt\\"}"}\n</tool_call>'
    _, calls, malformed = split_tool_calls(text)
    assert malformed is False
    assert calls[0]["arguments"] == {"path": "x.txt"}


# --------------------------------------------------------------- engine state

def test_engine_reports_missing_weights_without_loading():
    engine = LocalModelEngine("/nonexistent/weights", model_name="whatever")
    assert engine.weights_present() is False
    assert engine.status["loaded"] is False
    assert engine.status["loading"] is False
    assert engine.status["error"] is None
    engine.begin_load()
    assert engine.status["loaded"] is False
    assert "No safetensors weights" in (engine.status["error"] or "")


def test_engine_rejects_invalid_options():
    with pytest.raises(ValueError):
        LocalModelEngine("/tmp", model_name="x", device="tpu")
    with pytest.raises(ValueError):
        LocalModelEngine("/tmp", model_name="x", quantization="int2")


# --------------------------------------------------------------- config fallback

def test_empty_local_model_dir_env_falls_back_to_models_dir(monkeypatch, tmp_path):
    """The .env.example ships LOCAL_MODEL_DIR empty; it must resolve to models/<name>,
    never to the process working directory (regression for the release smoke finding)."""
    import importlib
    from pathlib import Path

    monkeypatch.setenv("LOCAL_MODEL_DIR", "")
    monkeypatch.setenv("LOCAL_MODEL_NAME", "tiny-qwen2-random")
    import backend.config as config

    importlib.reload(config)
    expected = (config.BASE_DIR / "models" / "tiny-qwen2-random").resolve()
    assert config.LOCAL_MODEL_DIR == expected
    assert config.LOCAL_MODEL_DIR != Path.cwd().resolve()
    # An explicit value still wins.
    monkeypatch.setenv("LOCAL_MODEL_DIR", str(tmp_path / "custom"))
    importlib.reload(config)
    assert config.LOCAL_MODEL_DIR == (tmp_path / "custom").resolve()
    # Restore the module for later tests: reload once more with the overrides
    # removed so config no longer carries this test's values (importlib.reload
    # mutates the shared module object; leaving the overrides in place would
    # leak into tests that read config attributes at runtime, e.g. the model
    # manager, which resolves LOCAL_MODEL_NAME/LOCAL_MODEL_DIR dynamically).
    monkeypatch.delenv("LOCAL_MODEL_DIR")
    monkeypatch.delenv("LOCAL_MODEL_NAME")
    importlib.reload(config)  # restore for other tests
