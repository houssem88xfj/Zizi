"""Install-path contract tests for the 0.7.2 GPU/CUDA install-fix round.

Pins the contract that was broken before: installers MUST NOT quietly install a
CPU-only torch build on an NVIDIA host. They must offer an explicit --cpu/--cuda
choice, keep an existing compatible torch build untouched, switch builds by
uninstalling first (never two conflicting torch builds in one environment), and
verify the result with a REAL torch.cuda.is_available() check that fails loudly.

Real-GPU/Docker behavior stays NOT RUN in this environment (no GPU, no Docker
daemon); check_torch.py's no-GPU failure path IS executed here as an honest
control test.
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
INSTALL_SH = ROOT / "scripts" / "install.sh"
INSTALL_BAT = ROOT / "scripts" / "install.bat"
DOCKERFILE = ROOT / "Dockerfile"
RUNNER_DOCKERFILE = ROOT / "runner" / "Dockerfile"
COMPOSE = ROOT / "compose.yaml"
CHECK_TORCH = ROOT / "scripts" / "check_torch.py"


def _run(cmd: list[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=120, **kwargs)


def _torch_installed() -> bool:
    return importlib.util.find_spec("torch") is not None


# ---------------------------------------------------------------- install.sh


def test_install_sh_offers_explicit_cpu_cuda_choice():
    text = INSTALL_SH.read_text(encoding="utf-8")
    for token in ("--cpu", "--cuda", "--gpu", "--with-model"):
        assert token in text, f"install.sh must document/accept {token}"
    for token in (
        "https://download.pytorch.org/whl/cu124",
        "https://download.pytorch.org/whl/cpu",
        "nvidia-smi",
        "check_torch.py",
    ):
        assert token in text, f"install.sh must reference {token}"


def test_install_sh_verifies_cuda_for_real_and_fails_loudly():
    text = INSTALL_SH.read_text(encoding="utf-8")
    # The real verification call plus the explicit failure branch on its exit code.
    assert 'python scripts/check_torch.py --"$TORCH_BUILD"' in text
    assert "TORCH_CHECK_RC" in text and "exit 1" in text
    assert "cannot see the GPU" in text


def test_install_sh_switches_builds_by_uninstalling_first():
    text = INSTALL_SH.read_text(encoding="utf-8")
    assert "pip uninstall -y torch" in text
    assert "reusing the existing" in text  # compatible build is kept, not reinstalled


def test_install_sh_rejects_build_flag_without_with_model():
    result = _run(["bash", str(INSTALL_SH), "--cuda"])
    assert result.returncode == 2
    assert "--with-model" in (result.stdout + result.stderr)


def test_install_sh_rejects_unknown_option():
    result = _run(["bash", str(INSTALL_SH), "--badflag"])
    assert result.returncode == 2
    assert "Unknown option" in (result.stdout + result.stderr)


# --------------------------------------------------------------- install.bat


def test_install_bat_offers_explicit_cpu_cuda_choice():
    text = INSTALL_BAT.read_text(encoding="utf-8")
    for token in ("--cpu", "--cuda", "--gpu", "--with-model"):
        assert token in text
    for token in (
        "https://download.pytorch.org/whl/cu124",
        "https://download.pytorch.org/whl/cpu",
        "nvidia-smi",
        "check_torch.py",
        "pip uninstall -y torch",
    ):
        assert token in text, f"install.bat must reference {token}"
    # Same loud failure branch for a CUDA install that cannot see the GPU.
    assert "cannot see the GPU" in text and "exit /b 1" in text


def test_install_bat_rejects_unknown_option():
    # Option validation happens before anything else; unknown flags must exit 2.
    # (cmd.exe is not available on this Linux host, so the contract is pinned by
    # the shell-syntax-level guard above plus this static assertion.)
    text = INSTALL_BAT.read_text(encoding="utf-8")
    assert 'echo Unknown option: %%~a' in text  # %%~a strips quoted arguments
    assert "exit /b 2" in text


# ------------------------------------------------------------- check_torch.py


def test_check_torch_help_documents_modes():
    result = _run([sys.executable, str(CHECK_TORCH), "--help"])
    assert result.returncode == 0
    for token in ("--cpu", "--cuda", "--check-model-extra"):
        assert token in result.stdout


def test_check_torch_cpu_mode_matches_environment():
    result = _run([sys.executable, str(CHECK_TORCH), "--cpu"])
    if _torch_installed():
        assert result.returncode == 0, result.stdout + result.stderr
        assert "PASS" in result.stdout
    else:
        assert result.returncode == 2, result.stdout + result.stderr
        assert "torch is not installed" in result.stdout


def test_check_torch_cuda_control_test_reports_honestly():
    """Control test WITHOUT a GPU: --cuda must never fake success."""
    result = _run([sys.executable, str(CHECK_TORCH), "--cuda"])
    if not _torch_installed():
        assert result.returncode == 2
        assert "torch is not installed" in result.stdout
        return
    text = result.stdout
    if "torch.cuda.is_available() : True" in text:
        assert result.returncode == 0  # only possible on a real GPU host
    else:
        assert result.returncode == 1
        assert "FAIL  CUDA was requested but torch.cuda.is_available() is False." in text
        assert "torch.cuda.is_available() : False" in text
        assert "Cause:" in text


def test_check_torch_evaluate_decision_core():
    """Pure decision-core checks with SYNTHETIC state dicts (no CUDA mocking of the
    live check - the subprocess tests above exercise the real environment)."""
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import check_torch
    finally:
        sys.path.pop(0)

    # torch missing -> exit 2 with the install hint
    code, lines = check_torch.evaluate("cpu", {"torch_installed": False, "import_error": None})
    assert code == 2 and any("torch is not installed" in line for line in lines)
    # broken install -> exit 4
    code, lines = check_torch.evaluate("cpu", {"torch_installed": True, "import_error": "OSError: libcuda missing"})
    assert code == 4 and any("cannot be imported" in line for line in lines)
    # --cuda with a CPU-only build -> exit 1 and name the actual cause
    cpu_state = {
        "torch_installed": True, "import_error": None, "torch_version": "2.9.1",
        "build_cuda": None, "cuda_available": False, "device_count": 0,
        "device_names": [], "bf16_supported": False,
    }
    code, lines = check_torch.evaluate("cuda", cpu_state)
    assert code == 1
    assert any("CPU-only build" in line for line in lines)
    assert any("pip uninstall -y torch" in line for line in lines)
    # --cuda with a CUDA build but no visible GPU -> exit 1 with driver guidance
    cuda_no_gpu = dict(cpu_state, build_cuda="12.4")
    code, lines = check_torch.evaluate("cuda", cuda_no_gpu)
    assert code == 1
    assert any("NVIDIA driver" in line for line in lines)
    # --cuda with a working GPU -> exit 0
    cuda_ok = dict(cpu_state, build_cuda="12.4", cuda_available=True, device_count=1,
                   device_names=["NVIDIA GeForce RTX 5090"], bf16_supported=True)
    code, lines = check_torch.evaluate("cuda", cuda_ok)
    assert code == 0 and any("PASS" in line for line in lines)
    # --cpu never requires a GPU
    code, _ = check_torch.evaluate("cpu", cpu_state)
    assert code == 0


def test_check_torch_model_extra_contract():
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import check_torch
    finally:
        sys.path.pop(0)
    expected = {
        "transformers", "tokenizers", "regex", "safetensors", "accelerate",
        "sentencepiece", "bitsandbytes", "huggingface_hub",
    }
    assert expected == set(check_torch.MODEL_EXTRA_MODULES)
    # In this environment the extra is not installed -> exit 3, never a fake pass.
    code, lines = check_torch.evaluate_model_extra(
        {"torch_installed": False, "import_error": None})
    assert code == 3
    assert any("requirements-local-model.txt" in line for line in lines)


# ----------------------------------------------------------- Dockerfile / pins


def test_dockerfile_model_extra_resolves_dependencies_normally():
    import re
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert not re.search(r"pip install[^\\]*--no-deps", text), (
        "the model extra must let pip resolve dependencies")
    assert "pip check" in text, "the image build must fail on broken dependencies"
    imports_line = next(
        line for line in text.splitlines()
        if "import torch, transformers" in line
    )
    for module in ("tokenizers", "regex", "safetensors", "accelerate",
                   "sentencepiece", "bitsandbytes", "huggingface_hub"):
        assert module in imports_line, f"import smoke test must include {module}"


def test_runner_dockerfile_pins_match_application_pins():
    pins: dict[str, str] = {}
    for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if "==" in line and not line.startswith("#"):
            name, _, version = line.partition("==")
            pins[name.split("[")[0]] = version
    runner = RUNNER_DOCKERFILE.read_text(encoding="utf-8")
    for package in ("fastapi", "uvicorn", "pydantic"):
        assert f"{package}=={pins[package]}" in runner, (
            f"runner pins drifted from the application pins for {package}")


# --------------------------------------------------------------- compose.yaml


def _compose_services() -> dict:
    import yaml
    return yaml.safe_load(COMPOSE.read_text(encoding="utf-8"))["services"]


def test_compose_gpu_passthrough_only_on_gpu_service():
    services = _compose_services()
    assert "nvidia" not in str(services["app"]), "the CPU/base service must not claim a GPU"
    gpu = services["app-gpu"]
    devices = gpu["deploy"]["resources"]["reservations"]["devices"]
    assert devices[0]["driver"] == "nvidia" and devices[0]["count"] == "all"
    assert gpu["environment"]["NVIDIA_VISIBLE_DEVICES"] == "all"


def test_compose_no_docker_socket_in_the_app_container():
    services = _compose_services()
    for service_name in ("app", "app-gpu"):
        mounts = " ".join(services[service_name].get("volumes", []))
        assert "docker.sock" not in mounts, f"{service_name} must not mount the Docker socket"
    # The runner keeps its socket by design (it launches isolated workload containers).
    assert "docker.sock" in " ".join(services["sandbox-runner"]["volumes"])


def test_compose_weights_mount_readonly_and_inference_port_unpublished():
    services = _compose_services()
    weights_mount = next(
        v for v in services["app"]["volumes"] if v.endswith(":/app/models:ro"))
    assert weights_mount.endswith(":/app/models:ro")
    compose_text = COMPOSE.read_text(encoding="utf-8")
    for published in ("8100:8100", '"8100:8100"', '"${LOCAL_INFERENCE_PORT'):
        assert published not in compose_text, "the internal inference port must stay unpublished"
    # Only 8080 is published, bound to loopback by default.
    assert '"${APP_BIND_ADDRESS:-127.0.0.1}:${APP_PORT:-8080}:8080"' in compose_text


@pytest.mark.parametrize("service", ["app", "app-gpu", "sandbox-runner"])
def test_compose_gpu_build_defaults_unchanged_for_cpu(service):
    services = _compose_services()
    if service == "app":
        build_args = services["app"]["build"]["args"]
        assert build_args["INSTALL_LOCAL_MODEL"] == "false"
        assert build_args["TORCH_INDEX_URL"] == "https://download.pytorch.org/whl/cpu"
    if service == "app-gpu":
        build_args = services["app-gpu"]["build"]["args"]
        assert build_args["INSTALL_LOCAL_MODEL"] == "true"
        assert build_args["TORCH_INDEX_URL"] == "https://download.pytorch.org/whl/cu124"
