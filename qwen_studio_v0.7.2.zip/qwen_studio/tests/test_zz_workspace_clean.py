from __future__ import annotations

from backend import config as backend_config
from conftest import REPO_WORKSPACE, _WORKSPACE_BASELINE, _workspace_snapshot


def test_test_session_did_not_write_into_repository_workspace():
    assert backend_config.WORKSPACE_DIR != REPO_WORKSPACE.resolve()
    assert backend_config.DATABASE_PATH.parent != REPO_WORKSPACE.resolve()
    assert backend_config.PUBLISH_DIR != REPO_WORKSPACE.resolve()
    assert _workspace_snapshot() == _WORKSPACE_BASELINE
