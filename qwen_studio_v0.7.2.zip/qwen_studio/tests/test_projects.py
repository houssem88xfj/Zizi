import pytest
from backend import projects


def test_create_project_has_preview_files(tmp_path, monkeypatch):
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path)
    record = projects.create_project("Demo", "first app")
    project = projects.project_path(record["id"])
    assert (project / "index.html").is_file()
    assert (project / "style.css").is_file()
    assert (project / "app.js").is_file()
    assert projects.get_project(record["id"])["name"] == "Demo"


def test_metadata_has_no_owner_field(tmp_path, monkeypatch):
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path)
    record = projects.create_project("Ownerless", "")
    assert "owner_id" not in record
    on_disk = (tmp_path / record["id"] / ".qwen-project.json").read_text(encoding="utf-8")
    assert "owner_id" not in on_disk


def test_invalid_project_id_rejected():
    with pytest.raises(ValueError):
        projects.project_path("../outside")


def test_delete_project(tmp_path, monkeypatch):
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path)
    record = projects.create_project("Delete me", "")
    projects.delete_project(record["id"])
    with pytest.raises(FileNotFoundError):
        projects.project_path(record["id"])
