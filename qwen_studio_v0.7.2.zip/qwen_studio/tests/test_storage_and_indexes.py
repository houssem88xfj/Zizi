import json
from pathlib import Path

from backend import db, projects, tools


def _setup_db(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "data.sqlite3")
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path / "projects")
    db.init_db()
    return projects.PROJECTS_DIR


def test_workspace_storage_cache_updates_on_write_rewrite_and_delete(tmp_path, monkeypatch):
    _setup_db(tmp_path, monkeypatch)
    project = projects.create_project("Storage", "")
    folder = projects.project_path(project["id"])

    original_project_size = projects.project_storage_size(folder)
    calls = {"count": 0}
    real_size = projects.project_storage_size

    def counted_size(path):
        calls["count"] += 1
        return real_size(path)

    monkeypatch.setattr(projects, "project_storage_size", counted_size)
    with tools.workspace_context(folder, project["id"]):
        tools.write_file({"path": "notes.txt", "content": "abc"})
        assert db.workspace_storage_if_initialized() == original_project_size + 3
        first_scan_count = calls["count"]

        tools.write_file({"path": "notes.txt", "content": "abcdefgh"})
        assert db.workspace_storage_if_initialized() == original_project_size + 8
        assert calls["count"] == first_scan_count  # no full project scan on subsequent writes

        tools.delete_file({"path": "notes.txt"})
        assert db.workspace_storage_if_initialized() == original_project_size
        assert calls["count"] == first_scan_count


def test_create_and_delete_project_update_initialized_storage(tmp_path, monkeypatch):
    _setup_db(tmp_path, monkeypatch)
    first = projects.create_project("First", "")
    folder = projects.project_path(first["id"])
    with tools.workspace_context(folder, first["id"]):
        tools.write_file({"path": "data.txt", "content": "hello"})
    before = db.workspace_storage_if_initialized()
    second = projects.create_project("Second", "")
    assert db.workspace_storage_if_initialized() > before
    second_size = projects.project_storage_size(projects.project_path(second["id"]))
    current = db.workspace_storage_if_initialized()
    projects.delete_project(second["id"])
    assert db.workspace_storage_if_initialized() == current - second_size


def test_projects_are_listed_from_sqlite_index(tmp_path, monkeypatch):
    projects_dir = _setup_db(tmp_path, monkeypatch)
    project = projects.create_project("Indexed", "")

    original_iterdir = Path.iterdir

    def forbid_projects_scan(self):
        if self == projects_dir:
            raise AssertionError("list_projects scanned the whole projects directory")
        return original_iterdir(self)

    monkeypatch.setattr(Path, "iterdir", forbid_projects_scan)
    listed = projects.list_projects()
    assert [item["id"] for item in listed] == [project["id"]]


def test_init_db_imports_legacy_project_metadata_once(tmp_path, monkeypatch):
    legacy_dir = tmp_path / "legacy-projects"
    legacy_dir.mkdir()
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "db.sqlite3")
    monkeypatch.setattr(projects, "PROJECTS_DIR", legacy_dir)
    # Simulate a database after its first schema setup, but before the
    # one-time project-index import migration has been applied.
    db.init_db()
    with db.db_session() as connection:
        connection.execute("DELETE FROM schema_migrations WHERE migration_key='project_index_import_v1'")
    project_id = "a" * 32
    folder = legacy_dir / project_id
    folder.mkdir()
    metadata = {
        "id": project_id,
        "name": "Legacy project",
        "description": "",
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-02T00:00:00+00:00",
    }
    (folder / ".qwen-project.json").write_text(json.dumps(metadata), encoding="utf-8")
    db.init_db()
    rows = db.list_project_index()
    assert rows is not None
    assert [row["id"] for row in rows] == [project_id]
