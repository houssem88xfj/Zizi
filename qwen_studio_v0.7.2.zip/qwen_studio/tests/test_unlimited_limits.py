"""Unlimited (0) semantics — shipped 0.7.2 defaults for the single-user workspace.

Every application-side limit knob accepts 0 = unlimited. These tests pin that
contract: quotas are bypassed (but still counted), history is sent uncut, the
agent loop runs until the model finishes, and the local engine derives its
context window from the model config while allowing unbounded generation.
"""
import json
from copy import deepcopy
from types import SimpleNamespace

import pytest

from backend import agent as agent_module
from backend import db, projects, quotas
from backend.agent import CodingAgent
from backend.tools import workspace_context


class _FakeCompletions:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(deepcopy(kwargs))
        return next(self.outputs)


class _FakeClient:
    def __init__(self, outputs):
        self.chat = SimpleNamespace(completions=_FakeCompletions(outputs))


def _response(content=None, tool_calls=None, finish_reason="stop"):
    message = SimpleNamespace(content=content, tool_calls=tool_calls or [])
    return SimpleNamespace(
        choices=[SimpleNamespace(message=message, finish_reason=finish_reason)], usage=None
    )


def _tool_call(name="list_files", arguments="{}"):
    return SimpleNamespace(
        id=f"tool-{json.dumps(arguments, sort_keys=True)}",
        function=SimpleNamespace(name=name, arguments=arguments),
    )


# ------------------------------------------------------------------ daily quotas

def test_zero_daily_chat_quota_is_unlimited(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "usage.sqlite3")
    db.init_db()
    day = quotas.today_key()
    for _ in range(60):  # far beyond the historical default of 40
        db.reserve_chat(day, 0)
    snapshot = quotas.usage_today()
    assert snapshot["chat_requests"] >= 60
    assert snapshot["limits"]["chat_requests"] is None
    assert snapshot["remaining"]["chat_requests"] is None


def test_positive_daily_chat_quota_still_enforced(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "usage2.sqlite3")
    db.init_db()
    day = quotas.today_key()
    db.reserve_chat(day, 2)
    db.reserve_chat(day, 2)
    with pytest.raises(PermissionError):
        db.reserve_chat(day, 2)


def test_zero_tool_and_deployment_quotas_are_unlimited(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "usage3.sqlite3")
    db.init_db()
    day = quotas.today_key()
    for _ in range(15):
        db.reserve_tool_call(day, 0)
        db.reserve_deployment(day, 0)
    snapshot = quotas.usage_today()
    assert snapshot["tool_calls"] >= 15 and snapshot["deployments"] >= 15
    assert snapshot["limits"]["tool_calls"] is None
    assert snapshot["limits"]["deployments"] is None


def test_unlimited_chat_quota_reports_none_tool_budget(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "usage4.sqlite3")
    db.init_db()
    monkeypatch.setattr(quotas, "MAX_DAILY_TOOL_CALLS", 0)
    snapshot, tool_budget = quotas.reserve_chat_quota()
    assert snapshot["chat_requests"] >= 1
    assert tool_budget is None


# ------------------------------------------------------------------ projects/files

def test_zero_project_limit_is_unlimited(client, monkeypatch):
    monkeypatch.setattr(projects, "MAX_PROJECTS", 0)
    monkeypatch.setattr(projects, "MAX_WORKSPACE_STORAGE_BYTES", 0)
    ids = []
    for index in range(12):  # more than the fixture's usual cap of 10
        response = client.post("/api/projects", json={"name": f"unlimited-{index}"})
        assert response.status_code == 201, response.text
        ids.append(response.json()["id"])
    assert len(set(ids)) == 12


def test_unlimited_file_size_roundtrip(client):
    project = client.post("/api/projects", json={"name": "big-file"}).json()
    content = "x" * (600 * 1024)  # beyond the historical 500000-byte default
    put = client.put(f"/api/projects/{project['id']}/file",
                     json={"path": "big.txt", "content": content})
    assert put.status_code == 200, put.text
    got = client.get(f"/api/projects/{project['id']}/file?path=big.txt")
    assert got.status_code == 200
    assert got.json()["content"] == content


# ------------------------------------------------------------------ agent tokens

def test_agent_omits_max_tokens_when_unlimited(tmp_path, monkeypatch):
    monkeypatch.setattr(agent_module, "MODEL_MAX_TOKENS", 0)
    fake_client = _FakeClient([_response(content="done")])
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "f" * 32):
        agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=1)
    assert "max_tokens" not in fake_client.chat.completions.calls[0]


def test_agent_sends_full_history_when_budget_unlimited(tmp_path, monkeypatch):
    monkeypatch.setattr(agent_module, "MODEL_CONTEXT_CHAR_BUDGET", 0)
    fake_client = _FakeClient([_response(content="done")])
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    history = [{"role": "user" if i % 2 else "assistant", "content": f"message {i}"}
               for i in range(30)]
    with workspace_context(tmp_path, "1" * 32):
        agent.chat("hello", history, project_workspace=tmp_path, project_id="2" * 32)
    sent = fake_client.chat.completions.calls[0]["messages"]
    # system prompt + all 30 history items + the new user message
    assert len(sent) == 32
    assert sent[1]["content"] == "message 0"


def test_agent_bounded_budget_still_truncates_history(tmp_path, monkeypatch):
    monkeypatch.setattr(agent_module, "MODEL_CONTEXT_CHAR_BUDGET", 60000)
    fake_client = _FakeClient([_response(content="done")])
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    history = [{"role": "user" if i % 2 else "assistant", "content": f"message {i}"}
               for i in range(30)]
    with workspace_context(tmp_path, "3" * 32):
        agent.chat("hello", history, project_workspace=tmp_path, project_id="4" * 32)
    sent = fake_client.chat.completions.calls[0]["messages"]
    assert len(sent) == 18  # system + last 16 + the new message


def test_agent_unlimited_turns_and_tool_calls(tmp_path, monkeypatch):
    monkeypatch.setattr(agent_module, "MAX_TOOL_TURNS", 0)
    outputs = [
        _response(tool_calls=[_tool_call(
            name="write_file",
            arguments=json.dumps({"path": f"gen-{i}.txt", "content": f"payload-{i}"}),
        )])
        for i in range(40)
    ] + [_response(content="finished")]
    fake_client = _FakeClient(outputs)
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "5" * 32):
        result = agent._run_tool_loop(
            [{"role": "system", "content": "test"}],
            max_tool_calls=None,
            tool_authorizer=lambda: None,
        )
    assert result["reply"] == "finished"
    assert len(result["tool_events"]) == 40  # beyond the 8-turn and 32-call caps
    assert "warning" not in result


def test_agent_unlimited_turns_still_stops_on_repetition(tmp_path, monkeypatch):
    monkeypatch.setattr(agent_module, "MAX_TOOL_TURNS", 0)
    stuck_call = _tool_call(arguments=json.dumps({"path": "same"}))
    outputs = [_response(tool_calls=[stuck_call]) for _ in range(50)]
    fake_client = _FakeClient(outputs)
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "6" * 32):
        result = agent._run_tool_loop(
            [{"role": "system", "content": "test"}],
            max_tool_calls=None,
            tool_authorizer=lambda: None,
        )
    # The loop guard ends the run instead of spinning forever on identical calls.
    assert result.get("warning") == "loop_detected"


# ------------------------------------------------------------------ local engine

def test_engine_zero_context_is_auto_from_model_config(tmp_path):
    from inference.engine import LocalModelEngine
    (tmp_path / "config.json").write_text(json.dumps({"max_position_embeddings": 16384}))
    engine = LocalModelEngine(model_dir=tmp_path, model_name="m",
                              max_context_tokens=0, max_new_tokens_cap=0)
    assert engine.max_context_tokens == 16384
    assert engine.max_new_tokens_cap is None


def test_engine_zero_context_falls_back_without_config(tmp_path):
    from inference.engine import LocalModelEngine
    engine = LocalModelEngine(model_dir=tmp_path, model_name="m",
                              max_context_tokens=0, max_new_tokens_cap=0)
    assert engine.max_context_tokens == 32768
    assert engine.max_new_tokens_cap is None


def test_engine_explicit_values_still_honored(tmp_path):
    from inference.engine import LocalModelEngine
    engine = LocalModelEngine(model_dir=tmp_path, model_name="m",
                              max_context_tokens=8192, max_new_tokens_cap=2048)
    assert engine.max_context_tokens == 8192
    assert engine.max_new_tokens_cap == 2048
