"""Test bootstrap: point all runtime storage outside the source checkout before imports."""
from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

REPO_ROOT = Path(__file__).resolve().parents[1]
REPO_WORKSPACE = REPO_ROOT / "workspace"
_WORKSPACE_BASELINE: set[str] = set()
_SESSION_RUNTIME_ROOT: Path | None = None


def _workspace_snapshot() -> set[str]:
    if not REPO_WORKSPACE.exists():
        return set()
    return {p.relative_to(REPO_WORKSPACE).as_posix() for p in REPO_WORKSPACE.rglob("*") if p.is_file() and p.name != ".gitkeep"}


def pytest_configure(config):
    """Use pytest's own tmp_path_factory before importing any backend module."""
    global _WORKSPACE_BASELINE, _SESSION_RUNTIME_ROOT
    factory = getattr(config, "_tmp_path_factory", None)
    if factory is None:
        # The built-in tmpdir plugin normally registers this before conftest hooks.
        from _pytest.tmpdir import TempPathFactory
        factory = TempPathFactory.from_config(config, _ispytest=True)
    _SESSION_RUNTIME_ROOT = factory.mktemp("qwen-studio-runtime")
    workspace = _SESSION_RUNTIME_ROOT / "workspace"
    publish = _SESSION_RUNTIME_ROOT / "published"
    workspace.mkdir(parents=True, exist_ok=True)
    publish.mkdir(parents=True, exist_ok=True)
    os.environ["WORKSPACE_DIR"] = str(workspace)
    os.environ["DATABASE_PATH"] = str(_SESSION_RUNTIME_ROOT / "qwen_studio.sqlite3")
    os.environ["PUBLISH_DIR"] = str(publish)
    os.environ.setdefault("APP_ENV", "test")
    # Deterministic test behavior regardless of the operator's .env: never start a
    # real model engine during tests and pin the loop/limit knobs the agent tests rely on.
    os.environ["LOCAL_INFERENCE"] = "false"
    os.environ["MAX_TOOL_TURNS"] = "8"
    os.environ["MODEL_MAX_TOKENS"] = "8192"
    _WORKSPACE_BASELINE = _workspace_snapshot()

    # Import only after runtime environment paths have been redirected.
    global app, API_ATTEMPTS, CHAT_ATTEMPTS
    global app_module, db, deployments, projects, config_module
    from backend.app import app, API_ATTEMPTS, CHAT_ATTEMPTS
    import backend.app as app_module
    from backend import db, deployments, projects
    from backend import config as config_module


def pytest_sessionfinish(session, exitstatus):
    current = _workspace_snapshot()
    created = sorted(current - _WORKSPACE_BASELINE)
    if created:
        reporter = getattr(session.config, "_qwen_workspace_reporter", None)
        message = "Test suite wrote runtime files into repository workspace/: " + ", ".join(created)
        if reporter:
            reporter(message)
        else:
            print("\nERROR: " + message)
        session.exitstatus = 1


@pytest.fixture
def client(tmp_path, monkeypatch):
    API_ATTEMPTS.clear()
    CHAT_ATTEMPTS.clear()
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "data.sqlite3")
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path / "projects")
    monkeypatch.setattr(deployments, "PUBLISH_DIR", tmp_path / "published")
    monkeypatch.setattr(config_module, "PUBLISH_DIR", tmp_path / "published")
    monkeypatch.setattr(app_module, "PUBLISH_DIR", tmp_path / "published")
    monkeypatch.setattr(config_module, "MAX_PROJECTS", 10)
    monkeypatch.setattr(config_module, "MAX_WORKSPACE_STORAGE_BYTES", 2_000_000)
    with TestClient(app) as test_client:
        yield test_client
