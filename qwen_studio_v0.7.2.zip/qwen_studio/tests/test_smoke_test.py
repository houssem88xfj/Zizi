from __future__ import annotations

import ast
import json
import re
import socket
import threading
import time
import urllib.error
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

import scripts.smoke_test as smoke_module
from scripts.smoke_test import (
    SmokeFailure,
    SmokeRunner,
    TIMEOUT_DEFAULT,
    TIMEOUT_RUN,
    TIMEOUT_PREVIEW_START,
    TIMEOUT_PUBLISH_STATIC,
    TIMEOUT_PUBLISH_NPM,
    TIMEOUT_STOP_DELETE,
    TIMEOUT_CHAT,
    TIMEOUT_SITE_FETCH,
)


class SmokeFakeState:
    def __init__(self):
        self.publish_delay = 0.0
        self.projects = {}
        self.next_project = 1
        self.publish_count = 0
        self.auth_endpoints = False
        self.auth_ui = False


@pytest.fixture
def fake_smoke_server():
    state = SmokeFakeState()

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status, body=b"", content_type="application/json", headers=None):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            for key, value in (headers or {}).items():
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if body:
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass

        def _json(self, status, data, headers=None):
            self._send(status, json.dumps(data).encode(), headers=headers)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
            path = urllib.parse.urlsplit(self.path).path

            # Account endpoints were removed; they must answer 404.
            if path.startswith("/api/auth/"):
                self._json(404, {"detail": "not found"})
                return

            if path == "/api/projects":
                project_id = f"{state.next_project:032x}"
                state.next_project += 1
                state.projects[project_id] = {"name": payload.get("name", ""), "files": {}}
                self._json(201, {"id": project_id})
                return

            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/run", path)
            if match:
                self._json(200, {"status": "passed"})
                return
            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/preview/start", path)
            if match:
                self._json(200, {"running": True})
                return
            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/publish", path)
            if match:
                time.sleep(state.publish_delay)
                project_id = match.group(1)
                state.publish_count += 1
                slug = "site-" + project_id
                self._json(201, {"slug": slug, "url": f"http://{slug}.sites.example.test/"})
                return
            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/preview/stop", path)
            if match:
                self._json(200, {"running": False})
                return
            if path == "/api/chat":
                project_id = payload.get("project_id")
                state.projects[project_id]["files"]["hello.txt"] = "QWEN_STUDIO_AGENT_SMOKE_FIXED_CONTENT"
                self._json(200, {"tool_events": [{"tool": "write_file", "result": {"status": "written"}}]})
                return
            self._json(404, {"detail": "not found"})

        def do_PUT(self):
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/file", urllib.parse.urlsplit(self.path).path)
            if not match or match.group(1) not in state.projects:
                self._json(404, {"detail": "not found"})
                return
            state.projects[match.group(1)]["files"][payload["path"]] = payload["content"]
            self._json(200, {"status": "written"})

        def do_DELETE(self):
            match = re.fullmatch(r"/api/projects/([a-f0-9]{32})", urllib.parse.urlsplit(self.path).path)
            if match:
                state.projects.pop(match.group(1), None)
                self._json(200, {"deleted": True})
            else:
                self._json(404, {"detail": "not found"})

        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == "/health":
                self._json(200, {"status": "ok", "version": "0.7.1"})
            elif path == "/":
                body = b"<!doctype html><title>Qwen Studio</title><div id='shell'></div>"
                if state.auth_ui:
                    body = b"<!doctype html><title>Qwen Studio</title><form id='auth-form'>Sign in</form>"
                self._send(200, body, "text/html")
            elif path == "/api/system/status":
                self._json(200, {"sandbox": {"connected": True}, "model": {"connected": True}, "proxy_headers": "ok"})
            elif path == "/api/usage":
                self._json(200, {"chat_requests": 0, "limits": {"chat_requests": 40}})
            elif path == "/api/projects":
                self._json(200, {"projects": []})
            elif path.startswith("/api/auth/"):
                # Removed account endpoints must be gone (404), unless the fake
                # deployment is configured to simulate a leftover route.
                self._json(200 if state.auth_endpoints else 404, {"ok": True} if state.auth_endpoints else {"detail": "not found"})
            elif path.startswith("/__site_"):
                self._send(
                    200,
                    b"QWEN_STUDIO_STATIC_SMOKE_OK QWEN_STUDIO_NPM_SMOKE_OK",
                    "text/html",
                    {"Content-Security-Policy": "default-src 'self'; connect-src 'self'"},
                )
            elif path == "/__bare_publish__":
                self._send(404, b"not found", "text/plain")
            elif path.startswith("/published/"):
                self._send(404, b"not found", "text/plain")
            else:
                match = re.fullmatch(r"/api/projects/([a-f0-9]{32})/file", path)
                if match and match.group(1) in state.projects:
                    query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                    file_path = query.get("path", [""])[0]
                    value = state.projects[match.group(1)]["files"].get(file_path)
                    if value is None:
                        self._json(404, {"detail": "not found"})
                    else:
                        self._json(200, {"content": value})
                else:
                    self._send(404, b"not found", "text/plain")

        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield state, f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        thread.join(timeout=2)
        server.server_close()


def _runner(base_url):
    return SmokeRunner(
        base_url, "preview.example.test", "sites.example.test",
        insecure_local=True, expected_version="0.7.1",
    )


def _map_site_requests(smoke, base_url, records=None):
    original = smoke.request
    records = records if records is not None else []

    def mapped(method, url, payload=None, headers=None, **kwargs):
        parsed = urllib.parse.urlsplit(url)
        original_host = parsed.hostname or ""
        original_path = parsed.path or "/"
        timeout = kwargs["timeout"]
        records.append((method.upper(), original_path, timeout))
        if original_host == smoke.publish_domain and original_path == "/":
            url = base_url + "/__bare_publish__"
        elif original_host.endswith("." + smoke.preview_domain):
            url = base_url + "/__site_preview__/"
        elif original_host.endswith("." + smoke.publish_domain):
            url = base_url + "/__site_published__/"
        return original(method, url, payload, headers, **kwargs)

    smoke.request = mapped
    return records


def test_smoke_checks_pass_against_fake_server(fake_smoke_server, monkeypatch):
    _state, base_url = fake_smoke_server
    smoke = _runner(base_url)
    monkeypatch.setattr(smoke, "_resolve_wildcard_host", lambda *_args: None)
    assert "health is ok" in smoke.check_health()
    assert "account endpoints are removed" in smoke.check_workspace_opens_without_login()
    assert "expected HTML" in smoke.check_site_response(
        base_url + "/__site_preview__/", "QWEN_STUDIO_STATIC_SMOKE_OK"
    )
    assert "returns 404" in smoke.check_old_published_path_404("site-" + "a" * 32)


def test_smoke_workspace_check_rejects_account_ui(fake_smoke_server):
    state, base_url = fake_smoke_server
    state.auth_ui = True
    with pytest.raises(Exception, match="still contains account UI"):
        _runner(base_url).check_workspace_opens_without_login()


def test_smoke_workspace_check_fails_when_auth_endpoints_exist(fake_smoke_server):
    state, base_url = fake_smoke_server
    state.auth_endpoints = True
    with pytest.raises(Exception, match="expected 404 \\(removed\\)"):
        _runner(base_url).check_workspace_opens_without_login()


def test_smoke_workspace_check_fails_when_api_requires_login(fake_smoke_server):
    _state, base_url = fake_smoke_server
    smoke = _runner(base_url)
    original = smoke.request

    def unauthorized(method, url, payload=None, headers=None, **kwargs):
        if urllib.parse.urlsplit(url).path == "/api/usage":
            return smoke_module.HTTPResult(401, {}, b'{"detail": "unauthorized"}')
        return original(method, url, payload, headers, **kwargs)

    smoke.request = unauthorized
    with pytest.raises(Exception, match="not open"):
        smoke.check_workspace_opens_without_login()


def test_smoke_preview_check_rejects_set_cookie(fake_smoke_server):
    state, base_url = fake_smoke_server

    class CookieResponse:
        status = 200
        headers = {"Set-Cookie": "qwen_session=unexpected"}

        def read(self):
            return b"QWEN_STUDIO_STATIC_SMOKE_OK"

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

    class CookieOpener:
        def open(self, *_args, **_kwargs):
            return CookieResponse()

    smoke = _runner(base_url)
    smoke.opener = CookieOpener()
    smoke._resolve_wildcard_host = lambda *_args: None
    with pytest.raises(Exception, match="unexpectedly set an application cookie"):
        smoke.check_site_response("http://preview.example.test/", "QWEN_STUDIO_STATIC_SMOKE_OK")


def test_smoke_legacy_publish_path_must_return_404(fake_smoke_server):
    _state, base_url = fake_smoke_server
    smoke = _runner(base_url)
    with pytest.raises(Exception, match="legacy app-host publish path returned HTTP 200"):
        # The fake server is switched to a legacy response for this request using a short handler patch.
        original = smoke.request

        def legacy_200(method, url, payload=None, headers=None, **kwargs):
            if "/published/" in url:
                return smoke_module.HTTPResult(200, {}, b"legacy route")
            return original(method, url, payload, headers, **kwargs)

        smoke.request = legacy_200
        smoke.check_old_published_path_404("site-" + "b" * 32)


def test_request_ast_requires_explicit_timeout_for_mutations():
    source = (smoke_module.REPO_ROOT / "scripts" / "smoke_test.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    missing = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "request" or not isinstance(node.func.value, ast.Name) or node.func.value.id != "self":
            continue
        method_node = node.args[0] if node.args else next(
            (kw.value for kw in node.keywords if kw.arg == "method"), None
        )
        if isinstance(method_node, ast.Constant) and method_node.value in {"POST", "PUT", "DELETE"}:
            if not any(keyword.arg == "timeout" for keyword in node.keywords):
                missing.append((node.lineno, method_node.value))
    assert not missing, f"Mutation self.request calls need explicit timeout=: {missing}"


def test_timeout_constants_exceed_sandbox_client_server_timeouts():
    expected = {
        "TIMEOUT_RUN": 720,
        "TIMEOUT_PREVIEW_START": 520,
        "TIMEOUT_PUBLISH_NPM": 520,
        "TIMEOUT_STOP_DELETE": 30,
    }
    constants = {
        "TIMEOUT_RUN": TIMEOUT_RUN,
        "TIMEOUT_PREVIEW_START": TIMEOUT_PREVIEW_START,
        "TIMEOUT_PUBLISH_NPM": TIMEOUT_PUBLISH_NPM,
        "TIMEOUT_STOP_DELETE": TIMEOUT_STOP_DELETE,
    }
    source = (smoke_module.REPO_ROOT / "backend" / "sandbox_client.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    actual = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in {
            "run_project_check", "start_project_preview", "stop_project_preview", "build_static_project"
        }:
            for child in ast.walk(node):
                if isinstance(child, ast.Call):
                    if node.name == "build_static_project" and isinstance(child.func, ast.Attribute) and child.func.attr == "post":
                        kw = next((item.value for item in child.keywords if item.arg == "timeout"), None)
                        if isinstance(kw, ast.Constant):
                            actual["TIMEOUT_PUBLISH_NPM"] = kw.value
                    elif isinstance(child.func, ast.Name) and child.func.id == "_runner_post" and len(child.args) >= 3:
                        value = child.args[2]
                        if isinstance(value, ast.Constant):
                            name = {
                                "run_project_check": "TIMEOUT_RUN",
                                "start_project_preview": "TIMEOUT_PREVIEW_START",
                                "stop_project_preview": "TIMEOUT_STOP_DELETE",
                            }[node.name]
                            actual[name] = value.value
    assert actual == expected, f"sandbox_client.py timeout values changed: {actual}"
    for name, server_timeout in expected.items():
        assert constants[name] > server_timeout, f"{name} must exceed server timeout {server_timeout}s"


def test_request_timeout_is_clear_and_get_retries_once_but_post_does_not():
    smoke = _runner("http://127.0.0.1:1")

    class AlwaysTimeout:
        def __init__(self):
            self.calls = 0

        def open(self, *_args, **_kwargs):
            self.calls += 1
            raise urllib.error.URLError(socket.timeout("timed out"))

    opener = AlwaysTimeout()
    smoke.opener = opener
    with pytest.raises(SmokeFailure, match=r"GET /probe timed out after 20 s \(server may still be working; check runner logs\)"):
        smoke.request("GET", "http://127.0.0.1/probe", timeout=TIMEOUT_DEFAULT)
    assert opener.calls == 2

    opener.calls = 0
    with pytest.raises(SmokeFailure, match=r"POST /probe timed out after 20 s"):
        smoke.request("POST", "http://127.0.0.1/probe", {}, timeout=TIMEOUT_DEFAULT)
    assert opener.calls == 1


def test_publish_timeout_reports_fail_without_hanging(fake_smoke_server, monkeypatch):
    state, base_url = fake_smoke_server
    state.publish_delay = 3.0
    monkeypatch.setattr(smoke_module, "TIMEOUT_PUBLISH_NPM", 1)
    smoke = _runner(base_url)
    _map_site_requests(smoke, base_url)
    smoke._resolve_wildcard_host = lambda *_args: None
    assert not smoke.check("npm publish", smoke.check_npm_project)
    assert smoke.results[-1][1] == "FAIL"
    assert "POST /api/projects/" in smoke.results[-1][2]
    assert "timed out after 1 s (server may still be working; check runner logs)" in smoke.results[-1][2]


def test_publish_succeeds_when_delay_is_under_timeout(fake_smoke_server, monkeypatch):
    state, base_url = fake_smoke_server
    state.publish_delay = 0.05
    monkeypatch.setattr(smoke_module, "TIMEOUT_PUBLISH_NPM", 2)
    smoke = _runner(base_url)
    _map_site_requests(smoke, base_url)
    smoke._resolve_wildcard_host = lambda *_args: None
    assert "published without a submitted lockfile" in smoke.check_npm_project()


def test_full_smoke_run_timeout_audit(fake_smoke_server, monkeypatch):
    _state, base_url = fake_smoke_server
    smoke = _runner(base_url)
    smoke._resolve_wildcard_host = lambda *_args: None
    records = _map_site_requests(smoke, base_url)

    assert smoke.run() == 0
    assert all(timeout >= 20 for _method, _path, timeout in records)

    by_path = {}
    for method, path, timeout in records:
        by_path.setdefault((method, path), []).append(timeout)

    assert any(path.endswith("/run") and method == "POST" and timeout == TIMEOUT_RUN
               for (method, path), values in by_path.items() for timeout in values)
    assert any(path.endswith("/preview/start") and method == "POST" and timeout == TIMEOUT_PREVIEW_START
               for (method, path), values in by_path.items() for timeout in values)
    publish_timeouts = [timeout for method, path, timeout in records
                        if method == "POST" and path.endswith("/publish")]
    assert publish_timeouts == [TIMEOUT_PUBLISH_STATIC, TIMEOUT_PUBLISH_NPM]
    assert any(method == "POST" and path == "/api/chat" and timeout == TIMEOUT_CHAT
               for method, path, timeout in records)
    assert any(method == "POST" and path.endswith("/preview/stop") and timeout == TIMEOUT_STOP_DELETE
               for method, path, timeout in records)
    assert any(method == "DELETE" and re.fullmatch(r"/api/projects/[a-f0-9]{32}", path)
               and timeout == TIMEOUT_STOP_DELETE for method, path, timeout in records)

    # No login flow: the run only GETs /api/auth/* to prove the endpoints are gone.
    assert not any(path.startswith("/api/auth/") and method != "GET"
                   for method, path, _timeout in records)


def test_timeout_constants_have_expected_values():
    assert {
        "TIMEOUT_DEFAULT": TIMEOUT_DEFAULT,
        "TIMEOUT_RUN": TIMEOUT_RUN,
        "TIMEOUT_PREVIEW_START": TIMEOUT_PREVIEW_START,
        "TIMEOUT_PUBLISH_STATIC": TIMEOUT_PUBLISH_STATIC,
        "TIMEOUT_PUBLISH_NPM": TIMEOUT_PUBLISH_NPM,
        "TIMEOUT_STOP_DELETE": TIMEOUT_STOP_DELETE,
        "TIMEOUT_CHAT": TIMEOUT_CHAT,
        "TIMEOUT_SITE_FETCH": TIMEOUT_SITE_FETCH,
    } == {
        "TIMEOUT_DEFAULT": 20,
        "TIMEOUT_RUN": 760,
        "TIMEOUT_PREVIEW_START": 560,
        "TIMEOUT_PUBLISH_STATIC": 120,
        "TIMEOUT_PUBLISH_NPM": 760,
        "TIMEOUT_STOP_DELETE": 60,
        "TIMEOUT_CHAT": 200,
        "TIMEOUT_SITE_FETCH": 30,
    }


def test_smoke_script_has_no_account_flags():
    source = (smoke_module.REPO_ROOT / "scripts" / "smoke_test.py").read_text(encoding="utf-8")
    for marker in ("--email", "--password", "check_login", "qwen_session",
                   "check_rate_limiter_active", "check_account_non_disclosure", "logged_in"):
        assert marker not in source, marker
