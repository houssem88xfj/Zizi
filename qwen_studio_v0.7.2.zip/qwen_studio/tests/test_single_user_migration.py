"""Migration tests: legacy multi-user 0.7.0/0.7.1 databases become a single workspace.

The migration must keep every project, chat message, deployment and usage counter,
drop the credentials (users table), and leave a restorable file backup behind.
"""
from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path

import pytest

from backend import db, projects


LEGACY_SCHEMA = """
CREATE TABLE users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    is_active INTEGER NOT NULL DEFAULT 1,
    token_version INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE usage_daily (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    chat_requests INTEGER NOT NULL DEFAULT 0,
    tool_calls INTEGER NOT NULL DEFAULT 0,
    deployments INTEGER NOT NULL DEFAULT 0,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX idx_chat_project ON chat_messages(user_id, project_id, id);
CREATE TABLE projects (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX idx_projects_owner_updated ON projects(owner_id, updated_at DESC);
CREATE TABLE user_storage (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    bytes_used INTEGER NOT NULL DEFAULT 0 CHECK(bytes_used >= 0),
    updated_at TEXT NOT NULL
);
CREATE TABLE schema_migrations (
    migration_key TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
);
CREATE TABLE deployments (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'published'
);
"""


def _build_legacy_db(tmp_path: Path, monkeypatch) -> tuple[Path, Path]:
    database = tmp_path / "legacy.sqlite3"
    projects_dir = tmp_path / "legacy-projects"
    projects_dir.mkdir()
    monkeypatch.setattr(db, "DATABASE_PATH", database)
    monkeypatch.setattr(projects, "PROJECTS_DIR", projects_dir)

    connection = sqlite3.connect(database)
    connection.executescript(LEGACY_SCHEMA)
    user_a, user_b = "user-a", "user-b"
    for user_id, email in ((user_a, "alice@example.com"), (user_b, "bob@example.com")):
        connection.execute(
            "INSERT INTO users(id,email,password_hash,role,is_active,created_at) VALUES(?,?,?,'user',1,'now')",
            (user_id, email, "pbkdf2_sha256$600000$c2FsdA$ZGlnZXN0"),
        )
    project_a, project_b = "a" * 32, "b" * 32
    connection.executemany(
        "INSERT INTO projects(id,owner_id,name,created_at,updated_at) VALUES(?,?,?,?,?)",
        [
            (project_a, user_a, "Alice app", "2026-01-01T00:00:00+00:00", "2026-01-02T00:00:00+00:00"),
            (project_b, user_b, "Bob app", "2026-01-01T00:00:00+00:00", "2026-01-03T00:00:00+00:00"),
        ],
    )
    connection.executemany(
        "INSERT INTO chat_messages(user_id,project_id,role,content,created_at) VALUES(?,?,?,?,?)",
        [
            (user_a, project_a, "user", "Build a landing page", "2026-01-02T01:00:00+00:00"),
            (user_a, project_a, "assistant", "Done.", "2026-01-02T01:01:00+00:00"),
            (user_b, project_b, "user", "Fix the bug", "2026-01-03T01:00:00+00:00"),
        ],
    )
    connection.executemany(
        "INSERT INTO usage_daily(user_id,day,chat_requests,tool_calls,deployments,input_tokens,output_tokens) VALUES(?,?,?,?,?,?,?)",
        [
            (user_a, "2026-01-02", 3, 10, 1, 100, 200),
            (user_b, "2026-01-02", 2, 5, 0, 50, 60),
            (user_a, "2026-01-03", 1, 2, 0, 20, 30),
        ],
    )
    connection.execute(
        "INSERT INTO user_storage(user_id,bytes_used,updated_at) VALUES(?,?,?)",
        (user_a, 1024, "2026-01-02T00:00:00+00:00"),
    )
    connection.execute(
        "INSERT INTO user_storage(user_id,bytes_used,updated_at) VALUES(?,?,?)",
        (user_b, 512, "2026-01-03T00:00:00+00:00"),
    )
    connection.executemany(
        "INSERT INTO deployments(id,user_id,project_id,slug,created_at,status) VALUES(?,?,?,?,?,?)",
        [
            ("dep-1", user_a, project_a, "site-" + "c" * 32, "2026-01-02T02:00:00+00:00", "published"),
            ("dep-2", user_b, project_b, "site-" + "d" * 32, "2026-01-03T02:00:00+00:00", "published"),
        ],
    )
    connection.commit()
    connection.close()

    # Matching on-disk project metadata still carries the retired owner_id field.
    for project_id, owner, name in ((project_a, user_a, "Alice app"), (project_b, user_b, "Bob app")):
        folder = projects_dir / project_id
        folder.mkdir()
        (folder / ".qwen-project.json").write_text(json.dumps({
            "id": project_id, "owner_id": owner, "name": name,
            "description": "", "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-02T00:00:00+00:00",
        }), encoding="utf-8")
    return database, projects_dir


def test_legacy_multi_user_db_migrates_to_single_workspace(tmp_path, monkeypatch):
    database, projects_dir = _build_legacy_db(tmp_path, monkeypatch)
    db.init_db()

    # The users table (credentials) is dropped; the backup file preserves the original data.
    with db.db_session() as connection:
        tables = {row["name"] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    assert "users" not in tables
    assert "user_storage" not in tables
    assert {"projects", "chat_messages", "usage_daily", "deployments", "workspace_storage"} <= tables

    backups = [p for p in tmp_path.glob("legacy.sqlite3.backup-*") if p.is_file() and not p.name.endswith(("-wal", "-shm"))]
    assert len(backups) == 1, "exactly one pre-migration backup must be created"
    backup_connection = sqlite3.connect(backups[0])
    backup_users = backup_connection.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    backup_connection.close()
    assert backup_users == 2, "backup must contain the original legacy data"

    # Both users' projects survive in the single workspace, newest first.
    listed = projects.list_projects()
    assert [item["id"] for item in listed] == ["b" * 32, "a" * 32]
    assert listed[0]["name"] == "Bob app"
    assert all("owner_id" not in item for item in listed)

    # On-disk metadata files no longer carry a user id.
    for project_id in ("a" * 32, "b" * 32):
        metadata = json.loads((projects_dir / project_id / ".qwen-project.json").read_text(encoding="utf-8"))
        assert "owner_id" not in metadata

    # Chat history, usage counters and deployments survive (merged across users).
    assert [m["content"] for m in db.recent_messages("a" * 32)] == ["Build a landing page", "Done."]
    assert [m["content"] for m in db.recent_messages("b" * 32)] == ["Fix the bug"]
    day = db.usage_snapshot("2026-01-02")
    assert day["chat_requests"] == 5 and day["tool_calls"] == 15
    assert db.usage_snapshot("2026-01-03")["chat_requests"] == 1
    slugs = {row["slug"] for row in db.list_deployments()}
    assert slugs == {"site-" + "c" * 32, "site-" + "d" * 32}
    assert db.workspace_storage_if_initialized() == 1024 + 512


def test_migration_runs_only_once(tmp_path, monkeypatch):
    database, _projects_dir = _build_legacy_db(tmp_path, monkeypatch)
    db.init_db()
    def main_backups():
        return [p for p in tmp_path.glob("legacy.sqlite3.backup-*")
                if p.is_file() and not p.name.endswith(("-wal", "-shm"))]
    assert len(main_backups()) == 1
    db.init_db()  # second startup must be a no-op
    assert len(main_backups()) == 1
    with db.db_session() as connection:
        applied = {row["migration_key"] for row in connection.execute(
            "SELECT migration_key FROM schema_migrations").fetchall()}
    assert "single_user_workspace_v1" in applied


def test_migration_fails_closed_and_keeps_original_on_error(tmp_path, monkeypatch):
    database, _projects_dir = _build_legacy_db(tmp_path, monkeypatch)
    # Fail the migration mid-transaction (while copying data) and verify the legacy
    # schema is fully restored by the rollback and no stray *_new tables remain.
    calls = {"count": 0}
    real_now_iso = db.now_iso

    def failing_now_iso():
        calls["count"] += 1
        if calls["count"] >= 1:
            raise RuntimeError("injected migration failure")
        return real_now_iso()

    monkeypatch.setattr(db, "now_iso", failing_now_iso)
    with pytest.raises(RuntimeError, match="injected migration failure"):
        db.init_db()
    monkeypatch.undo()

    connection = sqlite3.connect(database)
    users = connection.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    projects_count = connection.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
    tables = {row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    connection.close()
    assert users == 2 and projects_count == 2
    assert not any(name.endswith("_new") for name in tables), tables
    assert "workspace_storage" not in tables

    # After the injected failure is removed, the next startup migrates successfully.
    db.init_db()
    with db.db_session() as session:
        tables_after = {row["name"] for row in session.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    assert "users" not in tables_after
    assert "workspace_storage" in tables_after


def test_fresh_database_has_no_user_tables(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DATABASE_PATH", tmp_path / "fresh.sqlite3")
    monkeypatch.setattr(projects, "PROJECTS_DIR", tmp_path / "projects")
    db.init_db()
    with db.db_session() as connection:
        tables = {row["name"] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    assert "users" not in tables
    assert "user_storage" not in tables
    assert {"projects", "chat_messages", "usage_daily", "deployments", "workspace_storage"} <= tables
