"""Memory-aware auto quantization planner tests (mock CUDA only).

These tests validate the BF16-vs-INT4 decision logic of inference/engine.py with
synthetic memory numbers and a stubbed torch module. They prove the DECISION
rules only — they do NOT run the model on a GPU and do NOT prove real-hardware
behaviour. Real-GPU validation stays NOT RUN in this environment (see
VALIDATION.md).

Reference numbers used throughout (Qwen2.5-Coder-14B-Instruct, bf16 originals):
  - 14.7B params x 2 bytes = 29.4 GB decimal ~= 27.4 GiB of weights,
  - KV cache = 2 (K+V) x 48 layers x 8 kv_heads x head_dim 128 x 2 bytes
    = 196,608 bytes/token = 6.0 GiB at the default 32,768-token context,
  - fixed runtime margin = 2.0 GiB (CUDA context + activations + fragmentation).
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest

from inference.engine import (
    EngineNotAvailable,
    LocalModelEngine,
    _choose_quantization,
    _FALLBACK_KV_BYTES_PER_TOKEN,
)

GIB = 1024 ** 3
WEIGHTS_GIB = 27.4          # 14.7B x 2 bytes / GiB
KV_PER_TOKEN = 196608       # Qwen2.5-14B geometry, bf16 K+V
CONTEXT = 32768             # default LOCAL_MODEL_MAX_CONTEXT_TOKENS


# --------------------------------------------------------------- pure planner

def test_24gb_card_never_gets_bf16():
    """On a 24GB card (weights alone need ~27.4 GiB) auto must pick INT4, not BF16."""
    choice = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=CONTEXT, total_gib=24.0, free_gib=23.5,
    )
    assert choice == "int4"


def test_32gb_card_with_low_free_memory_gets_int4():
    """Nominal 32 GiB capacity is not enough if FREE memory is low at load time."""
    choice = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=CONTEXT, total_gib=32.0, free_gib=18.0,
    )
    assert choice == "int4"


def test_40gb_card_with_free_memory_gets_bf16():
    """A 40GB+ card with actually-free VRAM is the safe BF16 path."""
    choice = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=CONTEXT, total_gib=48.0, free_gib=44.0,
    )
    assert choice == "none"


def test_32gb_bf16_is_conditional_on_context():
    """32 GiB can hold bf16 ONLY with a reduced context — never guaranteed."""
    full = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=32768, total_gib=32.0, free_gib=31.5,
    )
    reduced = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=8192, total_gib=32.0, free_gib=31.5,
    )
    assert full == "int4"       # 27.4 + 6.0 + 2.0 = 35.4 GiB needed > 31.5 free
    assert reduced == "none"    # 27.4 + 1.5 + 2.0 = 30.9 GiB needed <= 31.5 free


def test_int4_insufficiency_raises_clear_error():
    """When even INT4 NF4 cannot fit, fail loudly with actionable guidance."""
    with pytest.raises(EngineNotAvailable) as exc:
        _choose_quantization(
            weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
            context_tokens=CONTEXT, total_gib=12.0, free_gib=9.0,
        )
    message = str(exc.value)
    assert "INT4 NF4" in message
    assert "LOCAL_MODEL_MAX_CONTEXT_TOKENS" in message
    assert "free" in message
    assert "15.5 GiB free" in message  # 7.5 weights + 6.0 KV + 2.0 margin


def test_reduced_context_fits_int4_on_12gb():
    """10-12GB cards: INT4 with a smaller context is the supported path."""
    choice = _choose_quantization(
        weights_gib=WEIGHTS_GIB, kv_bytes_per_token=KV_PER_TOKEN,
        context_tokens=8192, total_gib=12.0, free_gib=11.4,
    )
    assert choice == "int4"


def test_unknown_geometry_uses_safe_kv_fallback():
    """Without config.json geometry the planner stays conservative, never optimistic."""
    kv = LocalModelEngine(Path("/tmp"), model_name="x")._kv_bytes_per_token()
    assert kv == _FALLBACK_KV_BYTES_PER_TOKEN


# ------------------------------------------------- mocked-CUDA integration

class _FakeProps:
    def __init__(self, total_bytes: int) -> None:
        self.total_memory = total_bytes


class FakeCuda:
    def __init__(self, total_gib: float, free_gib: float, available: bool = True,
                 mem_get_info_fails: bool = False) -> None:
        self._total = int(total_gib * GIB)
        self._free = int(free_gib * GIB)
        self._available = available
        self._mem_get_info_fails = mem_get_info_fails
        self.mem_get_info_calls = 0

    def is_available(self) -> bool:
        return self._available

    def get_device_properties(self, index: int = 0) -> _FakeProps:
        return _FakeProps(self._total)

    def mem_get_info(self) -> tuple[int, int]:
        self.mem_get_info_calls += 1
        if self._mem_get_info_fails:
            raise RuntimeError("mem_get_info not available on this build")
        return self._free, self._total


class FakeTorch:
    def __init__(self, total_gib: float, free_gib: float, available: bool = True,
                 mem_get_info_fails: bool = False) -> None:
        self.cuda = FakeCuda(total_gib, free_gib, available, mem_get_info_fails)


@pytest.fixture
def model_dir_14b(tmp_path: Path) -> Path:
    """A 14B-shaped checkpoint: real config.json geometry + sparse 27.4 GiB shards.

    The safetensors files are SPARSE (f.truncate) — logically 27.4 GiB, ~0 bytes of
    real disk usage — so the planner measures realistic weights without storing them.
    """
    d = tmp_path / "Qwen2.5-Coder-14B-Instruct"
    d.mkdir()
    (d / "config.json").write_text(json.dumps({
        "model_type": "qwen2",
        "num_hidden_layers": 48,
        "num_attention_heads": 28,
        "num_key_value_heads": 8,
        "hidden_size": 3584,
    }), encoding="utf-8")
    with open(d / "model-00001-of-00002.safetensors", "wb") as f:
        f.truncate(int(15.0 * GIB))
    with open(d / "model-00002-of-00002.safetensors", "wb") as f:
        f.truncate(int(12.4 * GIB))
    return d


def test_auto_picks_int4_on_mocked_24gb(model_dir_14b: Path):
    engine = LocalModelEngine(model_dir_14b, model_name="Qwen2.5-Coder-14B-Instruct",
                              device="auto", quantization="auto")
    device, quant, _ = engine._resolve_device_and_quantization(FakeTorch(24.0, 23.5))
    assert (device, quant) == ("cuda", "int4")


def test_auto_picks_bf16_on_mocked_48gb(model_dir_14b: Path):
    engine = LocalModelEngine(model_dir_14b, model_name="Qwen2.5-Coder-14B-Instruct",
                              device="auto", quantization="auto")
    device, quant, _ = engine._resolve_device_and_quantization(FakeTorch(48.0, 44.0))
    assert (device, quant) == ("cuda", "none")


def test_auto_fails_clearly_when_even_int4_cannot_fit(model_dir_14b: Path):
    engine = LocalModelEngine(model_dir_14b, model_name="Qwen2.5-Coder-14B-Instruct",
                              device="auto", quantization="auto")
    with pytest.raises(EngineNotAvailable) as exc:
        engine._resolve_device_and_quantization(FakeTorch(12.0, 9.0))
    assert "LOCAL_MODEL_MAX_CONTEXT_TOKENS" in str(exc.value)


def test_manual_quantization_is_respected_even_when_tight(model_dir_14b: Path,
                                                          caplog: pytest.LogCaptureFixture):
    """An explicit bf16 on a 24GB card is honored with a warning — never swapped silently."""
    engine = LocalModelEngine(model_dir_14b, model_name="Qwen2.5-Coder-14B-Instruct",
                              device="cuda", quantization="bf16")
    with caplog.at_level(logging.WARNING, logger="qwen_studio.local_inference"):
        device, quant, _ = engine._resolve_device_and_quantization(FakeTorch(24.0, 23.5))
    assert (device, quant) == ("cuda", "bf16")
    assert "may fail with CUDA out of memory" in caplog.text


def test_manual_int4_is_respected(model_dir_14b: Path):
    engine = LocalModelEngine(model_dir_14b, model_name="Qwen2.5-Coder-14B-Instruct",
                              device="cuda", quantization="int4")
    device, quant, _ = engine._resolve_device_and_quantization(FakeTorch(48.0, 44.0))
    assert (device, quant) == ("cuda", "int4")


def test_auto_without_cuda_falls_back_to_cpu(model_dir_14b: Path):
    fake = FakeTorch(24.0, 23.5, available=False)
    engine = LocalModelEngine(model_dir_14b, model_name="x",
                              device="auto", quantization="auto")
    device, quant, _ = engine._resolve_device_and_quantization(fake)
    assert (device, quant) == ("cpu", "none")
    assert fake.cuda.mem_get_info_calls == 0  # no GPU decisions on a CPU path


def test_forced_cuda_without_gpu_errors_clearly(model_dir_14b: Path):
    engine = LocalModelEngine(model_dir_14b, model_name="x",
                              device="cuda", quantization="auto")
    with pytest.raises(EngineNotAvailable, match="no CUDA device is visible"):
        engine._resolve_device_and_quantization(FakeTorch(24.0, 23.5, available=False))


def test_cpu_device_never_touches_gpu_memory_queries(model_dir_14b: Path):
    """Running on CPU must not apply GPU memory decisions at all."""
    fake = FakeTorch(24.0, 23.5)
    engine = LocalModelEngine(model_dir_14b, model_name="x",
                              device="cpu", quantization="auto")
    device, quant, _ = engine._resolve_device_and_quantization(fake)
    assert (device, quant) == ("cpu", "none")
    assert fake.cuda.mem_get_info_calls == 0


def test_mem_get_info_unavailable_falls_back_to_discounted_total(model_dir_14b: Path,
                                                                 caplog: pytest.LogCaptureFixture):
    fake = FakeTorch(24.0, 24.0, mem_get_info_fails=True)  # free unknown
    engine = LocalModelEngine(model_dir_14b, model_name="x",
                              device="auto", quantization="auto")
    with caplog.at_level(logging.WARNING, logger="qwen_studio.local_inference"):
        device, quant, _ = engine._resolve_device_and_quantization(fake)
    assert (device, quant) == ("cuda", "int4")  # 24*0.85=20.4 free -> INT4, never BF16
    assert "Could not measure free VRAM" in caplog.text


# ------------------------------------------------------------ loader hygiene

def test_begin_load_does_not_spawn_multiple_threads(tmp_path: Path, monkeypatch):
    d = tmp_path
    (d / "config.json").write_text("{}", encoding="utf-8")
    (d / "model.safetensors").write_bytes(b"")
    monkeypatch.setattr(LocalModelEngine, "_load", lambda self: None)
    engine = LocalModelEngine(d, model_name="m")
    engine.begin_load()
    first_thread = engine._load_thread
    assert first_thread is not None
    engine.begin_load()
    assert engine._load_thread is first_thread  # no second loader spawned


def test_begin_load_never_retries_after_a_failed_attempt(tmp_path: Path):
    engine = LocalModelEngine(tmp_path, model_name="m")  # empty dir -> weights missing
    engine.begin_load()
    first_error = engine._error
    assert first_error and "No safetensors weights found" in first_error
    engine.begin_load()
    assert engine._error == first_error          # state unchanged
    assert engine._load_thread is None           # no new loader thread respawned


# --------------------------------------------------- code/docs consistency

def test_docs_match_memory_aware_planner():
    """The corrected free-VRAM guidance must exist and the old claims must be gone."""
    root = Path(__file__).resolve().parents[1]
    guide = (root / "docs" / "GPU_GUIDE.md").read_text(encoding="utf-8")
    readme = (root / "README.md").read_text(encoding="utf-8")
    start_here = (root / "START_HERE_AR.md").read_text(encoding="utf-8")
    env_example = (root / ".env.example").read_text(encoding="utf-8")

    # the required guidance table rows exist
    assert "24GB" in guide and "32GB" in guide and "40GB+" in guide
    assert "INT4" in guide and "الذاكرة الحرة" in guide
    # the old inaccurate claims are gone
    assert "يحتاج 32GB+" not in guide
    assert "32+ GiB VRAM it runs bf16" not in readme
    # free-memory wording present everywhere sizing is mentioned
    assert "free VRAM" in readme or "FREE VRAM" in readme
    assert "الذاكرة الحرة" in start_here
    assert "FREE VRAM" in env_example
