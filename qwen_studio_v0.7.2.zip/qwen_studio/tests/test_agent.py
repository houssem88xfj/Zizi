from types import SimpleNamespace
from copy import deepcopy

from backend.agent import CodingAgent
from backend.tools import workspace_context


class _FakeCompletions:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(deepcopy(kwargs))
        return next(self.outputs)


class _FakeClient:
    def __init__(self, outputs):
        self.chat = SimpleNamespace(completions=_FakeCompletions(outputs))


def _response(content=None, tool_calls=None, finish_reason="stop"):
    message = SimpleNamespace(content=content, tool_calls=tool_calls or [])
    return SimpleNamespace(choices=[SimpleNamespace(message=message, finish_reason=finish_reason)], usage=None)


def test_agent_calls_tool_only_after_atomic_authorizer(tmp_path):
    call = SimpleNamespace(
        id='tool-1',
        function=SimpleNamespace(name='list_files', arguments='{"path":"."}'),
    )
    agent = CodingAgent()
    fake_client = _FakeClient([
        _response(tool_calls=[call]),
        _response(content='I inspected the project files.'),
    ])
    agent._get_client = lambda: fake_client
    authorized = []
    with workspace_context(tmp_path, 'a' * 32):
        result = agent._run_tool_loop(
            [{'role': 'system', 'content': 'test'}],
            max_tool_calls=2,
            tool_authorizer=lambda: authorized.append(True),
        )
    assert authorized == [True]
    assert result['tool_events'][0]['tool'] == 'list_files'
    assert result['tool_events'][0]['result']['items'] == []


def test_agent_reports_quota_error_without_executing_tool(tmp_path):
    call = SimpleNamespace(
        id='tool-1',
        function=SimpleNamespace(name='list_files', arguments='{"path":"."}'),
    )
    agent = CodingAgent()
    fake_client = _FakeClient([
        _response(tool_calls=[call]),
        _response(content='Tool quota unavailable.'),
    ])
    agent._get_client = lambda: fake_client

    def deny():
        raise PermissionError('Daily tool-call limit reached.')

    with workspace_context(tmp_path, 'b' * 32):
        result = agent._run_tool_loop(
            [{'role': 'system', 'content': 'test'}],
            max_tool_calls=2,
            tool_authorizer=deny,
        )
    assert result['tool_events'][0]['result']['error'] == 'Daily tool-call limit reached.'


def test_agent_reports_truncated_native_tool_arguments_explicitly(tmp_path):
    call = SimpleNamespace(
        id="tool-truncated",
        function=SimpleNamespace(name="write_file", arguments='{"path":"index.html","content":"<html>'),
    )
    agent = CodingAgent()
    fake_client = _FakeClient([
        _response(tool_calls=[call], finish_reason="length"),
        _response(content="I will continue in smaller chunks."),
    ])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "c" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    error = result["tool_events"][0]["result"]["error"]
    assert "truncated" in error
    assert "edit_file" in error and "append_file" in error


def test_agent_reprompts_after_invalid_fallback_tool_json(tmp_path):
    outputs = [_response(content='{"tool":"write_file","arguments":{"path":"x"'),
               _response(content="Please provide smaller chunks.")]
    agent = CodingAgent()
    fake_client = _FakeClient(outputs)
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "d" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["tool_events"] == []
    assert len(fake_client.chat.completions.calls) == 2
    retry_messages = fake_client.chat.completions.calls[1]["messages"]
    assert retry_messages[-1]["content"] == (
        "The JSON tool call is invalid or truncated. Retry with a complete JSON object, "
        "or use edit_file or append_file in smaller chunks."
    )


def test_model_max_tokens_is_configurable(monkeypatch):
    from backend import config
    assert config.MODEL_MAX_TOKENS == 8192
    monkeypatch.setattr(config, "MODEL_MAX_TOKENS", 12000)
    assert config.MODEL_MAX_TOKENS == 12000


def test_agent_uses_configured_max_output_tokens(tmp_path, monkeypatch):
    from backend import agent as agent_module
    monkeypatch.setattr(agent_module, "MODEL_MAX_TOKENS", 12000)
    fake_client = _FakeClient([_response(content="done")])
    agent = CodingAgent()
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "e" * 32):
        agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=1)
    assert fake_client.chat.completions.calls[0]["max_tokens"] == 12000


def test_normal_reply_mentioning_tool_is_returned_without_retry(tmp_path):
    text = "The tool is optional; the normal answer is complete."
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=text)])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "f" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == text
    assert result["tool_events"] == []
    assert len(fake_client.chat.completions.calls) == 1


def test_json_tool_example_inside_prose_is_returned_unchanged(tmp_path):
    text = 'Example: {"tool":"write_file","arguments":{"path":"x.txt","content":"hi"}} is just documentation.'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=text)])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "1" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == text
    assert result["tool_events"] == []
    assert len(fake_client.chat.completions.calls) == 1


def test_truncated_top_level_tool_json_retries_at_most_twice(tmp_path):
    malformed = '{"tool":"write_file","arguments":{"path":"x.txt","content":"unfinished"'
    outputs = [
        _response(content=malformed),
        _response(content=malformed + " "),
        _response(content=malformed + "  "),
    ]
    agent = CodingAgent()
    fake_client = _FakeClient(outputs)
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "2" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == malformed + "  "
    assert result["tool_events"] == []
    assert len(fake_client.chat.completions.calls) == 3  # first response plus exactly two retries


def test_valid_raw_json_fallback_tool_call_executes(tmp_path):
    response = '{"tool":"write_file","arguments":{"path":"from-agent.txt","content":"written"}}'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=response), _response(content="Completed.")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "3" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert (tmp_path / "from-agent.txt").read_text(encoding="utf-8") == "written"
    assert result["tool_events"][0]["tool"] == "write_file"
    assert result["reply"] == "Completed."


def test_qwen_tool_call_xml_block_executes(tmp_path):
    content = '<tool_call>{"name":"write_file","arguments":{"path":"qwen.xml.txt","content":"executed"}}</tool_call>'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content), _response(content="Done")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "4" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert (tmp_path / "qwen.xml.txt").read_text(encoding="utf-8") == "executed"
    assert result["tool_events"][0]["tool"] == "write_file"
    assert result["reply"] == "Done"


def test_multiple_qwen_tool_call_blocks_execute_in_order(tmp_path):
    content = (
        '<tool_call>{"name":"write_file","arguments":{"path":"ordered.txt","content":"first"}}</tool_call>\n'
        '<tool_call>{"name":"write_file","arguments":"{\\"path\\":\\"ordered.txt\\",\\"content\\":\\"second\\"}"}</tool_call>'
    )
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content), _response(content="Completed")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "5" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert [event["tool"] for event in result["tool_events"]] == ["write_file", "write_file"]
    assert (tmp_path / "ordered.txt").read_text(encoding="utf-8") == "second"


def test_fenced_json_tool_call_executes(tmp_path):
    content = '```json\n{"name":"write_file","arguments":{"path":"fenced.txt","content":"fenced"}}\n```'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content), _response(content="Done")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "6" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert (tmp_path / "fenced.txt").read_text(encoding="utf-8") == "fenced"
    assert result["tool_events"][0]["tool"] == "write_file"


def test_unknown_text_tool_name_returns_error_result(tmp_path):
    content = '<tool_call>{"name":"drop_everything","arguments":{}}</tool_call>'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content), _response(content="I cannot do that")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "7" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["tool_events"][0]["result"]["error"] == "Unknown tool name: drop_everything"
    assert result["reply"] == "I cannot do that"


def test_bare_name_json_tool_call_executes(tmp_path):
    content = '{"name":"write_file","arguments":{"path":"bare-name.txt","content":"accepted"}}'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content), _response(content="Done")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "8" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert (tmp_path / "bare-name.txt").read_text(encoding="utf-8") == "accepted"
    assert result["tool_events"][0]["tool"] == "write_file"


def test_invalid_qwen_tool_call_block_retries_then_executes_valid_block(tmp_path):
    malformed = '<tool_call>{"name":"write_file","arguments":{"path":}}</tool_call>'
    valid = '<tool_call>{"name":"write_file","arguments":{"path":"recovered.txt","content":"ok"}}</tool_call>'
    agent = CodingAgent()
    fake_client = _FakeClient([
        _response(content=malformed),
        _response(content=valid),
        _response(content="Recovered and completed."),
    ])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "9" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert (tmp_path / "recovered.txt").read_text(encoding="utf-8") == "ok"
    assert result["reply"] == "Recovered and completed."
    assert len(fake_client.chat.completions.calls) == 3
    retry_message = fake_client.chat.completions.calls[1]["messages"][-1]["content"]
    assert retry_message == (
        'The <tool_call> block is invalid. Send exactly one or more complete blocks of the form '
        '<tool_call>{"name":"TOOL_NAME","arguments":{}}</tool_call> with valid JSON, '
        'or use edit_file or append_file in smaller chunks.'
    )


def test_qwen_tool_call_without_closing_tag_triggers_retry(tmp_path):
    malformed = '<tool_call>{"name":"write_file","arguments":{"path":"unfinished.txt"}}'
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=malformed), _response(content="Please resend the request.")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "a" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == "Please resend the request."
    assert len(fake_client.chat.completions.calls) == 2
    assert "The <tool_call> block is invalid." in fake_client.chat.completions.calls[1]["messages"][-1]["content"]


def test_qwen_tool_call_with_trailing_prose_triggers_retry(tmp_path):
    malformed = (
        '<tool_call>{"name":"write_file","arguments":{"path":"x.txt","content":"x"}}</tool_call>'
        '\nI will also explain what I did.'
    )
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=malformed), _response(content="The tool call was corrected.")])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "b" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == "The tool call was corrected."
    assert len(fake_client.chat.completions.calls) == 2


def test_invalid_qwen_tool_call_after_two_retries_returns_clean_error(tmp_path):
    invalid = '<tool_call>{not valid json}</tool_call>'
    agent = CodingAgent()
    fake_client = _FakeClient([
        _response(content=invalid),
        _response(content=invalid),
        _response(content=invalid),
    ])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "c" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == "The model produced an invalid tool call. Please retry your request."
    assert "<tool_call>" not in result["reply"]
    assert result["warning"] == "invalid_tool_call"
    assert len(fake_client.chat.completions.calls) == 3


def test_multiline_markdown_explanation_without_tool_call_tag_is_normal_prose(tmp_path):
    content = (
        "The tool-call protocol is shown below in abstract form.\n"
        "```text\n"
        "NAME: write_file\n"
        "ARGUMENTS: a JSON object\n"
        "```\n"
        "This is documentation, not an instruction to execute anything."
    )
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content=content)])
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, "d" * 32):
        result = agent._run_tool_loop([{"role": "system", "content": "test"}], max_tool_calls=2)
    assert result["reply"] == content
    assert result["tool_events"] == []
    assert len(fake_client.chat.completions.calls) == 1


def _native_call(i, name='list_files', arguments='{"path":"."}'):
    return SimpleNamespace(id=f'tool-{i}', function=SimpleNamespace(name=name, arguments=arguments))


def test_agent_stops_when_same_call_and_result_repeat(tmp_path):
    outputs = [_response(tool_calls=[_native_call(i)]) for i in range(6)]
    agent = CodingAgent()
    fake_client = _FakeClient(outputs)
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, 'a' * 32):
        result = agent._run_tool_loop([{'role': 'system', 'content': 'test'}], max_tool_calls=20)
    assert result['warning'] == 'loop_detected'
    assert len(result['tool_events']) == 4
    # The third identical result carries a hint so the model can change course before the stop.
    third_tool_message = [m for m in fake_client.chat.completions.calls[3]['messages'] if m.get('role') == 'tool'][2]
    assert 'Loop warning' in third_tool_message['content']


def test_agent_does_not_flag_repeated_calls_with_different_results(tmp_path):
    outputs = [
        _response(tool_calls=[_native_call(1)]),
        _response(tool_calls=[_native_call(2, 'write_file', '{"path":"a.txt","content":"x"}')]),
        _response(tool_calls=[_native_call(3)]),
        _response(tool_calls=[_native_call(4)]),
        _response(content='Done.'),
    ]
    agent = CodingAgent()
    fake_client = _FakeClient(outputs)
    agent._get_client = lambda: fake_client
    with workspace_context(tmp_path, 'a' * 32):
        result = agent._run_tool_loop([{'role': 'system', 'content': 'test'}], max_tool_calls=20)
    assert 'warning' not in result
    assert result['reply'] == 'Done.'


def test_model_temperature_is_configurable_and_validated(tmp_path, monkeypatch):
    import backend.agent as agent_module
    import backend.config as config
    monkeypatch.setattr(agent_module, 'MODEL_TEMPERATURE', 0.05)
    agent = CodingAgent()
    fake_client = _FakeClient([_response(content='ok')])
    agent._get_client = lambda: fake_client
    agent._run_tool_loop([{'role': 'system', 'content': 'test'}], max_tool_calls=1)
    assert fake_client.chat.completions.calls[0]['temperature'] == 0.05

    monkeypatch.setattr(config, 'MODEL_TEMPERATURE', 1.5)
    import pytest
    with pytest.raises(RuntimeError, match='MODEL_TEMPERATURE'):
        config.validate_runtime_config()


def test_system_prompt_requires_inspect_then_verify_workflow():
    from backend.agent import SYSTEM_PROMPT
    assert 'Inspect first' in SYSTEM_PROMPT and 'Verify' in SYSTEM_PROMPT
    assert '<tool_call>{"name":"list_files"' in SYSTEM_PROMPT


def test_path_error_hint_injected_into_tool_message():
    from backend.agent import _looks_like_path_error, _PATH_ERROR_HINT
    assert _looks_like_path_error({"error": "Path escapes the project workspace."})
    assert _looks_like_path_error({"error": "Rejected absolute path '/etc/passwd'."})
    assert not _looks_like_path_error({"error": "File too large."})
    assert not _looks_like_path_error({"path": "ok.txt"})
    assert "RELATIVE path" in _PATH_ERROR_HINT
