from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from backend import config
from backend.app import app
from backend import app as app_module
from backend import db, projects
from backend import deployments
from deploy.preflight import validate


def _valid_env():
    return {
        "APP_ENV": "production",
        "SANDBOX_RUNNER_TOKEN": "B" * 64,
        "APP_BIND_ADDRESS": "127.0.0.1",
        "ALLOW_REMOTE_ACCESS": "false",
        "FORWARDED_ALLOW_IPS": "172.28.0.1",
        "SANDBOX_ALLOW_NETWORK_INSTALL": "false",
        "PUBLIC_BASE_URL": "https://studio.example.com",
        "PUBLISH_BASE_URL": "https://sites.example.com",
        "PUBLISH_DOMAIN": "sites.example.com",
        "PREVIEW_BASE_URL": "https://preview.example.com",
        "PREVIEW_DOMAIN": "preview.example.com",
        "MODEL_BASE_URL": "https://gpu.example.net/v1",
        "MODEL_NAME": "Qwen2.5-Coder-14B-Instruct",
        "SANDBOX_RUNNER_URL": "http://sandbox-runner:8090",
    }


def test_production_preflight_accepts_secure_configuration():
    assert validate(_valid_env()) == []


def test_production_preflight_rejects_weak_runner_token_and_http():
    values = _valid_env()
    values["SANDBOX_RUNNER_TOKEN"] = "short"
    values["PUBLIC_BASE_URL"] = "http://studio.example.com"
    errors = validate(values)
    assert any("SANDBOX_RUNNER_TOKEN" in error for error in errors)
    assert any("HTTPS origin" in error for error in errors)


def test_production_runtime_validation_requires_loopback(monkeypatch):
    monkeypatch.setattr(config, "APP_ENV", "production")
    monkeypatch.setattr(config, "SANDBOX_RUNNER_TOKEN", "B" * 64)
    monkeypatch.setattr(config, "SANDBOX_ALLOW_NETWORK_INSTALL", False)
    monkeypatch.setattr(config, "APP_BIND_ADDRESS", "0.0.0.0")
    with pytest.raises(RuntimeError, match="loopback"):
        config.validate_runtime_config()


def test_runtime_validation_allows_remote_access_only_with_explicit_opt_in(monkeypatch):
    monkeypatch.setattr(config, "APP_ENV", "development")
    monkeypatch.setattr(config, "APP_BIND_ADDRESS", "0.0.0.0")
    monkeypatch.setattr(config, "ALLOW_REMOTE_ACCESS", False)
    with pytest.raises(RuntimeError, match="ALLOW_REMOTE_ACCESS"):
        config.validate_runtime_config()
    monkeypatch.setattr(config, "ALLOW_REMOTE_ACCESS", True)
    config.validate_runtime_config()


def test_no_account_or_session_settings_remain_in_config():
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / "backend" / "config.py").read_text(encoding="utf-8")
    for removed in ("AUTH_SECRET", "ALLOW_SIGNUP", "COOKIE_SECURE", "SESSION_TTL_SECONDS",
                    "MAX_PROJECTS_PER_USER", "MAX_USER_STORAGE_BYTES"):
        assert removed not in source, removed


def test_api_sets_security_headers(client):
    response = client.get("/")
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert "camera=()" in response.headers["permissions-policy"]

def test_fetch_metadata_cross_site_mutation_is_rejected(client):
    response = client.post("/api/projects", json={"name": "CSRF"}, headers={"Sec-Fetch-Site": "cross-site"})
    assert response.status_code == 403


def test_project_delete_fails_closed_when_preview_cannot_be_stopped(client, monkeypatch):
    project = client.post("/api/projects", json={"name": "Keep until runner recovers"}).json()
    monkeypatch.setattr(app_module, "SANDBOX_RUNNER_TOKEN", "R" * 64)
    monkeypatch.setattr(app_module, "stop_project_preview", lambda *_: (_ for _ in ()).throw(
        app_module.SandboxUnavailable("runner offline")))
    response = client.delete(f"/api/projects/{project['id']}")
    assert response.status_code == 503
    assert client.get(f"/api/projects/{project['id']}").status_code == 200


def test_run_check_is_charged_once(client, monkeypatch):
    project = client.post("/api/projects", json={"name": "Quota check"}).json()
    before = client.get("/api/usage").json()["tool_calls"]
    monkeypatch.setattr(app_module, "run_project_check", lambda *args: {"status": "passed"})
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "python_compile"})
    assert response.status_code == 200
    after = client.get("/api/usage").json()["tool_calls"]
    assert after - before == 1


def test_invalid_project_ids_return_404_not_500(client):
    bad_id = "not-a-project-id"
    assert client.get(f"/api/projects/{bad_id}/preview-url").status_code == 404
    assert client.get(f"/api/projects/{bad_id}/preview/status").status_code == 404
    assert client.get(f"/api/projects/{bad_id}/messages").status_code == 404


def test_run_check_quota_exhaustion_returns_429(client, monkeypatch):
    project = client.post("/api/projects", json={"name": "Quota exhausted"}).json()
    monkeypatch.setattr(app_module, "reserve_tool_call_quota", lambda *_: (_ for _ in ()).throw(
        PermissionError("Daily tool-call limit reached.")))
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "python_compile"})
    assert response.status_code == 429


def test_production_preflight_rejects_external_plain_http_model_endpoint():
    values = _valid_env()
    values["MODEL_BASE_URL"] = "http://gpu.example.net/v1"
    assert any("HTTPS for an external MODEL_BASE_URL" in error for error in validate(values))


def test_production_preflight_allows_private_http_model_endpoint():
    values = _valid_env()
    values["MODEL_BASE_URL"] = "http://10.0.0.12:8000/v1"
    assert validate(values) == []


def test_production_preflight_accepts_only_internal_npm_proxy_for_installs():
    values = _valid_env()
    values["SANDBOX_ALLOW_NETWORK_INSTALL"] = "true"
    values["SANDBOX_NPM_REGISTRY_URL"] = "http://npm-proxy:4873"
    assert validate(values) == []

    values["SANDBOX_NPM_REGISTRY_URL"] = "https://registry.npmjs.org/"
    assert any("internal npm proxy" in error for error in validate(values))


def test_preview_and_published_responses_have_non_sandbox_csp_and_no_app_cookie(client, monkeypatch, tmp_path):
    project = client.post("/api/projects", json={"name": "CSP validation"}).json()
    monkeypatch.setattr(app_module, "PREVIEW_DOMAIN", "preview.example.com")
    monkeypatch.setattr(app_module, "fetch_preview", lambda *args: (_ for _ in ()).throw(
        app_module.SandboxUnavailable("runner unavailable")))
    preview = client.get("/", headers={"host": project["id"] + ".preview.example.com"})
    assert preview.status_code == 200
    assert "sandbox" not in preview.headers["content-security-policy"].lower()
    assert "set-cookie" not in preview.headers

    monkeypatch.setattr(app_module, "PUBLISH_DIR", tmp_path / "published")
    slug_a = "site-" + "c" * 32
    slug_b = "site-" + "d" * 32
    for slug in (slug_a, slug_b):
        (tmp_path / "published" / slug).mkdir(parents=True)
        (tmp_path / "published" / slug / "index.html").write_text(f"<h1>{slug}</h1>", encoding="utf-8")
    db.create_deployment(project["id"], "d" * 32, slug_a)
    db.create_deployment(project["id"], "e" * 32, slug_b)
    monkeypatch.setattr(app_module, "PUBLISH_DOMAIN", "sites.localhost")

    bare = client.get("/api/usage", headers={"host": "sites.localhost:8080"})
    assert bare.status_code == 404
    invalid = client.get("/", headers={"host": "not-a-site.sites.localhost:8080"})
    assert invalid.status_code == 404

    published = client.get("/", headers={"host": f"{slug_a}.sites.localhost:8080"})
    assert published.status_code == 200
    assert slug_a in published.text
    assert "sandbox" not in published.headers["content-security-policy"].lower()
    assert "connect-src 'self'" in published.headers["content-security-policy"]
    assert "set-cookie" not in published.headers
    old_path_route = client.get(f"/published/{slug_a}/", headers={"host": f"{slug_a}.sites.localhost:8080"})
    assert old_path_route.status_code == 404
    app_host_old_path = client.get(f"/published/{slug_a}/")
    assert app_host_old_path.status_code == 404
    assert f"{slug_a}.sites.localhost" != f"{slug_b}.sites.localhost"


def test_production_preflight_rejects_publish_host_collision():
    values = _valid_env()
    values["PUBLISH_BASE_URL"] = "https://studio.example.com"
    values["PUBLISH_DOMAIN"] = "studio.example.com"
    errors = validate(values)
    assert any("published-sites host must differ from the app host" in error for error in errors)


def test_production_preflight_rejects_publish_domain_mismatch():
    values = _valid_env()
    values["PUBLISH_DOMAIN"] = "wrong.example.com"
    assert any("PUBLISH_DOMAIN must exactly match" in error for error in validate(values))


def test_rate_limit_cleanup_removes_empty_and_expired_keys_at_most_once_per_minute(monkeypatch):
    from collections import deque
    from backend import app as app_module
    app_module.API_ATTEMPTS.clear()
    app_module.CHAT_ATTEMPTS.clear()
    app_module.API_ATTEMPTS["expired"] = deque([1.0])
    app_module.API_ATTEMPTS["empty"] = deque()
    app_module.CHAT_ATTEMPTS["fresh"] = deque([119.0])
    monkeypatch.setattr(app_module, "_last_rate_cleanup", 0.0)
    app_module._maybe_cleanup_rate_limit_state(120.0)
    assert "expired" not in app_module.API_ATTEMPTS
    assert "empty" not in app_module.API_ATTEMPTS
    assert "fresh" in app_module.CHAT_ATTEMPTS

    app_module.API_ATTEMPTS["empty-later"] = deque()
    app_module._maybe_cleanup_rate_limit_state(150.0)  # within one minute: skip cleanup
    assert "empty-later" in app_module.API_ATTEMPTS
    app_module._maybe_cleanup_rate_limit_state(181.0)
    assert "empty-later" not in app_module.API_ATTEMPTS


def test_proxy_headers_are_trusted_only_from_configured_docker_range():
    dockerfile = (app_module.Path(__file__).resolve().parents[1] / "Dockerfile").read_text(encoding="utf-8")
    nginx = (app_module.Path(__file__).resolve().parents[1] / "deploy" / "nginx-qwen-studio.conf").read_text(encoding="utf-8")
    assert "${FORWARDED_ALLOW_IPS:-172.28.0.1}" in dockerfile
    assert "--forwarded-allow-ips \"*\"" not in dockerfile
    assert nginx.count("proxy_set_header X-Forwarded-For $remote_addr;") == 3
    assert "$proxy_add_x_forwarded_for" not in nginx


def test_api_rate_limit_returns_429_after_180_requests_per_minute(client, monkeypatch):
    # The workspace API limiter still protects the local machine from runaway loops.
    app_module.API_ATTEMPTS.clear()
    for index in range(180):
        response = client.get("/api/usage")
        assert response.status_code == 200, index
    limited = client.get("/api/usage")
    assert limited.status_code == 429


def test_production_dependencies_are_exactly_pinned_and_dev_tools_are_separate():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    production = [line.strip() for line in (root / "requirements.txt").read_text().splitlines()
                  if line.strip() and not line.lstrip().startswith("#")]
    development = (root / "requirements-dev.txt").read_text()
    dockerfile = (root / "Dockerfile").read_text()
    assert production
    assert all("==" in line for line in production)
    assert not any(line.lower().startswith("pytest") for line in production)
    assert "pytest==" in development
    assert "COPY requirements.txt requirements-local-model.txt ./" in dockerfile
    assert "COPY inference ./inference" in dockerfile
    assert "requirements-dev.txt" not in dockerfile


def test_chat_concurrency_setting_is_in_environment_template():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    env_example = (root / ".env.example").read_text()
    assert "MAX_CONCURRENT_CHATS=0" in env_example


def test_preflight_requires_a_narrow_trusted_forwarder_address():
    values = _valid_env()
    values["FORWARDED_ALLOW_IPS"] = "172.28.0.1"
    assert validate(values) == []

    for invalid in ("", "*", "0.0.0.0/0", "172.16.0.0/12", "not-an-ip", "172.28.0.0/23"):
        values = _valid_env()
        values["FORWARDED_ALLOW_IPS"] = invalid
        errors = validate(values)
        assert any("FORWARDED_ALLOW_IPS" in error for error in errors), invalid


def test_forwarded_header_diagnostic_warns_after_more_than_20_unapplied_headers(caplog):
    import logging
    from backend import app as app_module

    with app_module._FORWARDED_DIAGNOSTIC_LOCK:
        app_module._FORWARDED_HEADERS_NOT_APPLIED.clear()
        app_module._FORWARDED_DIAGNOSTIC_WARNING_AT = 0.0
    scope = {"client": ("172.28.0.1", 50000)}
    with caplog.at_level(logging.WARNING, logger="qwen_studio.proxy_headers"):
        for index in range(21):
            app_module._record_forwarded_headers_not_applied(
                scope, "198.51.100.42", now=1000.0 + index / 100
            )
    assert "X-Forwarded-For is present but not applied; check FORWARDED_ALLOW_IPS and APP_NET_GATEWAY" in caplog.text


def test_forwarded_header_diagnostic_ignores_correct_rewrite_and_missing_header():
    from backend import app as app_module

    with app_module._FORWARDED_DIAGNOSTIC_LOCK:
        app_module._FORWARDED_HEADERS_NOT_APPLIED.clear()
        app_module._FORWARDED_DIAGNOSTIC_WARNING_AT = 0.0
    app_module._record_forwarded_headers_not_applied(
        {"client": ("198.51.100.42", 50000)}, "198.51.100.42, 172.28.0.1", now=2000.0
    )
    app_module._record_forwarded_headers_not_applied(
        {"client": ("172.28.0.1", 50000)}, None, now=2001.0
    )
    assert app_module._proxy_headers_status(now=2002.0) == "ok"


def test_compose_app_network_gateway_matches_forwarded_allow_ips_defaults():
    root = app_module.Path(__file__).resolve().parents[1]
    compose = (root / "compose.yaml").read_text(encoding="utf-8")
    env_example = (root / ".env.example").read_text(encoding="utf-8")
    dockerfile = (root / "Dockerfile").read_text(encoding="utf-8")
    assert "${APP_NET_SUBNET:-172.28.0.0/24}" in compose
    assert "${APP_NET_GATEWAY:-172.28.0.1}" in compose
    assert "FORWARDED_ALLOW_IPS=172.28.0.1" in env_example
    assert "ENV FORWARDED_ALLOW_IPS=172.28.0.1" in dockerfile


def test_preflight_rejects_wildcard_publish_domain():
    values = _valid_env()
    values["PUBLISH_BASE_URL"] = "https://*.sites.example.com"
    values["PUBLISH_DOMAIN"] = "*.sites.example.com"
    assert any("bare DNS domain" in error for error in validate(values))


def test_runtime_config_rejects_wildcard_publish_domain(monkeypatch):
    monkeypatch.setattr(config, "APP_ENV", "production")
    monkeypatch.setattr(config, "SANDBOX_RUNNER_TOKEN", "B" * 64)
    monkeypatch.setattr(config, "APP_BIND_ADDRESS", "127.0.0.1")
    monkeypatch.setattr(config, "SANDBOX_ALLOW_NETWORK_INSTALL", False)
    monkeypatch.setattr(config, "PUBLIC_BASE_URL", "https://studio.example.com")
    monkeypatch.setattr(config, "PREVIEW_BASE_URL", "https://preview.example.com")
    monkeypatch.setattr(config, "PREVIEW_DOMAIN", "preview.example.com")
    monkeypatch.setattr(config, "PUBLISH_BASE_URL", "https://*.sites.example.com")
    monkeypatch.setattr(config, "PUBLISH_DOMAIN", "*.sites.example.com")
    monkeypatch.setattr(config, "MODEL_BASE_URL", "https://gpu.example.net/v1")
    with pytest.raises(RuntimeError, match="bare DNS domain"):
        config.validate_runtime_config()


def test_env_example_exists_with_clear_release_error():
    from pathlib import Path
    env_example = Path(__file__).resolve().parents[1] / ".env.example"
    assert env_example.is_file(), "Missing .env.example from the release; restore it before packaging."


def test_env_example_contains_every_config_getenv_name():
    import re
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    env_names = {
        line.split("=", 1)[0].strip()
        for line in (root / ".env.example").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#") and "=" in line
    }
    missing = set()
    for relative in ("backend/config.py", "runner/app.py"):
        source = (root / relative).read_text(encoding="utf-8")
        missing.update(set(re.findall(r"os\.getenv\(\s*['\"]([A-Z0-9_]+)['\"]", source)) - env_names)
    assert not missing, f".env.example is missing environment variables: {', '.join(sorted(missing))}"


def test_release_packaging_check_reports_missing_dotfiles(tmp_path):
    from scripts.check_release import REQUIRED_DOTFILES, missing_release_files
    for name in REQUIRED_DOTFILES:
        (tmp_path / name).write_text("placeholder", encoding="utf-8")
    assert missing_release_files(tmp_path) == []
    (tmp_path / ".env.example").unlink()
    assert missing_release_files(tmp_path) == [".env.example"]


def test_deploy_script_runs_release_check_before_build():
    from pathlib import Path
    deploy_script = (Path(__file__).resolve().parents[1] / "deploy/deploy.sh").read_text(encoding="utf-8")
    assert "python3 scripts/check_release.py" in deploy_script
    assert deploy_script.index("python3 scripts/check_release.py") < deploy_script.index("docker build -t qwen-sandbox")
