import pytest
from backend import tools


def test_agent_workspace_is_project_scoped(tmp_path):
    project_a = tmp_path / "a"
    project_b = tmp_path / "b"
    project_a.mkdir()
    project_b.mkdir()
    with tools.workspace_context(project_a):
        tools.write_file({"path": "src/app.py", "content": "A"})
        assert tools.read_file({"path": "src/app.py"})["content"] == "A"
    with tools.workspace_context(project_b):
        with pytest.raises(ValueError):
            tools.read_file({"path": "src/app.py"})
