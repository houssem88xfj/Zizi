import subprocess
import sys
from pathlib import Path


def test_publish_copy_only_exports_static_output(tmp_path):
    project = tmp_path / 'project'
    (project / 'dist').mkdir(parents=True)
    (project / 'dist' / 'index.html').write_text('<h1>built</h1>', encoding='utf-8')
    (project / 'dist' / 'app.js').write_text('console.log(1)', encoding='utf-8')
    (project / 'dist' / '.env').write_text('SECRET=do-not-copy', encoding='utf-8')
    (project / 'package.json').write_text('{"scripts":{"build":"vite build"}}', encoding='utf-8')
    target = tmp_path / 'published' / 'site-test'
    script = Path(__file__).resolve().parents[1] / 'sandbox' / 'publish_copy.py'
    result = subprocess.run(
        [sys.executable, str(script), '--source', str(project), '--target', str(target)],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    assert (target / 'index.html').read_text(encoding='utf-8') == '<h1>built</h1>'
    assert (target / 'app.js').is_file()
    assert not (target / '.env').exists()
    assert not (target / 'package.json').exists()


def test_next_server_build_without_static_export_is_rejected(tmp_path):
    from sandbox.publish_copy import choose_output
    project = tmp_path / 'next-project'
    project.mkdir()
    (project / 'index.html').write_text('starter placeholder', encoding='utf-8')
    (project / 'package.json').write_text('{"scripts":{"build":"next build"}}', encoding='utf-8')
    (project / '.next').mkdir()
    try:
        choose_output(project)
    except SystemExit as exc:
        assert 'static export' in str(exc)
    else:
        raise AssertionError('Next.js SSR build should not be published as placeholder HTML')


def _run_publish_script(project: Path, target: Path):
    script = Path(__file__).resolve().parents[1] / "sandbox" / "publish_copy.py"
    return subprocess.run(
        [sys.executable, str(script), "--source", str(project), "--target", str(target)],
        capture_output=True, text=True,
    )


def test_publish_rejects_dist_symlink_outside_source_and_copies_nothing(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "index.html").write_text("<h1>secret</h1>", encoding="utf-8")
    (project / "dist").symlink_to(outside, target_is_directory=True)
    target = tmp_path / "published" / "site-dist-link"

    result = _run_publish_script(project, target)
    assert result.returncode != 0
    assert "symlink" in result.stderr.lower()
    assert not target.exists()


def test_publish_rejects_file_symlink_outside_source_and_copies_nothing(tmp_path):
    project = tmp_path / "project"
    (project / "dist").mkdir(parents=True)
    (project / "dist" / "index.html").write_text("<h1>ok</h1>", encoding="utf-8")
    outside = tmp_path / "secret.js"
    outside.write_text("secret data", encoding="utf-8")
    (project / "dist" / "external.js").symlink_to(outside)
    target = tmp_path / "published" / "site-file-link"

    result = _run_publish_script(project, target)
    assert result.returncode != 0
    assert "outside" in result.stderr.lower()
    assert not target.exists()


def test_publish_rejects_root_index_symlink_outside_source(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    outside = tmp_path / "external.html"
    outside.write_text("<h1>outside</h1>", encoding="utf-8")
    (project / "index.html").symlink_to(outside)
    target = tmp_path / "published" / "site-root-link"

    result = _run_publish_script(project, target)
    assert result.returncode != 0
    assert "root index.html" in result.stderr.lower()
    assert not target.exists()


def test_copy_project_rejects_outside_symlink_before_copy(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    (source / "index.html").write_text("safe", encoding="utf-8")
    outside = tmp_path / "private.txt"
    outside.write_text("private", encoding="utf-8")
    (source / "link.txt").symlink_to(outside)
    target = tmp_path / "target"
    script = Path(__file__).resolve().parents[1] / "sandbox" / "copy_project.py"

    result = subprocess.run(
        [sys.executable, str(script), "--source", str(source), "--target", str(target)],
        capture_output=True, text=True,
    )
    assert result.returncode != 0
    assert "outside" in result.stderr.lower()
    assert not target.exists()
