from __future__ import annotations

import logging

from backend import app as app_module


def reset_diagnostic():
    with app_module._FORWARDED_DIAGNOSTIC_LOCK:
        app_module._FORWARDED_HEADERS_NOT_APPLIED.clear()
        app_module._FORWARDED_DIAGNOSTIC_WARNING_AT = 0.0


def test_suspect_proxy_detected_after_repeated_unapplied_forwarded_headers(caplog):
    reset_diagnostic()
    scope = {"client": ("172.28.0.1", 50000)}
    with caplog.at_level(logging.WARNING, logger="qwen_studio.proxy_headers"):
        for tick in range(21):
            app_module._record_forwarded_headers_not_applied(
                scope, "198.51.100.24", now=1000.0 + tick / 10
            )
    assert app_module._proxy_headers_status(now=1002.2) == "suspect"
    assert "X-Forwarded-For is present but not applied; check FORWARDED_ALLOW_IPS and APP_NET_GATEWAY" in caplog.text


def test_correctly_rewritten_public_client_ip_is_not_flagged():
    reset_diagnostic()
    app_module._record_forwarded_headers_not_applied(
        {"client": ("198.51.100.24", 50000)}, "198.51.100.24, 172.28.0.1", now=1000.0
    )
    assert app_module._proxy_headers_status(now=1001.0) == "ok"


def test_missing_forwarded_header_does_not_flag_proxy():
    reset_diagnostic()
    app_module._record_forwarded_headers_not_applied(
        {"client": ("172.28.0.1", 50000)}, None, now=1000.0
    )
    assert app_module._proxy_headers_status(now=1001.0) == "ok"


def test_system_status_exposes_proxy_header_health(client, monkeypatch):
    monkeypatch.setattr(app_module, "_proxy_headers_status", lambda: "suspect")
    monkeypatch.setattr(app_module, "SANDBOX_RUNNER_TOKEN", "")
    response = client.get("/api/system/status")
    assert response.status_code == 200
    assert response.json()["proxy_headers"] == "suspect"


def test_frontend_contains_proxy_warning_banner():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend/index.html").read_text(encoding="utf-8")
    js = (root / "frontend/app.js").read_text(encoding="utf-8")
    assert 'id="proxy-warning-banner"' in html
    assert "status.proxy_headers !== 'suspect'" in js
