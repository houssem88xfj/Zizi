from __future__ import annotations

import re
import pytest
from pathlib import Path

from scripts.check_release import REQUIRED_DOTFILES, missing_release_files

ROOT = Path(__file__).resolve().parents[1]


def test_env_example_is_in_release_with_clear_failure_message():
    env_example = ROOT / ".env.example"
    assert env_example.is_file(), (
        "Release is missing .env.example; restore it before packaging so operators can configure deployment."
    )


def test_every_config_and_runner_getenv_name_is_documented_in_env_example():
    names = {
        line.split("=", 1)[0].strip()
        for line in (ROOT / ".env.example").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#") and "=" in line
    }
    missing: set[str] = set()
    for relative in ("backend/config.py", "runner/app.py"):
        source = (ROOT / relative).read_text(encoding="utf-8")
        reads = set(re.findall(r"os\.getenv\(\s*['\"]([A-Z0-9_]+)['\"]", source))
        missing.update(reads - names)
    assert not missing, f".env.example is missing environment variables: {', '.join(sorted(missing))}"


def test_release_checker_requires_all_repository_dotfiles(tmp_path: Path):
    for name in REQUIRED_DOTFILES:
        (tmp_path / name).write_text("placeholder", encoding="utf-8")
    assert missing_release_files(tmp_path) == []
    (tmp_path / ".env.example").unlink()
    assert missing_release_files(tmp_path) == [".env.example"]


def test_deploy_runs_release_packaging_check_before_build():
    script = (ROOT / "deploy/deploy.sh").read_text(encoding="utf-8")
    assert "python3 scripts/check_release.py" in script
    assert script.index("python3 scripts/check_release.py") < script.index("docker build -t qwen-sandbox")


def test_required_dotfiles_are_present_in_repository():
    assert missing_release_files(ROOT) == []


def test_env_example_has_all_required_deployment_settings_and_safe_defaults():
    values = {
        line.split("=", 1)[0].strip(): line.split("=", 1)[1].strip()
        for line in (ROOT / ".env.example").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#") and "=" in line
    }
    required = {
        "APP_ENV", "SANDBOX_RUNNER_TOKEN", "APP_BIND_ADDRESS", "APP_PORT",
        "ALLOW_REMOTE_ACCESS",
        "FORWARDED_ALLOW_IPS", "APP_NET_SUBNET", "APP_NET_GATEWAY", "MODEL_BASE_URL",
        "MODEL_NAME", "MODEL_API_KEY", "MODEL_MAX_TOKENS", "MAX_CONCURRENT_CHATS",
        "MAX_PROJECTS", "MAX_DAILY_CHAT_REQUESTS", "MAX_DAILY_TOOL_CALLS",
        "MAX_DAILY_DEPLOYMENTS", "MAX_WORKSPACE_STORAGE_BYTES", "MAX_FILE_BYTES",
        "PUBLIC_BASE_URL", "PREVIEW_BASE_URL", "PREVIEW_DOMAIN", "PUBLISH_BASE_URL",
        "PUBLISH_DOMAIN", "SANDBOX_RUNNER_URL", "SANDBOX_VOLUME_NAME",
        "SANDBOX_SHARED_VOLUME_NAME", "SANDBOX_IMAGE", "SANDBOX_MAX_ACTIVE_PREVIEWS",
        "SANDBOX_MAX_CONCURRENT_RUNS", "SANDBOX_ALLOW_NETWORK_INSTALL", "SANDBOX_NPM_NETWORK",
        "SANDBOX_NPM_REGISTRY_URL",
    }
    assert required <= values.keys(), f".env.example is missing: {', '.join(sorted(required - values.keys()))}"
    assert values["FORWARDED_ALLOW_IPS"] == "172.28.0.1"
    # Shipped default: 0 = unlimited concurrency for the single-user workspace.
    assert values["MAX_CONCURRENT_CHATS"] == "0"
    assert values["APP_BIND_ADDRESS"] == "127.0.0.1"
    assert values["ALLOW_REMOTE_ACCESS"].lower() == "false"
    # Account-system variables must not return.
    for removed in ("AUTH_SECRET", "ALLOW_SIGNUP", "COOKIE_SECURE", "SESSION_TTL_SECONDS",
                    "MAX_PROJECTS_PER_USER", "MAX_USER_STORAGE_BYTES"):
        assert removed not in values, removed
    assert values["SANDBOX_NPM_REGISTRY_URL"] == ""
    assert values["SANDBOX_RUNNER_TOKEN"].startswith("REPLACE_WITH")


def test_health_endpoint_reports_release_version(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["version"] == "0.7.2"


def _clean_release_tree(root: Path) -> None:
    for name in REQUIRED_DOTFILES:
        (root / name).write_text("placeholder\n", encoding="utf-8")
    (root / "workspace").mkdir(exist_ok=True)
    (root / "workspace" / ".gitkeep").write_text("", encoding="utf-8")


def test_release_checker_passes_on_clean_staged_tree(tmp_path):
    from scripts.check_release import release_issues
    _clean_release_tree(tmp_path)
    assert release_issues(tmp_path) == []


def test_release_checker_allows_models_readme_only(tmp_path):
    from scripts.check_release import release_issues
    _clean_release_tree(tmp_path)
    (tmp_path / "models").mkdir()
    (tmp_path / "models" / "README.md").write_text("# models\n", encoding="utf-8")
    assert release_issues(tmp_path) == []


@pytest.mark.parametrize(
    "relative_path,is_dir",
    [
        ("workspace/runtime.json", False),
        ("workspace/subdir/data.txt", False),
        ("workspace/empty-directory", True),
        ("nested/.env", False),
        ("somewhere/backups", True),
        ("nested/.pytest_cache", True),
        ("nested/__pycache__", True),
        ("runtime.sqlite3", False),
        ("runtime.sqlite3-wal", False),
        ("runtime.sqlite3-shm", False),
        (".env", False),
        ("backend/__pycache__", True),
        (".pytest_cache", True),
        ("nested/release.zip", False),
        ("backups", True),
        ("models/Qwen2.5-Coder-14B-Instruct/model-00001-of-00005.safetensors", False),
        ("models/Qwen2.5-Coder-14B-Instruct/config.json", False),
        ("weights/model.bin", False),
        ("checkpoint.gguf", False),
        ("nested/.venv", True),
    ],
)
def test_release_checker_rejects_each_runtime_artifact(tmp_path, relative_path, is_dir):
    from scripts.check_release import release_issues
    _clean_release_tree(tmp_path)
    offender = tmp_path / relative_path
    if is_dir:
        offender.mkdir(parents=True)
    else:
        offender.parent.mkdir(parents=True, exist_ok=True)
        offender.write_text("runtime", encoding="utf-8")
    issues = release_issues(tmp_path)
    assert any(relative_path in issue for issue in issues), issues


def test_make_release_script_supports_git_and_non_git_archive_paths():
    script = (ROOT / "scripts/make_release.sh").read_text(encoding="utf-8")
    assert "git archive" in script
    assert "zip -q -r" in script
    assert "scripts/check_release.py" in script
    assert 'OUTPUT_DIR="${OUTPUT_DIR:-$(dirname "$ROOT")}"' in script
    assert 'OUTPUT_DIR must be outside the repository tree' in script


