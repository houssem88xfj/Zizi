import pytest
from fastapi.testclient import TestClient

from runner.app import app as runner_app


def test_runner_requires_token(monkeypatch):
    monkeypatch.setattr("runner.app.RUNNER_TOKEN", "test-secret-token")
    client = TestClient(runner_app)
    response = client.post("/run", json={"project_id": "a" * 32, "profile": "python_compile"})
    assert response.status_code == 401


def test_runner_target_rejects_traversal():
    from runner.app import _target_path
    from fastapi import HTTPException
    with pytest.raises(HTTPException):
        _target_path("../../etc")


def test_runner_profile_allowlist():
    from runner.app import PROFILE_COMMANDS
    assert set(PROFILE_COMMANDS) == {"python_compile", "pytest", "npm_test", "npm_build"}


def test_preview_network_is_unique_per_project():
    from runner.app import _preview_network_name
    assert _preview_network_name('a' * 32) != _preview_network_name('b' * 32)
    assert _preview_network_name('a' * 32) == 'qwen-preview-net-' + ('a' * 32)


def test_preview_fetch_script_compiles():
    from runner.app import PREVIEW_FETCH_CODE
    compile(PREVIEW_FETCH_CODE, '<preview-fetch>', 'exec')


def test_package_dependency_state_without_dependencies_skips_node_modules_check(monkeypatch):
    from subprocess import CompletedProcess
    from runner import app as runner_module

    seen = []
    monkeypatch.setattr(runner_module, "_docker", lambda args, timeout=10: (
        seen.append(args) or CompletedProcess(args, 0, stdout="100\n", stderr="")
    ))
    state = runner_module._package_dependency_state("volume-test")
    assert state == {"has_package": True, "has_dependencies": False, "has_lock": False}
    assert len(seen) == 1
    assert "node_modules" not in " ".join(seen[0])


def test_npm_install_uses_internal_proxy_network_and_npm_ci(monkeypatch):
    from subprocess import CompletedProcess
    from runner import app as runner_module

    captured = {}
    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", True)
    monkeypatch.setattr(runner_module, "NPM_REGISTRY_URL", "http://npm-proxy:4873")
    monkeypatch.setattr(runner_module, "NPM_INSTALL_NETWORK", "qwen_npm_install")
    monkeypatch.setattr(runner_module, "_docker", lambda args, timeout=180: (
        captured.update(args=args, timeout=timeout) or CompletedProcess(args, 0, stdout="", stderr="")
    ))
    runner_module._install_node_dependencies("a" * 32, "volume-test", {
        "has_package": True, "has_dependencies": True, "has_lock": True,
    })
    args = captured["args"]
    assert args[args.index("--network") + 1] == "qwen_npm_install"
    assert "npm ci --ignore-scripts" in args[-1]
    assert "--registry http://npm-proxy:4873" in args[-1]
    assert "bridge" not in args


def test_npm_install_skips_empty_dependency_project(monkeypatch):
    from runner import app as runner_module

    def unexpected(*args, **kwargs):
        raise AssertionError("Docker must not be called for an empty dependency set")

    monkeypatch.setattr(runner_module, "_docker", unexpected)
    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", False)
    runner_module._install_node_dependencies("a" * 32, "volume-test", {
        "has_package": True, "has_dependencies": False, "has_lock": False,
    })


def test_proxy_preview_rejects_invalid_status_and_body_combinations():
    from runner.app import _validated_preview_status
    assert _validated_preview_status(200, b"ok") == 200
    assert _validated_preview_status(599, b"error") == 599
    assert _validated_preview_status(99, b"") == 502
    assert _validated_preview_status(600, b"") == 502
    assert _validated_preview_status(101, b"unexpected body") == 502
    assert _validated_preview_status(204, b"unexpected body") == 502
    assert _validated_preview_status(304, b"unexpected body") == 502
    assert _validated_preview_status(204, b"") == 204


def test_npm_install_generates_missing_lockfile_then_runs_ci_in_same_hardened_container(monkeypatch):
    from subprocess import CompletedProcess
    from runner import app as runner_module

    calls = []
    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", True)
    monkeypatch.setattr(runner_module, "NPM_REGISTRY_URL", "http://npm-proxy:4873")
    monkeypatch.setattr(runner_module, "NPM_INSTALL_NETWORK", "qwen_npm_install")

    def fake_docker(args, timeout=180):
        calls.append((args, timeout))
        return CompletedProcess(args, 0, stdout="", stderr="")

    monkeypatch.setattr(runner_module, "_docker", fake_docker)
    runner_module._install_node_dependencies("a" * 32, "temporary-volume", {
        "has_package": True, "has_dependencies": True, "has_lock": False,
    })
    assert len(calls) == 2
    generation, install = [call[0] for call in calls]
    assert generation[-1].startswith("npm install --package-lock-only --ignore-scripts --no-audit --no-fund --registry")
    assert install[-1].startswith("npm ci --ignore-scripts --no-audit --no-fund --registry")
    for args in (generation, install):
        assert args[args.index("--network") + 1] == "qwen_npm_install"
        assert "--read-only" in args
        assert args[args.index("--cap-drop") + 1] == "ALL"
        assert args[args.index("--security-opt") + 1] == "no-new-privileges:true"
        assert args[args.index("--user") + 1] == "10001:10001"
        assert "type=volume,source=temporary-volume,target=/workspace" in args
        assert args[args.index("--memory") + 1] == "1536m"
        assert args[args.index("--pids-limit") + 1] == "128"


def test_npm_install_skips_lock_generation_when_lockfile_exists(monkeypatch):
    from subprocess import CompletedProcess
    from runner import app as runner_module

    calls = []
    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", True)
    monkeypatch.setattr(runner_module, "NPM_REGISTRY_URL", "http://npm-proxy:4873")
    monkeypatch.setattr(runner_module, "_docker", lambda args, timeout=180: (
        calls.append(args) or CompletedProcess(args, 0, stdout="", stderr="")
    ))
    runner_module._install_node_dependencies("a" * 32, "volume-with-lock", {
        "has_package": True, "has_dependencies": True, "has_lock": True,
    })
    assert len(calls) == 1
    assert calls[0][-1].startswith("npm ci")
    assert "--package-lock-only" not in calls[0][-1]


def test_npm_install_disabled_returns_clear_409(monkeypatch):
    from fastapi import HTTPException
    from runner import app as runner_module

    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", False)
    monkeypatch.setattr(runner_module, "NPM_REGISTRY_URL", "http://npm-proxy:4873")
    with pytest.raises(HTTPException) as exc:
        runner_module._install_node_dependencies("a" * 32, "volume-test", {
            "has_package": True, "has_dependencies": True, "has_lock": False,
        })
    assert exc.value.status_code == 409
    assert "internal" in exc.value.detail.lower()


def test_gvisor_runtime_is_injected_for_every_docker_run(monkeypatch):
    from runner import app as runner_module
    monkeypatch.setattr(runner_module, "SANDBOX_CONTAINER_RUNTIME", "runsc")
    assert runner_module._docker_args(["run", "--rm", "image", "true"]) == [
        "run", "--runtime", "runsc", "--rm", "image", "true"
    ]
    assert runner_module._docker_args(["volume", "create", "workspace"]) == [
        "volume", "create", "workspace"
    ]


def test_runc_runtime_does_not_change_docker_arguments(monkeypatch):
    from runner import app as runner_module
    monkeypatch.setattr(runner_module, "SANDBOX_CONTAINER_RUNTIME", "runc")
    args = ["run", "--rm", "image", "true"]
    assert runner_module._docker_args(args) == args


def test_run_container_is_named_and_reaped_on_failure(monkeypatch):
    """A timed-out run must leave a NAMED container that cleanup can remove."""
    from subprocess import CompletedProcess
    from fastapi import HTTPException
    from runner import app as runner_module

    calls = []
    removed = []

    def fake_docker(args, timeout=180):
        calls.append(args)
        if args[0] == "run" and "--name" in args:
            raise HTTPException(status_code=504, detail="Sandbox operation timed out.")
        return CompletedProcess(args, 0, stdout="", stderr="")

    monkeypatch.setattr(runner_module, "_docker", fake_docker)
    monkeypatch.setattr(runner_module, "_force_remove", lambda name: removed.append(name))
    request = runner_module.RunRequest(project_id="a" * 32, profile="python_compile")
    with pytest.raises(HTTPException):
        runner_module._run_project_inner(request)
    run_call = next(args for args in calls if args[0] == "run" and "--name" in args)
    name = run_call[run_call.index("--name") + 1]
    assert name.startswith("qwen-run-")
    assert removed == [name]


def test_npm_build_container_is_named_and_reaped_on_failure(monkeypatch):
    from subprocess import CompletedProcess
    from fastapi import HTTPException
    from runner import app as runner_module

    calls = []
    removed = []

    def fake_docker(args, timeout=180):
        calls.append(args)
        if args[0] == "run" and "--name" in args:
            raise HTTPException(status_code=504, detail="Sandbox operation timed out.")
        return CompletedProcess(args, 0, stdout="", stderr="")

    monkeypatch.setattr(runner_module, "_docker", fake_docker)
    monkeypatch.setattr(runner_module, "_force_remove", lambda name: removed.append(name))
    monkeypatch.setattr(runner_module, "_package_dependency_state",
                        lambda volume: {"has_package": True, "has_dependencies": False, "has_lock": False})
    request = runner_module.BuildRequest(project_id="a" * 32, slug="site-" + "b" * 32)
    with pytest.raises(HTTPException):
        runner_module._build_static_inner(request)
    build_call = next(args for args in calls if args[0] == "run" and "--name" in args)
    name = build_call[build_call.index("--name") + 1]
    assert name.startswith("qwen-build-")
    assert removed == [name]


def test_npm_install_containers_carry_unique_names(monkeypatch):
    from subprocess import CompletedProcess
    from runner import app as runner_module

    calls = []
    monkeypatch.setattr(runner_module, "ALLOW_NETWORK_INSTALL", True)
    monkeypatch.setattr(runner_module, "NPM_REGISTRY_URL", "http://npm-proxy:4873")
    monkeypatch.setattr(runner_module, "NPM_INSTALL_NETWORK", "qwen_npm_install")
    monkeypatch.setattr(runner_module, "_docker", lambda args, timeout=180: (
        calls.append(args) or CompletedProcess(args, 0, stdout="", stderr="")
    ))
    runner_module._install_node_dependencies("a" * 32, "temporary-volume", {
        "has_package": True, "has_dependencies": True, "has_lock": False,
    })
    assert len(calls) == 2
    names = []
    for args in calls:
        assert args[0] == "run" and args[1] == "--name"
        names.append(args[2])
    assert names[0].startswith("qwen-npm-lock-")
    assert names[1].startswith("qwen-npm-ci-")
    assert names[0] != names[1]


def test_force_remove_swallows_cleanup_errors():
    from fastapi import HTTPException
    from runner import app as runner_module

    def failing_docker(args, timeout=15):
        raise HTTPException(status_code=503, detail="Docker CLI is not installed in the runner.")

    original = runner_module._docker
    try:
        runner_module._docker = failing_docker
        runner_module._force_remove("qwen-run-anything")  # must not raise
    finally:
        runner_module._docker = original


def test_runner_limit_env_parsing_defaults():
    from runner.app import (SANDBOX_MEMORY_LIMIT, SANDBOX_INSTALL_MEMORY_LIMIT,
                            SANDBOX_CPU_LIMIT, SANDBOX_PIDS_LIMIT,
                            SANDBOX_TIMEOUT_SECONDS, SANDBOX_MAX_OUTPUT_BYTES)
    assert SANDBOX_MEMORY_LIMIT == "1536m"
    assert SANDBOX_INSTALL_MEMORY_LIMIT == "1536m"
    assert SANDBOX_CPU_LIMIT == "1.25"
    assert SANDBOX_PIDS_LIMIT == 128
    assert SANDBOX_TIMEOUT_SECONDS == 120
    assert SANDBOX_MAX_OUTPUT_BYTES == 12000


def test_runner_limit_env_parsing_rejects_bad_values(monkeypatch):
    import importlib
    import runner.app as runner_module
    for name, value in [
        ("SANDBOX_MEMORY_LIMIT", "not-a-number"),
        ("SANDBOX_MEMORY_LIMIT", "32m"),
        ("SANDBOX_CPU_LIMIT", "0"),
        ("SANDBOX_PIDS_LIMIT", "8"),
        ("SANDBOX_TIMEOUT_SECONDS", "5"),
        ("SANDBOX_MAX_OUTPUT_BYTES", "500"),
    ]:
        monkeypatch.setenv(name, value)
        with pytest.raises(RuntimeError):
            importlib.reload(runner_module)
    monkeypatch.delenv("SANDBOX_MEMORY_LIMIT", raising=False)
    monkeypatch.delenv("SANDBOX_CPU_LIMIT", raising=False)
    monkeypatch.delenv("SANDBOX_PIDS_LIMIT", raising=False)
    monkeypatch.delenv("SANDBOX_TIMEOUT_SECONDS", raising=False)
    monkeypatch.delenv("SANDBOX_MAX_OUTPUT_BYTES", raising=False)
    importlib.reload(runner_module)
