from types import SimpleNamespace

import pytest

from backend import agent as agent_module
from backend.agent import CodingAgent, _compact_messages
from scripts import eval_agent


def _tool_msg(text, i=0):
    return {"role": "tool", "tool_call_id": f"t{i}", "content": text}


def test_compaction_shrinks_oldest_tool_outputs_and_protects_recent_and_system():
    messages = [
        {"role": "system", "content": "S" * 5000},
        {"role": "user", "content": "U" * 5000},
        {"role": "assistant", "content": "a"},
        _tool_msg("old" * 5000, 1),
        _tool_msg("mid" * 5000, 2),
        {"role": "assistant", "content": "b"},
        _tool_msg("new1" * 5000, 3),
        _tool_msg("new2" * 5000, 4),
        {"role": "assistant", "content": "c"},
        {"role": "user", "content": "latest"},
    ]
    shrunk = _compact_messages(messages, budget=40000)
    assert shrunk >= 1
    assert messages[0]["content"] == "S" * 5000 and messages[1]["content"] == "U" * 5000
    assert messages[3]["content"].endswith(agent_module._COMPACT_MARK)
    assert messages[-1]["content"] == "latest"
    assert messages[-3]["content"] == "new2" * 5000 or messages[-3]["role"] == "assistant"


def test_compaction_is_a_noop_under_budget_and_idempotent():
    messages = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}, _tool_msg("x" * 2000)] + [
        {"role": "assistant", "content": "a"}] * 5
    assert _compact_messages(messages, budget=10**6) == 0
    big = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}, _tool_msg("y" * 9000)] + [
        {"role": "assistant", "content": "a"}] * 5
    assert _compact_messages(big, budget=1000) == 1
    assert _compact_messages(big, budget=1000) == 0


def test_agent_loop_compacts_before_each_model_call(tmp_path, monkeypatch):
    seen = []

    class Completions:
        def __init__(self):
            self.step = 0

        def create(self, **kwargs):
            seen.append([dict(m) for m in kwargs["messages"]])
            self.step += 1
            if self.step < 6:
                call = SimpleNamespace(id=f"c{self.step}", function=SimpleNamespace(name="read_file", arguments='{"path":"big%d.txt"}' % self.step))
                msg = SimpleNamespace(content=None, tool_calls=[call])
            else:
                msg = SimpleNamespace(content="done", tool_calls=[])
            return SimpleNamespace(choices=[SimpleNamespace(message=msg, finish_reason="stop")], usage=None)

    client = SimpleNamespace(chat=SimpleNamespace(completions=Completions()))
    monkeypatch.setattr(agent_module, "MODEL_CONTEXT_CHAR_BUDGET", 1500)
    for n in range(1, 6):
        (tmp_path / f"big{n}.txt").write_text(chr(96 + n) * 20000)
    agent = CodingAgent()
    agent._get_client = lambda: client
    from backend.tools import workspace_context
    messages = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}]
    with workspace_context(tmp_path, "a" * 32):
        result = agent._run_tool_loop(messages, max_tool_calls=10)
    assert result["reply"] == "done"
    assert any(m.get("content", "") and m["content"].endswith(agent_module._COMPACT_MARK) for m in seen[-1])


def test_eval_has_twenty_well_formed_tasks_and_checks_fail_closed(tmp_path):
    tasks = eval_agent.build_tasks()
    assert len(tasks) >= 20
    titles = [t[0] for t in tasks]
    assert len(set(titles)) == len(titles)
    for title, prompt, prepare, check in tasks:
        folder = tmp_path / title.replace(" ", "_")
        folder.mkdir()
        if prepare:
            prepare(folder)
        passed, detail = check(folder, {"tool_events": [], "reply": ""})
        # Nothing was done by an agent, so no task may pass (except tasks whose correct outcome is "do nothing").
        if title not in {"Refuse to expose secrets", "Resist prompt injection in a file"}:
            assert not passed, f"{title} passes without any agent work"
        assert isinstance(detail, str)


def test_eval_list_runs_without_a_model(capsys):
    assert eval_agent.main(["--list"]) == 0
    assert "Fix off-by-one bug" in capsys.readouterr().out


def test_account_operator_scripts_are_removed():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    for name in ("create_user.py", "reset_password.py", "revoke_sessions.py"):
        assert not (root / "scripts" / name).exists(), name
