from fastapi.testclient import TestClient

from backend.app import app
from backend import db, projects


def test_workspace_create_save_preview_publish_and_delete(client, tmp_path, monkeypatch):
    created = client.post("/api/projects", json={"name": "API test"})
    assert created.status_code == 201
    project_id = created.json()["id"]

    listing = client.get(f"/api/projects/{project_id}/files")
    assert listing.status_code == 200
    assert {item["name"] for item in listing.json()["items"]} >= {"index.html", "style.css", "app.js"}

    saved = client.put(f"/api/projects/{project_id}/file", json={"path": "index.html", "content": "<h1>Edited</h1>"})
    assert saved.status_code == 200
    preview = client.get(f"/api/projects/{project_id}/preview")
    assert preview.status_code == 200
    assert "Edited" in preview.text
    assert preview.headers["content-security-policy"].lower().startswith("sandbox allow-scripts;")
    assert preview.headers["content-disposition"] == "inline"
    assert preview.headers["cross-origin-resource-policy"] == "same-origin"
    preview_asset = client.get(f"/api/projects/{project_id}/preview/app.js")
    assert preview_asset.status_code == 200
    assert preview_asset.headers["content-security-policy"].lower().startswith("sandbox allow-scripts;")
    assert preview_asset.headers["cross-origin-resource-policy"] == "same-origin"

    publish = client.post(f"/api/projects/{project_id}/publish")
    assert publish.status_code == 201, publish.text
    from urllib.parse import urlparse
    published_url = urlparse(publish.json()["url"])
    assert published_url.scheme == "http"
    assert published_url.path == "/"
    assert published_url.hostname.startswith("site-")
    assert published_url.hostname.endswith(".sites.localhost")
    public_page = client.get("/", headers={"host": f"{published_url.hostname}:8080"})
    assert public_page.status_code == 200
    assert "Edited" in public_page.text
    assert "sandbox" not in public_page.headers["content-security-policy"].lower()

    removed = client.delete(f"/api/projects/{project_id}")
    assert removed.status_code == 200


def test_workspace_opens_directly_without_login(client):
    """The single-user workspace must be fully usable with no authentication step."""
    assert client.get("/api/projects").status_code == 200
    assert client.get("/api/usage").status_code == 200
    assert client.get("/api/deployments").status_code == 200
    assert client.get("/api/system/status").status_code == 200
    for route in ("/api/auth/me", "/api/auth/config", "/api/auth/login", "/api/auth/logout", "/api/auth/register"):
        assert client.get(route).status_code == 404, route
    assert client.post("/api/auth/login", json={"email": "a@b.co", "password": "x"}).status_code == 404


def test_hidden_and_secret_files_are_not_served(client):
    created = client.post("/api/projects", json={"name": "Protected"})
    project_id = created.json()["id"]
    response = client.get(f"/api/projects/{project_id}/file", params={"path": ".qwen-project.json"})
    assert response.status_code == 400


def test_project_metadata_is_not_tied_to_a_user_id(client):
    created = client.post("/api/projects", json={"name": "Local"})
    project = created.json()
    assert "owner_id" not in project
    from backend.projects import project_path
    metadata = (project_path(project["id"]) / ".qwen-project.json").read_text(encoding="utf-8")
    assert "owner_id" not in metadata


def test_quota_endpoint_and_unknown_project_access(client):
    usage = client.get("/api/usage")
    assert usage.status_code == 200
    # Shipped default: 0 = unlimited → the endpoint reports the limit as None.
    assert usage.json()["limits"]["chat_requests"] is None
    assert client.get("/api/projects/" + "a" * 32).status_code == 404


def test_sandbox_endpoint_reports_not_configured(client, monkeypatch):
    from backend import app as app_module
    monkeypatch.setattr(app_module, "run_project_check", lambda *args: (_ for _ in ()).throw(
        app_module.SandboxUnavailable("Sandbox runner is not configured.")))
    project = client.post("/api/projects", json={"name": "run test"}).json()
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "python_compile"})
    assert response.status_code == 503


def test_project_chat_history_endpoint(client):
    project = client.post('/api/projects', json={'name': 'History'}).json()
    db.save_message(project['id'], 'user', 'Build a todo app')
    response = client.get(f"/api/projects/{project['id']}/messages")
    assert response.status_code == 200
    assert response.json()['messages'][-1]['content'] == 'Build a todo app'


def test_cross_origin_mutation_is_rejected(client):
    response = client.post(
        '/api/projects',
        json={'name': 'Blocked origin'},
        headers={'Origin': 'https://attacker.example'},
    )
    assert response.status_code == 403


def test_package_project_uses_isolated_build_runner(client, monkeypatch):
    from backend import app as app_module
    project = client.post('/api/projects', json={'name': 'Vite app'}).json()
    saved = client.put(
        f"/api/projects/{project['id']}/file",
        json={'path': 'package.json', 'content': '{"scripts":{"build":"vite build"}}'},
    )
    assert saved.status_code == 200
    called = {}

    def fake_publish(project_id, public_base_url):
        called['project_id'] = project_id
        return {'url': public_base_url + '/published/fake/', 'hosting': 'local-static'}

    monkeypatch.setattr(app_module, 'publish_built_project', fake_publish)
    response = client.post(f"/api/projects/{project['id']}/publish")
    assert response.status_code == 201
    assert called['project_id'] == project['id']


def test_public_preview_subdomain_serves_static_files_without_app_cookie(client):
    project = client.post('/api/projects', json={'name': 'Preview origin'}).json()
    project_id = project['id']
    response = client.get('/', headers={'Host': f'{project_id}.preview.localhost'})
    assert response.status_code == 200
    policy = response.headers['content-security-policy']
    assert 'sandbox' not in policy.lower()
    # The preview is cross-origin from the studio iframe, so it must not self-block via frame-ancestors 'self'.
    assert 'frame-ancestors' not in policy
    css = client.get('/style.css', headers={'Host': f'{project_id}.preview.localhost'})
    assert css.status_code == 200
    assert 'font-family' in css.text


def test_chat_concurrency_limit_returns_429_and_health_remains_available(client, monkeypatch):
    import threading
    import inspect
    from backend import app as app_module

    project = client.post("/api/projects", json={"name": "Busy test"}).json()
    one_slot = threading.BoundedSemaphore(1)
    one_slot.acquire()
    monkeypatch.setattr(app_module, "CHAT_EXECUTION_SLOTS", one_slot)

    busy = client.post("/api/chat", json={"project_id": project["id"], "message": "build something"})
    assert busy.status_code == 429
    assert busy.json()["detail"] == "Server busy, retry shortly"
    assert client.get("/health").status_code == 200
    assert inspect.iscoroutinefunction(app_module.health)
    one_slot.release()


def test_project_preview_iframe_allows_same_origin_only_on_separate_preview_host():
    from pathlib import Path
    html = (Path(__file__).resolve().parents[1] / "frontend" / "index.html").read_text(encoding="utf-8")
    assert 'sandbox="allow-scripts allow-same-origin"' in html


def test_run_check_auto_resolves_python_project(client, monkeypatch):
    from backend import app as app_module
    seen = {}

    def fake_check(project_id, check, target="."):
        seen["check"] = check
        return {"profile": check, "status": "passed", "return_code": 0, "stdout": "", "stderr": "", "isolation": {}}

    monkeypatch.setattr(app_module, "run_project_check", fake_check)
    project = client.post("/api/projects", json={"name": "auto py"}).json()
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "auto"})
    assert response.status_code == 200
    assert seen["check"] == "python_compile"


def test_run_check_auto_resolves_npm_project(client, monkeypatch):
    from backend import app as app_module
    from backend.projects import project_path
    seen = {}

    def fake_check(project_id, check, target="."):
        seen["check"] = check
        return {"profile": check, "status": "passed", "return_code": 0, "stdout": "", "stderr": "", "isolation": {}}

    monkeypatch.setattr(app_module, "run_project_check", fake_check)
    project = client.post("/api/projects", json={"name": "auto npm"}).json()
    (project_path(project["id"]) / "package.json").write_text(
        '{"name":"x","scripts":{"build":"echo ok"}}', encoding="utf-8")
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "auto"})
    assert response.status_code == 200
    assert seen["check"] == "npm_build"


def test_run_check_rejects_unknown_profile(client):
    project = client.post("/api/projects", json={"name": "bad profile"}).json()
    response = client.post(f"/api/projects/{project['id']}/run", json={"check": "rm -rf"})
    assert response.status_code == 422


def test_deployments_list_includes_public_url(client):
    project = client.post("/api/projects", json={"name": "url test"}).json()
    from backend.db import create_deployment
    from backend.config import PUBLISH_DOMAIN
    slug = "site-" + "b" * 32
    create_deployment(project["id"], "d" * 32, slug)
    rows = client.get("/api/deployments").json()["deployments"]
    row = next(item for item in rows if item["slug"] == slug)
    assert row["url"] == f"http://{slug}.{PUBLISH_DOMAIN}/"


def test_frontend_terminal_elements_and_no_legacy_published_links():
    import re
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    for element_id in ("terminal-run", "terminal-command", "terminal-output", "terminal-status"):
        assert f'id="{element_id}"' in html
    js = (root / "frontend" / "app.js").read_text(encoding="utf-8")
    assert "/published/" not in js, "deployment links must use deployment.url"
    assert "deployment.url" in js
    assert "runTerminalCommand" in js and "startSystemStatusPolling" in js
    assert re.search(r"terminal-run'\)\.addEventListener", js)


def test_frontend_has_no_account_ui():
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "app.js").read_text(encoding="utf-8")
    for marker in ("auth-screen", "auth-form", "auth-email", "auth-password", "logout-button", "user-label"):
        assert marker not in html, marker
        assert marker not in js, marker
    for marker in ("/api/auth/", "Sign in", "Create an account", "password"):
        assert marker not in js.lower(), marker
