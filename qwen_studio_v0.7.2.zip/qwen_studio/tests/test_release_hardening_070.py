from __future__ import annotations
import ast, re, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_nginx_studio_timeouts_exceed_runner_build_and_smoke_timeout():
    nginx=(ROOT/'deploy/nginx-qwen-studio.conf').read_text()
    block=nginx.split('# Authenticated studio and per-project preview origins.',1)[1].split('server {',1)[1].split('\n}',1)[0]
    value=int(re.search(r'proxy_read_timeout\s+(\d+)s',block).group(1))
    source=(ROOT/'backend/sandbox_client.py').read_text()
    vals=[float(x) for x in re.findall(r'timeout\s*=\s*(\d+(?:\.\d+)?)',source)]
    largest=max(vals)
    smoke=(ROOT/'scripts/smoke_test.py').read_text()
    publish=int(re.search(r'TIMEOUT_PUBLISH_NPM\s*=\s*(\d+)',smoke).group(1))
    assert value>largest and publish>largest
    pubblock=nginx.split('server_name *.sites.example.com;',2)[-1]
    assert 'proxy_read_timeout 60s' in pubblock

def test_nginx_body_limit_exceeds_file_limit_plus_json_overhead():
    config=(ROOT/'backend/config.py').read_text(); maximum=int(re.search(r'MAX_FILE_BYTES\s*=\s*int\(os.getenv\([^,]+,\s*"(\d+)"',config).group(1))
    nginx=(ROOT/'deploy/nginx-qwen-studio.conf').read_text()
    size=re.search(r'client_max_body_size\s+(\d+)([kKmM]?)',nginx)
    factor={'':1,'k':1024,'m':1024**2}[size.group(2).lower()]
    assert int(size.group(1))*factor >= maximum+100*1024

def test_verify_pins_handles_exists_missing_and_network(monkeypatch):
    from scripts import verify_pins
    class Response:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def read(self,n): return b'{}'
    def exists(url,timeout): return Response()
    assert verify_pins.verify([('pypi','fastapi','1','x')],exists)[0][0]=='EXISTS'
    def missing(url,timeout): raise __import__('urllib.error').error.HTTPError(url,404,'missing',{},None)
    assert verify_pins.verify([('pypi','fastapi','1','x')],missing)[0][0]=='MISSING'
    def offline(url,timeout): raise OSError('offline')
    assert verify_pins.verify([('pypi','fastapi','1','x')],offline)[0][0]=='SKIP'

def test_verify_pins_parses_requirements_dockerfiles_and_verdaccio(tmp_path):
    (tmp_path/'requirements.txt').write_text('fastapi==1.2.3\n')
    (tmp_path/'requirements-dev.txt').write_text('pytest==9.1.0\n')
    (tmp_path/'runner').mkdir(); (tmp_path/'sandbox').mkdir()
    (tmp_path/'runner/Dockerfile').write_text('RUN pip install fastapi==1.2.3 uvicorn==1.2.3 pydantic==1.2.3')
    (tmp_path/'sandbox/Dockerfile').write_text('RUN pip install pytest==9.1.0')
    (tmp_path/'compose.yaml').write_text('image: verdaccio/verdaccio:5.31.1')
    from scripts.verify_pins import collect_pins
    got=collect_pins(tmp_path)
    assert {(x[1],x[2]) for x in got} >= {('fastapi','1.2.3'),('pytest','9.1.0'),('uvicorn','1.2.3'),('pydantic','1.2.3'),('verdaccio/verdaccio','5.31.1')}

def test_check_consistency_script_runs():
    result=subprocess.run([sys.executable,'scripts/check_consistency.py'],cwd=ROOT,text=True,capture_output=True)
    assert result.returncode==0, result.stdout+'\n'+result.stderr

def test_verify_all_and_make_release_are_wired():
    verify=(ROOT/'scripts/verify_all.sh').read_text(); release=(ROOT/'scripts/make_release.sh').read_text(); deploy=(ROOT/'deploy/deploy.sh').read_text()
    for item in ('pytest','node --check frontend/app.js','compileall','check_consistency.py','verify_pins.py','check_release.py','bash -n'):
        assert item in verify
    assert 'verify_all.sh' in release and 'verify_pins.py' in deploy

def test_smoke_steps_are_in_runbook_failure_table():
    smoke=(ROOT/'scripts/smoke_test.py').read_text(); runbook=(ROOT/'docs/RUNBOOK.md').read_text()
    labels=re.findall(r'self\.check\("(\d+)(?:[a-z])?\. ([^"]+)',smoke)
    for number,label in labels:
        assert re.search(rf'\|\s*{re.escape(number)}\.',runbook), f'smoke step {number}. {label} missing from runbook'
