# مجلد الأوزان المحلية — Local weights directory

هذا المجلد يستضيف أوزان النموذج بصيغة safetensors، مجلد واحد لكل نموذج واسمه =
قيمة `LOCAL_MODEL_NAME` (الافتراضي `Qwen2.5-Coder-14B-Instruct`).

Put Hugging Face safetensors weights here, one folder per model named after
`LOCAL_MODEL_NAME` (default `Qwen2.5-Coder-14B-Instruct`):

```
models/
  Qwen2.5-Coder-14B-Instruct/        # المستودع الرسمي: Qwen/Qwen2.5-Coder-14B-Instruct
    config.json
    generation_config.json
    model-00001-of-00006.safetensors  # ست شِردات في المستودع الرسمي (~27.5 GiB إجمالًا)
    model-00002-of-00006.safetensors
    model-00003-of-00006.safetensors
    model-00004-of-00006.safetensors
    model-00005-of-00006.safetensors
    model-00006-of-00006.safetensors
    model.safetensors.index.json
    tokenizer.json
    tokenizer_config.json
    vocab.json
    merges.txt
```

## الطريقة الأسهل — زر Model داخل التطبيق (0.7.2)

افتح التطبيق، اضغط زر **Model** في الشريط العلوي ثم **Download model**. يقوم المدير
الدمج في `backend/model_manager.py` بـ:

1. جلب قائمة الملفات والأحجام من واجهة Hugging Face Hub الرسمية (`HfApi.model_info`)
   والتحقق من المساحة الحرة على القرص قبل البدء (لا شيء يُنزّل تلقائيًا عند التثبيت أو
   بدء التشغيل — التنزيل يبدأ فقط بضغطة المستخدم).
2. تنزيل ملفات النموذج فقط (`safetensors`/`json`/`txt`/`jinja`/`md`/`LICENSE`) إلى هذا
   المجلد عبر HTTP Range مع ملفات `<file>.part` — **الاستكمال عند انقطاع الإنترنت بدون
   إعادة تنزيل الملفات المكتملة**، مع عرض النسبة والسرعة والحجم المتبقي والوقت التقريبي.
3. التحقق من السلامة: مطابقة SHA-256 لكل شِرد كما نشره المستودع، اكتمال كل الشِردات
   المذكورة في `model.safetensors.index.json`، صلاحية `config.json`، ووجود ملفات
   الـtokenizer. التحقق يعمل بلا إنترنت للنماذج المنقولة يدويًا (زر **Verify files**).
4. عند نجاح التحقق: كتابة `LOCAL_INFERENCE=true` في `.env` (وتعليق أي `MODEL_BASE_URL`
   خارجي مع إبقاء قيمته السابقة في تعليق قابل للتراجع)، وتشغيل محرك الاستدلال المحلي
   داخل نفس العملية، وإظهار الحالة: غير مثبت / جاري التنزيل / متوقف (قابل للاستكمال) /
   جاهز / فشل التحميل مع السبب والحل.
5. من نفس النافذة: تحديد مسار نموذج موجود مسبقًا (**Use this folder**)، إعادة المحاولة،
   وحذف الملفات (**Delete model files** بعد تأكيد صريح، ويعيد `LOCAL_INFERENCE=false`).

الأمان: المدير ينفّذ طلبات GET/HEAD فقط — لا يرفع أي ملف من جهازك إلى Hugging Face،
لا يقرأ ولا يرسل أي مفاتيح أو أسرار، ولا يسمح بتنزيل ملفات تنفيذية أو سكربتات أو أرشيفات
(`.exe/.dll/.bat/.sh/.py/.zip/...` مرفوضة من قائمة المانيفست). المستودع الافتراضي عام ولا
يحتاج توكنًا؛ لا يوجد توكن في الكود إطلاقًا. لاستخدام مرآة مختلفة: `HF_ENDPOINT`؛ ولتفعيل
مستودع آخر: `QWEN_MODEL_REPO_ID`.

## طريقة النسخ اليدوية (بديلة)

```bash
mkdir -p models
python3 -c "import shutil; shutil.move('path/to/Qwen2.5-Coder-14B-Instruct', 'models/Qwen2.5-Coder-14B-Instruct')"
# أو بـ huggingface_hub:
pip install -U "huggingface_hub[cli]"
hf download Qwen/Qwen2.5-Coder-14B-Instruct --local-dir models/Qwen2.5-Coder-14B-Instruct
```

بعد النسخ اليدوي تحقق من الاكتمال بزر **Verify files** في نافذة Model أو بـ
`python3 scripts/verify_weights.py`، ثم فعّل `LOCAL_INFERENCE=true` في `.env`
وأعد تشغيل الخدمة. المحرك يقرأ الملفات من القرص فقط (`local_files_only=True`) ولا يجلب
أي شيء من الإنترنت وقت التشغيل.

## الترخيص — License

أوزان Qwen2.5-Coder-14B-Instruct مرخّصة **Apache-2.0** من Alibaba/Qwen (تحقّق منه في
ملف LICENSE داخل مستودع النموذج الرسمي على Hugging Face — يُنزّل مع باقي الملفات عند
استخدام زر Model). عند إعادة توزيع الأوزان أبقِ ملف ترخيص النموذج بجانب الملفات ولا تحذف
إسناد Qwen من ملفات الميتاداتا. المنصة لا تعدّل الأوزان ولا تدّعي امتلاكها أو تدريبها —
راجع `LICENSES.md` و`NOTICE` في جذر المشروع. ترخيص تطبيق الاستوديو نفسه MIT ومنفصل عن
ترخيص النموذج.

Qwen2.5-Coder-14B-Instruct weights are Apache-2.0 licensed by Alibaba/Qwen. When
redistributing the weight files, keep the model's LICENSE file alongside them. The
studio application never modifies the weights and claims no ownership of them.
