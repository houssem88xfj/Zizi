#!/bin/sh
set -eu

# Named Docker volumes are initially root-owned. Fix this once before dropping privileges.
mkdir -p /app/workspace /app/workspace/projects /app/workspace/published
if [ ! -f /app/workspace/.qwen-volume-permissions-v1 ]; then
  chown -R appuser:appuser /app/workspace
  touch /app/workspace/.qwen-volume-permissions-v1
  chown appuser:appuser /app/workspace/.qwen-volume-permissions-v1
fi

exec gosu appuser "$@"
