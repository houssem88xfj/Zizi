# Changelog

## 0.7.2 — Local model manager, UI design pass, GPU/CUDA install path, Docker model-extra dependencies, documentation accuracy
- **UI design pass (CSS only):** a second-pass polish of the graphite theme with zero
  HTML/JS/behaviour changes — a spacing/elevation rhythm (panel radius/shadow scale,
  deeper app background, layered panel/panel-deep surfaces), refined interactive states
  (hover/active/focus-visible rings on every control, unified button sizes, accent press
  states), slim custom scrollbars and accent text selection, an accent left-rail for the
  active project and the selected file, tinted project icons, asymmetric chat bubble
  corners with chip-style system messages, dashed empty states, a dark preview empty
  state (the white block only appears once a real frame loads), blurred dialog backdrops
  with a subtle open animation, tabular numerals in counters, and `prefers-reduced-motion`
  support. Verified live in a browser (Playwright captures across desktop/narrow/dialog
  states) and by the full release gate; all element IDs, contract tests and behaviour
  unchanged.
- **New Model manager:** a **Model** button in the studio UI downloads the official
  `Qwen/Qwen2.5-Coder-14B-Instruct` checkpoint from the Hugging Face Hub on explicit user
  request only (`backend/model_manager.py` + `GET/POST /api/model/*` endpoints). Resumable
  across connection drops (ETag-validated HTTP Range into `.part` files, finished files
  never re-downloaded), progress with percent/speed/remaining/ETA per file and overall,
  disk-space precheck with a clear refusal, SHA-256 verification of every LFS shard against
  the repository manifest plus shard completeness from `model.safetensors.index.json`,
  automatic `LOCAL_INFERENCE=true` binding (`.env` write + in-process engine start) after
  successful verification, existing-checkpoint path binding (**Use this folder**), retry,
  and delete-with-confirmation (resets `LOCAL_INFERENCE=false`). Only model artefacts are
  fetched (safetensors/json/txt/jinja/md/LICENSE); executables, archives and scripts are
  refused; GET/HEAD only — nothing from this machine is uploaded and no token is read or
  sent. Installers and startup never download weights. New deps: `huggingface_hub==2.4.0`,
  `requests==2.32.5`; new optional env `QWEN_MODEL_REPO_ID` (see `.env.example`).
- **Installers no longer install a CPU-only torch build on NVIDIA hosts.** `scripts/install.sh`
  and `scripts\install.bat` accept an explicit `--cpu` / `--cuda` (alias `--gpu`) choice with
  `--with-model`; without a flag they preselect CUDA when `nvidia-smi` actually lists a GPU,
  otherwise CPU — and the preselection is never trusted: after installing, the new
  `scripts/check_torch.py` runs a REAL `torch.cuda.is_available()` check. A `--cuda` install
  whose torch cannot see the GPU fails the installer with the actual cause (CPU-only build
  vs missing/old driver) and the fix, instead of a fake success message. An existing torch
  build is reused when it already matches the request, and switching builds uninstalls first
  so two conflicting torch builds never coexist. CPU-only installs remain fully supported.
- **New `scripts/check_torch.py`:** read-only torch/CUDA verifier (torch version, CUDA build
  tag, `torch.cuda.is_available()`, device names, driver probe on failure, bf16 support;
  optional `--check-model-extra` verifies transformers, tokenizers, regex, safetensors,
  accelerate, sentencepiece, bitsandbytes and huggingface-hub all import). Used by both
  installers, the Docker/compose docs and the troubleshooting guides.
- **Docker GPU image dependency fix:** the model extra no longer installs transformers with
  `--no-deps` (which silently omitted tokenizers, regex, huggingface-hub, numpy, pyyaml,
  requests, tqdm, filelock, packaging). pip now resolves the full runtime set, `pip check`
  runs in both the base and model-extra image stages, and a build-time import smoke test
  fails the image build when any model dependency is missing. No CPU-torch-in-GPU-image
  risk: the extra keeps the torch installed from `TORCH_INDEX_URL` (`torch>=2.4` is already
  satisfied). Runner image pins aligned with the application pins
  (fastapi/uvicorn/pydantic) so the stack no longer drifts.
- **Documentation corrections:** `docs/MODEL_DEPLOYMENT.md` now states the local inference
  engine is part of the repository while the Qwen weights are not (download once, never
  bundled) and the external endpoint is optional; stale account instructions removed from
  `docs/INSTALL_LINUX.md` (single-user workspace opens with no login); README's stale
  `MODEL_MAX_TOKENS` default corrected to `0 = unlimited` (256–131072 when bounded);
  install guides document the CPU/CUDA choice and the real post-install verification;
  GPU guide documents the in-container `check_torch.py` verification and that the internal
  inference port stays unpublished.

## 0.7.2 — unlimited limits for the single-user workspace
- Every application-side limit knob now supports **0 = unlimited** and ships unlimited by
  default: reply tokens (`MODEL_MAX_TOKENS`), conversation history budget
  (`MODEL_CONTEXT_CHAR_BUDGET`), agent tool turns, concurrent chats, daily chat/tool/
  deployment quotas, project count, workspace storage and per-file size (the hard
  500000-character API body cap and the 12000-character chat message cap are gone).
  Positive values keep the documented bounded ranges; daily counters still increment and
  the usage pill shows `AI n · Tools m · unlimited`. `LOCAL_MODEL_MAX_CONTEXT_TOKENS=0`
  (auto) reads the context window from the model's `config.json`, and the local engine
  fills the remaining window when no token cap is set. The repetition loop guard is
  unchanged. 14 new tests pin the contract; full suite 228 passed.

## 0.7.2 — workspace UI theme refresh
- Replaced the purple-gradient styling (brand mark, send button, glowing status dots,
  radial background glow) with a restrained graphite theme: neutral grey surfaces, a single
  steel-blue accent, solid button fills, flat panels, no gradients and no glow. Layout,
  components, copy and behavior are unchanged — colors only (`frontend/app.css`).
  Verified visually against a live local instance (empty workspace, new-project dialog,
  open project with editor/terminal, chat bubbles, model status pill states).

## 0.7.2 — memory-aware auto quantization (final GPU requirements correction)
- **`auto` now plans from MEASURED FREE VRAM, not nominal card capacity:** the planner sums
  the actual safetensors bytes on disk (bf16 originals ≈ in-memory size), computes the KV
  cache from the model geometry in `config.json` and `LOCAL_MODEL_MAX_CONTEXT_TOKENS`, adds
  a runtime margin (CUDA context + activations + fragmentation), and picks bf16 only when
  the full plan fits — otherwise INT4 NF4, and a clear `EngineNotAvailable` error when even
  INT4 cannot fit (with the exact GiB figures and the fix: reduce context / free VRAM /
  larger GPU). No silent fallback to a setting that would OOM; manual quantization values
  are always honored (with a load-time warning when bf16 clearly cannot fit). The
  bitsandbytes GPU `max_memory` cap is now derived from measured free VRAM instead of the
  hardcoded 22GiB assumption. `begin_load` never respawns loader threads after a failed
  attempt. Decision tests use a mocked CUDA surface only — real-GPU behavior remains NOT
  RUN in this environment.

## 0.7.2 — pre-release verification round (testing & tooling)
- **New benchmark harness `scripts/bench_local_model.py`:** runs the real production engine
  (`inference.engine.LocalModelEngine`) against a local safetensors checkpoint and measures
  load time, plain chat, code generation, function/tool calling, malformed-history handling,
  streaming rejection, long-context handling, peak RAM and VRAM (on GPU hosts) and engine
  restart. Structural gates pass/fail; quality signals are recorded as measurements, never
  hard-coded. This is the tool an operator runs on the GPU host with the real
  Qwen2.5-Coder-14B-Instruct weights before trusting a deployment.
- **New release-hygiene tool `scripts/account_removal_scan.py`:** scans the whole tree for any
  re-introduced account-system artifact (auth files, `/api/auth/*` routes, session/cookie/
  password code, user tables, auth env vars, account UI markers), with documented exceptions
  for the legacy-migration code path and absence-asserting tests. Current tree: clean.
- Verified live (details in `VALIDATION.md`): full release gate green (195 pytest tests),
  real-engine benchmark against genuine Qwen2.5-0.5B-Instruct safetensors (11/11 structural
  gates), deterministic agent full-cycle E2E through the real `/api/chat` tool loop
  (3 files written + deliberate bug fixed on disk), terminal/preview API behavior with the
  runner offline (honest 503s), preview isolation between projects, security headers/origin/
  path-traversal/auth-404 checks.
- `.runtime` log directory and runtime workspace data are now excluded from release archives
  by the packaging check (a stray local run previously polluted `workspace/`).
- Docs: GPU guide documents the benchmark step; RELEASE_STATUS/VALIDATION updated with the
  honest not-executed-here list (live Docker/gVisor sandbox, 14B quality numbers) and the
  exact commands to run them on real hardware.

## 0.7.1 — single-user local workspace (account system removed)
- **Removed the entire account system.** There are no accounts, registration, login, logout,
  sessions, user roles, password hashing/recovery, or email verification in the product anymore:
  deleted `backend/auth.py`, the `/api/auth/*` endpoints (`config`, `register`, `login`,
  `logout`, `me`), the login rate-limiter branch, the users table and all account operator
  scripts (`scripts/create_user.py`, `scripts/reset_password.py`, `scripts/revoke_sessions.py`),
  and the frontend auth screen, user label, sign-out button and related CSS. The studio now
  opens directly on the workspace: install, start, create a project.
- **Single-workspace database schema.** `projects`, `chat_messages`, `deployments` and daily
  usage counters are no longer keyed by `user_id`; storage accounting moved to one
  `workspace_storage` row. On first start after upgrading, `db.init_db()` detects a legacy
  multi-user database, writes a timestamped file backup (`qwen_studio.sqlite3.backup-<UTC>`),
  and in one transaction merges every project, chat history, deployment and usage counter into
  the single workspace, drops the credentials table, and strips `owner_id` from
  `.qwen-project.json` files. A mid-migration failure rolls back completely.
- **Loopback-by-default with explicit remote-access opt-in.** Non-loopback `APP_BIND_ADDRESS`
  values are rejected at startup unless `ALLOW_REMOTE_ACCESS=true` is set; preflight treats
  remote access as an error in production. Origin/Fetch-Metadata checks, per-IP API rate
  limits, preview/publish origin isolation, sandbox limits, and the internal
  `SANDBOX_RUNNER_TOKEN` (app-to-runner authentication) are unchanged.
- **Env renames/removals:** removed `AUTH_SECRET`, `ALLOW_SIGNUP`, `COOKIE_SECURE`,
  `SESSION_TTL_SECONDS`; renamed `MAX_PROJECTS_PER_USER`→`MAX_PROJECTS` (default 100) and
  `MAX_USER_STORAGE_BYTES`→`MAX_WORKSPACE_STORAGE_BYTES` (default 2 GiB). HSTS is now emitted
  only when `PUBLIC_BASE_URL` is HTTPS.
- **Smoke test reworked for the no-login flow:** removed the login/cookie/logout/session-
  revocation/account-non-disclosure/login-limiter steps; added a "workspace opens without
  login" check that verifies no account UI is served and every `/api/auth/*` route answers
  404. The pytest rate-limiter probe now covers the API limiter directly.
- Docs updated for the no-account model (README, START_HERE_AR, RUNBOOK,
  PRODUCTION_READINESS, SECURITY, checklist); local-only exposure caveats documented.

## 0.7.1 — release-final round
- **Terminal (sandbox exec log):** new panel in the workspace runs the whitelisted sandbox profiles (`auto`, `python_compile`, `pytest`, `npm_test`, `npm_build`) against the real runner and shows the exit code, stdout/stderr and the isolation summary per run. There is deliberately no arbitrary shell. `check: "auto"` resolves to `npm_build` when `package.json` exists, otherwise `python_compile`; the old "Run check" button now uses the same path.
- Fixed dead Deployment links: `/api/deployments` now returns the real public `url` (`<slug>.<PUBLISH_DOMAIN>`) and the frontend links it instead of the removed `/published/` app path (which always returned 404).
- Model/sandbox status now keeps refreshing: a 30-second poll of `/api/system/status` runs while the page is open (previously the sandbox/model state was checked once and went stale).
- Sandbox resource limits are operator-configurable and actually read by the runner (previously documented but hard-coded): `SANDBOX_MEMORY_LIMIT`, `SANDBOX_INSTALL_MEMORY_LIMIT`, `SANDBOX_CPU_LIMIT`, `SANDBOX_PIDS_LIMIT`, `SANDBOX_TIMEOUT_SECONDS`, `SANDBOX_MAX_OUTPUT_BYTES` (validated at startup, defaults unchanged; wired through compose.yaml).
- Agent robustness: the system prompt states explicitly that all tool paths are relative to the project root, and a rejected path (workspace escape / absolute path) now appends an actionable relative-path retry hint to the tool message. Measured against a real Qwen2.5-0.5B-Instruct checkpoint: this is required for smaller models; the 14B target gets the same clearer contract.
- Engine honesty fixes: int8-on-CPU logs an experimental warning (measured: loads and generates with realistic tensor shapes; degenerate tiny checkpoints can fail inside bitsandbytes); CPU_GUIDE corrected to match the measured behavior instead of claiming a refusal that did not exist.
- Windows/UX fixes: `stop.bat` no longer reports "not running" after a successful PowerShell stop (sentinel file); `install.sh` no longer depends on GNU `sed -i` (works on macOS/BSD sed; documented platforms only); RUNBOOK deployment-order fix.
- Validation (details in VALIDATION.md): 204 pytest tests pass; release gate green; live engine tests re-run against the genuine Qwen/Qwen2.5-0.5B-Instruct safetensors (completeness, load, real chat, real tool-call emission parsed to native `tool_calls`, int4+int8 CPU load & generation) plus the scripted agent E2E (project → 3 files → `edit_file` bug fix verified on disk) and Playwright UI proof including the new Terminal panel.

## 0.7.1 — local weights mode
- Added `inference/` engine: loads Qwen safetensors weights from a local `models/<LOCAL_MODEL_NAME>/` directory (Hugging Face `transformers`, `local_files_only=True`) and serves an OpenAI-compatible API on loopback, so the studio no longer requires an external model server when `LOCAL_INFERENCE=true`.
- Auto device/quantization selection: bf16 at 32+ GiB VRAM, 4-bit NF4 via bitsandbytes below that; explicit `LOCAL_MODEL_DEVICE` (auto/cuda/cpu) and `LOCAL_MODEL_QUANTIZATION` (auto/none/bf16/fp16/int8/int4) overrides with runtime validation; transformers>=5 `dtype` vs older `torch_dtype` handled by version detection.
- Model gateway defaults to the bundled loopback engine when `LOCAL_INFERENCE=true` and `MODEL_BASE_URL` is left as a placeholder; `/api/system/status` now reports engine state (`loaded`, `loading`, `device`, `quantization`) under `model.local`.
- Docker/compose: the app image now ships the `inference/` package and `requirements-local-model.txt`; weights are mounted read-only from `${LOCAL_MODEL_HOST_DIR:-./models}` at `/app/models` (never baked into the image; `.dockerignore` keeps excluding `*.safetensors`); added an `app-gpu` profile service with NVIDIA device reservation, CUDA torch build args (`TORCH_INDEX_URL`), and an `INSTALL_LOCAL_MODEL` build switch; the loopback inference port stays unpublished.
- Frontend: the top bar shows live local-model status (loading / connected with model name, device and quantization / errors, polled every 3s) and the chat panel prints each executed tool with its target file instead of a bare count.
- Operator tooling: `scripts/install.sh` + `scripts/install.bat` (venv + deps + generated `.env`), `scripts/check_requirements.sh` pre-flight, `scripts/verify_weights.py` (+ `.bat`) weight-completeness checker (shard index, tokenizer, corrupted/partial files), `scripts/start.sh`/`stop.sh` (+ `.bat`), `scripts/docker_check.sh` in-container weights/GPU verification.
- Docs: new-user quick path in `START_HERE_AR.md`, `docs/INSTALL_LINUX.md`, `docs/INSTALL_WINDOWS.md`, `docs/GPU_GUIDE.md`, `docs/CPU_GUIDE.md`, `LICENSES.md` + `NOTICE` (Qwen2.5-Coder-14B-Instruct is Apache-2.0 - verified against the official repo; weights redistribution requirements documented), `models/README.md` license section.
- Validation (details in VALIDATION.md): 195 pytest tests pass; live full-cycle on a real (small) Qwen checkpoint - engine load, gateway connection, real chat reply, real tool-call emission parsed to native `tool_calls`; a scripted-model E2E proves the agent creates a web project, edits files, and fixes a bug on disk; restart persistence and clean-venv install (with the explicit missing-extra error) verified. GPU/CUDA execution and Docker sandboxed previews were NOT exercised (no GPU/Docker in the validation environment).
- Fixed: an empty `LOCAL_MODEL_DIR` (the `.env.example` default) resolved to the process working directory instead of `models/<LOCAL_MODEL_NAME>`, so a fresh install with local weights reported "No safetensors weights found"; found by the from-zip clean-install smoke, covered by a regression test.
- The remote-endpoint mode remains fully supported as the fallback: set `LOCAL_INFERENCE=false` (default) and point `MODEL_BASE_URL` at any OpenAI-compatible server.

## Unreleased
- Rewrote the agent system prompt with an explicit inspect → plan → edit → verify workflow, a repeat-avoidance rule, and a concrete Qwen `<tool_call>` example. Model weights and tokenizer are untouched.
- Added `MODEL_TEMPERATURE` (default 0.2, validated 0–1) so sampling can be tuned per deployment without code changes.
- Added loop detection: three identical tool calls with identical results add a warning to the tool message; a fourth stops the run with `warning: loop_detected`.
- Expanded `scripts/eval_agent.py` from 5 to 20 tasks with `--list`, `--only`, and `--json-out` for before/after comparison. Checks are static or based on sandbox results; generated code is never executed on the host.
- Added history compaction: when the conversation exceeds `MODEL_CONTEXT_CHAR_BUDGET` (default 60000 characters), the oldest bulky tool outputs are truncated; the system prompt, first request, and latest messages are never touched.
- (Superseded in the single-user round: the account operator scripts, including this one, have since been removed entirely.)
- Added four tests covering loop detection, non-loop repeats, temperature configuration/validation, and the prompt workflow. Seven further tests cover compaction, the eval task set, and password reset. None of this has been measured against a live model yet; run `scripts/eval_agent.py` before and after to compare.

## 0.7.0
- Increased the studio Nginx proxy read/send timeouts to 420 seconds, exceeding the Runner static-build timeout; publish-host timeouts remain 60 seconds. Added regression checks for Runner timeout and upload-body-size alignment.
- Added standard-library dependency-pin verification for requirements, Dockerfile package pins, and the Verdaccio image tag; deployment treats confirmed missing pins as fatal and offline checks as warnings.
- Added a cross-document consistency audit for release versions, environment configuration, API routes, collected test count, and removed guidance.
- Added `scripts/verify_all.sh` as the release gate and made `make_release.sh` run it before packaging.
- Added `docs/RUNBOOK.md` with deployment prerequisites/order, model-serving guidance, smoke/preflight failure mapping, backups, secret rotation, and known limits.


## 0.6.5
- Replaced the 15-second implicit smoke-test timeout with named operation-specific timeouts; mutation requests require explicit timeout values, timeout failures include method/path and runner-log guidance, and GET requests alone retry once.
- Split rate-limit validation into account non-disclosure (two invalid attempts before workloads) and a deliberate limiter-active probe (up to 12 invalid attempts, requiring HTTP 429 by attempt 10); moved the probe after cleanup/logout and added an injectable 61-second reset wait.
- Added AST coverage for explicit mutation timeouts and timeout constants against `backend/sandbox_client.py`, timeout fake-server tests, rate-limit behavior tests, and a full fake-server request-timeout audit.
- Clarified in README that the smoke limiter check does not prove forwarded-header spoof resistance; proxy trust remains separately checked via `proxy_headers`.

## 0.6.4
- Removed the stray SQLite runtime database from the release tree and redirected all pytest runtime paths to a session-scoped `tmp_path_factory` directory before importing backend modules; added a final workspace cleanliness guard.
- Extended release validation to reject workspace runtime data, SQLite files, `.env`, Python/pytest caches, nested ZIP archives, and backup directories; added `scripts/make_release.sh` to stage and validate clean archives while retaining required dotfiles.
- Added the operator-run standard-library `scripts/smoke_test.py` for health/version, secure login cookie, sandbox/model/proxy status, spoofed forwarded-IP rate-limit behavior, static preview/publish origin isolation, npm no-lockfile installation/build, agent file-writing, and cleanup/session revocation.
- Added fake-HTTP-server tests for smoke-test success and failures involving an incorrect cookie name, a cookie Domain attribute, spoofed-login 429s, preview Set-Cookie, and the legacy published path. The smoke script is not run against a live deployment in pytest.
- Local pytest, JavaScript syntax, Python compilation, release packaging and smoke-test fake-server checks are recorded in `VALIDATION.md`; Docker, Nginx, Verdaccio, wildcard DNS/TLS, real proxy address, pinned dependencies and model integration remain unverified.

## 0.6.3
- Malformed Qwen `<tool_call>` blocks now trigger the bounded invalid-tool retry; after two retries, invalid block markup is removed and a clean error is returned instead of exposing raw tags.
- Added a shared `registrable_domain()` helper with a built-in partial multi-label public-suffix set; runtime and production preflight warnings now distinguish domains such as `a.com.dz` and `b.com.dz` correctly and avoid warnings for IP/localhost hosts.
- Added regression tests for invalid/missing/trailing-prose tool-call blocks, terminal sanitization, multi-label suffixes, bare two-label domains, IP addresses, and localhost.
- Local checks after each fix group: 124 and 131 tests passed; JavaScript syntax and Python compilation checks passed. Docker, Nginx, Verdaccio, wildcard DNS/TLS, real proxy peer identity, pinned package resolution, and the model remain unverified.

## 0.6.2
- Restored the root `.env.example` with all app/runner configuration and added a release check for required dotfiles; deployment checks packaging before building.
- Replaced the proxy-header failure diagnostic with a check for forwarded addresses present but not applied by Uvicorn; exposed `proxy_headers` in authenticated system status and added a frontend warning banner.
- Production sessions now use `__Host-qwen_session` with Secure, Path=/, and no Domain attribute; wrong-name cookies are ignored and an expected-name cookie cannot be bypassed with a Bearer header.
- Added non-fatal runtime and preflight warnings when studio, preview, and publish origins share the same last-two-label parent domain.
- Extended best-effort text tool-call parsing to native Qwen `<tool_call>` blocks (including multiple ordered calls and JSON-string arguments), whole-message fenced JSON, and legacy bare JSON using either `tool` or `name`; unknown tool names return explicit errors.
- Updated the vLLM recommendation to use `--enable-auto-tool-choice --tool-call-parser hermes` and added a first real deployment checklist.
- Validation after requested fix groups: 99, 104, 111, and 116 tests passed respectively; the final suite including supplementary deployment-template, health-version, and secure-cookie checks passed 119 tests. JavaScript syntax and Python compile checks passed after each group and on final validation. Docker, Nginx, Verdaccio, DNS/TLS, real proxy peer identity, and the model remain unverified.

## 0.6.1
- npm dependency setup now generates a missing `package-lock.json` inside the temporary isolated volume via the internal proxy before running `npm ci --ignore-scripts`; the generated lockfile is not copied back to the shared project.
- Changed the default trusted proxy address to the Compose `app-net` gateway `172.28.0.1`, added configurable fixed app-network IPAM, strict production preflight validation, and a startup traffic diagnostic for missing forwarded headers.
- Published deployments now use one subdomain origin per slug (`<slug>.<PUBLISH_DOMAIN>`); removed path-based `/published/{slug}` routes and added wildcard publish-host routing.
- Restored `sandbox allow-scripts` and same-origin CORP on authenticated app-origin preview responses only.
- Fixed agent fallback parsing so prose and embedded JSON examples are not misread as tool calls; malformed top-level tool JSON receives at most two retries.
- Added regression tests for all five fixes. Local suite: 90 passed; JavaScript syntax and Python compilation passed. Docker, Nginx, Verdaccio, wildcard DNS/TLS, and model integration remain unverified.

## 0.6.0
- Added optional internal Verdaccio npm proxy and isolated install-network path; npm installs use `npm ci --ignore-scripts` with a lockfile, while packages with no declared dependencies skip installation.
- Added `edit_file`, `append_file`, and `delete_file` agent tools; configurable model output-token ceiling and a manual five-task evaluation script.
- Removed CSP sandbox directives from preview/published responses and allowed same-origin iframe behavior only on the separate preview origin; published sites now require their own host.
- Hardened forwarded-IP trust, added once-per-minute cleanup of in-memory rate-limit state, and added a non-blocking concurrent chat cap.
- Closed directory/file symlink escapes in project/publish copying; strengthened password hashing, legacy-hash rehashing, timing equalization, and token-version session revocation.
- Added cached per-user storage accounting updated incrementally, a SQLite project index with one-time legacy metadata import, exact dependency pins, and a separate dev requirements file.
- Added tests across all requested changes. Local suite: 77 passed; JavaScript syntax and Python compilation passed. Docker, Nginx live routing, and GPU/model execution were not available and remain unverified.

## 0.5.1
- Hardened production preflight to reject externally reachable plain-HTTP model endpoints and URL credentials/fragments.
- Validated the private Compose runner endpoint and application port before deployment.
- Deployment now validates the rendered Compose configuration before building images.
- Revalidated the release: 43 automated tests, JS syntax, Python compilation, Bash syntax, and Compose YAML assertions.

## 0.5.0
- Added strict production-mode configuration validation: persistent distinct secrets, secure cookies, HTTPS app/preview origins, loopback-only app binding, and disabled dependency network installation.
- Added JWT header/claim validation and response security headers.
- Added Fetch Metadata checks to browser mutation requests.
- Fixed sandbox run quota double charging.
- Added quota charging and correct 429 handling for preview restarts.
- Made project deletion fail closed if an active sandbox cannot be stopped.
- Serialized preview starts to avoid concurrent container/volume/network races.
- Hardened service containers with read-only root filesystems and temporary filesystems.
- Added production preflight, deployment, Nginx TLS reverse-proxy, backup scripts, and a production-readiness report.

## 0.4.1
- Accounts, project separation, model gateway, agent tools, quotas, editor, sandbox runner, previews and static publishing.


## Release candidate patch

- Made static publish ownership assignment tolerant of non-root local validation environments; production runner still attempts to assign UID/GID 10001.
- Full automated test suite: 182 passed.
- Production deployment, Docker isolation, DNS/TLS, model inference and billing remain unverified/not included; this archive is a closed-beta release candidate, not a public SaaS launch certification.

## 0.7.0 deployment hardening update

- Added mandatory gVisor `runsc` enforcement for production runner startup; the runner checks Docker's registered runtimes and adds `--runtime runsc` to every workload container launch.
- Added `deploy/prepare_env.py` to generate independent production secrets without overwriting an existing `.env`.
- Added `deploy/verify_host.sh` for Docker, Compose, gVisor, environment, and Compose-config preflight checks.
- Added Arabic deployment handoff in `START_HERE_AR.md`.
- Validation: 184 automated tests passed; JS syntax, Python compilation, release consistency, packaging, Compose YAML parsing, and shell syntax passed. Live Docker/gVisor operation, model inference, DNS/TLS, billing/email integrations, and independent penetration testing still require target infrastructure.
