# Model integration notes

Observed facts from the official `Qwen/Qwen2.5-Coder-14B-Instruct` repository metadata
(config.json, tokenizer and README on the Hugging Face Hub):
- Model repository: `Qwen/Qwen2.5-Coder-14B-Instruct`
- Architecture: `Qwen2ForCausalLM` / `qwen2`
- Parameter count stated in the model README: 14.7B
- `config.json` sets `max_position_embeddings` to 32,768
- Tokenizer chat template includes `<tool_call>` and `</tool_call>` markers
- Model README states its implementation is available in current Hugging Face Transformers and recommends vLLM for deployment
- Model README states Apache-2.0 licensing

Qwen Studio uses an application-level OpenAI-compatible tool interface. It does not modify
weights, tokenizer files, architecture, training data, or model behavior internally.

The uploaded metadata files are not model weight shards and are not sufficient by themselves
to run inference. An inference server and the actual model weights must be provided separately.

## Local weights mode (added in 0.7.1)

Qwen Studio can now host the weights itself. With `LOCAL_INFERENCE=true` the backend
starts `inference/server.py`: a loopback-only OpenAI-compatible service backed by
Hugging Face `transformers` that loads the safetensors shards from
`models/<LOCAL_MODEL_NAME>/` with `local_files_only=True`. The existing gateway in
`backend/agent.py` is untouched — it still speaks the OpenAI Chat Completions protocol,
now against the local engine instead of a remote server. Tool schemas are passed through
the Qwen chat template, and `<tool_call>` blocks in the output are parsed back to native
OpenAI `tool_calls` for the agent loop. Auto sizing loads 4-bit NF4 below 32 GiB VRAM
and bf16 above; overrides are available via `LOCAL_MODEL_DEVICE` and
`LOCAL_MODEL_QUANTIZATION`.

## Model downloader (added in 0.7.2)

`backend/model_manager.py` adds the Model button: a user-triggered download of the
official `Qwen/Qwen2.5-Coder-14B-Instruct` checkpoint (manifest via the official
`HfApi`, bytes via ETag-validated HTTP `Range` requests into `.part` files that are
renamed atomically). It resumes across connection drops without re-downloading finished
files, checks disk space before starting, verifies every LFS SHA-256 and the shard
completeness from `model.safetensors.index.json` after downloading, then writes
`LOCAL_INFERENCE=true` into `.env` and starts the bundled loopback engine in-process.
GET/HEAD only — no user file, project file, or secret ever reaches the Hub; executables,
archives and scripts are refused by the manifest filter. See `models/README.md`.
