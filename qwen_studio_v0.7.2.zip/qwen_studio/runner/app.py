from __future__ import annotations

import hmac
import os
import re
import subprocess
import time
import threading
import uuid
import urllib.error
import urllib.request
from typing import Literal
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

RUNNER_TOKEN = os.getenv("SANDBOX_RUNNER_TOKEN", "")
APP_ENV = os.getenv("APP_ENV", "development").strip().lower()
SHARED_VOLUME = os.getenv("SANDBOX_SHARED_VOLUME_NAME", "qwen_workspace")
SANDBOX_IMAGE = os.getenv("SANDBOX_IMAGE", "qwen-sandbox:latest")
SANDBOX_CONTAINER_RUNTIME = os.getenv("SANDBOX_CONTAINER_RUNTIME", "runc").strip()
ALLOW_NETWORK_INSTALL = os.getenv("SANDBOX_ALLOW_NETWORK_INSTALL", "false").lower() == "true"
NPM_REGISTRY_URL = os.getenv("SANDBOX_NPM_REGISTRY_URL", "").strip().rstrip("/")
NPM_INSTALL_NETWORK = os.getenv("SANDBOX_NPM_NETWORK", "qwen_npm_install")
MAX_ACTIVE_PREVIEWS = max(1, int(os.getenv("SANDBOX_MAX_ACTIVE_PREVIEWS", "4")))
RUN_SLOTS = threading.BoundedSemaphore(max(1, int(os.getenv("SANDBOX_MAX_CONCURRENT_RUNS", "2"))))

# Operator-tunable workload limits (documented in README.md; defaults keep the
# previous hard-coded values). Parsed eagerly so bad values fail fast at startup.
def _env_int(name: str, default: str, minimum: int, maximum: int) -> int:
    raw = os.getenv(name, default).strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer between {minimum} and {maximum}.") from exc
    if not minimum <= value <= maximum:
        raise RuntimeError(f"{name} must be an integer between {minimum} and {maximum}.")
    return value


def _env_memory(name: str, default: str) -> str:
    raw = os.getenv(name, default).strip().lower()
    if not re.fullmatch(r"\d+(m|g)?", raw):
        raise RuntimeError(f"{name} must look like '1536m' or '2g'.")
    amount = int(raw[:-1] if raw[-1] in {"m", "g"} else raw)
    if amount < 64 or amount > 16384:
        raise RuntimeError(f"{name} must be between 64m and 16g.")
    return raw if raw[-1] in {"m", "g"} else raw + "m"


def _env_cpu(name: str, default: str) -> str:
    raw = os.getenv(name, default).strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a number between 0.1 and 32.") from exc
    if not 0.1 <= value <= 32:
        raise RuntimeError(f"{name} must be a number between 0.1 and 32.")
    return raw


SANDBOX_MEMORY_LIMIT = _env_memory("SANDBOX_MEMORY_LIMIT", "1536m")
SANDBOX_INSTALL_MEMORY_LIMIT = _env_memory("SANDBOX_INSTALL_MEMORY_LIMIT", "1536m")
SANDBOX_CPU_LIMIT = _env_cpu("SANDBOX_CPU_LIMIT", "1.25")
SANDBOX_PIDS_LIMIT = _env_int("SANDBOX_PIDS_LIMIT", "128", 16, 1024)
SANDBOX_TIMEOUT_SECONDS = _env_int("SANDBOX_TIMEOUT_SECONDS", "120", 10, 600)
SANDBOX_MAX_OUTPUT_BYTES = _env_int("SANDBOX_MAX_OUTPUT_BYTES", "12000", 1000, 100000)
BUILD_SLOTS = threading.BoundedSemaphore(1)
PREVIEW_START_LOCK = threading.Lock()
PROJECT_RE = re.compile(r"^[a-f0-9]{32}$")
PROFILE_COMMANDS = {
    "python_compile": "python -m compileall -q .",
    "pytest": "pytest -q",
    "npm_test": "npm test",
    "npm_build": "npm run build",
}
@asynccontextmanager
async def runner_lifespan(application: FastAPI):
    if RUNNER_TOKEN.startswith("REPLACE_WITH") or (RUNNER_TOKEN and len(RUNNER_TOKEN) < 32):
        raise RuntimeError("SANDBOX_RUNNER_TOKEN must be a random secret of at least 32 characters.")
    if APP_ENV == "production" and not RUNNER_TOKEN:
        raise RuntimeError("SANDBOX_RUNNER_TOKEN is required in production.")
    if SANDBOX_CONTAINER_RUNTIME not in {"runc", "runsc"}:
        raise RuntimeError("SANDBOX_CONTAINER_RUNTIME must be runc or runsc.")
    if APP_ENV == "production":
        if SANDBOX_CONTAINER_RUNTIME != "runsc":
            raise RuntimeError("Production sandbox execution requires the gVisor runsc runtime. Configure runsc on the Docker host and set SANDBOX_CONTAINER_RUNTIME=runsc.")
        runtime_check = _docker(["info", "--format", "{{json .Runtimes}}"], timeout=10)
        if runtime_check.returncode != 0:
            raise RuntimeError("Cannot verify Docker runtimes. Ensure the runner can reach the Docker daemon.")
        try:
            runtimes = __import__("json").loads(runtime_check.stdout or "{}")
        except Exception as exc:
            raise RuntimeError("Docker returned invalid runtime metadata; cannot verify gVisor.") from exc
        if "runsc" not in runtimes:
            raise RuntimeError("gVisor runsc is not registered with the Docker daemon. Install/configure it before starting the production runner.")
    if ALLOW_NETWORK_INSTALL:
        from urllib.parse import urlsplit
        registry = urlsplit(NPM_REGISTRY_URL)
        if (registry.scheme != "http" or registry.hostname != "npm-proxy" or registry.port != 4873
                or registry.username or registry.password or registry.path not in {"", "/"}
                or registry.query or registry.fragment):
            raise RuntimeError("Network install requires the private npm proxy URL http://npm-proxy:4873.")
    yield


app = FastAPI(title="Qwen Isolated Sandbox Runner", version="1.0.0", lifespan=runner_lifespan)

PREVIEW_FETCH_CODE = (
    "import sys,urllib.request,urllib.error;"
    "u=sys.argv[1];"
    "\ntry:\n r=urllib.request.urlopen(u,timeout=8); status=r.status; ct=r.headers.get('Content-Type','application/octet-stream'); body=r.read(10000001)"
    "\nexcept urllib.error.HTTPError as e:\n status=e.code; ct=e.headers.get('Content-Type','text/plain'); body=e.read(2000)"
    "\nif len(body)>10000000: status=413; ct='text/plain'; body=b'Preview response too large.'"
    "\nsys.stderr.write(str(status)+'\\n'+ct+'\\n'); sys.stdout.buffer.write(body)"
)


class RunRequest(BaseModel):
    project_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    profile: Literal["python_compile", "pytest", "npm_test", "npm_build"]
    target: str = Field(default=".", max_length=160)


class BuildRequest(BaseModel):
    project_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    slug: str = Field(pattern=r"^site-[a-f0-9]{32}$")


def _docker_args(args: list[str]) -> list[str]:
    """Force every workload container through the configured runtime."""
    result = list(args)
    if result and result[0] == "run" and SANDBOX_CONTAINER_RUNTIME == "runsc":
        result[1:1] = ["--runtime", "runsc"]
    return result


def _docker(args: list[str], timeout: int = 180) -> subprocess.CompletedProcess:
    args = _docker_args(args)
    try:
        return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout, check=False)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Docker CLI is not installed in the runner.") from exc
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Sandbox operation timed out.") from exc


def _docker_bytes(args: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
    args = _docker_args(args)
    try:
        return subprocess.run(["docker", *args], capture_output=True, text=False, timeout=timeout, check=False)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Docker CLI is not installed in the runner.") from exc
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Preview fetch timed out.") from exc


def _force_remove(container: str) -> None:
    """Best-effort removal of a workload container left behind by a timeout.

    Killing the docker CLI does not stop the daemon-side container: without an
    explicit reaping step a timed-out pytest/npm run would keep its volume busy
    until it exits on its own. Names are unique per invocation, so removal
    cannot collide with a newer workload.
    """
    try:
        _docker(["rm", "-f", container], timeout=15)
    except HTTPException:  # noqa: BLE001 - cleanup must never mask the real error
        pass


def _workload_container_name(kind: str, project_id: str) -> str:
    """Unique, greppable container name for one workload invocation.

    Named containers are what makes `_force_remove` possible: unnamed
    `docker run --rm` containers orphaned by a CLI timeout are invisible to
    every cleanup path.
    """
    return f"qwen-{kind}-{project_id[:8]}-{uuid.uuid4().hex[:8]}"


def _auth(token: str | None) -> None:
    if not RUNNER_TOKEN or not token or not hmac.compare_digest(RUNNER_TOKEN, token):
        raise HTTPException(status_code=401, detail="Invalid runner authentication.")


def _target_path(target: str) -> str:
    if target in {"", "."}:
        return "."
    parts = target.replace("\\", "/").split("/")
    if target.startswith(("/", "\\")) or any(p in {"", ".", ".."} for p in parts):
        raise HTTPException(status_code=400, detail="Invalid target path.")
    if any(p.startswith(".") for p in parts):
        raise HTTPException(status_code=400, detail="Hidden target paths are not allowed.")
    return "/".join(parts)


def _prepare_isolated_volume(project_id: str, volume_name: str) -> None:
    result = _docker(["volume", "rm", "-f", volume_name], timeout=20)
    created = _docker(["volume", "create", volume_name], timeout=20)
    if created.returncode != 0:
        raise HTTPException(status_code=503, detail="Could not create an isolated project volume.")
    copied = _docker([
        "run", "--rm", "--network", "none", "--user", "0:0",
        "--mount", f"type=volume,source={SHARED_VOLUME},target=/source,readonly",
        "--mount", f"type=volume,source={volume_name},target=/target",
        SANDBOX_IMAGE, "python3", "/opt/copy_project.py",
        "--source", f"/source/projects/{project_id}", "--target", "/target",
    ], timeout=60)
    if copied.returncode != 0:
        _docker(["volume", "rm", "-f", volume_name], timeout=20)
        raise HTTPException(status_code=400, detail="Could not stage the project for sandbox execution.")


def _cleanup_volume(volume_name: str) -> None:
    _docker(["volume", "rm", "-f", volume_name], timeout=20)


@app.post("/build-static")
def build_static(request: BuildRequest, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not BUILD_SLOTS.acquire(blocking=False):
        raise HTTPException(status_code=429, detail="A build is already running. Retry shortly.")
    try:
        return _build_static_inner(request)
    finally:
        BUILD_SLOTS.release()


def _build_static_inner(request: BuildRequest):
    volume_name = f"qwen_build_{request.project_id}_{uuid.uuid4().hex}"
    _prepare_isolated_volume(request.project_id, volume_name)
    try:
        package_state = _package_dependency_state(volume_name)
        has_package = package_state["has_package"]
        if has_package:
            if package_state["has_dependencies"]:
                has_modules = _docker(["run", "--rm", "--network", "none",
                    "--mount", f"type=volume,source={volume_name},target=/workspace,readonly",
                    SANDBOX_IMAGE, "sh", "-lc", "test -d /workspace/node_modules"], timeout=10).returncode == 0
                if not has_modules:
                    _install_node_dependencies(request.project_id, volume_name, package_state)
            build_name = _workload_container_name("build", request.project_id)
            build_cmd = [
                "run", "--name", build_name, "--rm", "--network", "none", "--memory", SANDBOX_MEMORY_LIMIT,
                "--memory-swap", SANDBOX_MEMORY_LIMIT, "--cpus", SANDBOX_CPU_LIMIT,
                "--pids-limit", str(SANDBOX_PIDS_LIMIT), "--read-only",
                "--tmpfs", "/tmp:rw,noexec,nosuid,size=128m", "--env", "HOME=/tmp",
                "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true", "--user", "10001:10001",
                "--mount", f"type=volume,source={volume_name},target=/workspace",
                "--workdir", "/workspace", SANDBOX_IMAGE, "sh", "-lc", "npm run build",
            ]
            try:
                build = _docker(build_cmd, timeout=180)
            except HTTPException:
                _force_remove(build_name)
                raise
            if build.returncode != 0:
                _force_remove(build_name)
                raise HTTPException(status_code=400, detail="Build failed: " + build.stderr[-2000:])
            build_log = (build.stdout + "\n" + build.stderr)[-6000:]
        else:
            build_log = "No package.json found; publishing static root files."

        copied = _docker([
            "run", "--rm", "--network", "none", "--user", "0:0",
            "--mount", f"type=volume,source={volume_name},target=/source,readonly",
            "--mount", f"type=volume,source={SHARED_VOLUME},target=/shared",
            SANDBOX_IMAGE, "python3", "/opt/publish_copy.py",
            "--source", "/source", "--target", f"/shared/published/{request.slug}",
        ], timeout=60)
        if copied.returncode != 0:
            raise HTTPException(status_code=400, detail="Could not publish static build: " + copied.stderr[-1500:])
        return {"status": "built_and_published", "slug": request.slug,
                "build_log": build_log, "copy_log": copied.stdout[-1000:],
                "network_during_build": "none"}
    finally:
        _cleanup_volume(volume_name)


def _container_name(project_id: str) -> str:
    return f"qwen-preview-{project_id}"


def _preview_network_name(project_id: str) -> str:
    return f"qwen-preview-net-{project_id}"


def _package_dependency_state(volume_name: str) -> dict[str, bool]:
    """Inspect package.json without executing project-controlled JavaScript."""
    script = (
        "import json,pathlib; p=pathlib.Path('/workspace/package.json'); "
        "d=json.loads(p.read_text()) if p.is_file() else {}; "
        "deps=any(bool(d.get(k)) for k in ('dependencies','devDependencies','optionalDependencies','peerDependencies')); "
        "print(('1' if p.is_file() else '0')+('1' if deps else '0')+('1' if pathlib.Path('/workspace/package-lock.json').is_file() else '0'))"
    )
    result = _docker([
        "run", "--rm", "--network", "none",
        "--mount", f"type=volume,source={volume_name},target=/workspace,readonly",
        SANDBOX_IMAGE, "python3", "-c", script,
    ], timeout=10)
    if result.returncode != 0 or len(result.stdout.strip()) != 3:
        raise HTTPException(status_code=400, detail="Could not inspect package.json safely.")
    values = result.stdout.strip()
    return {"has_package": values[0] == "1", "has_dependencies": values[1] == "1", "has_lock": values[2] == "1"}


def _npm_install_container_args(volume_name: str, command: str,
                                container_name: str | None = None) -> list[str]:
    """Build the hardened npm container command used for both lock generation and ci."""
    args = ["run"]
    if container_name:
        args += ["--name", container_name]
    args += [
        "--rm", "--network", NPM_INSTALL_NETWORK, "--memory", SANDBOX_INSTALL_MEMORY_LIMIT,
        "--memory-swap", SANDBOX_INSTALL_MEMORY_LIMIT, "--cpus", "1.0",
        "--pids-limit", str(SANDBOX_PIDS_LIMIT), "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=256m",
        "--env", "HOME=/tmp", "--env", "npm_config_cache=/tmp/npm-cache",
        "--env", f"npm_config_registry={NPM_REGISTRY_URL}",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true", "--user", "10001:10001",
        "--mount", f"type=volume,source={volume_name},target=/workspace",
        "--workdir", "/workspace", SANDBOX_IMAGE, "sh", "-lc", command,
    ]
    return args


def _install_node_dependencies(project_id: str, volume_name: str, package_state: dict[str, bool] | None = None) -> None:
    """Generate a lockfile when required, then install dependencies in the isolated temp volume."""
    import shlex

    state = package_state or _package_dependency_state(volume_name)
    if not state.get("has_package") or not state.get("has_dependencies"):
        return
    if not ALLOW_NETWORK_INSTALL or not NPM_REGISTRY_URL:
        raise HTTPException(
            status_code=409,
            detail="This npm project declares dependencies. Enable SANDBOX_ALLOW_NETWORK_INSTALL and configure the internal SANDBOX_NPM_REGISTRY_URL proxy to install them.",
        )

    registry = shlex.quote(NPM_REGISTRY_URL)
    if not state.get("has_lock"):
        lock_command = (
            "npm install --package-lock-only --ignore-scripts --no-audit --no-fund --registry " + registry
        )
        lock_name = _workload_container_name("npm-lock", project_id)
        try:
            generated = _docker(_npm_install_container_args(volume_name, lock_command, lock_name), timeout=180)
        except HTTPException:
            _force_remove(lock_name)
            raise
        if generated.returncode != 0:
            _force_remove(lock_name)
            raise HTTPException(status_code=400, detail="Lockfile generation failed: " + generated.stderr[-1500:])

    install_command = "npm ci --ignore-scripts --no-audit --no-fund --registry " + registry
    install_name = _workload_container_name("npm-ci", project_id)
    try:
        installed = _docker(_npm_install_container_args(volume_name, install_command, install_name), timeout=180)
    except HTTPException:
        _force_remove(install_name)
        raise
    if installed.returncode != 0:
        _force_remove(install_name)
        raise HTTPException(status_code=400, detail="Dependency install failed: " + installed.stderr[-1500:])


def _preview_is_running(container_name: str) -> bool:
    inspected = _docker(["inspect", "--format", "{{.State.Running}}", container_name], timeout=8)
    return inspected.returncode == 0 and inspected.stdout.strip().lower() == "true"


@app.post("/preview/start/{project_id}")
def start_preview(project_id: str, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not PROJECT_RE.fullmatch(project_id):
        raise HTTPException(status_code=400, detail="Invalid project id.")
    if not PREVIEW_START_LOCK.acquire(blocking=False):
        raise HTTPException(status_code=429, detail="A preview is starting. Retry shortly.")
    try:
        return _start_preview_locked(project_id)
    finally:
        PREVIEW_START_LOCK.release()

def _start_preview_locked(project_id: str):
    name = _container_name(project_id)
    network = _preview_network_name(project_id)
    running = _docker(["ps", "--filter", "name=^/qwen-preview-", "--format", "{{.Names}}"], timeout=10)
    active_names = [line for line in running.stdout.splitlines() if line.startswith("qwen-preview-")]
    if len(active_names) >= MAX_ACTIVE_PREVIEWS and name not in active_names:
        raise HTTPException(status_code=429, detail=f"Host preview limit reached ({MAX_ACTIVE_PREVIEWS}). Stop an unused preview first.")
    _docker(["rm", "-f", name], timeout=15)
    _docker(["network", "rm", network], timeout=10)
    network_created = _docker(["network", "create", "--internal", "--label", f"qwen.project={project_id}", network], timeout=15)
    if network_created.returncode != 0:
        raise HTTPException(status_code=503, detail="Could not create a private network for the preview.")
    volume_name = f"qwen_preview_vol_{project_id}"
    try:
        _prepare_isolated_volume(project_id, volume_name)
    except Exception:
        _docker(["network", "rm", network], timeout=10)
        raise

    # Install dependencies only with scripts disabled and only when the operator has opted in.
    package_state = _package_dependency_state(volume_name)
    has_package = package_state["has_package"]
    if has_package:
        if package_state["has_dependencies"]:
            has_modules = _docker(["run", "--rm", "--network", "none",
                "--mount", f"type=volume,source={volume_name},target=/workspace,readonly",
                SANDBOX_IMAGE, "sh", "-lc", "test -d /workspace/node_modules"], timeout=10).returncode == 0
            if not has_modules:
                try:
                    _install_node_dependencies(project_id, volume_name, package_state)
                except Exception:
                    _cleanup_volume(volume_name)
                    _docker(["network", "rm", network], timeout=10)
                    raise
        start_command = (
            "if node -e \"const p=require('./package.json'); process.exit(p.scripts?.dev ? 0 : 1)\"; then "
            "if node -e \"const p=require('./package.json'); process.exit((p.dependencies?.next || p.devDependencies?.next) ? 0 : 1)\"; then "
            "npm run dev -- --hostname 0.0.0.0 --port 4173; "
            "else npm run dev -- --host 0.0.0.0 --port 4173; fi; "
            "elif node -e \"const p=require('./package.json'); process.exit(p.scripts?.start ? 0 : 1)\"; then "
            "HOST=0.0.0.0 PORT=4173 npm start; "
            "else echo 'package.json needs a dev or start script' >&2; exit 3; fi"
        )
    else:
        start_command = "python3 -m http.server 4173 --bind 0.0.0.0"

    started = _docker([
        "run", "-d", "--name", name, "--network", network,
        "--network-alias", name, "--memory", SANDBOX_MEMORY_LIMIT,
        "--memory-swap", SANDBOX_MEMORY_LIMIT, "--cpus", "1.0",
        "--pids-limit", str(SANDBOX_PIDS_LIMIT), "--read-only",
        "--tmpfs", "/tmp:rw,noexec,nosuid,size=128m", "--env", "HOME=/tmp",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true", "--user", "10001:10001",
        "--mount", f"type=volume,source={volume_name},target=/workspace",
        "--workdir", "/workspace", SANDBOX_IMAGE, "sh", "-lc", start_command,
    ], timeout=20)
    if started.returncode != 0:
        _cleanup_volume(volume_name)
        _docker(["network", "rm", network], timeout=10)
        raise HTTPException(status_code=503, detail="Could not start isolated preview: " + started.stderr[-1200:])

    # Verify the container is alive and its server has time to bind.
    time.sleep(1.5)
    if not _preview_is_running(name):
        logs = _docker(["logs", name], timeout=8).stderr
        _docker(["rm", "-f", name], timeout=10)
        _cleanup_volume(volume_name)
        _docker(["network", "rm", network], timeout=10)
        raise HTTPException(status_code=400, detail="Preview process exited: " + logs[-1500:])
    return {"status": "running", "project_id": project_id, "container": name,
            "port": 4173, "network_isolated": True, "network_install_enabled": ALLOW_NETWORK_INSTALL}


@app.get("/preview/status/{project_id}")
def preview_status(project_id: str, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not PROJECT_RE.fullmatch(project_id):
        raise HTTPException(status_code=400, detail="Invalid project id.")
    running = _preview_is_running(_container_name(project_id))
    return {"project_id": project_id, "running": running}


@app.post("/preview/stop/{project_id}")
def stop_preview(project_id: str, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not PROJECT_RE.fullmatch(project_id):
        raise HTTPException(status_code=400, detail="Invalid project id.")
    name = _container_name(project_id)
    _docker(["rm", "-f", name], timeout=15)
    _docker(["network", "rm", _preview_network_name(project_id)], timeout=10)
    _cleanup_volume(f"qwen_preview_vol_{project_id}")
    return {"status": "stopped", "project_id": project_id}


def _validated_preview_status(status: int, body: bytes) -> int:
    if not isinstance(status, int) or not 100 <= status <= 599:
        return 502
    if (100 <= status < 200 or status in {204, 304}) and body:
        return 502
    return status


@app.get("/preview/{project_id}/{relative_path:path}")
def proxy_preview(project_id: str, relative_path: str, request: Request, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not PROJECT_RE.fullmatch(project_id):
        raise HTTPException(status_code=400, detail="Invalid project id.")
    rel = relative_path or "index.html"
    if rel.startswith(("/", "\\")) or ".." in rel.replace("\\", "/").split("/"):
        raise HTTPException(status_code=400, detail="Invalid preview path.")
    if not _preview_is_running(_container_name(project_id)):
        raise HTTPException(status_code=409, detail="Preview is not running.")

    # Fetch from inside this project's container. The runner itself is NOT attached to the
    # project network, and separate projects never share a preview network.
    from urllib.parse import quote
    url = "http://127.0.0.1:4173/" + "/".join(quote(part, safe="") for part in rel.split("/"))
    if request.url.query:
        url += "?" + request.url.query
    fetched = _docker_bytes([
        "exec", "--user", "10001:10001", _container_name(project_id),
        "python3", "-c", PREVIEW_FETCH_CODE, url,
    ], timeout=15)
    if fetched.returncode != 0:
        detail = fetched.stderr.decode("utf-8", "replace")[-500:]
        raise HTTPException(status_code=502, detail="Preview server is not responding: " + detail)
    header_blob = fetched.stderr.decode("utf-8", "replace").splitlines()
    try:
        upstream_status = int(header_blob[0])
        content_type = header_blob[1] if len(header_blob) > 1 else "application/octet-stream"
    except (ValueError, IndexError):
        raise HTTPException(status_code=502, detail="Preview upstream returned an invalid status line.")
    status = _validated_preview_status(upstream_status, fetched.stdout)
    if status == 502:
        raise HTTPException(status_code=502, detail="Preview upstream returned an invalid status/body combination.")
    return Response(
        content=fetched.stdout, status_code=status, media_type=content_type,
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )

@app.get("/health")
def health():
    check = _docker(["info", "--format", "{{.ServerVersion}}"], timeout=5)
    return {"status": "ok" if check.returncode == 0 else "unavailable",
            "docker": check.stdout.strip() if check.returncode == 0 else "not connected"}


@app.post("/run")
def run_project(request: RunRequest, x_runner_token: str | None = Header(default=None)):
    _auth(x_runner_token)
    if not RUN_SLOTS.acquire(blocking=False):
        raise HTTPException(status_code=429, detail="All sandbox execution slots are busy. Retry shortly.")
    try:
        return _run_project_inner(request)
    finally:
        RUN_SLOTS.release()


def _run_project_inner(request: RunRequest):
    target = _target_path(request.target)
    volume_name = f"qwen_run_{request.project_id}_{uuid.uuid4().hex}"
    _prepare_isolated_volume(request.project_id, volume_name)
    if request.profile in {"npm_test", "npm_build"}:
        package_state = _package_dependency_state(volume_name)
        if package_state["has_dependencies"]:
            has_modules = _docker(["run", "--rm", "--network", "none",
                "--mount", f"type=volume,source={volume_name},target=/workspace,readonly",
                SANDBOX_IMAGE, "sh", "-lc", "test -d /workspace/node_modules"], timeout=10).returncode == 0
            if not has_modules:
                try:
                    _install_node_dependencies(request.project_id, volume_name, package_state)
                except Exception:
                    _cleanup_volume(volume_name)
                    raise
    command = PROFILE_COMMANDS[request.profile]
    run_name = _workload_container_name("run", request.project_id)
    cmd = [
        "run", "--name", run_name, "--rm", "--network", "none",
        "--memory", SANDBOX_MEMORY_LIMIT, "--memory-swap", SANDBOX_MEMORY_LIMIT,
        "--cpus", SANDBOX_CPU_LIMIT,
        "--pids-limit", str(SANDBOX_PIDS_LIMIT), "--ulimit", "nofile=1024:1024",
        "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=128m",
        "--env", "HOME=/tmp", "--env", "npm_config_cache=/tmp/npm-cache",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
        "--user", "10001:10001",
        "--mount", f"type=volume,source={volume_name},target=/workspace",
        "--workdir", f"/workspace/{target}" if target != "." else "/workspace",
        SANDBOX_IMAGE, "sh", "-lc", command,
    ]
    try:
        try:
            result = _docker(cmd, timeout=SANDBOX_TIMEOUT_SECONDS)
        except HTTPException:
            _force_remove(run_name)
            raise
        return {
            "profile": request.profile,
            "status": "passed" if result.returncode == 0 else "failed",
            "return_code": result.returncode,
            "stdout": result.stdout[-SANDBOX_MAX_OUTPUT_BYTES:],
            "stderr": result.stderr[-SANDBOX_MAX_OUTPUT_BYTES:],
            "isolation": {
                "network": "none", "memory": SANDBOX_MEMORY_LIMIT, "cpus": float(SANDBOX_CPU_LIMIT),
                "pids_limit": SANDBOX_PIDS_LIMIT, "read_only_root": True,
                "capabilities_dropped": "ALL", "project_volume_isolated": True,
            },
        }
    finally:
        _cleanup_volume(volume_name)
