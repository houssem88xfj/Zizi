# Qwen Studio 0.7.0 — Verification and Release Audit

Audit date: 2026-11-23

> **Superseded historical document.** This audit describes the 0.7.0 tree (184 tests at
> the time). It is kept for the record only; the current release state, gate results and
> honest NOT-RUN list live in `VALIDATION.md`, `RELEASE_STATUS.md` and `PRODUCTION_READINESS.md`.

## Decision

**Hardened deployment candidate only. NOT approved for unrestricted public launch or production SaaS until live infrastructure checks and independent security testing pass.**

This audit separates checks actually run in the available environment from checks requiring a real deployment. Passing unit tests does not establish production security.

## Additional hardening in this package

- Production runner startup fails closed unless `SANDBOX_CONTAINER_RUNTIME=runsc` and Docker reports `runsc` as an available runtime.
- All runner-created workload containers are explicitly launched with the configured runtime.

## Checks executed

| Check | Result | Scope |
|---|---:|---|
| Python automated tests | PASS — 184 passed | Unit/API tests in this environment |
| JavaScript syntax | PASS | `node --check frontend/app.js` |
| Python bytecode compilation | PASS | `compileall` |
| Repository consistency | PASS | `scripts/check_consistency.py` |
| Release packaging | PASS | `scripts/check_release.py` |
| Shell syntax | PASS | Deployment, backup, restore, release and validation scripts |
| Dependency pin availability | NOT VERIFIED | Package index/network unavailable |
| Docker Compose build/runtime | NOT RUN | Docker CLI/daemon unavailable |
| Nginx deployment validation | NOT RUN | Example config contains placeholder domains/certificate paths |
| Live Qwen inference/tool calling | NOT RUN | No configured model endpoint or GPU endpoint supplied |
| DNS/TLS/wildcard preview/publish | NOT RUN | Requires a real domain and server |
| Backup and restore on production data | NOT RUN | Requires a deployed instance |

## Confirmed release blockers

1. **Docker socket authority:** `sandbox-runner` mounts `/var/run/docker.sock`; access remains effectively host-level control. The runner now requires gVisor `runsc` in production and injects `--runtime runsc` into every workload `docker run`. This reduces kernel attack surface but does not neutralize Docker socket authority. Run the entire runner/daemon on a dedicated disposable worker host with no unrelated services or valuable secrets, and complete independent escape testing before public untrusted workloads.
2. **Model not bundled/configured:** the archive does not include Qwen 14B weight shards or a working inference server. AI generation will not work until a compatible, reachable OpenAI-style model endpoint is configured and evaluated.
3. **No account onboarding (by design):** the account system was removed entirely in 0.7.1; the studio serves one local workspace with no login. Anyone who can reach the app port can use it, so keep loopback binding or add an authenticating proxy.
4. **No billing:** subscriptions, payment processing, metering-based billing and refunds are not implemented. Existing quotas are technical limits, not a payment system.
5. **Single-instance persistence/limits:** SQLite and in-process rate limiting are not a multi-replica production architecture. PostgreSQL and shared rate-limit storage such as Redis are required before horizontal scaling.
6. **No external hosting/CDN:** preview and published sites are served by this deployment; this is not a globally distributed hosting/CDN service.
7. **No independent security assessment:** no third-party penetration test, Docker escape test, abuse-controls review, privacy/terms legal review, or production incident-response exercise was performed.

## Safe release scope

Use locally on loopback after configuring the model endpoint and sandbox. For a small, invite-only group on a dedicated host add an authenticating reverse proxy, DNS/TLS, backups and monitoring first. Do not invite untrusted users to execute code until the runner isolation blocker is resolved and independently tested.

## Reproduction

From the extracted `qwen_studio` directory:

```bash
bash scripts/verify_all.sh
node --check frontend/app.js
python -m compileall -q backend runner deploy scripts
```

`verify_all.sh` reports dependency pin verification as a warning when package-index access is unavailable. A successful local test run is not a substitute for live deployment checks.
