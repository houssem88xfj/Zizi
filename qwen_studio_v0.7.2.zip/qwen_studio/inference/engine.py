"""Local weights inference engine for Qwen Studio.

Loads Hugging Face `safetensors` weights from a local directory (no network calls
at runtime) and exposes an OpenAI-compatible chat completion implementation, so the
existing model gateway in `backend.agent` works unchanged while everything stays on
this host.

The heavy dependencies (torch / transformers) are imported lazily so the rest of
Qwen Studio keeps working when the local-model extra is not installed.
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger("qwen_studio.local_inference")

# Qwen2.5-Instruct emits tool calls as <tool_call>{"name":...,"arguments":{...}}</tool_call>.
_TOOL_CALL_BLOCK_RE = re.compile(r"<tool_call>\s*(.*?)\s*</tool_call>", re.DOTALL)

VALID_DEVICES = {"auto", "cuda", "cpu"}
# "none" and "bf16" both load bf16; "fp16" loads half precision; int8/int4 use bitsandbytes.
VALID_QUANTIZATIONS = {"auto", "none", "bf16", "fp16", "int8", "int4"}

# --- memory planning (operational estimates, not compatibility guarantees) ---
# Weights alone are NOT the whole story: CUDA runtime context, KV cache, activation
# buffers and allocator fragmentation add several GiB on top of the checkpoint size.
_BF16_BYTES_PER_PARAM = 2.0
# NF4 with double quantization stores ~4.3-4.5 bits per parameter; keep a conservative
# 0.55 bytes/param so the estimate never undershoots.
_INT4_BYTES_PER_PARAM = 0.55
# CUDA context + activation buffers + fragmentation headroom (excludes KV cache,
# which is computed from the model geometry and the configured context length).
_RUNTIME_MARGIN_GIB = 2.0
# Fallback KV-cache estimate when config.json geometry is unreadable: 0.25 MiB/token
# covers GQA models of the 14B size class with headroom.
_FALLBACK_KV_BYTES_PER_TOKEN = 262144


def _choose_quantization(
    *,
    weights_gib: float,
    kv_bytes_per_token: int,
    context_tokens: int,
    total_gib: float,
    free_gib: float,
) -> str:
    """Decide bf16 ("none") vs int4 NF4 from MEASURED GPU memory.

    The decision is based on the FREE VRAM observed at load time (not the nominal
    card capacity) plus an operational estimate of what the weights actually need:

    - bf16 weights ~= on-disk safetensors size (2 bytes per parameter);
    - int4 NF4 weights ~= 0.55/2.0 of the bf16 size;
    - KV cache ~= per-token bytes (model geometry) x context length, bf16;
    - a fixed runtime margin for CUDA context, activations and fragmentation.

    Returns "none" (bf16) when everything fits with room to spare, "int4" when only
    the 4-bit plan fits, and raises EngineNotAvailable when even int4 NF4 cannot fit
    instead of silently selecting a setting that would OOM during loading.
    """
    kv_gib = kv_bytes_per_token * max(1024, int(context_tokens)) / (1024 ** 3)
    bf16_gib = weights_gib + kv_gib + _RUNTIME_MARGIN_GIB
    int4_gib = (
        weights_gib * (_INT4_BYTES_PER_PARAM / _BF16_BYTES_PER_PARAM)
        + kv_gib
        + _RUNTIME_MARGIN_GIB
    )
    if free_gib >= bf16_gib and total_gib >= bf16_gib:
        return "none"
    if free_gib >= int4_gib and total_gib >= int4_gib:
        return "int4"
    raise EngineNotAvailable(
        f"Not enough GPU memory for a {context_tokens}-token context even with INT4 NF4: "
        f"needs ~{int4_gib:.1f} GiB free (weights ~{weights_gib:.1f} + KV cache ~{kv_gib:.1f} "
        f"+ runtime margin ~{_RUNTIME_MARGIN_GIB:.1f}), but only {free_gib:.1f} of "
        f"{total_gib:.1f} GiB is free. Reduce LOCAL_MODEL_MAX_CONTEXT_TOKENS, close other "
        f"processes using the GPU, or use a larger card, then restart the platform."
    )

GENERATION_TOP_P = 0.8
GENERATION_TOP_K = 20
GENERATION_REPETITION_PENALTY = 1.05


class EngineNotReady(RuntimeError):
    """Raised when a chat request arrives before weights finished loading."""


class EngineNotAvailable(RuntimeError):
    """Raised when local inference is misconfigured (missing weights or dependencies)."""


def split_tool_calls(text: str) -> tuple[str, list[dict[str, Any]], bool]:
    """Extract ``<tool_call>`` blocks from generated text.

    Returns ``(clean_content, tool_calls, malformed)``. ``malformed`` marks a dangling
    opening tag so callers can retry or clean the reply instead of leaking raw JSON.
    """
    content = text or ""
    calls: list[dict[str, Any]] = []
    for match in _TOOL_CALL_BLOCK_RE.finditer(content):
        try:
            payload = json.loads(match.group(1))
        except json.JSONDecodeError:
            return content, [], True
        name = payload.get("name") if isinstance(payload, dict) else None
        arguments = payload.get("arguments", {}) if isinstance(payload, dict) else None
        if not isinstance(name, str) or not name:
            return content, [], True
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError:
                return content, [], True
        if not isinstance(arguments, dict):
            arguments = {}
        calls.append({"name": name, "arguments": arguments})
    if not calls:
        # A dangling opening tag (no matching closer) means an unfinished call.
        opens = len(re.findall(r"<tool_call>", content, re.IGNORECASE))
        closes = len(re.findall(r"</tool_call>", content, re.IGNORECASE))
        return content, [], (opens > closes)
    cleaned = _TOOL_CALL_BLOCK_RE.sub(" ", content)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned, calls, False


class LocalModelEngine:
    """Loads bundled weights from disk and serves chat completions in-process."""

    def __init__(
        self,
        model_dir: str | Path,
        *,
        model_name: str,
        device: str = "auto",
        quantization: str = "auto",
        max_context_tokens: int = 32768,
        max_new_tokens_cap: int = 8192,
    ) -> None:
        if device not in VALID_DEVICES:
            raise ValueError(f"Unsupported LOCAL_MODEL_DEVICE: {device}")
        if quantization not in VALID_QUANTIZATIONS:
            raise ValueError(f"Unsupported LOCAL_MODEL_QUANTIZATION: {quantization}")
        self.model_dir = Path(model_dir).resolve()
        self.model_name = model_name
        self.device = device
        self.quantization = quantization
        if int(max_context_tokens) <= 0:
            # 0 = auto: use the model's own max_position_embeddings from config.json.
            self.max_context_tokens = self._model_context_limit()
        else:
            self.max_context_tokens = max(1024, int(max_context_tokens))
        # 0 = unlimited: generation fills whatever the context window allows.
        self.max_new_tokens_cap = max(256, int(max_new_tokens_cap)) if int(max_new_tokens_cap) > 0 else None
        self._lock = threading.Lock()
        self._load_thread: threading.Thread | None = None
        self._loaded = False
        self._loading = False
        self._error: str | None = None
        self._tokenizer: Any = None
        self._model: Any = None
        self._device_label = "not-loaded"
        self._quant_label = quantization
        self._loaded_at: float = 0.0

    # ------------------------------------------------------------------ state

    def weights_present(self) -> bool:
        return (self.model_dir / "config.json").is_file() and any(
            self.model_dir.glob("*.safetensors")
        )

    def _model_context_limit(self) -> int:
        """Context window from the model's config.json (max_position_embeddings).

        Used when LOCAL_MODEL_MAX_CONTEXT_TOKENS=0 (auto). Falls back to 32768
        when the config is missing or unreadable.
        """
        try:
            config = json.loads((self.model_dir / "config.json").read_text(encoding="utf-8"))
            value = int(config.get("max_position_embeddings") or 0)
            if value >= 1024:
                return value
        except (OSError, ValueError, TypeError):
            pass
        return 32768

    @property
    def status(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "model": self.model_name,
            "model_dir": str(self.model_dir),
            "weights_present": self.weights_present(),
            "loading": self._loading,
            "loaded": self._loaded,
            "error": self._error,
            "device": self._device_label,
            "quantization": self._quant_label,
        }

    def wait_until_ready(self, timeout: float = 10.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._loaded:
                return
            if self._error:
                raise EngineNotAvailable(self._error)
            time.sleep(0.1)
        raise EngineNotReady("Local model is still loading. Retry shortly.")

    # ------------------------------------------------------------------ loading

    def begin_load(self) -> None:
        """Start loading weights in a daemon thread so the API stays responsive."""
        if self._loaded or self._loading:
            return
        if self._error:
            # A previous attempt already failed (missing weights, missing dependency,
            # insufficient GPU memory, ...). Never respawn loader threads repeatedly:
            # fix the reported cause and restart the platform for a fresh attempt.
            logger.debug("Local model load previously failed; not retrying: %s", self._error)
            return
        if not self.weights_present():
            self._error = (
                f"No safetensors weights found in {self.model_dir}. Place the "
                f"{self.model_name} config.json and *.safetensors files there."
            )
            logger.error("%s", self._error)
            return
        self._loading = True
        self._load_thread = threading.Thread(target=self._load, name="local-model-load", daemon=True)
        self._load_thread.start()

    def _resolve_device_and_quantization(self, torch: Any) -> tuple[str, str, dict[str, Any] | None]:
        cuda_available = torch.cuda.is_available()
        if self.device == "cpu":
            cuda_used = False
        elif self.device == "cuda":
            if not cuda_available:
                raise EngineNotAvailable("LOCAL_MODEL_DEVICE=cuda but no CUDA device is visible.")
            cuda_used = True
        else:  # auto
            cuda_used = cuda_available

        if not cuda_used and self.quantization == "int8":
            logger.warning(
                "int8 quantization on CPU is experimental in bitsandbytes: loading may succeed "
                "while generation can fail depending on tensor shapes and library version. "
                "Prefer int4 or bf16 on CPU."
            )

        quantization = self.quantization
        if quantization == "auto":
            if not cuda_used:
                quantization = "none"
            else:
                free_gib, total_gib = self._cuda_memory_gib(torch)
                weights_gib = self._weights_size_gib()
                quantization = _choose_quantization(
                    weights_gib=weights_gib,
                    kv_bytes_per_token=self._kv_bytes_per_token(),
                    context_tokens=self.max_context_tokens,
                    total_gib=total_gib,
                    free_gib=free_gib,
                )
                logger.info(
                    "Local inference auto-quantization: %s (weights %.1f GiB on disk, "
                    "free VRAM %.1f of %.1f GiB, context %d tokens)",
                    quantization, weights_gib, free_gib, total_gib, self.max_context_tokens,
                )
        elif cuda_used and quantization in {"none", "bf16"}:
            # Manual full-precision choice is honored, but warn when the measured free
            # VRAM clearly cannot hold it; never silently swap the user's setting.
            free_gib, _ = self._cuda_memory_gib(torch)
            need_gib = (
                self._weights_size_gib()
                + self._kv_bytes_per_token() * self.max_context_tokens / (1024 ** 3)
                + _RUNTIME_MARGIN_GIB
            )
            if free_gib < need_gib:
                logger.warning(
                    "LOCAL_MODEL_QUANTIZATION=%s needs ~%.1f GiB free VRAM for a %d-token "
                    "context but only %.1f GiB is free; loading may fail with CUDA out of "
                    "memory. Consider auto or int4 if it does.",
                    quantization, need_gib, self.max_context_tokens, free_gib,
                )
        return ("cuda" if cuda_used else "cpu"), quantization, None

    def _weights_size_gib(self) -> float:
        """Approximate in-memory weights by the safetensors bytes on disk (bf16 originals)."""
        total_bytes = 0
        try:
            for shard in self.model_dir.glob("*.safetensors"):
                total_bytes += shard.stat().st_size
        except OSError:
            return 0.0
        return total_bytes / (1024 ** 3)

    def _kv_bytes_per_token(self) -> int:
        """KV-cache bytes per token (bf16) from config.json geometry, with a safe fallback."""
        try:
            config = json.loads((self.model_dir / "config.json").read_text(encoding="utf-8"))
            layers = int(config["num_hidden_layers"])
            heads = int(config["num_attention_heads"])
            kv_heads = int(config.get("num_key_value_heads") or heads)
            hidden = int(config["hidden_size"])
            if min(layers, heads, kv_heads, hidden) <= 0 or heads % kv_heads:
                raise ValueError("implausible attention geometry")
            # Two tensors (K and V) per layer, bf16 = 2 bytes per element.
            return 2 * layers * kv_heads * (hidden // heads) * 2
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            return _FALLBACK_KV_BYTES_PER_TOKEN

    @staticmethod
    def _cuda_memory_gib(torch: Any) -> tuple[float, float]:
        """(free, total) VRAM in GiB; falls back to a discounted total when free cannot be measured."""
        props = torch.cuda.get_device_properties(0)
        total_gib = getattr(props, "total_memory", 0) / (1024 ** 3)
        try:
            free_gib = torch.cuda.mem_get_info()[0] / (1024 ** 3)
        except Exception:  # noqa: BLE001 - exotic torch builds without mem_get_info
            free_gib = total_gib * 0.85
            logger.warning(
                "Could not measure free VRAM (mem_get_info unavailable); assuming "
                "%.1f GiB free of %.1f GiB total.", free_gib, total_gib,
            )
        return free_gib, total_gib

    def _load(self) -> None:
        try:
            try:
                import torch  # noqa: PLC0415
                from transformers import AutoModelForCausalLM, AutoTokenizer  # noqa: PLC0415
            except ImportError as exc:  # pragma: no cover - depends on optional extra
                raise EngineNotAvailable(
                    "Local inference needs the model extra: pip install -r requirements-local-model.txt "
                    f"(missing {exc.name})."
                ) from exc

            device, quantization, _ = self._resolve_device_and_quantization(torch)
            self._quant_label = quantization
            started = time.monotonic()
            logger.info("Loading local weights from %s (device=%s, quantization=%s)", self.model_dir, device, quantization)

            tokenizer = AutoTokenizer.from_pretrained(str(self.model_dir), trust_remote_code=False, local_files_only=True)
            model_kwargs: dict[str, Any] = {
                "local_files_only": True,
                "trust_remote_code": False,
                "low_cpu_mem_usage": True,
            }
            if quantization in {"int4", "int8"}:
                try:
                    from transformers import BitsAndBytesConfig  # noqa: PLC0415
                except ImportError as exc:
                    raise EngineNotAvailable(
                        "LOCAL_MODEL_QUANTIZATION=int4/int8 requires bitsandbytes: pip install bitsandbytes"
                    ) from exc
                compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
                if quantization == "int4":
                    model_kwargs["quantization_config"] = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_quant_type="nf4",
                        bnb_4bit_use_double_quant=True,
                        bnb_4bit_compute_dtype=compute_dtype,
                    )
                else:
                    model_kwargs["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)
                # With quantization the whole model fits on one GPU; keep it there.
                model_kwargs["device_map"] = {"": 0} if device == "cuda" else "auto"
                if device == "cuda":
                    # Cap the GPU share from MEASURED free VRAM (not a hardcoded card
                    # size) so larger and smaller cards both behave sensibly.
                    free_gib, _ = self._cuda_memory_gib(torch)
                    gpu_cap_gib = max(4, int(free_gib - _RUNTIME_MARGIN_GIB))
                    model_kwargs["max_memory"] = {0: f"{gpu_cap_gib}GiB", "cpu": "24GiB"}
                    logger.info(
                        "bitsandbytes max_memory cap on GPU 0: %d GiB (measured free %.1f GiB).",
                        gpu_cap_gib, free_gib,
                    )
            else:
                # transformers>=5 renamed torch_dtype -> dtype; older releases only accept torch_dtype.
                dtype = torch.float16 if quantization == "fp16" else torch.bfloat16
                if device == "cpu" and quantization == "fp16":
                    logger.warning("fp16 on CPU is supported but slower than bf16 on most CPUs.")
                transformers_version = str(__import__("transformers").__version__)
                major = int(transformers_version.split(".", 1)[0] or 0)
                if major >= 5:
                    model_kwargs["dtype"] = dtype
                else:
                    model_kwargs["torch_dtype"] = dtype
                model_kwargs["device_map"] = "auto" if device == "cuda" else None
                if device == "cpu":
                    model_kwargs.pop("device_map")

            model = AutoModelForCausalLM.from_pretrained(str(self.model_dir), **model_kwargs)
            model.eval()
            if device == "cpu" and not quantization:
                model = model.to("cpu")

            self._tokenizer = tokenizer
            self._model = model
            self._device_label = device + ("+bnb" if quantization in {"int4", "int8"} else "")
            self._loaded = True
            self._loading = False
            self._loaded_at = time.monotonic()
            logger.info("Local model ready in %.1fs (%s/%s)", self._loaded_at - started, device, quantization)
        except Exception as exc:  # noqa: BLE001 - surface every load failure through /health
            self._loading = False
            self._error = str(exc)[:500]
            logger.exception("Local model failed to load: %s", exc)

    # ------------------------------------------------------------------ prompt

    def _convert_messages(self, messages: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, str]]:
        """Map OpenAI-style messages onto the Qwen chat-template structure."""
        tool_names: dict[str, str] = {}
        for message in messages:
            for call in message.get("tool_calls") or []:
                call_id = call.get("id")
                name = (call.get("function") or {}).get("name")
                if call_id and name:
                    tool_names[call_id] = name
        converted: list[dict[str, Any]] = []
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            if role == "tool":
                converted.append({
                    "role": "tool",
                    "name": tool_names.get(message.get("tool_call_id", ""), "tool"),
                    "content": content if isinstance(content, str) else "",
                })
                continue
            if role == "assistant" and message.get("tool_calls"):
                template_calls = []
                for call in message.get("tool_calls"):
                    function = call.get("function") or {}
                    raw_args = function.get("arguments")
                    if isinstance(raw_args, str):
                        try:
                            raw_args = json.loads(raw_args or "{}")
                        except json.JSONDecodeError:
                            raw_args = {}
                    template_calls.append({
                        "id": call.get("id", f"call_{uuid.uuid4().hex[:8]}"),
                        "type": "function",
                        "function": {"name": function.get("name", ""), "arguments": raw_args or {}},
                    })
                converted.append({
                    "role": "assistant",
                    "content": content if isinstance(content, str) else None,
                    "tool_calls": template_calls,
                })
                continue
            converted.append({
                "role": role if role in {"system", "user", "assistant"} else "user",
                "content": content if isinstance(content, str) else "",
            })
        return converted, tool_names

    def _build_prompt_ids(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None) -> list[int]:
        tokenizer = self._tokenizer
        converted, _ = self._convert_messages(messages)
        template_kwargs: dict[str, Any] = {"add_generation_prompt": True}
        if tools:
            template_kwargs["tools"] = tools
        prompt_text = tokenizer.apply_chat_template(converted, tokenize=False, **template_kwargs)
        input_ids = tokenizer(prompt_text, add_special_tokens=False, return_tensors=None)["input_ids"]
        cap = self.max_new_tokens_cap or 64
        budget = self.max_context_tokens - cap
        if budget <= 0:
            raise EngineNotAvailable("LOCAL_MODEL_MAX_CONTEXT_TOKENS must exceed MODEL_MAX_TOKENS.")
        while len(input_ids) > budget and len(converted) > 2:
            # Drop the oldest non-system message and retry.
            del converted[1]
            prompt_text = tokenizer.apply_chat_template(converted, tokenize=False, **template_kwargs)
            input_ids = tokenizer(prompt_text, add_special_tokens=False, return_tensors=None)["input_ids"]
        if len(input_ids) > budget:  # last resort: left-truncate, keep the newest context
            input_ids = input_ids[-budget:]
        return input_ids

    # ------------------------------------------------------------------ inference

    def chat_completion(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self._loaded:
            if self._error:
                raise EngineNotAvailable(self._error)
            if self.weights_present():
                raise EngineNotReady("Local model is still loading. Retry shortly.")
            raise EngineNotAvailable(
                f"No weights found in {self.model_dir}. Upload the safetensors files first."
            )
        if payload.get("stream"):
            raise ValueError("Streaming responses are not supported by the local engine.")

        messages = payload.get("messages") or []
        tools = payload.get("tools") or None
        requested_max = payload.get("max_tokens")
        try:
            requested_max = int(requested_max) if requested_max else None
        except (TypeError, ValueError):
            requested_max = None
        temperature = float(payload.get("temperature", 0.2))

        input_ids = self._build_prompt_ids(messages, tools)
        with self._lock:
            import torch as _torch  # noqa: PLC0415
            input_tensor = _torch.tensor([input_ids])
            device = next(self._model.parameters()).device
            input_tensor = input_tensor.to(device)
            prompt_tokens = input_tensor.shape[1]
            if self.max_new_tokens_cap is None:
                # Unlimited cap: fill the remaining context window after the prompt.
                remaining = max(64, self.max_context_tokens - prompt_tokens)
                max_new_tokens = min(requested_max, remaining) if requested_max else remaining
                max_new_tokens = max(64, max_new_tokens)
            else:
                max_new_tokens = int(requested_max or self.max_new_tokens_cap)
                max_new_tokens = max(64, min(max_new_tokens, self.max_new_tokens_cap))
            generate_kwargs: dict[str, Any] = {
                "input_ids": input_tensor,
                "max_new_tokens": max_new_tokens,
                "do_sample": temperature > 0,
                "top_p": GENERATION_TOP_P,
                "top_k": GENERATION_TOP_K,
                "repetition_penalty": GENERATION_REPETITION_PENALTY,
                "pad_token_id": self._tokenizer.pad_token_id or self._tokenizer.eos_token_id,
            }
            if temperature > 0:
                generate_kwargs["temperature"] = max(temperature, 1e-4)
            with _torch.no_grad():
                output = self._model.generate(**generate_kwargs)
        new_tokens = output[0][prompt_tokens:]
        completion_tokens = int(new_tokens.shape[0])
        generated_text = self._tokenizer.decode(new_tokens, skip_special_tokens=True)

        content, tool_calls, malformed = split_tool_calls(generated_text)
        message: dict[str, Any] = {"role": "assistant", "content": content or None}
        finish_reason = "stop"
        if tool_calls:
            message["tool_calls"] = [
                {
                    "id": f"call_{uuid.uuid4().hex[:12]}",
                    "type": "function",
                    "function": {"name": call["name"], "arguments": json.dumps(call["arguments"], ensure_ascii=False)},
                }
                for call in tool_calls
            ]
            finish_reason = "tool_calls"
        elif malformed:
            finish_reason = "stop"
        elif completion_tokens >= max_new_tokens:
            finish_reason = "length"

        completion_id = f"chatcmpl-local-{uuid.uuid4().hex[:12]}"
        return {
            "id": completion_id,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": self.model_name,
            "choices": [
                {
                    "index": 0,
                    "message": message,
                    "finish_reason": finish_reason,
                }
            ],
            "usage": {
                "prompt_tokens": int(prompt_tokens),
                "completion_tokens": completion_tokens,
                "total_tokens": int(prompt_tokens + completion_tokens),
            },
            "local_inference": {
                "malformed_tool_call": malformed,
                "device": self._device_label,
            },
        }
