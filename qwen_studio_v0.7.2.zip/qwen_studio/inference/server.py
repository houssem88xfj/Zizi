"""OpenAI-compatible HTTP wrapper around the local weights engine.

Started in a daemon thread from the Qwen Studio lifespan when `LOCAL_INFERENCE=true`.
Bound to loopback only: the studio backend talks to it over `MODEL_BASE_URL`, and no
traffic leaves the host for model inference.
"""
from __future__ import annotations

import logging
import threading
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel

from .engine import EngineNotAvailable, EngineNotReady, LocalModelEngine

logger = logging.getLogger("qwen_studio.local_inference")

_ENGINE: LocalModelEngine | None = None
_SERVER_THREAD: threading.Thread | None = None


class ChatCompletionRequest(BaseModel):
    model: str | None = None
    messages: list[dict[str, Any]]
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    stream: bool = False
    user: str | None = None


def create_app(engine: LocalModelEngine) -> FastAPI:
    app = FastAPI(
        title="Qwen Studio Local Inference",
        version="0.7.2",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    @app.middleware("http")
    async def harden_headers(request: Request, call_next):
        response: Response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        return response

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "service": "qwen-studio-local-inference",
            "model": engine.model_name,
            **engine.status,
        }

    @app.get("/v1/models")
    def list_models() -> dict[str, Any]:
        return {
            "object": "list",
            "data": [
                {
                    "id": engine.model_name,
                    "object": "model",
                    "created": 0,
                    "owned_by": "qwen-studio-local",
                }
            ],
        }

    @app.post("/v1/chat/completions")
    def chat_completions(request: ChatCompletionRequest) -> dict[str, Any]:
        try:
            return engine.chat_completion(request.model_dump(exclude_none=True))
        except EngineNotReady as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except EngineNotAvailable as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return app


def get_engine() -> LocalModelEngine | None:
    return _ENGINE


def start_local_inference(
    *,
    model_dir: str,
    model_name: str,
    host: str,
    port: int,
    device: str,
    quantization: str,
    max_context_tokens: int,
    max_new_tokens_cap: int,
) -> None:
    """Start the loopback inference server and kick off weight loading."""
    global _ENGINE, _SERVER_THREAD
    if _SERVER_THREAD is not None:
        return

    engine = LocalModelEngine(
        model_dir,
        model_name=model_name,
        device=device,
        quantization=quantization,
        max_context_tokens=max_context_tokens,
        max_new_tokens_cap=max_new_tokens_cap,
    )
    _ENGINE = engine

    import uvicorn  # noqa: PLC0415 - uvicorn is always installed with Qwen Studio

    app = create_app(engine)
    config = uvicorn.Config(app, host=host, port=port, log_level="warning", access_log=False)
    server = uvicorn.Server(config)

    def _serve() -> None:
        logger.info("Local inference server listening on http://%s:%s/v1", host, port)
        server.run()

    _SERVER_THREAD = threading.Thread(target=_serve, name="local-inference-server", daemon=True)
    _SERVER_THREAD.start()
    engine.begin_load()
