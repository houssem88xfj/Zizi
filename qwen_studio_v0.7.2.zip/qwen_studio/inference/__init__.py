"""Qwen Studio local inference: run the bundled model weights on this host.

The module exposes a small OpenAI-compatible HTTP server (see `server.py`) backed by
Hugging Face `transformers`, so `backend.agent` keeps talking to a standard
`MODEL_BASE_URL` endpoint while the weights are loaded from a local directory.
No external service is contacted when `LOCAL_INFERENCE=true`.
"""
from .engine import EngineNotAvailable, EngineNotReady, LocalModelEngine

__all__ = ["EngineNotAvailable", "EngineNotReady", "LocalModelEngine"]
