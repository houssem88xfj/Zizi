# Open-source release checklist

This checklist distinguishes repository publication from operating a public hosted service.

## Repository publication

- [x] MIT license added for this repository's code.
- [x] Contribution guidance added.
- [x] Security reporting and deployment warnings added.
- [x] Code of Conduct added.
- [x] GitHub Actions CI added.
- [x] Bug and feature issue templates added.
- [x] Model deployment and licensing separation documented.
- [x] `python3 scripts/account_removal_scan.py` passes (no account-system artifacts in the tree).
- [x] `bash scripts/verify_all.sh` green before packaging; `scripts/make_release.sh` refuses a dirty git worktree.
- [ ] On the GPU host: `python3 scripts/verify_weights.py` + `python3 scripts/bench_local_model.py --json bench-14b.json` with the real Qwen2.5-Coder-14B-Instruct weights, and `python3 scripts/eval_agent.py` (20 tasks) before publishing a claim about 14B agent quality.
- [ ] Confirm the copyright holder/contributor attribution before publishing.
- [ ] Review every dependency and bundled asset license; retain required notices.
- [ ] Scan the complete Git history for secrets before making the repository public.
- [ ] Create the public repository, add maintainers, and configure private vulnerability reporting.
- [ ] Run CI on GitHub and publish a tagged release only after it passes.

## Before inviting untrusted users to a hosted instance

- [ ] Dedicated disposable runner host; do not co-locate unrelated workloads or secrets.
- [ ] Verify gVisor runtime and workload restrictions on the actual host.
- [ ] Independent security review and sandbox escape testing.
- [ ] Live model tool-call evaluation on the exact model and serving stack.
- [ ] Real DNS, reverse proxy, TLS, preview and publishing hostname tests.
- [ ] Backup and restore drill; monitoring, alerting, incident response and rate-limit/abuse tests.
- [ ] Privacy policy, terms, data retention/deletion process, and support contact.
- [ ] If ever turning this single-user workspace into a hosted multi-user service: design and implement authentication, email verification, password recovery, billing, cancellation, invoices and webhook signature validation from scratch (none of this exists in the repository).

Passing repository CI does not complete the hosted-service checklist. The repository can be published as source while the hosted service remains clearly labeled experimental/self-hosted.
