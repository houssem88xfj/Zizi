#!/usr/bin/env python3
"""Create a production .env with the internal runner secret; never overwrite an existing file.

Qwen Studio has no user accounts, so only the internal Backend-to-Runner token is
generated here.
"""
from __future__ import annotations

import secrets
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".env.example"
TARGET = ROOT / ".env"


def main() -> int:
    if TARGET.exists():
        print("Refusing to overwrite existing .env. Back it up or edit it manually.")
        return 2
    content = SOURCE.read_text(encoding="utf-8")
    content = content.replace(
        "SANDBOX_RUNNER_TOKEN=REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARACTERS",
        f"SANDBOX_RUNNER_TOKEN={secrets.token_urlsafe(48)}",
    )
    TARGET.write_text(content, encoding="utf-8")
    try:
        TARGET.chmod(0o600)
    except OSError:
        pass
    print("Created .env with a random internal runner secret (file mode 0600 where supported).")
    print("Now edit MODEL_BASE_URL, MODEL_NAME, MODEL_API_KEY and all three HTTPS domains.")
    print("Keep APP_ENV=production and SANDBOX_CONTAINER_RUNTIME=runsc.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
