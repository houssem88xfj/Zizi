#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ARCHIVE="${1:-}"
if [[ -z "$ARCHIVE" || ! -f "$ARCHIVE" ]]; then
  echo "Usage: deploy/restore.sh backups/qwen-studio-YYYYMMDDTHHMMSSZ.tar.gz" >&2
  exit 2
fi
BACKUP_DIR="$(realpath "$ROOT/backups")"
ARCHIVE_REAL="$(realpath "$ARCHIVE")"
case "$ARCHIVE_REAL" in
  "$BACKUP_DIR"/*) ;;
  *) echo "Restore archive must be stored inside the repository backups/ directory." >&2; exit 2 ;;
esac
ARCHIVE_NAME="$(basename "$ARCHIVE_REAL")"
cd "$ROOT"
command -v docker >/dev/null 2>&1 || { echo "Docker is required." >&2; exit 1; }
echo "WARNING: this replaces the entire qwen_workspace volume with the selected backup."
read -r -p "Type RESTORE to continue: " CONFIRM
[[ "$CONFIRM" == "RESTORE" ]] || { echo "Cancelled."; exit 1; }
docker compose stop app sandbox-runner
docker run --rm \
  -v qwen_workspace:/data \
  -v "$BACKUP_DIR:/backup:ro" \
  alpine:3.20 sh -c 'find /data -mindepth 1 -maxdepth 1 -exec rm -rf {} + && tar -xzf "/backup/$1" -C /data' restore "$ARCHIVE_NAME"
docker compose start sandbox-runner app
echo "Restore completed. Restore the matching qwen-studio-*.env file separately if needed."
echo "Confirm app health and inspect user projects."
