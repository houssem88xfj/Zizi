#!/usr/bin/env python3
"""Production configuration validator. Reads .env without printing secret values."""
from __future__ import annotations

import ipaddress
import sys
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT / ".env"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.domains import registrable_domain


def read_env(path: Path = ENV_FILE) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        raise ValueError("Missing .env. Copy .env.example to .env and fill in the settings.")
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        values[key.strip()] = value
    return values


def warnings(values: dict[str, str]) -> list[str]:
    """Return non-fatal production deployment warnings."""
    if values.get("APP_ENV", "").lower() != "production":
        return []
    public_host = urlsplit(values.get("PUBLIC_BASE_URL", "")).hostname
    preview_host = urlsplit(values.get("PREVIEW_BASE_URL", "")).hostname
    publish_host = urlsplit(values.get("PUBLISH_BASE_URL", "")).hostname
    parents = [registrable_domain(host) for host in (public_host, preview_host, publish_host)]
    if all(parents) and len(set(parents)) == 1:
        return [
            "PUBLIC_BASE_URL, PREVIEW_BASE_URL and PUBLISH_BASE_URL share the same registrable parent domain; "
            "use a separate registered domain for previews and published sites so generated project code "
            "cannot share the application origin."
        ]
    return []


def validate(values: dict[str, str]) -> list[str]:
    errors: list[str] = []
    if values.get("APP_ENV", "").lower() != "production":
        errors.append("APP_ENV must be production.")
    # There are no user accounts or session cookies. SANDBOX_RUNNER_TOKEN stays: it
    # authenticates the internal Backend-to-Runner connection, which is unrelated to
    # the removed account system.
    runner = values.get("SANDBOX_RUNNER_TOKEN", "")
    if len(runner) < 32 or runner.startswith("REPLACE_WITH"):
        errors.append("SANDBOX_RUNNER_TOKEN must be a generated secret of at least 32 characters.")
    if values.get("ALLOW_REMOTE_ACCESS", "false").lower() == "true":
        errors.append("ALLOW_REMOTE_ACCESS must remain false; keep the app on loopback behind Nginx.")
    if values.get("APP_BIND_ADDRESS", "127.0.0.1") not in {"127.0.0.1", "::1"}:
        errors.append("APP_BIND_ADDRESS must be loopback; put Nginx in front of the app.")
    forwarded_allow_ips = values.get("FORWARDED_ALLOW_IPS", "").strip()
    if not forwarded_allow_ips or forwarded_allow_ips in {"*", "0.0.0.0/0", "::/0"}:
        errors.append("FORWARDED_ALLOW_IPS must be set to a trusted proxy IP or narrow CIDR; wildcards/default routes are forbidden.")
    else:
        for entry in forwarded_allow_ips.split(","):
            entry = entry.strip()
            try:
                try:
                    parsed_ip = ipaddress.ip_address(entry)
                    network = ipaddress.ip_network(f"{parsed_ip}/{parsed_ip.max_prefixlen}", strict=False)
                except ValueError:
                    network = ipaddress.ip_network(entry, strict=False)
                if network.version == 4 and network.prefixlen < 24:
                    raise ValueError("IPv4 prefix is broader than /24")
                if network.prefixlen == 0:
                    raise ValueError("default route is not a trusted proxy")
            except ValueError:
                errors.append("FORWARDED_ALLOW_IPS entries must be valid IPs or CIDRs; IPv4 CIDRs must be /24 or narrower.")
                break
    npm_install = values.get("SANDBOX_ALLOW_NETWORK_INSTALL", "false").lower() == "true"
    npm_registry = urlsplit(values.get("SANDBOX_NPM_REGISTRY_URL", ""))
    if npm_install and (npm_registry.scheme != "http" or npm_registry.hostname != "npm-proxy"
                        or npm_registry.port != 4873 or npm_registry.username or npm_registry.password
                        or npm_registry.path not in {"", "/"} or npm_registry.query or npm_registry.fragment):
        errors.append("SANDBOX_ALLOW_NETWORK_INSTALL requires SANDBOX_NPM_REGISTRY_URL=http://npm-proxy:4873 on the internal npm proxy network.")

    public_url = urlsplit(values.get("PUBLIC_BASE_URL", ""))
    preview_url = urlsplit(values.get("PREVIEW_BASE_URL", ""))
    publish_url = urlsplit(values.get("PUBLISH_BASE_URL", ""))
    if (public_url.scheme != "https" or not public_url.hostname or public_url.username
            or public_url.password or public_url.path not in {"", "/"}
            or public_url.query or public_url.fragment):
        errors.append("PUBLIC_BASE_URL must be an HTTPS origin without credentials, path, query, or fragment.")
    if (preview_url.scheme != "https" or not preview_url.hostname or preview_url.username
            or preview_url.password or preview_url.path not in {"", "/"}
            or preview_url.query or preview_url.fragment):
        errors.append("PREVIEW_BASE_URL must be an HTTPS origin without credentials, path, query, or fragment.")
    if (publish_url.scheme != "https" or not publish_url.hostname or publish_url.username
            or publish_url.password or publish_url.path not in {"", "/"}
            or publish_url.query or publish_url.fragment):
        errors.append("PUBLISH_BASE_URL must be an HTTPS origin without credentials, path, query, or fragment.")
    publish_domain = values.get("PUBLISH_DOMAIN", "").lower()
    if publish_url.hostname and publish_domain != publish_url.hostname.lower():
        errors.append("PUBLISH_DOMAIN must exactly match the PUBLISH_BASE_URL hostname.")
    if publish_domain and not __import__("re").fullmatch(
        r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+",
        publish_domain,
    ):
        errors.append("PUBLISH_DOMAIN must be a bare DNS domain suitable for wildcard per-site subdomains.")
    preview_domain = values.get("PREVIEW_DOMAIN", "").lower()
    if preview_url.hostname and preview_domain != preview_url.hostname.lower():
        errors.append("PREVIEW_DOMAIN must exactly match the PREVIEW_BASE_URL hostname.")
    if public_url.hostname and preview_url.hostname and public_url.hostname.lower() == preview_url.hostname.lower():
        errors.append("The app and preview must use different hostnames.")
    if publish_url.hostname and public_url.hostname and publish_url.hostname.lower() == public_url.hostname.lower():
        errors.append("The published-sites host must differ from the app host.")
    if publish_url.hostname and preview_url.hostname and publish_url.hostname.lower() == preview_url.hostname.lower():
        errors.append("The published-sites host must differ from the preview host.")
    model_url = urlsplit(values.get("MODEL_BASE_URL", ""))
    if (model_url.scheme not in {"http", "https"} or not model_url.hostname
            or model_url.username or model_url.password or model_url.fragment):
        errors.append("MODEL_BASE_URL must be a valid HTTP(S) endpoint without embedded credentials or fragments.")
    elif model_url.scheme == "http":
        host = model_url.hostname.lower()
        internal_names = {"localhost", "host.docker.internal", "sandbox-runner"}
        try:
            is_private_host = ipaddress.ip_address(host).is_private
        except ValueError:
            is_private_host = host.endswith((".internal", ".local"))
        if host not in internal_names and not is_private_host:
            errors.append("Use HTTPS for an external MODEL_BASE_URL; HTTP is allowed only for private/internal hosts.")
    if values.get("MODEL_NAME", "").strip() == "":
        errors.append("MODEL_NAME must not be empty.")
    if values.get("SANDBOX_RUNNER_URL", "").strip() != "http://sandbox-runner:8090":
        errors.append("SANDBOX_RUNNER_URL must point to the private Compose service http://sandbox-runner:8090.")
    try:
        app_port = int(values.get("APP_PORT", "8080"))
        if not 1024 <= app_port <= 65535:
            raise ValueError
    except ValueError:
        errors.append("APP_PORT must be an integer between 1024 and 65535.")
    return errors


def main() -> int:
    try:
        values = read_env()
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 2
    errors = validate(values)
    if errors:
        print("Production preflight FAILED:")
        for error in errors:
            print(f" - {error}")
        return 2
    print("Production preflight passed. Secret values were not displayed.")
    for warning in warnings(values):
        print(f"WARNING: {warning}")
    print("Next: verify DNS/TLS, then run deploy/deploy.sh.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
