#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p backups
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE="$ROOT/backups/qwen-studio-${STAMP}.tar.gz"

command -v docker >/dev/null 2>&1 || { echo "Docker is required." >&2; exit 1; }
restart_services() { docker compose start sandbox-runner app >/dev/null 2>&1 || true; }
trap restart_services EXIT
docker compose stop app sandbox-runner

docker run --rm \
  -v qwen_workspace:/data:ro \
  -v "$ROOT/backups:/backup" \
  alpine:3.20 \
  sh -c "tar -czf '/backup/qwen-studio-${STAMP}.tar.gz' -C /data ."
cp .env "backups/qwen-studio-${STAMP}.env"
chmod 600 "backups/qwen-studio-${STAMP}.env"

restart_services
trap - EXIT
echo "Backup created: $ARCHIVE"
echo "Store this archive encrypted and off the server. Test restoration periodically."
