#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v docker >/dev/null 2>&1 || { echo "Docker Engine/CLI is required." >&2; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin is required." >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "Python 3 is required for preflight validation." >&2; exit 1; }
command -v curl >/dev/null 2>&1 || { echo "curl is required for the post-deploy health check." >&2; exit 1; }

python3 scripts/check_release.py
set +e
python3 scripts/verify_pins.py
PINS_RC=$?
set -e
if [[ "$PINS_RC" -eq 1 ]]; then echo "A pinned dependency version is missing from PyPI." >&2; exit 1; elif [[ "$PINS_RC" -eq 3 ]]; then echo "WARNING: package index unavailable; dependency pins were not verified." >&2; fi
python3 deploy/preflight.py
docker compose config --quiet

echo "Building isolated execution image..."
docker build -t qwen-sandbox:latest ./sandbox

echo "Building and starting Qwen Studio services..."
docker compose up -d --build

PORT="$(python3 - <<'PYPORT'
from deploy.preflight import read_env
print(read_env().get("APP_PORT", "8080"))
PYPORT
)"
HEALTH_URL="http://127.0.0.1:${PORT}/health"
for attempt in $(seq 1 40); do
  if curl --fail --silent --show-error "$HEALTH_URL" >/tmp/qwen-studio-health.json 2>/dev/null; then
    echo "Qwen Studio API is healthy: $(cat /tmp/qwen-studio-health.json)"
    echo "Now verify the Nginx TLS site and wildcard preview DNS from an external browser."
    exit 0
  fi
  sleep 3
done

echo "Application health check failed. Recent service logs:" >&2
docker compose logs --tail=100 app sandbox-runner >&2
exit 1
