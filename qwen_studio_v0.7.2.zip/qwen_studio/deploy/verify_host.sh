#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail=0
for command in docker python3 runsc; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "FAIL: missing command: $command"
    fail=1
  else
    echo "PASS: $command found"
  fi
done
if command -v docker >/dev/null 2>&1; then
  if docker info >/dev/null 2>&1; then echo "PASS: Docker daemon reachable"; else echo "FAIL: Docker daemon unavailable/current user lacks permission"; fail=1; fi
  runtimes="$(docker info --format '{{json .Runtimes}}' 2>/dev/null || true)"
  if printf '%s' "$runtimes" | grep -q '"runsc"'; then echo "PASS: Docker runsc runtime registered"; else echo "FAIL: Docker daemon does not advertise runsc"; fail=1; fi
  if docker compose version >/dev/null 2>&1; then echo "PASS: Docker Compose plugin available"; else echo "FAIL: Docker Compose plugin unavailable"; fail=1; fi
fi
if [[ ! -f .env ]]; then echo "FAIL: .env is missing; run python3 deploy/prepare_env.py"; fail=1
else
  if grep -q '^SANDBOX_CONTAINER_RUNTIME=runsc$' .env; then echo "PASS: .env selects runsc"; else echo "FAIL: set SANDBOX_CONTAINER_RUNTIME=runsc in .env"; fail=1; fi
  if grep -q '^SANDBOX_RUNNER_TOKEN=REPLACE_WITH' .env; then echo "FAIL: placeholder runner secret remains in .env"; fail=1; else echo "PASS: no obvious placeholder secrets"; fi
  if docker compose --env-file .env config -q >/dev/null 2>&1; then echo "PASS: Compose configuration parses"; else echo "FAIL: Docker Compose configuration invalid (run docker compose --env-file .env config for details)"; fail=1; fi
fi
if [[ "$fail" -ne 0 ]]; then echo "HOST CHECK FAILED. Do not expose this deployment to public users."; exit 1; fi
echo "HOST CHECK PASSED. This verifies prerequisites only; it is not a penetration test or live service test."
