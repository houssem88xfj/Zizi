# Security Policy

## Supported version

Security fixes are accepted for the latest published release. Older versions may not receive fixes; upgrade before reporting a vulnerability.

## Reporting a vulnerability

Please do not disclose exploitable vulnerabilities in public issues, discussions, or pull requests. Contact the repository maintainer privately through the security contact configured in the hosting platform (for example, GitHub's **Report a vulnerability** feature). If private reporting is unavailable, first open a minimal issue asking for a private contact without including exploit details.

Include, where possible:

- affected version/commit and deployment mode;
- impact and prerequisites;
- reproducible steps or a minimal proof of concept;
- logs with tokens, credentials, personal data, and project contents removed.

Do not access, modify, or exfiltrate other users' data; do not run destructive tests against systems you do not own or have permission to test.

## Deployment security notes

Qwen Studio executes user-controlled project content. Do not expose it to untrusted users until the runner is deployed on a dedicated, disposable worker host, gVisor is verified, resource limits and network restrictions are active, and an independent security review has been completed. The runner's Docker daemon access is highly privileged. gVisor is defense in depth, not a complete security boundary. Keep the application host, runner host, model host, and their secrets separated where practical.

Never commit `.env`, API keys, session secrets, user projects, logs containing personal data, or model weights. Rotate any secret that may have been exposed.
