# دليل تثبيت Linux — Qwen Studio

هذا الدليل يشرح التثبيت من الصفر على لينكس (أو macOS) بدون Docker، مع النموذج المحلي
Qwen2.5-Coder-14B-Instruct. للنشر بالإنتاج مع Docker وgVisor راجع `README.md` و`docs/RUNBOOK.md`.

## 1) المتطلبات

- Python 3.11 أو أحدث (`python3 --version`).
- 40GB مساحة حرة على الأقل (نظام + بيئة بايثون + ~30GB إضافية لأوزان النموذج 14B بصيغة safetensors — الأوزان تُنزَّل من داخل التطبيق عبر صفحة Model بعد التثبيت).
- الذاكرة/كرت الشاشة: راجع `docs/GPU_GUIDE.md` (NVIDIA: 40GB+ لـbf16، أو 24GB كافية لـINT4، أو 10–12GB بشروط مع تقليل السياق — تقديرات تشغيلية وليست ضمانًا لكل بطاقة) أو `docs/CPU_GUIDE.md` (بدون كرت).
- اتصال إنترنت مرة واحدة أثناء التثبيت فقط. **تشغيل النموذج بعد ذلك بدون إنترنت تمامًا.**

## 2) التثبيت بخطوة واحدة

```bash
cd qwen-studio
# بعد git clone سيكون المجلد qwen-studio؛ وبعد فك ضغط qwen_studio_v0.7.2.zip سيكون qwen_studio
bash scripts/install.sh --with-model --cuda   # جهاز NVIDIA: نسخة CUDA من torch + فحص حقيقي
# أو:
bash scripts/install.sh --with-model --cpu    # بدون كرت شاشة: نسخة CPU من torch
# أو بدون علم (يكتشف تلقائيًا): bash scripts/install.sh --with-model
```

يقوم السكربت بـ: إنشاء بيئة افتراضية `.venv`، تثبيت تبعيات التطبيق ثم torch **بإصدار مثبّت
`torch==2.6.0`** (أحدث إصدار منشور رسميًا في فهرس cu124، متاح لـPython 3.11–3.13 على لينكس
وويندوز للنسختين) بالنسخة المطلوبة (CPU أو CUDA cu124 — مع إلغاء تثبيت أي نسخة متعارضة
أو معطوبة سابقًا وعدم ترك نسختين)، تثبيت `requirements-local-model.txt`، ثم **فحص حقيقي**
عبر `scripts/check_torch.py`: `torch.cuda.is_available()` يُستدعى فعليًا، وعند طلب CUDA
دون رؤية GPU يفشل التثبيت برسالة واضحة وسبل الإصلاح بدل رسالة نجاح زائفة، توليد ملف
`.env` بأسرار عشوائية وإعدادات تطوير جاهزة، وفحص مجلد الأوزان.

للتحقق بعد التثبيت في أي وقت:

```bash
python scripts/check_torch.py --cuda   # أو --cpu — يطبع نسخة torch وbuild‏ CUDA ورؤية الكرت فعليًا
```

## 3) الأوزان — من داخل التطبيق (الأسهل) أو يدويًا

### الطريقة الأسهل: زر Model داخل التطبيق

شغّل التطبيق (القسم 4) وافتح `http://127.0.0.1:8080` ثم:

1. اضغط زر **Model** في الشريط العلوي.
2. اضغط **Download model** — تنزيل يدوي بموافقتك فقط، لا شيء يُنزّل تلقائيًا عند التثبيت أو بدء التشغيل.

سيقوم التطبيق بـ:

- تنزيل المستودع الرسمي `Qwen/Qwen2.5-Coder-14B-Instruct` من Hugging Face إلى
  `models/Qwen2.5-Coder-14B-Instruct/` عبر واجهة Hugging Face Hub الرسمية.
- **استكمال التنزيل** عند انقطاع الإنترنت دون إعادة تنزيل الملفات المكتملة (ملفات `.part`
  تُستأنف من نفس الإزاحة عبر HTTP Range).
- عرض **نسبة التنزيل والسرعة والحجم المتبقي والوقت التقريبي** لكل ملف وللإجمالي.
- **فحص مساحة القرص** قبل البدء ورفض التنزيل برسالة واضحة عند نقص المساحة.
- **التحقق من سلامة الملفات** بعد التنزيل: SHA-256 لكل شِرد safetensors كما نشره المستودع،
  اكتمال كل الشِردات المذكورة في `model.safetensors.index.json`، وجود config.json والـtokenizer.
- عند نجاح التحقق: **كتابة `LOCAL_INFERENCE=true` في `.env` تلقائيًا** وتشغيل محرك الاستدلال
  المحلي داخل نفس العملية، مع إظهار الحالة بوضوح: غير مثبت / جاري التنزيل / متوقف (قابل
  للاستكمال) / جاهز / فشل التحميل مع سبب الفشل وحل مقترح.
- من نفس النافذة يمكنك أيضًا: تحديد **مسار نموذج موجود مسبقًا** واستخدامه، إعادة المحاولة،
  وحذف ملفات النموذج بعد تأكيد صريح.

### الطريقة اليدوية (بديل)

ضع ملفات Qwen2.5-Coder-14B-Instruct كاملة في:

```
models/Qwen2.5-Coder-14B-Instruct/
```

إذا كانت الأوزان عندك كملفات محلية انسخها كما هي. إذا أردت تنزيلها مرة واحدة من Hugging Face:

```bash
source .venv/bin/activate
pip install -U "huggingface_hub[cli]"
hf download Qwen/Qwen2.5-Coder-14B-Instruct --local-dir models/Qwen2.5-Coder-14B-Instruct
```

بعد النسخ أو التنزيل اليدوي اضغط **Verify files** من نافذة Model للتحقق من الاكتمال، أو:

```bash
python scripts/verify_weights.py
```

وفي `.env` فعّل:

```
LOCAL_INFERENCE=true
```

لا تحتاج أي `MODEL_BASE_URL` أو مفتاح API — البوابة تتصل تلقائيًا بالمحرك المحلي.

## 4) التشغيل والإيقاف

```bash
bash scripts/start.sh    # التشغيل + فحص الصحة تلقائيًا
bash scripts/stop.sh     # الإيقاف
```

افتح `http://127.0.0.1:8080` — **لا يوجد تسجيل دخول ولا إنشاء حساب**؛ الواجهة تفتح مباشرة
على مساحة العمل. راقب حالة النموذج من الشريط العلوي:
«Model connected · Qwen2.5-Coder-14B-Instruct · cuda · int4».

## 5) فحص ما قبل التشغيل

```bash
bash scripts/check_requirements.sh
```

يفحص إصدار Python، المكتبات، الأوزان، المنافذ 8080/8100، ورؤية كرت الشاشة.

## 6) فك أي مشكلة

| الرسالة | السبب والحل |
| --- | --- |
| `No safetensors weights found in ...` | الأوزان ليست في `models/<LOCAL_MODEL_NAME>/` — انقل الملفات ثم أعد التشغيل |
| `Local inference needs the model extra ... missing torch` | لم تثبّت الإضافة: `pip install -r requirements-local-model.txt` |
| `LOCAL_MODEL_DEVICE=cuda but no CUDA device is visible` | تعريف NVIDIA غير مثبت أو `nvidia-smi` لا يعمل — راجع `docs/GPU_GUIDE.md` |
| `Local model is still loading` | انتظر حتى يكتمل التحميل وتتبع الحالة: `curl http://127.0.0.1:8100/health` |
| `Model error: ...` في الشريط العلوي | تفاصيل الخطأ كاملة داخل الرسالة نفسها، وغالبًا تبعية ناقصة أو ملف تالف |

## 7) تشغيله كخدمة (systemd — اختياري)

```ini
# /etc/systemd/system/qwen-studio.service
[Unit]
Description=Qwen Studio
After=network.target

[Service]
WorkingDirectory=/opt/qwen-studio
User=qwen
Environment=APP_ENV=development
ExecStart=/opt/qwen-studio/.venv/bin/python -m uvicorn backend.app:app --host 127.0.0.1 --port 8080
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

لاحظ: وضع التطوير هنا لأن المنفذ محلي 127.0.0.1. للنشر العام اتبع قسم الإنتاج في `README.md`
(HTTPS + نطاقات منفصلة + gVisor + `APP_ENV=production`).
