# دليل تشغيل CPU — Qwen Studio

تشغيل المنصة والنموذج بدون كرت شاشة. يعمل، لكن يجب أن تكون توقعاتك واضحة.

## 1) التوقعات الواقعية

| النموذج | الذاكرة المطلوبة | سرعة التوليد التقريبية (خادم حديث 8 أنوية) |
| --- | --- | --- |
| Qwen2.5-Coder-14B-Instruct (bf16) | ~30GB RAM | ~1–3 رمز/ثانية — رد واحد 200 رمز = 1–3 دقائق |
| Qwen2.5-Coder-14B-Instruct (int4 عبر bitsandbytes CPU) | ~10–12GB RAM | ~2–5 رمز/ثانية |
| بدائل أصغر (مثل 7B أو 0.5B) | 15GB / 2GB | أسرع كثيرًا — لكن يجب استبدال النموذج فقط بقرار منك |

**لا يغيّر هذا الدليل النموذج** — الافتراضي يبقى Qwen2.5-Coder-14B-Instruct. إن أردت
نموذجًا آخر ضع ملفاته في مجلد آخر وغيّر `LOCAL_MODEL_NAME` و`LOCAL_MODEL_DIR` فقط.

## 2) الإعدادات في `.env`

```
LOCAL_INFERENCE=true
LOCAL_MODEL_DEVICE=cpu
LOCAL_MODEL_QUANTIZATION=auto    # على CPU يتحول تلقائيًا إلى bf16 بدون ضغط
# لضغط 4-bit على CPU (يتطلب bitsandbytes حديثًا يدعم CPU):
# LOCAL_MODEL_QUANTIZATION=int4
MODEL_MAX_TOKENS=1024            # اختياري: الافتراضي المُصدّر الآن 0=unlimited؛ على CPU قد تفضّل سقفًا أقل لتقصير زمن الردود الطويلة
```

ملاحظات مهمة:
- `LOCAL_MODEL_QUANTIZATION=int8` و`int4` على CPU يعملان عبر bitsandbytes multi-backend:
  تم اختبار التحميل والتوليد فعليًا بنجاح (checkpoint حقيقي Qwen2.5 بحجم 0.5B، بأشكال
  موترات واقعية). ملاحظة: checkpoints بأبعاد صغيرة جدًا قد تفشل داخل bitsandbytes عند
  التوليد بسبب حجم الكتل، وهي حالة لا تخص نموذج 14B. عند تشغيل int8 ستظهر رسائل
  `MatMul8bitLt: inputs will be cast from torch.bfloat16 to float16` — وهي تحويل دقة
  داخلي في bitsandbytes وليس خطأ.
- أداء توليد CPU من 4-bit قد لا يكون أسرع من bf16 على كل الأجهزة — جرّب الاثنين.

## 3) تقليل الاستهلاك

- `MODEL_MAX_TOKENS=512` اختياري (الافتراضي 0=unlimited) لمنع الردود الطويلة جدًا.
- `MAX_CONCURRENT_CHATS=1` يمنع تعدد الطلبات المتزامنة (المحرك يستخدم قفلًا ويخدّم طلبًا واحدًا زمنيًا).
- `LOCAL_MODEL_MAX_CONTEXT_TOKENS=16384` يقلص الذاكرة المستخدمة للسياق الطويل (يظل النموذج نفسه).

## 4) التشغيل

```bash
bash scripts/install.sh --with-model --cpu   # يثبّت نسخة CPU من torch صراحةً (torch==2.6.0) ويتحقق منها
python scripts/check_torch.py --cpu          # PASS  torch works on this machine
bash scripts/check_requirements.sh   # سيخبرك صراحة: "no CUDA GPU visible - the model will run on CPU"
bash scripts/start.sh
```

تنزيل الأوزان إن لم تكن موجودة بعد: زر **Model** في الواجهة ← **Download model** —
تنزيل بموافقتك فقط إلى `models/Qwen2.5-Coder-14B-Instruct/` (استكمال تلقائي عند الانقطاع،
فحص مساحة القرص قبل البدء، تحقق SHA-256 لكل شِرد، ثم تفعيل LOCAL_INFERENCE تلقائيًا بعد
نجاح التحقق). التفاصيل: `models/README.md`.

## 5) متى ينبغي CPU ومتى لا

- مناسب: التجربة، التطوير بدون GPU، أجهزة بذاكرة كبيرة + صبر، مستخدم واحد.
- غير مناسب: أكثر من مستخدم متزامن، ردود فورية، تجربة الإنتاج الفعلية.

## 6) ما اختُبر فعليًا في هذه البيئة

- تحميل bf16 على CPU وإكمال محادثة حقيقية (بمصغّر 0.5B لأسباب ذاكرة بيئة الاختبار) — نجح.
- تحميل int4 على CPU عبر bitsandbytes — نجح.
- إعادة تحقق هذه الجولة (تثبيت حقيقي كامل عبر المثبّت): torch 2.6.0+cpu + transformers
  5.24.1 + bitsandbytes 0.50.2 — المحرك حمّل الأوزان وأجاب عبر `/v1/chat/completions`
  بنجاح، وعمليات bitsandbytes‏ 4-bit على CPU (quantize/dequantize وforward لـ`Linear4bit`)
  اختُبرت بنجاح عند الأبعاد الواقعية.
- مع bitsandbytes ≥ 0.50 قد تظهر على CPU رسالة إعلامية عن `kernels` (حزمة اختيارية لمسار
  matmul المدمج الأسرع) — التحميل والتوليد يعملان بدونها؛ التثبيت الاختياري
  `pip install "kernels>=0.11.1"` يفعّل المسار الأسرع فقط.
- زمن التوليد المذكور أعلاه **تقدير** وليس قياسًا على جهازك — قِسه بأول محادثة.
