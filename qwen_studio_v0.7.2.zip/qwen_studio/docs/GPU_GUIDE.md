# دليل تشغيل GPU — Qwen Studio

تشغيل Qwen2.5-Coder-14B-Instruct على كرت NVIDIA محليًا. كل ما يلي يعمل بدون أي
إنترنت بعد وضع الأوزان مرة واحدة.

## 1) متطلبات كرت الشاشة (VRAM)

أوزان النموذج وحدها بدقة BF16 = 14.7 مليار معامل × 2 بايت ≈ **29.4GB (≈27.4GiB)** — وهذا
لا يشمل CUDA Runtime وKV Cache وActivation Buffers وهامش التشغيل (عدة GiB إضافية بحسب
طول السياق). لذلك يقيس الوضع التلقائي (`auto`) **الذاكرة الحرة فعليًا** عند بدء التحميل
(وليس سعة البطاقة الاسمية)، ويحسب KV Cache من هندسة النموذج وطول
`LOCAL_MODEL_MAX_CONTEXT_TOKENS` ويضيف هامشًا للـRuntime.

| ذاكرة GPU | التوجيه |
| --- | --- |
| 24GB | **INT4 (4-bit NF4) — وليس BF16** (الأوزان ~8GiB + KV Cache) |
| 32GB | BF16 **مشروط** بالذاكرة الحرة وطول السياق — ليس مضمونًا؛ مع السياق الكامل 32K يلجأ التلقائي إلى INT4 |
| 40GB+ | **BF16 هو الخيار الأكثر أمانًا** |
| 10–12GB | INT4 **بشروط** — قد يتطلب تقليل `LOCAL_MODEL_MAX_CONTEXT_TOKENS` (مثلًا 8192) أو offload |
| CPU فقط | تشغيل ممكن حسب RAM (راجع `docs/CPU_GUIDE.md`) — **بطيء جدًا** |

ملاحظات:

- هذه **تقديرات تشغيلية وليست ضمان توافق لكل بطاقة**؛ القرار يقيس الذاكرة الحرة عند
  الإقلاع: BF16 إن اتسع الحجم كاملًا، وإلا INT4، وإن لم يتسع حتى INT4 يفشل برسالة واضحة
  تشرح الحاجة والبديل — **بدون الانتقال الصامت إلى إعداد غير مدعوم**.
- الوضع اليدوي (`bf16`/`fp16`/`int8`/`int4`) يُحترم دائمًا؛ وإن كانت الذاكرة الحرة غير
  كافية ظاهريًا للدقة الكاملة يظهر تحذير في السجل دون منع التحميل.

## 2) تعريف NVIDIA (مرة واحدة)

تأكد أن `nvidia-smi` يعمل ويعرض اسم الكرت. عجلات PyTorch cu124 تأتي بـCUDA Runtime
مدمج، لذا يكفي **درايفر ≥ 525** عبر التوافق الثانوي لـCUDA 12.x (Minor Version
Compatibility — وثائق NVIDIA الرسمية)، بينما يتطلب توافق CUDA 12.4 الكامل درايفر
**≥ 550.54.14 على Linux / ≥ 551.61 على Windows**. عند استخدام Docker ثبّت أيضًا NVIDIA
Container Toolkit على Linux.

## 3) تثبيت torch نسخة CUDA

المسار الأساسي (المثبّت يختار النسخة ويجري الفحص الحقيقي تلقائيًا؛ الإصدار مثبّت على
`torch==2.6.0` — أحدث إصدار منشور رسميًا في فهرس cu124، ويتوافق رسميًا مع
Python 3.11/3.12/3.13 وbitsandbytes وtransformers/accelerate الحالية):

```bash
bash scripts/install.sh --with-model --cuda
```

يفشل التثبيت برسالة واضحة إذا لم يرَ torch الكرت فعليًا (بدون رسالة نجاح زائفة). أو يدويًا:

```bash
source .venv/bin/activate      # ويندوز: .venv\Scripts\activate
pip uninstall -y torch         # إن كانت نسخة CPU مثبتة — لا تترك نسختين متعارضتين
pip install "torch==2.6.0" --index-url https://download.pytorch.org/whl/cu124
pip install -r requirements-local-model.txt   # transformers/accelerate/safetensors/bitsandbytes
python scripts/check_torch.py --cuda --check-model-extra
```

يجب أن ينتهي الفحص بـ `PASS  CUDA mode verified` ويعرض اسم الكرت وسعة VRAM المقاسة.
`torch.cuda.is_available()`
هو الحكم الحقيقي — وجود كرت NVIDIA في الجهاز وحده لا يعني أن CUDA صالحة (الدرايفر
مهم). عند الفشل يطبع الفحص السبب الفعلي: نسخة CPU من torch، أو درايفر مفقود/قديم.

ملاحظة بطاقات Turing (مثل T4 — Compute Capability 7.5): لا تحتوي نوى BF16؛ الفحص
يعرض `bf16 supported : False` والتخطيط التلقائي ينتقل إلى INT4 مع `compute_dtype`
= FP16 تلقائيًا داخل المحرك (engine.py يختار fp16 عندما لا تدعم البطاقة BF16).
وفق وثائق BitsAndBytes الرسمية: يلزم PyTorch 2.4+ وPython 3.10+ وCUDA 11.8+
وCompute Capability ≥ 6.0 لـNF4 و≥ 7.5 لـLLM.int8 — أي أن T4 مدعومة للـINT4/INT8
بينما BF16 الكامل مخصص لبطاقات Ampere وأحدث (40GB+ مقترح).

## 4) الإعدادات في `.env`

```
LOCAL_INFERENCE=true
LOCAL_MODEL_DEVICE=auto          # أو cuda لإجبار GPU
LOCAL_MODEL_QUANTIZATION=auto    # يقيس الذاكرة الحرة عند الإقلاع: bf16 إن اتسع كاملًا، وإلا 4-bit NF4
LOCAL_MODEL_MAX_CONTEXT_TOKENS=32768
```

ثم:

```bash
bash scripts/start.sh            # ويندوز: scripts\start.bat
```

## 5) التحقق

- تنزيل الأوزان إن لم تكن موجودة بعد: زر **Model** في الواجهة ← **Download model** —
  تنزيل بموافقتك فقط إلى `models/Qwen2.5-Coder-14B-Instruct/` (استكمال تلقائي عند
  الانقطاع، فحص مساحة القرص قبل البدء، تحقق SHA-256 لكل شِرد، ثم تفعيل LOCAL_INFERENCE
  تلقائيًا بعد نجاح التحقق). التفاصيل: `models/README.md`.
- الشريط العلوي في الواجهة: «Model connected · Qwen2.5-Coder-14B-Instruct · cuda+bnb · int4».
- برمجيًا:
  ```bash
  curl http://127.0.0.1:8100/health
  # تنتظر: "loaded": true, "device": "cuda+bnb", "quantization": "int4"
  ```
- داخل Docker:
  ```bash
  bash scripts/docker_check.sh app-gpu
  ```
- **قياس كامل قبل الثقة بالنشر (زمن التحميل، المحادثة، توليد الكود، استدعاء الأدوات،
  السياق الطويل، VRAM/RAM، إعادة التشغيل):**
  ```bash
  python scripts/bench_local_model.py \
      --model-dir models/Qwen2.5-Coder-14B-Instruct \
      --model-name Qwen2.5-Coder-14B-Instruct \
      --device auto --quantization auto \
      --json bench-14b.json
  ```
  يُخرج الحكم PASS/FAIL لكل بوابة هيكلية + قياسات فعلية (بما فيها VRAM المستخدمة على
  كرت الشاشة). شغّله أيضًا بعد تغيير `LOCAL_MODEL_QUANTIZATION` لمقارنة الأوضاع.

## 6) Docker مع GPU

```bash
docker compose --profile gpu build \
  --build-arg INSTALL_LOCAL_MODEL=true \
  --build-arg TORCH_INDEX_URL=https://download.pytorch.org/whl/cu124 app-gpu
docker compose --profile gpu up app-gpu
```

المتطلبات على المضيف: NVIDIA Container Toolkit مثبت. تمرير الكرت يحدث تلقائيًا عبر
`deploy.resources.reservations.devices` — لا تضيف `--gpus` يدويًا. ملفات الأوزان تُركَّب
من `./models` للقراءة فقط ولا تُنسخ داخل الصورة.

المنفذ الداخلي للمحرك (8100) لا يُنشر للإنترنت إطلاقًا — فقط 8080 يُنشر مرتبطًا بـ
`127.0.0.1` افتراضيًا، ولا يُمرَّر Docker Socket إلى حاوية التطبيق.

تحققات داخل الحاوية نفسها: بناء الصورة يتضمن `pip check` واختبار استيراد كامل لـ
transformers وtokenizers وregex وsafetensors وaccelerate وsentencepiece وbitsandbytes
وhuggingface_hub — أي أن الصورة لا تُبنى أصلًا إذا كانت الاعتماديات ناقصة. وبعد التشغيل:

```bash
docker compose --profile gpu exec app-gpu python scripts/check_torch.py --cuda
# PASS  CUDA mode verified: torch can see and use the GPU above.
bash scripts/docker_check.sh app-gpu   # الأوزان + torch + حالة المحرك + صحة التطبيق
```

## 7) حل المشاكل

| المشكلة | الحل |
| --- | --- |
| `CUDA out of memory` أثناء التحميل | `LOCAL_MODEL_QUANTIZATION=int4` — وإن استمر، أغلق تطبيقات تستخدم VRAM |
| `torch.cuda.is_available() == False` | نفّذ `python scripts/check_torch.py --cuda` — يطبع السبب الفعلي (نسخة CPU من torch أو درايفر مفقود/قديم) مع خطوات الإصلاح |
| `bitsandbytes` لا يرى الكرت على Linux | ثبّت النسخة الأخيرة: `pip install -U bitsandbytes` وشغّل `python -m bitsandbytes` للتشخيص |
| بطء أول رد | تحميل الأوزان يحصل مرة واحدة عند بدء التشغيل (~1–2 دقيقة) — راقب `/health` |
| `max_memory` انتهى أثناء 4-bit | سقف GPU يُحسب تلقائيًا من الذاكرة الحرة عند الإقلاع؛ إن ظهر الخطأ فالذاكرة لم تكفِ فعليًا: أغلق تطبيقات تستخدم الكرت أو خفّض السياق وأعد التشغيل |

## 8) ما لم يُختبر من هذه البيئة

اختبارات التطوير هنا بدون GPU، لذلك كُتب هذا الدليل من الكود وليس من تجربة قياس.
المسار المحمّل فعليًا واختبارًا: تحميل bf16 على CPU + int4 NF4 عبر bitsandbytes على CPU
+ الدورة الكاملة عبر الـAPI. **اختبار CUDA الفعلي على كرت حقيقي لم يُنفَّذ** — عند أول
تشغيل على كرتك تحقق من `/api/system/status` وأن `device` تبدأ بـ `cuda`.
