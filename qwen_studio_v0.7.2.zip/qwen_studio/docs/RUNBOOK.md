# Qwen Studio operator runbook

## Prerequisites

- Use a dedicated Linux VPS for the app and a dedicated worker/VPS for the Docker Runner. A practical starting point is 2–4 vCPU and 4–8 GB RAM for the app, plus 4–8 vCPU and 8–16 GB RAM for the runner; size higher for concurrent builds. GPU hosting is separate: the app calls a model endpoint and does not make the app/runner VPS a GPU host.
- DNS: `studio.example.com` to the app proxy; `*.preview.example.com` to the preview proxy; `*.sites.example.com` to the publish proxy; the bare `sites.example.com` apex must resolve to the publish proxy and return 404.
- TLS: use DNS-01 wildcard certificates covering `*.preview.example.com` and `*.sites.example.com`; include the bare publish apex in its certificate SANs.
- Set `APP_NET_SUBNET`, `APP_NET_GATEWAY`, and `FORWARDED_ALLOW_IPS` consistently. The gateway must be inside the configured subnet and `FORWARDED_ALLOW_IPS` must trust the actual proxy peer address seen by the app. Verify the actual peer with `docker network inspect` and app diagnostics; do not assume defaults match a custom network.

## Deployment order

Run exactly in this order:

1. `python3 scripts/verify_pins.py`
2. `python3 deploy/preflight.py`
3. `./deploy/deploy.sh`
4. `python3 scripts/smoke_test.py --app-url https://studio.example.com --preview-domain preview.example.com --publish-domain sites.example.com`
5. `python3 scripts/eval_agent.py`

There is no account setup step: the studio serves the single-user workspace as soon as
services start, and the smoke script runs without credentials.

`deploy.sh` also runs the pin verifier; a network-unavailable result is a warning, but a confirmed missing pin is fatal.

## Model serving

Example vLLM launch for Qwen2.5-Coder-14B-Instruct:

```bash
vllm serve Qwen/Qwen2.5-Coder-14B-Instruct \
  --host 10.0.0.10 --port 8000 \
  --enable-auto-tool-choice --tool-call-parser hermes
```

Bind the model endpoint to a private interface/firewall and allow access only from the app host. Never expose the inference endpoint publicly.

## Failure mapping

| Smoke step / preflight failure | Likely cause | Exact checks |
|---|---|---|
| 1. health/version | App down or wrong release | `docker compose ps`; `curl -i http://127.0.0.1:8080/health`; `docker compose logs --tail=100 app` |
| 2. workspace opens without login | Old account UI/endpoints still present or workspace API not open | `grep -rn "api/auth" frontend/ backend/app.py`; `curl -i http://127.0.0.1:8080/api/auth/me` (must be 404); `docker compose logs --tail=100 app` |
| 3. system status / `proxy_headers: suspect` | `FORWARDED_ALLOW_IPS` does not contain the real proxy peer/gateway | `docker network inspect qwen-studio_app-net`; `docker compose logs --tail=200 app` |
| 4. static project create/check/preview/publish (and 4a. preview 502) | Project flow failure, runner unreachable, missing Docker socket, or runner token mismatch | `docker compose ps`; `docker compose logs --tail=200 app sandbox-runner`; `ls -l /var/run/docker.sock` |
| 5. published response / publish origin 404 | Wildcard publish DNS, Host routing, slug, or TLS certificate mismatch | `dig site-test.sites.example.com`; `nginx -T`; `curl -vk https://sites.example.com/` |
| 6. npm publish 409/400 | Verdaccio profile not started, proxy URL/network wrong, or `SANDBOX_ALLOW_NETWORK_INSTALL=false` | `docker compose --profile npm-proxy ps`; `docker compose logs --tail=200 npm-proxy sandbox-runner`; `grep SANDBOX_ .env` |
| 7. model file-writing task | Model endpoint, model name, tool parser, or tool-call quality | `curl -sS "$MODEL_BASE_URL/models"`; `python3 scripts/eval_agent.py`; `docker compose logs --tail=200 app` |
| Preflight: invalid secrets | Missing/short `SANDBOX_RUNNER_TOKEN` | `grep -E '^SANDBOX_RUNNER_TOKEN=' .env` (do not share output) |
| Preflight: remote access enabled | `ALLOW_REMOTE_ACCESS=true` or non-loopback `APP_BIND_ADDRESS` | `grep -E '^(ALLOW_REMOTE_ACCESS|APP_BIND_ADDRESS)=' .env` |
| Startup rejected: non-loopback bind | `APP_BIND_ADDRESS` not loopback without `ALLOW_REMOTE_ACCESS=true` | `grep -E '^(APP_BIND_ADDRESS|ALLOW_REMOTE_ACCESS)=' .env`; keep loopback unless you also add a TLS-authenticating proxy |
| Preflight: host/DNS mismatch | App/preview/publish URLs or domains do not align | `grep -E '^(PUBLIC_BASE_URL|PREVIEW_BASE_URL|PREVIEW_DOMAIN|PUBLISH_BASE_URL|PUBLISH_DOMAIN)=' .env`; `dig studio.example.com; dig x.preview.example.com; dig x.sites.example.com` |
| Preflight: forwarded IP invalid | `FORWARDED_ALLOW_IPS` is broad, invalid, or does not match trusted proxy | `docker network inspect qwen-studio_app-net`; `grep FORWARDED_ALLOW_IPS .env` |
| Preflight: npm registry invalid | Production npm install is not restricted to internal proxy | `grep -E '^(SANDBOX_ALLOW_NETWORK_INSTALL|SANDBOX_NPM_REGISTRY_URL)=' .env`; `docker compose --profile npm-proxy ps` |
| Preflight: shared parent domain | Studio/preview/publish share registrable domain | Review DNS design; use a separately registered domain for preview/publish |

## Backups, logs, and secrets

- Back up the SQLite database under `workspace/` and the published-site data under the configured publish directory. Follow the repository backup scripts/documentation if installed; test restore on a separate host before relying on backups.
- Logs: `docker compose logs -f app sandbox-runner`; Verdaccio: `docker compose logs -f npm-proxy`; Nginx: typically `/var/log/nginx/access.log` and `/var/log/nginx/error.log`.
- Rotate `SANDBOX_RUNNER_TOKEN` in `.env` and in the runner/app service configuration together, then recreate both app and runner (`docker compose up -d --force-recreate app sandbox-runner`).
- After upgrading from a multi-user release, the first app start creates `workspace/qwen_studio.sqlite3.backup-<UTC timestamp>` before migrating the database; keep those backups until you have verified the migrated workspace.

## Known limits

- The Runner holds the Docker socket and must live on a dedicated host; this is effectively host-level privilege.
- In-memory rate limits are per process, not distributed across replicas.
- SQLite is single-instance; do not run multiple app replicas against it.
- The built-in public-suffix list is partial.
- Model quality is unmeasured until `scripts/eval_agent.py` is run against the deployed endpoint.

## Access control (single-user local workspace)

Qwen Studio has no user accounts, sessions, or password recovery because there is nothing to
recover: the app serves one local workspace with no login. The only secret is the internal
`SANDBOX_RUNNER_TOKEN` between the app and the runner. Whoever can reach the app port can use
the workspace, so keep the default loopback binding and, for any network exposure, put an
authenticating TLS reverse proxy and server-level access controls in front of the app.
