# Connecting a model to Qwen Studio

Qwen Studio ships its own **local inference engine** (`inference/engine.py`). With
`LOCAL_INFERENCE=true` the backend loads the operator-supplied `safetensors` weights from
`models/<LOCAL_MODEL_NAME>/` and serves an OpenAI-compatible Chat Completions endpoint on
loopback — no separate model server is needed. Keep the distinction clear:

- **The engine is part of this repository** — it parses tool calls, manages context and
  serves the gateway; nothing extra to install beyond the `requirements-local-model.txt`
  extra (torch/transformers/...).
- **The Qwen weights are NOT part of the package** — you download
  `Qwen2.5-Coder-14B-Instruct` yourself, once, and keep the files on your machine; they
  are never committed to this repository and nothing is fetched at runtime.
- **An external model endpoint is optional** — any independently operated service that
  implements the OpenAI-compatible Chat Completions API with tool calling works through
  the same gateway (see "Serve the model externally" below).

Hardware expectations for the local engine: `docs/GPU_GUIDE.md` (NVIDIA) and
`docs/CPU_GUIDE.md` (CPU only). Install path: `bash scripts/install.sh --with-model --cuda`
or `--cpu` (Windows: `scripts\install.bat --with-model --cuda` / `--cpu`), then verify
with `python scripts/check_torch.py --cuda` / `--cpu`.

## 1. Serve the model externally (optional alternative)

Choose a model whose license permits your intended use, and verify the model card and license for the exact revision. For a compatible vLLM installation, a typical Qwen2.5-Coder-14B-Instruct launch is:

```bash
vllm serve Qwen/Qwen2.5-Coder-14B-Instruct \
  --served-model-name Qwen2.5-Coder-14B-Instruct \
  --enable-auto-tool-choice \
  --tool-call-parser hermes
```

The exact parser flags and hardware requirements depend on the vLLM and model versions. Consult the model card and vLLM documentation, then verify tool calling with a real request before connecting production traffic. The command above is an example, not a hardware guarantee or a claim that inference was tested by this repository.

## 2. Configure Qwen Studio

Set these values in the application `.env`:

```dotenv
MODEL_BASE_URL=https://YOUR-PRIVATE-MODEL-ENDPOINT/v1
MODEL_NAME=Qwen2.5-Coder-14B-Instruct
MODEL_API_KEY=YOUR_MODEL_ENDPOINT_KEY
```

Use the exact served model name. Keep the endpoint private and authenticated; use HTTPS for external endpoints. Never put a real API key in source control, screenshots, issue reports, or client-side frontend code.

For local development only, the model endpoint may be reachable from Compose at `http://host.docker.internal:8000/v1` when the inference server listens on the host and the Compose host-gateway mapping is enabled.

## 3. Verify

1. Start the model server and verify its `/v1/models` endpoint from the Qwen Studio app container/network.
2. Confirm `MODEL_NAME` matches a served model identifier.
3. Send a simple chat request.
4. Test at least one tool call that creates or edits a file in a disposable project.
5. Run `python scripts/eval_agent.py` and review all task results before enabling users.

A successful HTTP connection alone does not prove tool calling or coding quality. Do not advertise a model as supported until the complete evaluation passes on the target model, quantization, serving version, and hardware.

## Model and code licensing are separate

The repository's MIT license applies to this repository's original code. It does not relicense Qwen model weights, tokenizer assets, third-party dependencies, or user-provided content. Check and comply with each model's and dependency's own license and usage terms. Do not copy model weights into this repository unless their license and distribution terms explicitly allow it.
