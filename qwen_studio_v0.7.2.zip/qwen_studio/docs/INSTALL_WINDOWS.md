# دليل تثبيت Windows — Qwen Studio

التثبيت من الصفر على ويندوز 10/11 بدون Docker، مع النموذج المحلي Qwen2.5-Coder-14B-Instruct.

## 1) المتطلبات

1. **Python 3.11+** من [python.org/downloads](https://www.python.org/downloads/).
   أثناء التثبيت فعّل ✅ **"Add python.exe to PATH"** — أهم خطوة في الدليل كله.
2. مساحة حرة: 40GB+ للأوزان والتطبيق.
3. كرت NVIDIA (راجع `docs/GPU_GUIDE.md`) أو CPU فقط (راجع `docs/CPU_GUIDE.md` — بطيء جدًا مع 14B).
4. **CMD فقط للتثبيت** — `install.bat` مكتوب بلغة CMD الخالصة ولا يستدعي PowerShell أبدًا
   (إنشاء `.env` يتم عبر Python المضمّن وجوده بالخطوة 1). ملاحظة: `start.bat` و`stop.bat`
   تستخدمان PowerShell للمساعدات، وهو مضمّن افتراضيًا في ويندوز 10/11 ولا يحتاج تثبيتًا.

## 2) التثبيت

افتح CMD في مجلد المشروع المستخرَج ثم:

```bat
scripts\install.bat --with-model --cuda   & REM كرت NVIDIA: نسخة CUDA من torch + فحص حقيقي
REM أو:
scripts\install.bat --with-model --cpu    & REM بدون كرت: نسخة CPU من torch
REM أو بدون علم: scripts\install.bat --with-model
```

السكربت: ينشئ `.venv`، يثبّت التبعيات + torch **بإصدار مثبّت `torch==2.6.0`** (أحدث إصدار
منشور رسميًا في فهرس cu124، متاح لـPython 3.11–3.13 على ويندوز ولينكس للنسختين) بالنسخة
المطلوبة (CPU أو CUDA cu124 — مع إلغاء تثبيت أي نسخة متعارضة أو معطوبة سابقًا)، يثبّت
`requirements-local-model.txt`، ثم يشغّل **فحصًا حقيقيًا** عبر `scripts\check_torch.py`:
يُستدعى `torch.cuda.is_available()` فعليًا، وعند طلب CUDA دون رؤية الكرت يفشل التثبيت
برسالة واضحة وسبل الإصلاح بدل رسالة نجاح زائفة، ثم ينشئ `.env` بأسرار جاهزة (عبر Python
بدون PowerShell) ويفحص مجلد الأوزان. ملاحظات:

- للتحقق بعد التثبيت في أي وقت:
  ```bat
  python scripts\check_torch.py --cuda
  ```
- إذا فشل فحص CUDA فالسبب غالبًا الدرايفر وليس المثبّت: تأكد أن `nvidia-smi` يعرض الكرت
  وحدّث الدرايفر من موقع NVIDIA، ثم أعد تشغيل المثبّت. تثبيت CPU يبقى متاحًا دائمًا بـ`--cpu`.
- قد يطلب ويندوز السماح لـ python في جدار الحماية عند أول تشغيل — اسمح له على الشبكات الخاصة فقط.

## 3) الأوزان — من داخل التطبيق (الأسهل) أو يدويًا

### الطريقة الأسهل: زر Model داخل التطبيق

شغّل التطبيق (القسم 4) وافتح `http://127.0.0.1:8080` ثم:

1. اضغط زر **Model** في الشريط العلوي.
2. اضغط **Download model** — تنزيل بموافقتك فقط؛ لا شيء يُنزّل تلقائيًا عند التثبيت أو بدء التشغيل.

يقوم التطبيق بتنزيل المستودع الرسمي `Qwen/Qwen2.5-Coder-14B-Instruct` من Hugging Face إلى
`models\Qwen2.5-Coder-14B-Instruct\` مع: **استكمال التنزيل** عند انقطاع الإنترنت دون إعادة
تنزيل الملفات المكتملة، عرض **النسبة والسرعة والحجم المتبقي والوقت التقريبي**، **فحص مساحة
القرص** قبل البدء، **التحقق من سلامة الملفات** بعد التنزيل (SHA-256 لكل شِرد safetensors
كما نشره المستودع + اكتمال شِردات `model.safetensors.index.json` + config.json والـtokenizer)،
ثم عند نجاح التحقق **كتابة `LOCAL_INFERENCE=true` في `.env` تلقائيًا** وتشغيل محرك الاستدلال
المحلي داخل نفس العملية. الحالات معروضة بوضوح: غير مثبت / جاري التنزيل / متوقف (قابل للاستكمال)
/ جاهز / فشل التحميل مع السبب والحل المقترح. من نفس النافذة يمكن تحديد مسار نموذج موجود
مسبقًا، إعادة المحاولة، أو حذف ملفات النموذج بعد تأكيد صريح.

### الطريقة اليدوية (بديل)

ضع ملفات النموذج في:

```
models\Qwen2.5-Coder-14B-Instruct\
```

المطلوب: `config.json` + كل ملفات `*.safetensors` + `model.safetensors.index.json`
+ `tokenizer.json` + `tokenizer_config.json` + `vocab.json` + `merges.txt`.

بعد النسخ أو التنزيل اليدوي تحقق من الاكتمال (أو اضغط **Verify files** من نافذة Model):

```bat
scripts\verify_weights.bat
```

ثم في `.env` فعّل:

```
LOCAL_INFERENCE=true
```

## 4) التشغيل والإيقاف

```bat
scripts\start.bat
scripts\stop.bat
```

افتح `http://127.0.0.1:8080`. الشريط العلوي سيعرض حالة الأوزان: التحميل ثم
«Model connected · Qwen2.5-Coder-14B-Instruct · cuda · int4» عند الجاهزية.

## 5) مشاكل شائعة على ويندوز

| الرسالة / العرض | الحل |
| --- | --- |
| `'python' is not recognized` | لم تُفعّل Add to PATH — أعد تثبيت Python مع تفعيل الخيار |
| `No safetensors weights found` | الملفات ليست في المجلد الصحيح أو ناقصة — شغّل `scripts\verify_weights.bat` |
| `missing torch` | `pip install -r requirements-local-model.txt` داخل `.venv` المفعّلة |
| بطء شديد في الردود | تعمل على CPU — راجع `docs/CPU_GUIDE.md` أو استخدم GPU |
| خطأ `CUDA out of memory` | اختر `LOCAL_MODEL_QUANTIZATION=int4` في `.env` وأعد التشغيل |
| `DLL load failed` عند استيراد torch | ثبّت [Microsoft Visual C++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe) ثم أعد المحاولة |
| المنفذ 8080 مشغول | غيّر `APP_PORT` في `.env` أو أغلق التطبيق الذي يستخدمه |

## 6) ملاحظات

- وضع Windows مدعوم للتشغيل المحلي الفردي. النشر العام (نطاقات، gVisor، Docker) مدعوم على Linux فقط.
- لا تنقل مجلد `models` إلى git — أضفه إلى `.gitignore` (موجود افتراضيًا).
