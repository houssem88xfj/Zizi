#!/usr/bin/env python3
"""Cross-check release version, env docs, API route docs, test count and stale guidance."""
from __future__ import annotations
import re, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def audit(root=ROOT):
    errors=[]
    app=(root/'backend/app.py').read_text(); readme=(root/'README.md').read_text(); change=(root/'CHANGELOG.md').read_text(); val=(root/'VALIDATION.md').read_text(); prod=(root/'PRODUCTION_READINESS.md').read_text()
    versions=re.findall(r'FastAPI\(title="Qwen Studio", version="([\d.]+)"',app)
    health=re.findall(r'"version":\s*"([\d.]+)"',app)
    changelog=re.search(r'^##\s+([\d.]+)',change,re.M)
    docs=[]
    for label,text in [('CHANGELOG',changelog.group(1) if changelog else ''),('VALIDATION',re.search(r'Qwen Studio\s+([\d.]+)',val).group(1) if re.search(r'Qwen Studio\s+([\d.]+)',val) else ''),('README',re.search(r'Qwen Studio\s+v?([\d.]+)',readme).group(1) if re.search(r'Qwen Studio\s+v?([\d.]+)',readme) else '')]: docs.append((label,text))
    expected=versions[0] if versions else ''
    if not expected or health[:1]!=[expected]: errors.append('backend FastAPI and /health versions differ')
    for label,v in docs:
        if v!=expected: errors.append(f'{label} version {v or "missing"} != {expected}')
    env_names=set()
    for path in [root/'backend/config.py',root/'runner/app.py',*list((root/'scripts').glob('*.py'))]:
        if path.exists(): env_names.update(re.findall(r'os\.getenv\(\s*[\'\"]([A-Z][A-Z0-9_]*)',path.read_text()))
    env=(root/'.env.example').read_text() if (root/'.env.example').exists() else ''
    missing=sorted(n for n in env_names if not re.search(rf'^\s*{re.escape(n)}=',env,re.M))
    if missing: errors.append('missing from .env.example: '+', '.join(missing))
    config_section=readme[readme.find('## Configuration'):readme.find('## ',readme.find('## Configuration')+3)] if '## Configuration' in readme else readme
    missing_readme=[n for n in sorted(env_names) if n not in config_section]
    if missing_readme: errors.append('missing from README configuration text: '+', '.join(missing_readme))
    routes=set(re.findall(r'@app\.(?:get|post|put|delete|patch)\(\s*[\'\"]([^\'\"]+)',app))
    api_section=readme.split('## API routes',1)[1].split('\n## ',1)[0] if '## API routes' in readme else ''
    documented=set(re.findall(r'`((?:GET|POST|PUT|DELETE|PATCH)\s+[^`]+)`',api_section))
    actual=set()
    for route in routes:
        method_match=re.search(rf'@app\.(get|post|put|delete|patch)\(\s*[\'\"]{re.escape(route)}',app)
        if method_match: actual.add(f'{method_match.group(1).upper()} {route}')
    # Existing README groups methods on one line; normalize by membership.
    for item in sorted(actual):
        method,path=item.split(' ',1)
        if f'{method} {path}' not in api_section: errors.append('README API routes missing: '+item)
    stale=['/published/{slug}','sandbox allow-scripts','172.17.0.0/16','SANDBOX_ALLOW_NETWORK_INSTALL must stay false in production']
    for token in stale:
        if token.lower() in (readme+'\n'+prod).lower(): errors.append('removed behavior still documented: '+token)
    try:
        out=subprocess.run([sys.executable,'-m','pytest','--collect-only','-q'],cwd=root,text=True,capture_output=True,check=True).stdout
        counts=re.findall(r'(\d+) tests? collected',out)
        count=int(counts[-1]) if counts else None
        quoted=re.findall(r'(?:Final pytest result|pytest result|tests collected|pytest -q.*?):\s*\*\*(\d+)|PASS\s*[—-]\s*(\d+)\s+passed',val,re.I)
        quoted=[a or b for a,b in quoted]
        if count is not None and quoted and any(int(x)!=count for x in quoted): errors.append(f'VALIDATION test count {quoted[-1]} != collected {count}')
        elif count is not None and not quoted: errors.append(f'VALIDATION.md must quote collected test count ({count})')
    except Exception as exc: errors.append(f'could not collect pytest tests: {exc}')
    return errors
if __name__=='__main__':
    issues=audit()
    if issues:
        print('Consistency check failed:'); print('\n'.join('- '+x for x in issues)); raise SystemExit(1)
    print('Consistency check passed.')
