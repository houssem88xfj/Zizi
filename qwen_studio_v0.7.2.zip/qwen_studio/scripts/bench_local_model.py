#!/usr/bin/env python3
"""Benchmark harness for the local weights inference engine.

Runs the REAL production engine (`inference.engine.LocalModelEngine`) against a
local safetensors checkpoint and measures load time, chat quality signals, code
generation, function/tool calling, malformed-response handling, long context,
memory usage and engine restart - the full pre-release checklist for local
inference.

This script does NOT fake results: every check reports what actually happened,
and quality checks are recorded as measurements, not hard-coded passes. Run it
on the GPU host with the real Qwen2.5-Coder-14B-Instruct weights:

    python scripts/bench_local_model.py \
        --model-dir models/Qwen2.5-Coder-14B-Instruct \
        --model-name Qwen2.5-Coder-14B-Instruct \
        --device auto --quantization auto \
        --json bench-results.json

On a CPU-only machine it still runs (smaller models, slower); the report states
the device it actually used.

Exit code 0 = all structural gates passed, 1 = at least one gate failed.
"""
from __future__ import annotations

import argparse
import json
import os
import resource
import sys
import time
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO))

from inference.engine import EngineNotAvailable, EngineNotReady, LocalModelEngine  # noqa: E402


def gpu_report() -> dict[str, Any]:
    """Detect NVIDIA GPU / CUDA without assuming either exists."""
    report: dict[str, Any] = {"torch_cuda_available": False, "gpu_name": None}
    try:
        import torch
        report["torch_version"] = torch.__version__
        report["torch_cuda_available"] = bool(torch.cuda.is_available())
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            report["gpu_name"] = props.name
            report["gpu_vram_gib"] = round(props.total_memory / 1024**3, 1)
            report["bf16_supported"] = bool(torch.cuda.is_bf16_supported())
    except Exception as exc:  # noqa: BLE001
        report["error"] = str(exc)
    return report


def peak_ram_mib() -> float:
    """Peak resident RAM of this process (Linux reports ru_maxrss in KiB)."""
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return round(usage.ru_maxrss / 1024.0, 1)


def run_chat(engine: LocalModelEngine, payload: dict[str, Any], label: str,
             started: float | None = None) -> dict[str, Any]:
    """Send one payload through the engine and record timing + shape of the reply."""
    if started is None:
        started = time.monotonic()
    try:
        response = engine.chat_completion(payload)
        elapsed = round(time.monotonic() - started, 2)
        choice = response["choices"][0]
        message = choice["message"]
        tool_calls = message.get("tool_calls") or []
        parsed_args = []
        for call in tool_calls:
            try:
                parsed_args.append(json.loads(call["function"]["arguments"]))
            except (json.JSONDecodeError, KeyError):
                parsed_args.append(None)
        return {
            "test": label,
            "ok": True,
            "finish_reason": choice.get("finish_reason"),
            "content_preview": (message.get("content") or "")[:160],
            "content_len": len(message.get("content") or ""),
            "tool_calls": [
                {"name": c.get("function", {}).get("name"), "arguments_valid": a is not None}
                for c, a in zip(tool_calls, parsed_args)
            ],
            "malformed_tool_call": (response.get("local_inference") or {}).get("malformed_tool_call"),
            "usage": response.get("usage"),
            "elapsed_s": elapsed,
        }
    except Exception as exc:  # noqa: BLE001
        return {"test": label, "ok": False, "error": f"{type(exc).__name__}: {exc}"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--model-name", default=None)
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--quantization", default="auto",
                        choices=["auto", "none", "bf16", "fp16", "int8", "int4"])
    parser.add_argument("--max-context-tokens", type=int, default=32768)
    parser.add_argument("--max-new-tokens", type=int, default=256)
    parser.add_argument("--long-context-tokens", type=int, default=3000,
                        help="approximate prompt size for the long-context test")
    parser.add_argument("--skip-restart", action="store_true")
    parser.add_argument("--json", dest="json_out", default=None)
    args = parser.parse_args()

    model_dir = Path(args.model_dir).expanduser().resolve()
    model_name = args.model_name or model_dir.name
    results: dict[str, Any] = {
        "harness": "scripts/bench_local_model.py",
        "model_name": model_name,
        "model_dir": str(model_dir),
        "requested_device": args.device,
        "requested_quantization": args.quantization,
    }
    gates: list[bool] = []

    # 0. environment / GPU detection ------------------------------------
    gpu = gpu_report()
    results["environment"] = gpu
    results["peak_ram_mib"] = peak_ram_mib()
    print(f"[env] torch={gpu.get('torch_version')} cuda={gpu.get('torch_cuda_available')} "
          f"gpu={gpu.get('gpu_name')} vram={gpu.get('gpu_vram_gib')}GiB ram_peak={results['peak_ram_mib']}MiB")
    gates.append(True)

    # 1. weights present -------------------------------------------------
    engine = LocalModelEngine(
        model_dir,
        model_name=model_name,
        device=args.device,
        quantization=args.quantization,
        max_context_tokens=args.max_context_tokens,
        max_new_tokens_cap=max(args.max_new_tokens, 256),
    )
    weights_ok = engine.weights_present()
    results["weights_present"] = weights_ok
    print(f"[weights] present={weights_ok} dir={model_dir}")
    if not weights_ok:
        results["verdict"] = "FAIL (weights missing - run scripts/verify_weights.py first)"
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return 1
    gates.append(True)

    # 2. load from local path (timed) ------------------------------------
    load_started = time.monotonic()
    engine.begin_load()
    load_error: str | None = None
    try:
        engine.wait_until_ready(timeout=1800)
    except (EngineNotAvailable, EngineNotReady) as exc:
        load_error = str(exc)
    load_elapsed = round(time.monotonic() - load_started, 1)
    results["load"] = {"elapsed_s": load_elapsed, "error": load_error,
                       "status": engine.status}
    print(f"[load] {load_elapsed}s device={engine.status['device']} "
          f"quantization={engine.status['quantization']} error={load_error}")
    gates.append(load_error is None)
    if load_error:
        results["verdict"] = "FAIL (model failed to load)"
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return 1

    def chat_payload(content: str, *, tools: list | None = None,
                     max_tokens: int | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "messages": [{"role": "user", "content": content}],
            "temperature": 0.2,
            "max_tokens": max_tokens or args.max_new_tokens,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        return payload

    # 3. plain chat --------------------------------------------------------
    results["chat"] = run_chat(engine, chat_payload("What is a Python variable? Answer in one short sentence."), "plain-chat")
    gates.append(results["chat"]["ok"])
    print(f"[chat] {results['chat'].get('elapsed_s')}s -> {results['chat'].get('content_preview', results['chat'].get('error'))[:100]}")

    # 4. code generation ----------------------------------------------------
    results["codegen"] = run_chat(engine, chat_payload("Write a Python function is_prime(n). Reply with code only."), "code-gen")
    code = results["codegen"].get("content_preview", "")
    has_code = results["codegen"]["ok"] and ("def " in results["codegen"].get("content_preview", "") or results["codegen"].get("content_len", 0) > 0)
    results["codegen"]["contains_def"] = "def " in results["codegen"].get("content_preview", "") or False
    print(f"[codegen] {results['codegen'].get('elapsed_s')}s def_found={results['codegen']['contains_def']} preview={code[:80]!r}")
    gates.append(results["codegen"]["ok"])

    # 5. function calling ----------------------------------------------------
    weather_tools = [{"type": "function", "function": {
        "name": "get_weather",
        "description": "Get current weather for a city",
        "parameters": {"type": "object", "properties": {"city": {"type": "string"}},
                       "required": ["city"]}}}]
    results["function_calling"] = run_chat(
        engine, chat_payload("What is the weather in Riyadh? Use the get_weather tool.", tools=weather_tools),
        "function-calling")
    fc = results["function_calling"]
    fc_structural_ok = fc["ok"] and (
        bool(fc.get("tool_calls")) or (fc.get("content_len") or 0) > 0
    )
    print(f"[function-calling] finish={fc.get('finish_reason')} tool_calls={fc.get('tool_calls')}")
    gates.append(fc_structural_ok)

    # 6. agent-style tool call (write_file) ----------------------------------
    agent_tools = [{"type": "function", "function": {
        "name": "write_file",
        "description": "Create or overwrite a file inside the project",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "relative file path"},
            "content": {"type": "string", "description": "full file content"}},
            "required": ["path", "content"]}}}]
    results["agent_tool_call"] = run_chat(
        engine, chat_payload(
            "Create a file named hello.py containing exactly: print('hello'). Use the write_file tool.",
            tools=agent_tools),
        "agent-tool-call")
    at = results["agent_tool_call"]
    print(f"[agent-tool-call] finish={at.get('finish_reason')} tool_calls={at.get('tool_calls')}")
    gates.append(at["ok"])

    # 7. malformed / invalid response handling --------------------------------
    malformed_history = {
        "messages": [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "call_bad", "type": "function",
                             "function": {"name": "write_file", "arguments": "{not valid json"}}]},
            {"role": "tool", "tool_call_id": "call_bad", "content": "stored"},
        ],
        "temperature": 0.2,
        "max_tokens": min(args.max_new_tokens, 64),
    }
    results["malformed_history"] = run_chat(engine, malformed_history, "malformed-history")
    gates.append(results["malformed_history"]["ok"])
    try:
        engine.chat_completion({"messages": [{"role": "user", "content": "x"}], "stream": True, "max_tokens": 8})
        stream_rejected = False
    except ValueError:
        stream_rejected = True
    except Exception:  # noqa: BLE001
        stream_rejected = False
    results["stream_rejected_cleanly"] = stream_rejected
    print(f"[invalid] malformed_history ok={results['malformed_history']['ok']} "
          f"stream_rejected={stream_rejected}")
    gates.append(stream_rejected)

    # 8. long context -----------------------------------------------------------
    filler = "Remember rule %d: keep answers focused on the requested file.\n" * 1
    long_text = "".join(f"Rule {i}: keep answers focused on the requested file.\n"
                        for i in range(args.long_context_tokens // 10))
    long_prompt = f"Below are {args.long_context_tokens // 10} numbered rules.\n{long_text}\nWhat is rule number 3? Quote it."
    results["long_context"] = run_chat(engine, chat_payload(long_prompt, max_tokens=min(args.max_new_tokens, 128)),
                                       "long-context")
    lc = results["long_context"]
    prompt_tokens = (lc.get("usage") or {}).get("prompt_tokens", 0)
    print(f"[long-context] prompt_tokens={prompt_tokens} elapsed={lc.get('elapsed_s')}s ok={lc['ok']}")
    gates.append(lc["ok"])

    # 9. memory after all work ----------------------------------------------------
    results["peak_ram_mib_final"] = peak_ram_mib()
    if gpu["torch_cuda_available"]:
        try:
            import torch
            results["vram_allocated_mib"] = round(torch.cuda.memory_allocated() / 1024**2, 1)
            results["vram_reserved_mib"] = round(torch.cuda.memory_reserved() / 1024**2, 1)
        except Exception:  # noqa: BLE001
            pass
    print(f"[memory] ram_peak={results['peak_ram_mib_final']}MiB "
          f"vram_alloc={results.get('vram_allocated_mib')} vram_reserved={results.get('vram_reserved_mib')}")

    # 10. engine restart ------------------------------------------------------------
    if not args.skip_restart:
        restart = LocalModelEngine(
            model_dir, model_name=model_name, device=args.device,
            quantization=args.quantization, max_context_tokens=args.max_context_tokens,
            max_new_tokens_cap=max(args.max_new_tokens, 256),
        )
        restart.begin_load()
        restart_error: str | None = None
        try:
            restart.wait_until_ready(timeout=1800)
            probe = restart.chat_completion({"messages": [{"role": "user", "content": "Reply with OK."}],
                                             "temperature": 0.0, "max_tokens": min(args.max_new_tokens, 16)})
            restart_ok = probe["choices"][0]["message"]["role"] == "assistant"
        except Exception as exc:  # noqa: BLE001
            restart_error = str(exc)
            restart_ok = False
        results["restart"] = {"ok": restart_ok, "error": restart_error}
        print(f"[restart] ok={restart_ok} error={restart_error}")
        gates.append(restart_ok)

    results["gates_passed"] = sum(1 for g in gates if g)
    results["gates_total"] = len(gates)
    results["verdict"] = "PASS" if all(gates) else "FAIL"
    print(json.dumps({k: results[k] for k in ("verdict", "gates_passed", "gates_total")}, indent=2))

    if args.json_out:
        Path(args.json_out).write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"results written to {args.json_out}")
    return 0 if all(gates) else 1


if __name__ == "__main__":
    raise SystemExit(main())
