#!/usr/bin/env python3
"""Validate release dotfiles and reject runtime/test artifacts from an archive tree."""
from __future__ import annotations

import os
import sys
from pathlib import Path

REQUIRED_DOTFILES = (".env.example", ".gitignore", ".gitattributes", ".dockerignore")

# Model weight binaries are downloaded by the in-app Model Manager and must
# never ship inside a release archive. Only models/README.md is allowed there.
WEIGHT_SUFFIXES = (".safetensors", ".bin", ".gguf", ".ckpt", ".pt", ".pth", ".onnx")


def missing_release_files(root: Path) -> list[str]:
    return [name for name in REQUIRED_DOTFILES if not (root / name).is_file()]


def release_issues(root: Path) -> list[str]:
    issues = [f"missing required file: {name}" for name in missing_release_files(root)]
    workspace = root / "workspace"
    if workspace.exists():
        for item in workspace.rglob("*"):
            rel_workspace = item.relative_to(workspace).as_posix()
            if rel_workspace == ".gitkeep" and item.is_file():
                continue
            if item.is_file() or item.is_dir():
                issues.append(f"runtime workspace data: {item.relative_to(root).as_posix()}")
    for item in root.rglob("*"):
        if not item.is_file() and not item.is_dir():
            continue
        rel = item.relative_to(root).as_posix()
        name = item.name
        if name == ".env":
            issues.append(f"environment secret file: {rel}")
        if ".runtime" in rel.split(os.sep):
            issues.append(f"runtime log/state directory: {rel}")
        if name.endswith((".sqlite3", ".sqlite3-wal", ".sqlite3-shm")):
            issues.append(f"runtime database file: {rel}")
        if name in {"__pycache__", ".pytest_cache"} and item.is_dir():
            issues.append(f"test/runtime cache directory: {rel}/")
        if name.endswith(".zip") and item.is_file():
            issues.append(f"archive nested in release tree: {rel}")
        if name == "backups" and item.is_dir():
            issues.append(f"backup directory: {rel}/")
        if name.endswith(WEIGHT_SUFFIXES) and item.is_file():
            issues.append(f"model weight file shipped in release tree: {rel}")
        if item.is_file() and rel.startswith("models/") and rel != "models/README.md":
            issues.append(f"model artefact other than models/README.md: {rel}")
        if item.is_dir() and item.name == ".venv":
            issues.append(f"virtualenv directory: {rel}/")
    return sorted(set(issues))


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
    issues = release_issues(root)
    if issues:
        print(f"Release packaging check failed for {root}:")
        for issue in issues:
            print(f" - {issue}")
        return 2
    print(f"Release packaging check passed: {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
