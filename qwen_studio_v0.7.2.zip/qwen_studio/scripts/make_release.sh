#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

bash "$ROOT/scripts/verify_all.sh"

VERSION="$(python3 - <<'PY'
import re
from pathlib import Path
source = Path('backend/app.py').read_text(encoding='utf-8')
match = re.search(r'FastAPI\(title="Qwen Studio", version="([0-9]+\.[0-9]+\.[0-9]+)"', source)
if not match:
    raise SystemExit('Could not determine Qwen Studio version from backend/app.py')
print(match.group(1))
PY
)"
OUTPUT_DIR="${OUTPUT_DIR:-$(dirname "$ROOT")}"
mkdir -p "$OUTPUT_DIR"
OUTPUT_DIR="$(cd "$OUTPUT_DIR" && pwd)"
case "$OUTPUT_DIR/" in
  "$ROOT/"*) echo "OUTPUT_DIR must be outside the repository tree." >&2; exit 2 ;;
esac
ARCHIVE="$OUTPUT_DIR/qwen_studio_v${VERSION}.zip"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
STAGED="$TMP/qwen_studio"
mkdir -p "$STAGED"

if git -C "$ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if [[ -n "$(git -C "$ROOT" status --porcelain)" ]]; then
    echo "Refusing git archive from a dirty worktree. Commit all release changes first." >&2
    exit 2
  fi
  git -C "$ROOT" archive --format=tar HEAD | tar -xf - -C "$STAGED"
else
  command -v zip >/dev/null 2>&1 || { echo "zip is required." >&2; exit 1; }
  command -v unzip >/dev/null 2>&1 || { echo "unzip is required." >&2; exit 1; }
  SOURCE_ZIP="$TMP/source.zip"
  (
    cd "$ROOT"
    zip -q -r "$SOURCE_ZIP" . \
      -x '.git/*' '*/.git/*' \
         '.env' '*/.env' \
         'workspace/*' '*/workspace/*' \
         '.runtime/*' '*/.runtime/*' \
         '*.sqlite3' '*.sqlite3-wal' '*.sqlite3-shm' \
         '__pycache__/*' '*/__pycache__/*' \
         '.pytest_cache/*' '*/.pytest_cache/*' \
         '.venv/*' '*/.venv/*' \
         'models/*' '*/models/*' \
         '*.safetensors' '*.bin' '*.gguf' '*.ckpt' '*.pt' '*.pth' '*.onnx' \
         '*.zip' 'backups/*' '*/backups/*'
    if [[ -f workspace/.gitkeep ]]; then
      zip -q "$SOURCE_ZIP" workspace/.gitkeep
    fi
    if [[ -f models/README.md ]]; then
      zip -q "$SOURCE_ZIP" models/README.md
    fi
  )
  unzip -q "$SOURCE_ZIP" -d "$STAGED"
fi

# Keep the empty workspace marker but never carry runtime workspace state.
mkdir -p "$STAGED/workspace"
find "$STAGED/workspace" -mindepth 1 -maxdepth 1 ! -name .gitkeep -exec rm -rf {} +
[[ -f "$STAGED/workspace/.gitkeep" ]] || : > "$STAGED/workspace/.gitkeep"

python3 "$STAGED/scripts/check_release.py" "$STAGED"
rm -f "$ARCHIVE"
(
  cd "$TMP"
  zip -q -r "$ARCHIVE" qwen_studio
)
echo "Created $ARCHIVE"
echo "Archive contents:"
unzip -Z1 "$ARCHIVE"
echo "Archive size: $(du -h "$ARCHIVE" | awk '{print $1}')"
