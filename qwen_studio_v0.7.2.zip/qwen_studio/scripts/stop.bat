@echo off
REM Stop Qwen Studio on Windows.
cd /d "%~dp0.."
set FOUND=0
if exist .runtime\qwen-studio.pid (
  for /f %%p in (.runtime\qwen-studio.pid) do (
    tasklist /fi "pid eq %%p" 2>nul | find "%%p" >nul && (
      taskkill /pid %%p /f >nul 2>nul
      echo Stopped Qwen Studio (PID %%p^).
      set FOUND=1
    )
  )
  del .runtime\qwen-studio.pid 2>nul
)
REM The PowerShell child process cannot set cmd variables; it reports through a sentinel file.
if exist .runtime\stop-found.tmp del .runtime\stop-found.tmp 2>nul
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name like 'python%%'\" | Where-Object {$_.CommandLine -match 'uvicorn backend.app'} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force; Write-Host ('Stopped uvicorn PID ' + $_.ProcessId); New-Item -ItemType File -Path '.runtime/stop-found.tmp' -Force | Out-Null }" 2>nul
if exist .runtime\stop-found.tmp ( set FOUND=1 & del .runtime\stop-found.tmp 2>nul )
if "%FOUND%"=="0" echo Qwen Studio was not running.
