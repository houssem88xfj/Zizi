#!/usr/bin/env python3
"""Operator-run smoke test for a live Qwen Studio deployment (stdlib only).

Qwen Studio is a single-user local workspace: there are no accounts, logins or
session cookies, so this script verifies that the API and workspace flows work
directly without any authentication step.
"""
from __future__ import annotations

import argparse
import json
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


REPO_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ID_RE = re.compile(r"^[a-f0-9]{32}$")
SITE_SLUG_RE = re.compile(r"^site-[a-f0-9]{32}$")

# Must exceed the 20 s sandbox_client.fetch_preview timeout and normal API waits.
TIMEOUT_DEFAULT = 20
# sandbox_client.run_project_check waits up to 720 s for the Runner (staging +
# an operator-raised SANDBOX_TIMEOUT_SECONDS up to 600 s).
TIMEOUT_RUN = 760
# sandbox_client.start_project_preview waits up to 520 s for the Runner.
TIMEOUT_PREVIEW_START = 560
# Static publish copies an existing tree (no Runner build); npm's 520 s static build
# is covered separately by TIMEOUT_PUBLISH_NPM.
TIMEOUT_PUBLISH_STATIC = 120
# sandbox_client.build_static_project waits up to 520 s for the Runner.
TIMEOUT_PUBLISH_NPM = 760
# sandbox_client.stop_project_preview waits up to 30 s; project deletion may stop it too.
TIMEOUT_STOP_DELETE = 60
# backend/agent.py configures the model client with a 120 s request timeout.
TIMEOUT_CHAT = 200
# sandbox_client.fetch_preview waits up to 20 s for the Runner.
TIMEOUT_SITE_FETCH = 30


class SmokeFailure(RuntimeError):
    pass


@dataclass
class HTTPResult:
    status: int
    headers: object
    body: bytes

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self) -> object:
        return json.loads(self.body)


def _headers_all(headers: object, name: str) -> list[str]:
    get_all = getattr(headers, "get_all", None) or getattr(headers, "get_all_comma_separated_values", None)
    if get_all is not None:
        values = get_all(name) or []
        return list(values)
    value = headers.get(name)
    return [value] if value else []


class SmokeRunner:
    def __init__(
        self,
        app_url: str,
        preview_domain: str,
        publish_domain: str,
        *,
        skip_model: bool = False,
        skip_npm: bool = False,
        insecure_local: bool = False,
        reporter: Callable[[str, str, str], None] | None = None,
        expected_version: str | None = None,
        opener=None,
    ) -> None:
        parsed = urllib.parse.urlsplit(app_url.rstrip("/"))
        if not parsed.hostname or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise ValueError("--app-url must be an origin, for example https://studio.example.com")
        if parsed.scheme not in {"https", "http"}:
            raise ValueError("--app-url must use HTTPS")
        if parsed.scheme == "http":
            if not insecure_local:
                raise ValueError("HTTP is allowed only with --insecure-local")
            if parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
                raise ValueError("--insecure-local permits HTTP only for localhost/loopback app URLs")
        self.app_url = app_url.rstrip("/")
        self.app_origin = f"{parsed.scheme}://{parsed.netloc}"
        self.app_host = parsed.hostname
        self.scheme = parsed.scheme
        self.preview_domain = preview_domain.strip().lower().rstrip(".")
        self.publish_domain = publish_domain.strip().lower().rstrip(".")
        if not self.preview_domain or not self.publish_domain:
            raise ValueError("--preview-domain and --publish-domain must be bare hostnames")
        self.skip_model = skip_model
        self.skip_npm = skip_npm
        self.insecure_local = insecure_local
        self.expected_version = expected_version or expected_release_version()
        self.opener = opener or urllib.request.build_opener()
        self.reporter = reporter or self._print_report
        self.results: list[tuple[str, str, str]] = []
        self.projects: list[str] = []
        self.preview_projects: set[str] = set()
        self.sleep: Callable[[float], None] = time.sleep

    @staticmethod
    def _print_report(label: str, status: str, reason: str) -> None:
        print(f"{status:<4} {label}: {reason}")

    def report(self, label: str, status: str, reason: str) -> None:
        self.results.append((label, status, reason))
        self.reporter(label, status, reason)

    def check(self, label: str, function: Callable[[], str]) -> bool:
        try:
            reason = function()
        except Exception as exc:
            reason = str(exc).splitlines()[0][:240] or exc.__class__.__name__
            self.report(label, "FAIL", reason)
            return False
        self.report(label, "PASS", reason)
        return True

    def skip(self, label: str, reason: str) -> None:
        self.report(label, "SKIP", reason)

    @staticmethod
    def _is_timeout_error(exc: BaseException) -> bool:
        if isinstance(exc, (TimeoutError, socket.timeout)):
            return True
        if isinstance(exc, urllib.error.URLError):
            reason = getattr(exc, "reason", exc)
            return isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower()
        return False

    def request(self, method: str, url: str, payload=None, headers=None, *, timeout: float) -> HTTPResult:
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        request_headers = {"Accept": "application/json, text/html;q=0.9, */*;q=0.8"}
        if body is not None:
            request_headers["Content-Type"] = "application/json"
        if headers:
            request_headers.update(headers)
        request = urllib.request.Request(url, data=body, headers=request_headers, method=method)
        method = method.upper()
        path = urllib.parse.urlsplit(url).path or "/"
        attempts = 2 if method == "GET" else 1
        for attempt in range(attempts):
            try:
                try:
                    response = self.opener.open(request, timeout=timeout)
                except urllib.error.HTTPError as http_response:
                    response = http_response
                with response:
                    status = getattr(response, "status", getattr(response, "code", 200))
                    return HTTPResult(status, response.headers, response.read())
            except (TimeoutError, socket.timeout, urllib.error.URLError) as exc:
                if not self._is_timeout_error(exc):
                    reason = getattr(exc, "reason", exc)
                    host = urllib.parse.urlsplit(url).hostname
                    raise SmokeFailure(f"request failed for {host}: {reason}") from exc
                if method == "GET" and attempt == 0:
                    continue
                raise SmokeFailure(
                    f"{method} {path} timed out after {timeout:g} s "
                    "(server may still be working; check runner logs)"
                ) from exc
        raise AssertionError("unreachable request retry state")

    def _resolve_wildcard_host(self, hostname: str, kind: str) -> None:
        port = 443 if self.scheme == "https" else 80
        try:
            socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
        except OSError as exc:
            wildcard = self.preview_domain if kind == "preview" else self.publish_domain
            raise SmokeFailure(
                f"{kind} hostname {hostname} does not resolve; configure wildcard DNS *.{wildcard}"
            ) from exc

    def check_health(self) -> str:
        response = self.request("GET", self.app_origin + "/health", timeout=TIMEOUT_DEFAULT)
        if response.status != 200:
            raise SmokeFailure(f"GET /health returned HTTP {response.status}")
        data = response.json()
        if data.get("status") != "ok" or data.get("version") != self.expected_version:
            raise SmokeFailure(
                f"health mismatch: status={data.get('status')!r}, version={data.get('version')!r}; "
                f"expected {self.expected_version}"
            )
        return f"health is ok; version {self.expected_version}"

    def check_workspace_opens_without_login(self) -> str:
        """The studio UI and API must work with no sign-in step and no account endpoints."""
        page = self.request("GET", self.app_origin + "/", timeout=TIMEOUT_DEFAULT)
        if page.status != 200:
            raise SmokeFailure(f"GET / returned HTTP {page.status}")
        lowered = page.text.lower()
        for marker in ("auth-form", "auth-screen", "sign in", "create an account", "logout"):
            if marker in lowered:
                raise SmokeFailure(f"index.html still contains account UI: {marker!r}")
        for route in ("/api/auth/config", "/api/auth/me", "/api/auth/login", "/api/auth/logout", "/api/auth/register"):
            response = self.request("GET", self.app_origin + route, timeout=TIMEOUT_DEFAULT)
            if response.status != 404:
                raise SmokeFailure(f"{route} returned HTTP {response.status}, expected 404 (removed)")
        usage = self.request("GET", self.app_origin + "/api/usage", timeout=TIMEOUT_DEFAULT)
        if usage.status != 200:
            raise SmokeFailure(f"/api/usage returned HTTP {usage.status}; the workspace API is not open")
        projects = self.request("GET", self.app_origin + "/api/projects", timeout=TIMEOUT_DEFAULT)
        if projects.status != 200:
            raise SmokeFailure(f"/api/projects returned HTTP {projects.status}; the workspace API is not open")
        return "studio UI and workspace API respond directly; account endpoints are removed"

    def check_system_status(self) -> str:
        response = self.request("GET", self.app_origin + "/api/system/status", timeout=TIMEOUT_DEFAULT)
        if response.status != 200:
            raise SmokeFailure(f"system status returned HTTP {response.status}")
        data = response.json()
        if not data.get("sandbox", {}).get("connected"):
            raise SmokeFailure("sandbox.connected is not true")
        if not self.skip_model and not data.get("model", {}).get("connected"):
            raise SmokeFailure("model.connected is not true")
        if data.get("proxy_headers") != "ok":
            raise SmokeFailure(f"proxy_headers is {data.get('proxy_headers')!r}, expected 'ok'")
        return "sandbox connected; proxy headers ok" + ("; model check skipped" if self.skip_model else "; model connected")

    def check_site_response(self, url: str, expected_marker: str, label: str = "site") -> str:
        host = urllib.parse.urlsplit(url).hostname or "unknown"
        self._resolve_wildcard_host(host, "preview" if self.preview_domain in host else "publish")
        response = self.request("GET", url, timeout=TIMEOUT_SITE_FETCH)
        if response.status != 200:
            raise SmokeFailure(f"{label} returned HTTP {response.status}")
        if expected_marker not in response.text:
            raise SmokeFailure(f"{label} response did not contain expected HTML marker")
        if _headers_all(response.headers, "Set-Cookie"):
            raise SmokeFailure(f"{label} response unexpectedly set an application cookie")
        csp = response.headers.get("Content-Security-Policy", "")
        if "sandbox" in csp.lower():
            raise SmokeFailure(f"{label} CSP unexpectedly contains sandbox")
        return f"{label} returned expected HTML without cookies or sandbox CSP"

    def check_published_root_404(self) -> str:
        response = self.request("GET", f"{self.scheme}://{self.publish_domain}/", timeout=TIMEOUT_DEFAULT)
        if response.status != 404:
            raise SmokeFailure(f"bare publish domain returned HTTP {response.status}, expected 404")
        return "bare publish domain returns 404"

    def check_old_published_path_404(self, slug: str) -> str:
        response = self.request("GET", f"{self.app_origin}/published/{slug}/", timeout=TIMEOUT_DEFAULT)
        if response.status != 404:
            raise SmokeFailure(f"legacy app-host publish path returned HTTP {response.status}, expected 404")
        return "legacy path-based publish URL returns 404"

    def _create_project(self, name: str) -> str:
        response = self.request("POST", self.app_origin + "/api/projects",
                                {"name": name, "description": "Automated deployment smoke test"}, timeout=TIMEOUT_DEFAULT)
        if response.status != 201:
            raise SmokeFailure(f"project creation returned HTTP {response.status}")
        project_id = str(response.json().get("id", ""))
        if not PROJECT_ID_RE.fullmatch(project_id):
            raise SmokeFailure("project creation did not return a valid project id")
        self.projects.append(project_id)
        return project_id

    def _put_file(self, project_id: str, path: str, content: str) -> None:
        response = self.request("PUT", f"{self.app_origin}/api/projects/{project_id}/file",
                                {"path": path, "content": content}, timeout=TIMEOUT_DEFAULT)
        if response.status != 200:
            raise SmokeFailure(f"writing {path} returned HTTP {response.status}")

    def _get_file(self, project_id: str, path: str) -> str:
        query = urllib.parse.urlencode({"path": path})
        response = self.request("GET", f"{self.app_origin}/api/projects/{project_id}/file?{query}", timeout=TIMEOUT_DEFAULT)
        if response.status != 200:
            raise SmokeFailure(f"reading {path} returned HTTP {response.status}")
        return str(response.json().get("content", ""))

    def check_static_project_preview_publish(self) -> tuple[str, str, str]:
        project_id = self._create_project("smoke-test-static")
        marker = "QWEN_STUDIO_STATIC_SMOKE_OK"
        self._put_file(project_id, "index.html", f"<!doctype html><title>Smoke</title><h1>{marker}</h1>")
        run = self.request("POST", f"{self.app_origin}/api/projects/{project_id}/run", {"check": "python_compile"}, timeout=TIMEOUT_RUN)
        if run.status != 200 or run.json().get("status") not in {"passed", "success", "ok"}:
            raise SmokeFailure(f"python_compile check failed with HTTP {run.status}")
        started = self.request("POST", f"{self.app_origin}/api/projects/{project_id}/preview/start", {}, timeout=TIMEOUT_PREVIEW_START)
        if started.status != 200:
            raise SmokeFailure(f"starting preview returned HTTP {started.status}")
        self.preview_projects.add(project_id)
        preview_url = f"{self.scheme}://{project_id}.{self.preview_domain}/"
        publish = self.request("POST", f"{self.app_origin}/api/projects/{project_id}/publish", {}, timeout=TIMEOUT_PUBLISH_STATIC)
        if publish.status != 201:
            raise SmokeFailure(f"publishing static project returned HTTP {publish.status}")
        published = publish.json()
        slug = str(published.get("slug", ""))
        if not SITE_SLUG_RE.fullmatch(slug):
            raise SmokeFailure("publish response did not return a valid site slug")
        published_url = str(published.get("url", ""))
        parsed = urllib.parse.urlsplit(published_url)
        if parsed.hostname != f"{slug}.{self.publish_domain}":
            raise SmokeFailure("published URL does not use the site's isolated publish subdomain")
        return preview_url, published_url, slug

    def check_npm_project(self) -> str:
        project_id = self._create_project("smoke-test-npm-no-lockfile")
        marker = "QWEN_STUDIO_NPM_SMOKE_OK"
        package_json = {
            "name": "qwen-studio-smoke-npm",
            "version": "1.0.0",
            "private": True,
            "dependencies": {"is-number": "7.0.0"},
            "scripts": {
                "build": "node -e \"require('fs').mkdirSync('dist',{recursive:true});require('fs').writeFileSync('dist/index.html','QWEN_STUDIO_NPM_SMOKE_OK')\""
            },
        }
        self._put_file(project_id, "package.json", json.dumps(package_json))
        publish = self.request("POST", f"{self.app_origin}/api/projects/{project_id}/publish", {}, timeout=TIMEOUT_PUBLISH_NPM)
        if publish.status != 201:
            raise SmokeFailure(f"npm project publish/build returned HTTP {publish.status}; check Verdaccio and lockfile generation")
        data = publish.json()
        slug = str(data.get("slug", ""))
        if not SITE_SLUG_RE.fullmatch(slug):
            raise SmokeFailure("npm publish did not return a valid site slug")
        url = str(data.get("url", ""))
        if urllib.parse.urlsplit(url).hostname != f"{slug}.{self.publish_domain}":
            raise SmokeFailure("npm published URL does not use the isolated publish subdomain")
        self.check_site_response(url, marker, "npm published site")
        return "dependency project built and published without a submitted lockfile"

    def check_model_agent(self) -> str:
        project_id = self._create_project("smoke-test-agent")
        marker = "QWEN_STUDIO_AGENT_SMOKE_FIXED_CONTENT"
        prompt = (
            "Create a file named hello.txt in this project. Its entire content must be exactly "
            + marker + ". Use a file tool to write it, then finish."
        )
        response = self.request("POST", self.app_origin + "/api/chat",
                                {"project_id": project_id, "message": prompt}, timeout=TIMEOUT_CHAT)
        if response.status != 200:
            raise SmokeFailure(f"agent chat returned HTTP {response.status}")
        events = response.json().get("tool_events", [])
        if not any(event.get("tool") in {"write_file", "edit_file"} for event in events):
            raise SmokeFailure("agent response contained no write_file/edit_file tool event")
        if self._get_file(project_id, "hello.txt") != marker:
            raise SmokeFailure("hello.txt content does not match the requested fixed content")
        return "agent used a file-writing tool and created the exact expected content"

    def cleanup(self) -> None:
        for project_id in reversed(self.projects):
            if project_id in self.preview_projects:
                self.check(f"cleanup stop preview {project_id[:8]}", lambda pid=project_id: self._cleanup_stop(pid))
            self.check(f"cleanup delete project {project_id[:8]}", lambda pid=project_id: self._cleanup_delete(pid))

    def _cleanup_stop(self, project_id: str) -> str:
        response = self.request("POST", f"{self.app_origin}/api/projects/{project_id}/preview/stop", {}, timeout=TIMEOUT_STOP_DELETE)
        if response.status not in {200, 404}:
            raise SmokeFailure(f"stop preview returned HTTP {response.status}")
        return "preview stopped"

    def _cleanup_delete(self, project_id: str) -> str:
        response = self.request("DELETE", f"{self.app_origin}/api/projects/{project_id}", timeout=TIMEOUT_STOP_DELETE)
        if response.status not in {200, 404}:
            raise SmokeFailure(f"delete project returned HTTP {response.status}")
        return "project deleted"

    def run(self) -> int:
        self.check("1. health/version", self.check_health)
        self.check("2. workspace opens without login", self.check_workspace_opens_without_login)
        self.check("3. system status", self.check_system_status)
        primary = None
        try:
            primary = self.check_static_project_preview_publish()
            self.report("4. create/check/preview/publish static project", "PASS", "project built, preview started and publish created")
        except Exception as exc:
            self.report("4. create/check/preview/publish static project", "FAIL", str(exc).splitlines()[0][:240])
        if primary:
            preview_url, published_url, slug = primary
            self.check("4a. preview response", lambda: self.check_site_response(
                preview_url, "QWEN_STUDIO_STATIC_SMOKE_OK", "preview"))
            self.check("5a. published response", lambda: self.check_site_response(
                published_url, "QWEN_STUDIO_STATIC_SMOKE_OK", "published site"))
            self.check("5b. bare publish domain isolation", self.check_published_root_404)
            self.check("5c. legacy app publish path isolation", lambda: self.check_old_published_path_404(slug))
        else:
            self.skip("5. published origin isolation", "static project publish did not complete")
        if self.skip_npm:
            self.skip("6. npm project without lockfile", "--skip-npm was supplied")
        else:
            self.check("6. npm project without lockfile", self.check_npm_project)
        if self.skip_model:
            self.skip("7. model file-writing task", "--skip-model was supplied")
        else:
            self.check("7. model file-writing task", self.check_model_agent)
        self.cleanup()
        failures = sum(status == "FAIL" for _, status, _ in self.results)
        passes = sum(status == "PASS" for _, status, _ in self.results)
        skips = sum(status == "SKIP" for _, status, _ in self.results)
        print(f"\nSmoke test summary: {passes} PASS, {failures} FAIL, {skips} SKIP")
        return 1 if failures else 0


def expected_release_version() -> str:
    app_py = (REPO_ROOT / "backend" / "app.py").read_text(encoding="utf-8")
    match = re.search(r'FastAPI\(title="Qwen Studio", version="([\d.]+)"', app_py)
    if not match:
        raise SmokeFailure("backend/app.py does not declare a release version")
    return match.group(1)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run deployment smoke tests against a live Qwen Studio instance.")
    parser.add_argument("--app-url", required=True, help="Studio origin, e.g. http://127.0.0.1:8080 or https://studio.example.com")
    parser.add_argument("--preview-domain", required=True, help="Bare preview wildcard domain, e.g. preview.example.com")
    parser.add_argument("--publish-domain", required=True, help="Bare publish wildcard domain, e.g. sites.example.com")
    parser.add_argument("--skip-model", action="store_true", help="Skip model connectivity and file-writing checks")
    parser.add_argument("--skip-npm", action="store_true", help="Skip Verdaccio/npm install and build check")
    parser.add_argument("--insecure-local", action="store_true", help="Allow HTTP only for localhost/loopback app URLs")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        runner = SmokeRunner(
            args.app_url, args.preview_domain, args.publish_domain,
            skip_model=args.skip_model, skip_npm=args.skip_npm, insecure_local=args.insecure_local,
        )
    except Exception as exc:
        print(f"FAIL configuration: {str(exc).splitlines()[0]}")
        return 2
    try:
        return runner.run()
    except KeyboardInterrupt:
        print("\nSmoke test interrupted by operator.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
