#!/usr/bin/env python3
"""Check exact Python pins and the Verdaccio image tag against package indexes."""
from __future__ import annotations
import re, sys, socket, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REQ=re.compile(r'^\s*([A-Za-z0-9_.-]+)(?:\[[^]]+\])?==([A-Za-z0-9_.+-]+)\s*$')

def collect_pins(root=ROOT):
    pins=[]
    for name in ('requirements.txt','requirements-dev.txt'):
        p=root/name
        if not p.exists(): continue
        for line in p.read_text().splitlines():
            m=REQ.match(line)
            if m: pins.append(('pypi',m.group(1),m.group(2),f'{name}: {line.strip()}'))
    for name in ('runner/Dockerfile','sandbox/Dockerfile'):
        p=root/name
        if p.exists():
            text=p.read_text()
            for package,version in re.findall(r'\b(fastapi|uvicorn|pydantic|pytest)==([0-9][A-Za-z0-9_.+-]*)',text,re.I):
                pins.append(('pypi',package,version,f'{name}: {package}=={version}'))
    compose=(root/'compose.yaml').read_text()
    m=re.search(r'image:\s*verdaccio/verdaccio:([^\s#]+)',compose)
    if m: pins.append(('docker','verdaccio/verdaccio',m.group(1),'compose.yaml'))
    return pins

def verify(pins, opener=None):
    custom_opener = opener is not None
    opener=opener or urllib.request.urlopen
    results=[]
    if not custom_opener:
        try:
            with socket.create_connection(("pypi.org", 443), timeout=1.5):
                pass
        except OSError:
            for kind,name,version,source in pins:
                results.append(("SKIP", f"{name}=={version} ({source}; network unavailable)"))
            return results
    for kind,name,version,source in pins:
        if kind=='docker':
            url=f'https://hub.docker.com/v2/repositories/{name}/tags/{version}'
        else:
            url=f'https://pypi.org/pypi/{name}/{version}/json'
        try:
            with opener(url,timeout=2) as response: response.read(1)
            results.append(('EXISTS',f'{name}:{version}' if kind=='docker' else f'{name}=={version}'))
        except urllib.error.HTTPError as exc:
            results.append(('MISSING' if exc.code==404 else 'SKIP',f'{name}:{version} ({source}; HTTP {exc.code})' if kind=='docker' else f'{name}=={version} ({source}; HTTP {exc.code})'))
        except Exception as exc:
            results.append(('SKIP',f'{name}=={version} ({source}; network unavailable: {type(exc).__name__})'))
    return results

def main():
    results=verify(collect_pins())
    for status,detail in results: print(f'{status}: {detail}')
    if any(s=='MISSING' for s,_ in results): return 1
    if not any(s=='EXISTS' for s,_ in results): return 3
    return 0
if __name__=='__main__': raise SystemExit(main())
