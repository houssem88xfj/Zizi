#!/usr/bin/env python3
"""Verify the installed PyTorch build and CUDA visibility — no mocks, no assumptions.

This is the single post-install verification used by scripts/install.sh,
scripts/install.bat and the Docker/compose GPU documentation. It reports what is
REALLY in the environment and fails loudly when the requested mode is not real.

Usage:
  python scripts/check_torch.py             # report only (exit 0 if torch imports and works)
  python scripts/check_torch.py --cpu       # require a working CPU torch (default mode)
  python scripts/check_torch.py --cuda      # REQUIRE torch.cuda.is_available() == True
  python scripts/check_torch.py --check-model-extra
                                            # additionally verify every runtime dependency the
                                            # local-model extra needs imports cleanly
                                            # (transformers, tokenizers, regex, safetensors,
                                            #  accelerate, sentencepiece, bitsandbytes,
                                            #  huggingface_hub)

Exit codes:
  0 = requested mode satisfied (and model extra complete when requested)
  1 = --cuda requested but torch.cuda.is_available() is False (clear diagnostics printed)
  2 = torch is not installed in this environment
  3 = torch imports but --check-model-extra found missing/broken model dependencies
  4 = torch is installed but cannot even be imported (broken installation)

The script is strictly read-only: it never installs, upgrades or downgrades anything.
"""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import shutil
import subprocess

MODEL_EXTRA_MODULES = (
    "transformers",
    "tokenizers",
    "regex",
    "safetensors",
    "accelerate",
    "sentencepiece",
    "bitsandbytes",
    "huggingface_hub",
)


def read_torch_state() -> dict:
    """Inspect the real environment. Never fakes values; missing torch is a plain flag."""
    state: dict = {"torch_installed": False, "import_error": None}
    try:
        import torch  # noqa: PLC0415 - deliberate lazy import
    except ImportError:
        return state
    except Exception as exc:  # noqa: BLE001 - a broken torch install must be reported as-is
        state["import_error"] = f"{type(exc).__name__}: {exc}"
        return state
    state.update(
        torch_installed=True,
        torch_version=torch.__version__,
        build_cuda=getattr(torch.version, "cuda", None),  # None => CPU-only build
        cuda_available=bool(torch.cuda.is_available()),
        device_count=torch.cuda.device_count() if torch.cuda.is_available() else 0,
        device_names=[],
        device_vram_gib=[],
        bf16_supported=bool(torch.cuda.is_available() and torch.cuda.is_bf16_supported()),
    )
    for index in range(state["device_count"]):
        try:
            state["device_names"].append(torch.cuda.get_device_name(index))
        except Exception:  # noqa: BLE001 - keep going; name is cosmetic
            state["device_names"].append(f"cuda:{index}")
        try:  # measured VRAM - real value from the device properties, not an assumption
            total_bytes = torch.cuda.get_device_properties(index).total_memory
            state["device_vram_gib"].append(round(total_bytes / (1024**3), 1))
        except Exception:  # noqa: BLE001 - keep going; VRAM is cosmetic
            state["device_vram_gib"].append(None)
    return state


def _driver_probe() -> str:
    """Best-effort NVIDIA driver probe for diagnostics. Never a pass/fail signal."""
    if shutil.which("nvidia-smi") is None:
        return "nvidia-smi: not found on PATH (NVIDIA driver userland tools are not installed)"
    try:
        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except Exception as exc:  # noqa: BLE001
        return f"nvidia-smi: failed to run ({type(exc).__name__})"
    if out.returncode != 0:
        return f"nvidia-smi: exited {out.returncode} ({(out.stderr or '').strip()[:200]})"
    return "nvidia-smi: " + "; ".join(line.strip() for line in out.stdout.strip().splitlines() if line.strip())


def evaluate(requested: str, state: dict) -> tuple[int, list[str]]:
    """Pure decision core: (exit_code, report_lines). Unit-testable without torch."""
    lines: list[str] = []
    if not state["torch_installed"]:
        lines.append("FAIL  torch is not installed in this environment.")
        lines.append("      Install it with: pip install -r requirements-local-model.txt")
        lines.append("      (or use scripts/install.sh --with-model / scripts\\install.bat --with-model,")
        lines.append("       which pick the CPU or CUDA build explicitly).")
        return 2, lines
    if state["import_error"]:
        lines.append(f"FAIL  torch is installed but cannot be imported: {state['import_error']}")
        lines.append("      The installation is broken; reinstall torch in a clean virtual environment.")
        return 4, lines

    build = "cuda" if state["build_cuda"] else "cpu"
    lines.append(f"torch version       : {state['torch_version']}")
    lines.append(f"built for CUDA      : {state['build_cuda'] if state['build_cuda'] else 'no (CPU-only build)'}")
    lines.append(f"torch.cuda.is_available() : {state['cuda_available']}")
    if state["cuda_available"]:
        lines.append(f"CUDA devices        : {state['device_count']}")
        for index, name in enumerate(state["device_names"]):
            vram = state.get("device_vram_gib", [None] * len(state["device_names"]))[index]
            vram_text = f", VRAM {vram} GiB" if vram is not None else ""
            lines.append(f"  - {name}{vram_text}")
        lines.append(f"bf16 supported      : {state['bf16_supported']}")
        if not state["bf16_supported"]:
            lines.append("                      this GPU has no BF16 tensor cores (pre-Ampere, e.g. T4):")
            lines.append("                      use fp16/int8/int4 - quantization=auto picks fp16 compute dtype automatically.")

    if requested == "cuda" and not state["cuda_available"]:
        lines.append("")
        lines.append("FAIL  CUDA was requested but torch.cuda.is_available() is False.")
        lines.append(f"      driver probe: {_driver_probe()}")
        if state["build_cuda"] is None:
            lines.append("      Cause: this torch is a CPU-only build (built for CUDA: no).")
            lines.append("      Fix: replace it with the CUDA build in THIS virtual environment:")
            lines.append("           pip uninstall -y torch")
            lines.append("           pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu124")
        else:
            lines.append(f"      Cause: torch is built for CUDA {state['build_cuda']} but no usable CUDA runtime/GPU is visible.")
            lines.append("      Likely reasons, in order:")
            lines.append("        1. The NVIDIA driver is missing or too old for this CUDA runtime version.")
            lines.append("        2. nvidia-smi is present but the GPU is hidden (container without GPU passthrough,")
            lines.append("           WSL2 without GPU support, or another process reinitialized the device).")
            lines.append("      Fix: install/upgrade the NVIDIA driver so `nvidia-smi` lists the card, then re-run.")
        lines.append("      This platform still runs on CPU, but the installer will NOT report success")
        lines.append("      for a GPU install that cannot actually see the GPU (see docs/GPU_GUIDE.md).")
        return 1, lines

    if requested == "cuda":
        lines.append("PASS  CUDA mode verified: torch can see and use the GPU above.")
    else:
        lines.append("PASS  torch works on this machine (CPU mode is always valid; CUDA not requested).")
    return 0, lines


def evaluate_model_extra(state: dict | None = None) -> tuple[int, list[str]]:
    """Verify every runtime dependency of the local-model extra imports cleanly."""
    lines: list[str] = []
    if state is None:
        state = read_torch_state()
    if state["torch_installed"] and not state["import_error"]:
        lines.append(f"torch {state['torch_version']} imports OK")
    missing: list[str] = []
    for module in MODEL_EXTRA_MODULES:
        try:
            importlib.import_module(module)
            try:
                version = importlib.metadata.version(module.replace("_", "-"))
            except Exception:  # noqa: BLE001 - cosmetic only
                version = "?"
            lines.append(f"OK    {module} ({version})")
        except Exception as exc:  # noqa: BLE001 - report the real import failure
            missing.append(module)
            lines.append(f"MISSING/BROKEN  {module}: {type(exc).__name__}: {str(exc)[:160]}")
    if missing:
        lines.append("")
        lines.append("FAIL  the local-model extra is incomplete. Install the missing modules:")
        lines.append("        pip install " + " ".join(missing))
        lines.append("      or reinstall the extra: pip install -r requirements-local-model.txt")
        return 3, lines
    lines.append("PASS  model-extra dependencies import cleanly (transformers, bitsandbytes, ...).")
    return 0, lines


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verify torch/CUDA visibility (read-only).")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--cpu", action="store_true", help="require a working CPU torch (default)")
    mode.add_argument("--cuda", "--gpu", dest="cuda", action="store_true", help="REQUIRE a visible, usable GPU")
    parser.add_argument(
        "--check-model-extra", action="store_true",
        help="also verify all local-model runtime dependencies import cleanly",
    )
    args = parser.parse_args(argv)
    requested = "cuda" if args.cuda else "cpu"

    state = read_torch_state()
    code, lines = evaluate(requested, state)
    for line in lines:
        print(line)
    if code != 0:
        return code
    if args.check_model_extra:
        extra_code, extra_lines = evaluate_model_extra(state)
        print()
        for line in extra_lines:
            print(line)
        return extra_code
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
