@echo off
REM Start Qwen Studio on Windows.
cd /d "%~dp0.."
if not exist .runtime mkdir .runtime
set APP_PORT=8080
if exist .env for /f "usebackq tokens=1,* delims==" %%a in (`findstr /b "APP_PORT=" .env`) do set APP_PORT=%%b
set BIND=127.0.0.1
if exist .env for /f "usebackq tokens=1,* delims==" %%a in (`findstr /b "APP_BIND_ADDRESS=" .env`) do set BIND=%%b

if exist .runtime\qwen-studio.pid (
  for /f %%p in (.runtime\qwen-studio.pid) do (
    tasklist /fi "pid eq %%p" 2>nul | find "%%p" >nul && (
      echo Qwen Studio is already running (PID %%p^). Use scripts\stop.bat first.
      exit /b 0
    )
  )
)

if exist .venv\Scripts\python.exe ( set PY=.venv\Scripts\python.exe ) else ( set PY=python )
echo Starting Qwen Studio on http://%BIND%:%APP_PORT% ...
start /b "" %PY% -m uvicorn backend.app:app --host %BIND% --port %APP_PORT% >> .runtime\qwen-studio.log 2>&1
powershell -NoProfile -Command "$p=Get-CimInstance Win32_Process -Filter \"Name like 'python%%'\" | Where-Object {$_.CommandLine -match 'uvicorn backend.app'} | Select-Object -First 1; if($p){$p.ProcessId|Set-Content .runtime\qwen-studio.pid}"

timeout /t 4 /nobreak >nul
powershell -NoProfile -Command "try{$r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%APP_PORT%/health -TimeoutSec 5; $r.Content}catch{exit 1}"
if errorlevel 1 (
  echo Server did not become healthy. Last log lines:
  powershell -NoProfile -Command "Get-Content .runtime\qwen-studio.log -Tail 20"
  exit /b 1
)
echo.
echo Qwen Studio is running: http://%BIND%:%APP_PORT%
if exist .env findstr /b "LOCAL_INFERENCE=true" .env >nul && (
  echo Local model is loading in the background. Check: curl http://127.0.0.1:8100/health
)
echo Log: .runtime\qwen-studio.log  ^(stop with scripts\stop.bat^)
