@echo off
REM Qwen Studio installer for Windows (PowerShell-free, plain cmd).
REM   scripts\install.bat                       - app only
REM   scripts\install.bat --with-model          - app + torch/transformers; torch build
REM                                               auto-picked (NVIDIA detected - CUDA, else CPU)
REM   scripts\install.bat --with-model --cpu    - force the CPU torch build
REM   scripts\install.bat --with-model --cuda   - force the CUDA torch build (torch 2.6.0, cu124)
REM   scripts\install.bat --with-model --gpu    - alias of --cuda
REM
REM Torch is pinned to 2.6.0, the newest release published on the official cu124 wheel
REM index (https://download.pytorch.org/whl/cu124/torch/). The CUDA build runs on any
REM NVIDIA driver >= 525 (CUDA 12.x minor-version compatibility); >= 551.61 recommended
REM on Windows for CUDA 12.4 GA. BitsAndBytes needs PyTorch 2.4+ / Python 3.10+ /
REM CUDA 11.8+ / compute capability 6.0+ (int8 needs 7.5+, e.g. T4) - all satisfied.
REM
REM The installer NEVER trusts hardware presence alone: after installing torch it runs
REM scripts\check_torch.py, which calls torch.cuda.is_available() for real. A GPU install
REM whose torch cannot see the GPU FAILS here instead of printing a fake success message.
REM
REM CMD expansion notes (maintenance - do not regress):
REM   * The whole "if ... ( ... )" blocks below are parsed as ONE command, so %VAR% inside
REM     them would read the value from BEFORE the block runs (stale/empty). Every variable
REM     that is SET inside a block and read afterwards uses delayed expansion !VAR!.
REM   * Delayed expansion is enabled only AFTER cd /d "%~dp0..", so project paths that
REM     contain "!" or spaces are never corrupted by the !-scanner.
REM   * python -c probes inside FOR /F use NO single quotes (they would end the FOR
REM     command string); quote-stripping of arguments is done with %%~a.
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
set "PROJECT_DIR=%cd%"
set "WITH_MODEL=0"
set "TORCH_BUILD="
echo == Qwen Studio installer ==
echo project: %PROJECT_DIR%
setlocal EnableDelayedExpansion

set "VALID_ARG=0"
for %%a in (%*) do (
  set "VALID_ARG=0"
  if /i "%%~a"=="--with-model" ( set "WITH_MODEL=1" & set "VALID_ARG=1" )
  if /i "%%~a"=="--cpu" ( set "TORCH_BUILD=cpu" & set "VALID_ARG=1" )
  if /i "%%~a"=="--cuda" ( set "TORCH_BUILD=cuda" & set "VALID_ARG=1" )
  if /i "%%~a"=="--gpu" ( set "TORCH_BUILD=cuda" & set "VALID_ARG=1" )
  if "!VALID_ARG!"=="0" (
    echo Unknown option: %%~a
    exit /b 2
  )
)
if not "!TORCH_BUILD!"=="" if "!WITH_MODEL!"=="0" (
  echo ERROR: --cpu/--cuda only make sense together with --with-model.
  exit /b 2
)

where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: python not found. Install Python 3.11+ from https://www.python.org/downloads/
  echo        IMPORTANT: check "Add python.exe to PATH" in the installer.
  exit /b 1
)
python -c "import sys; raise SystemExit(0 if (sys.version_info.major,sys.version_info.minor)>=(3,11) else 1)"
if errorlevel 1 (
  echo ERROR: Python 3.11+ required.
  python --version
  exit /b 1
)
for /f "tokens=*" %%v in ('python -c "import sys; print(f\"{sys.version_info.major}.{sys.version_info.minor}\")"') do echo [OK] Python %%v

if not exist .venv (
  python -m venv .venv
  if errorlevel 1 (
    echo ERROR: could not create the virtual environment .venv.
    exit /b 1
  )
  echo [OK] created virtual environment .venv
) else (
  echo [OK] reusing existing .venv
)
call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo ERROR: could not activate .venv\Scripts\activate.bat.
  exit /b 1
)
if not defined VIRTUAL_ENV (
  echo ERROR: the virtual environment is not active - refusing to install into the global Python.
  exit /b 1
)
python -m pip install --upgrade pip --quiet
if errorlevel 1 (
  echo ERROR: pip could not be upgraded inside .venv.
  exit /b 1
)

echo == installing application dependencies ==
pip install -r requirements.txt
if errorlevel 1 ( echo ERROR: dependency installation failed & exit /b 1 )

if "!WITH_MODEL!"=="1" (
  REM Torch build selection. Detection only PREFERS CUDA when an NVIDIA GPU is visible;
  REM it never assumes a valid CUDA runtime exists - the real torch.cuda.is_available()
  REM check below decides whether a --cuda install succeeded.
  if "!TORCH_BUILD!"=="" (
    where nvidia-smi >nul 2>nul
    if not errorlevel 1 (
      nvidia-smi -L >nul 2>nul
      if not errorlevel 1 (
        set "TORCH_BUILD=cuda"
        echo == NVIDIA GPU detected - installing the CUDA torch build ==
        echo    ^(preselection only - the real torch.cuda.is_available check decides^)
      ) else (
        set "TORCH_BUILD=cpu"
        echo == no usable NVIDIA GPU detected - installing the CPU torch build ==
      )
    ) else (
      set "TORCH_BUILD=cpu"
      echo == no NVIDIA GPU detected - installing the CPU torch build ==
    )
  ) else (
    echo == installing the !TORCH_BUILD! torch build ^(explicitly requested^) ==
  )
  if "!TORCH_BUILD!"=="cuda" ( set "TORCH_INDEX_URL=https://download.pytorch.org/whl/cu124" ) else ( set "TORCH_INDEX_URL=https://download.pytorch.org/whl/cpu" )

  REM Replace an existing torch ONLY when its build family differs from the request.
  REM CPU/CUDA builds carry local version tags, so a plain "pip install" would silently
  REM keep the wrong build; uninstall first when switching. A torch that is installed
  REM but cannot even be imported is reported as "broken" and replaced the same way.
  set "TORCH_STATE=missing"
  for /f "tokens=*" %%v in ('python -c "import torch;print(torch.version.cuda is not None)" 2^>nul') do (
    if /i "%%v"=="True" ( set "TORCH_STATE=cuda" ) else ( set "TORCH_STATE=cpu" )
  )
  if "!TORCH_STATE!"=="missing" (
    pip show torch >nul 2>nul && set "TORCH_STATE=broken"
  )
  if "!TORCH_STATE!"=="missing" (
    echo == torch not found in .venv - installing torch 2.6.0 !TORCH_BUILD! build ==
    pip install "torch==2.6.0" --index-url !TORCH_INDEX_URL!
    if errorlevel 1 ( echo ERROR: torch installation failed. See docs\GPU_GUIDE.md & exit /b 1 )
  ) else if "!TORCH_STATE!"=="!TORCH_BUILD!" (
    echo [OK] reusing the existing !TORCH_STATE! torch build ^(no reinstall, no duplicates^)
  ) else (
    echo == replacing the installed !TORCH_STATE! torch build with the !TORCH_BUILD! build ==
    pip uninstall -y torch
    if errorlevel 1 ( echo ERROR: could not remove the existing torch build & exit /b 1 )
    pip install "torch==2.6.0" --index-url !TORCH_INDEX_URL!
    if errorlevel 1 ( echo ERROR: torch installation failed. See docs\GPU_GUIDE.md & exit /b 1 )
  )
  pip install -r requirements-local-model.txt
  if errorlevel 1 ( echo ERROR: local-model extra installation failed & exit /b 1 )

  REM Real verification, never a fake success message:
  REM   0 OK / 1 CUDA requested but not visible / 2 torch missing / 3 model extra broken / 4 torch broken
  echo == verifying the installed torch for real ^(torch.cuda.is_available^) ==
  python scripts\check_torch.py --!TORCH_BUILD! --check-model-extra
  if errorlevel 1 (
    if /i "!TORCH_BUILD!"=="cuda" (
      echo ERROR: the CUDA torch install cannot see the GPU.
      echo        Fix the driver/build as printed above, or rerun with --cpu for a CPU install:
      echo          scripts\install.bat --with-model --cpu
    ) else (
      echo ERROR: the local-model extra failed its verification.
    )
    exit /b 1
  )
)

if not exist .env (
  copy .env.example .env >nul
  if errorlevel 1 (
    echo ERROR: could not create .env from .env.example.
    exit /b 1
  )
  REM Pure Python - no PowerShell dependency. Same logic as scripts\install.sh.
  python -c "import pathlib,secrets; p=pathlib.Path('.env'); t=p.read_text(encoding='utf-8'); t=t.replace('APP_ENV=production','APP_ENV=development',1); t=t.replace('REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARACTERS',secrets.token_urlsafe(48)); p.write_text(t,encoding='utf-8')"
  if errorlevel 1 (
    echo ERROR: could not finalize .env - see the python error above.
    exit /b 1
  )
  echo [OK] created .env with generated secrets ^(development defaults^)
) else (
  echo [OK] keeping existing .env
)

echo.
echo Install complete. Next steps:
echo   1. ^(local model only^) put safetensors files into models\Qwen2.5-Coder-14B-Instruct\
echo      and set LOCAL_INFERENCE=true in .env
echo   2. scripts\start.bat
echo   3. open http://127.0.0.1:8080
