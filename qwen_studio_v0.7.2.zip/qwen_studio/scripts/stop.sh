#!/bin/bash
# Stop Qwen Studio cleanly.
set -uo pipefail
cd "$(dirname "$0")/.."
PID_FILE=".runtime/qwen-studio.pid"

stopped=0
if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE")"
  if kill -0 "$PID" 2>/dev/null; then
    kill "$PID"
    for _ in $(seq 1 20); do kill -0 "$PID" 2>/dev/null || break; sleep 0.5; done
    kill -9 "$PID" 2>/dev/null || true
    echo "Stopped Qwen Studio (PID $PID)."
    stopped=1
  fi
  rm -f "$PID_FILE"
fi
# Fallback: catch detached instances started outside scripts/start.sh
if pkill -f "uvicorn backend.app:app" 2>/dev/null; then
  echo "Stopped remaining uvicorn instances."
  stopped=1
fi
[ "$stopped" = "0" ] && echo "Qwen Studio was not running."
exit 0
