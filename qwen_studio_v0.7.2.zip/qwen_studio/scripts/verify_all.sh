#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
STATUS=0
run(){ local label="$1"; shift; printf '\n== %s ==\n' "$label"; if "$@"; then printf 'PASS  %s\n' "$label"; else printf 'FAIL  %s\n' "$label"; STATUS=1; exit 1; fi; }
cleanup(){ find . -type d \( -name __pycache__ -o -name .pytest_cache \) -prune -exec rm -rf {} +; }
trap cleanup EXIT
run pytest python -m pytest -q
run javascript node --check frontend/app.js
run compileall python -m compileall -q backend runner sandbox deploy scripts
cleanup
run consistency python scripts/check_consistency.py
printf '\n== dependency pins ==\n'
set +e; python scripts/verify_pins.py; pin_rc=$?; set -e
if [[ $pin_rc -eq 1 ]]; then echo 'FAIL  dependency pins'; exit 1; elif [[ $pin_rc -eq 3 ]]; then echo 'WARN  dependency pins (package index unavailable)'; else echo 'PASS  dependency pins'; fi
cleanup
run release python scripts/check_release.py .
while IFS= read -r -d '' file; do run "bash syntax: $file" bash -n "$file"; done < <(find . -type f -name '*.sh' -not -path './.git/*' -print0)
printf '\nFINAL RESULT\n'
printf '%-28s %s\n' 'pytest' PASS 'javascript' PASS 'compileall' PASS 'consistency' PASS 'dependency pins' "$( [[ $pin_rc -eq 3 ]] && echo WARN || echo PASS )" 'release tree' PASS 'shell syntax' PASS
