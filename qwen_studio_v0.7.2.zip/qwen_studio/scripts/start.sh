#!/bin/bash
# Start Qwen Studio (app + bundled local inference when LOCAL_INFERENCE=true).
set -uo pipefail
cd "$(dirname "$0")/.."

# Load environment (works with or without .env)
if [ -f .env ]; then set -a; . ./.env; set +a; fi
APP_PORT="${APP_PORT:-8080}"
BIND="${APP_BIND_ADDRESS:-127.0.0.1}"
PID_FILE=".runtime/qwen-studio.pid"
LOG_FILE=".runtime/qwen-studio.log"
mkdir -p .runtime

# Reuse the project virtualenv when present
PY=python3
if [ -x .venv/bin/python ]; then PY=.venv/bin/python; fi

if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo "Qwen Studio is already running (PID $(cat "$PID_FILE")). Use scripts/stop.sh first."
  exit 0
fi

echo "Starting Qwen Studio on http://$BIND:$APP_PORT ..."
nohup "$PY" -m uvicorn backend.app:app --host "$BIND" --port "$APP_PORT" >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

# Wait for health
for _ in $(seq 1 60); do
  if curl -sf "http://127.0.0.1:$APP_PORT/health" > /dev/null 2>&1; then
    echo "API is up: http://$BIND:$APP_PORT"
    if grep -qE '^LOCAL_INFERENCE=true' .env 2>/dev/null; then
      echo "Local model is loading in the background. Track it at:"
      echo "  curl http://127.0.0.1:${LOCAL_INFERENCE_PORT:-8100}/health"
    fi
    echo "Log: $LOG_FILE (stop with scripts/stop.sh)"
    exit 0
  fi
  sleep 1
done
echo "Server did not become healthy in 60s. Last log lines:"
tail -20 "$LOG_FILE"
exit 1
