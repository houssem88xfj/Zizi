#!/bin/bash
# Verify inside the running container that the weights are visible and the GPU is usable.
# Usage:
#   bash scripts/docker_check.sh            # check the CPU/base service
#   bash scripts/docker_check.sh app-gpu    # check the GPU service
set -euo pipefail
SERVICE="${1:-app}"

echo "== $SERVICE: model files visible in the container =="
docker compose exec "$SERVICE" sh -c 'ls -la /app/models/ 2>/dev/null && ls -la /app/models/*/ 2>/dev/null | head -20'

echo "== $SERVICE: PyTorch + GPU visibility =="
docker compose exec "$SERVICE" python -c "
import torch
print('torch:', torch.__version__)
print('cuda available:', torch.cuda.is_available())
if torch.cuda.is_available():
    print('device:', torch.cuda.get_device_name(0))
    print('vram (GiB):', round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 1))
"

echo "== $SERVICE: local engine status =="
docker compose exec "$SERVICE" python -c "
import urllib.request, json
body = json.load(urllib.request.urlopen('http://127.0.0.1:8100/health', timeout=5))
print(json.dumps({k: body.get(k) for k in ('model','weights_present','loading','loaded','error','device','quantization')}, indent=2))
"

echo "== $SERVICE: app health =="
docker compose exec "$SERVICE" python -c "import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8080/health', timeout=5).read().decode())"
