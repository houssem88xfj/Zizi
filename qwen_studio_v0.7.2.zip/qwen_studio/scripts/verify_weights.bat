@echo off
REM Verify that the local model directory contains complete weights (Windows).
cd /d "%~dp0.."
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
if "%~1"=="" ( python scripts\verify_weights.py ) else ( python scripts\verify_weights.py "%~1" )
