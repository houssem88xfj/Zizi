#!/usr/bin/env python3
"""Verify that a local Qwen model directory contains complete, loadable weights.

Checks (no network access is performed):
  1. config.json exists and parses; reports architecture + dtype hints.
  2. Every *.safetensors file opens and all tensors are readable.
  3. If model.safetensors.index.json exists, every shard it references is present
     and every weight_map entry is covered (detects missing or extra shards).
  4. Tokenizer files are present (tokenizer.json, or vocab.json + merges.txt,
     plus tokenizer_config.json).
  5. Reports total on-disk size and an approximate parameter count.

Exit codes: 0 = complete, 1 = incomplete/corrupted, 2 = usage error.
Usage: python scripts/verify_weights.py [MODEL_DIR]
       (defaults to LOCAL_MODEL_DIR from .env, else models/<LOCAL_MODEL_NAME>)
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

REQUIRED_TOKENIZER_FILES = [("tokenizer.json",), ("vocab.json", "merges.txt")]


def fail(message: str) -> None:
    print(f"[FAIL] {message}")


def ok(message: str) -> None:
    print(f"[OK]   {message}")


def resolve_model_dir(argv: list[str]) -> Path:
    if len(argv) > 1:
        return Path(argv[1]).expanduser().resolve()
    base_dir = Path(__file__).resolve().parent.parent
    model_name = os.getenv("LOCAL_MODEL_NAME", "Qwen2.5-Coder-14B-Instruct").strip()
    configured = os.getenv("LOCAL_MODEL_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    # Fall back to reading .env in the project root without importing the app.
    env_file = base_dir / ".env"
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("LOCAL_MODEL_DIR=") and line.split("=", 1)[1].strip():
                return Path(line.split("=", 1)[1].strip()).expanduser().resolve()
            if line.startswith("LOCAL_MODEL_NAME=") and line.split("=", 1)[1].strip():
                model_name = line.split("=", 1)[1].strip()
    return (base_dir / "models" / model_name).resolve()


def main() -> int:
    model_dir = resolve_model_dir(sys.argv)
    print(f"Verifying local weights in: {model_dir}")
    problems: list[str] = []

    if not model_dir.is_dir():
        fail(f"Directory does not exist: {model_dir}")
        print("\nPlace the model files there (config.json, *.safetensors, tokenizer files).")
        return 1

    # 1. config.json ------------------------------------------------------
    config_path = model_dir / "config.json"
    if not config_path.is_file():
        fail("config.json is missing.")
        problems.append("config.json")
    else:
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
            architectures = config.get("architectures")
            model_type = config.get("model_type")
            hidden = config.get("hidden_size")
            layers = config.get("num_hidden_layers")
            vocab = config.get("vocab_size")
            ok(f"config.json: architecture={architectures} model_type={model_type}")
            print(f"       hidden_size={hidden} layers={layers} vocab_size={vocab}")
            if not model_type or "qwen2" not in str(model_type).lower():
                print("[WARN] model_type is not qwen2 - the engine expects a Qwen2-family checkpoint.")
        except (json.JSONDecodeError, OSError) as exc:
            fail(f"config.json is unreadable or invalid JSON: {exc}")
            problems.append("config.json")

    # 2. safetensors shards ----------------------------------------------
    shards = sorted(model_dir.glob("*.safetensors"))
    if not shards:
        fail("No *.safetensors files found.")
        problems.append("safetensors")
    total_bytes = 0
    total_tensors = 0
    covered: set[str] = set()
    for shard in shards:
        try:
            from safetensors import safe_open

            with safe_open(str(shard), framework="pt") as handle:
                keys = list(handle.keys())
            total_bytes += shard.stat().st_size
            total_tensors += len(keys)
            covered.update(keys)
            ok(f"{shard.name}: {len(keys)} tensors, {shard.stat().st_size / (1024**2):.1f} MiB")
        except Exception as exc:  # noqa: BLE001
            fail(f"{shard.name}: corrupted or unreadable ({exc})")
            problems.append(shard.name)
    partial = list(model_dir.glob("*.incomplete")) + list(model_dir.glob("*.part"))
    for leftover in partial:
        fail(f"Partial download leftover found: {leftover.name} - re-download this file.")
        problems.append(leftover.name)

    # 3. shard index consistency ------------------------------------------
    index_path = model_dir / "model.safetensors.index.json"
    if index_path.is_file():
        try:
            index = json.loads(index_path.read_text(encoding="utf-8"))
            weight_map: dict[str, str] = index.get("weight_map", {})
            referenced_files = sorted(set(weight_map.values()))
            missing = [name for name in referenced_files if not (model_dir / name).is_file()]
            if missing:
                fail(f"Index references missing shards: {missing}")
                problems.extend(missing)
            else:
                ok(f"Shard index complete: {len(referenced_files)} shard(s) all present.")
            not_covered = sorted(set(weight_map) - covered)
            if not_covered and not missing:
                fail(f"{len(not_covered)} weights declared in the index were not found in any shard.")
                problems.append("index-weight-mismatch")
        except (json.JSONDecodeError, OSError) as exc:
            fail(f"model.safetensors.index.json is invalid: {exc}")
            problems.append("model.safetensors.index.json")

    # 4. tokenizer ----------------------------------------------------------
    tokenizer_config = model_dir / "tokenizer_config.json"
    if not tokenizer_config.is_file():
        fail("tokenizer_config.json is missing (required for the chat template).")
        problems.append("tokenizer_config.json")
    else:
        ok("tokenizer_config.json present (chat template).")
    has_tokenizer_json = (model_dir / "tokenizer.json").is_file()
    has_legacy = (model_dir / "vocab.json").is_file() and (model_dir / "merges.txt").is_file()
    if has_tokenizer_json or has_legacy:
        ok("Tokenizer vocabulary present.")
    else:
        fail("Tokenizer vocabulary missing: need tokenizer.json OR vocab.json + merges.txt.")
        problems.append("tokenizer")

    # 5. summary ------------------------------------------------------------
    if not problems and shards:
        print("\nResult: WEIGHTS COMPLETE")
        print(f"  shards={len(shards)} tensors={total_tensors} on_disk={total_bytes / (1024**3):.2f} GiB")
        print("  The engine can load this checkpoint with local_files_only=True.")
        return 0
    print("\nResult: INCOMPLETE")
    print(f"  {len(problems)} problem(s): {', '.join(sorted(set(problems)))}")
    print("  Do not start the platform until this check passes; the engine will refuse to load.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
