#!/usr/bin/env python3
"""Structural account-removal verification for Qwen Studio (Phase 7).

Scans the whole release tree for ANY remaining account-system artifacts:
files, routes, UI markers, DB tables, env vars, scripts, and code references.
Exit 0 = clean, 1 = findings (printed).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]

# Files that must NOT exist anywhere in the release tree.
FORBIDDEN_FILES = {
    "auth.py", "create_user.py", "reset_password.py", "revoke_sessions.py",
    "test_auth_cookie_security.py",
}

# Code patterns that must not appear in backend/frontend/scripts (excluding
# the migration TEST which legitimately builds a LEGACY schema to migrate away
# from, and tests that assert absence).
SCAN_DIRS = ["backend", "frontend", "runner", "sandbox", "deploy", "inference", "scripts", "docs"]
PATTERNS = [
    (r"/api/auth/", "auth API route"),
    (r"AUTH_SECRET", "auth secret env"),
    (r"ALLOW_SIGNUP", "signup env"),
    (r"COOKIE_SECURE", "cookie env"),
    (r"SESSION_TTL_SECONDS", "session env"),
    (r"password_hash|hash_password|pbkdf2", "password hashing"),
    (r"current_user|Depends\(current_user\)", "auth dependency"),
    (r"session_token|set_cookie\(", "session cookie"),
    (r"user_storage|CREATE TABLE.*users", "user tables"),
    (r"login|signin|sign_in|sign out|signout|logout", "login/logout UI text (en)"),
    (r"تسجيل الدخول|إنشاء حساب|الخروج|كلمة المرور", "login UI text (ar)"),
]

ALLOWED_CONTEXT = re.compile(
    r"^\s*(#|//|\"\"\"|\*|<!--|check_)"  # comments
)
# Files where absence-assertions legitimately mention the terms.
ALLOWLIST_FILES = {
    "scripts/smoke_test.py",       # asserts auth endpoints return 404 / UI has no markers
    "scripts/check_consistency.py",
    "scripts/eval_agent.py",       # contains "sign in"? no; keep allowlist anyway
    "scripts/check_release.py",
    "scripts/verify_weights.py",
    "scripts/bench_local_model.py",
    "scripts/account_removal_scan.py",  # this scanner: its own pattern definitions match itself
    "scripts/install.sh", "scripts/install.bat", "scripts/start.sh", "scripts/start.bat",
    "scripts/stop.sh", "scripts/stop.bat",
    "scripts/verify_all.sh", "scripts/docker_check.sh", "scripts/check_requirements.sh",
    "scripts/verify_pins.py",
}


def is_comment(line: str) -> bool:
    return bool(re.match(r"^\s*(#|//|\*|<!--|\'\'\')", line))


def migration_line_ranges(db_text: str) -> list[tuple[int, int]]:
    """Line ranges of legacy-migration functions in db.py (old tables read/dropped there)."""
    ranges: list[tuple[int, int]] = []
    start: int | None = None
    for i, line in enumerate(db_text.splitlines(), 1):
        if re.match(r"^def ", line):
            if start is not None:
                ranges.append((start, i - 1))
                start = None
            if re.search(r"migrate|legacy", line):
                start = i
    if start is not None:
        ranges.append((start, len(db_text.splitlines())))
    return ranges


def main() -> int:
    findings: list[str] = []

    # migration ranges are needed by the backend scan (section 2)
    _db_py_path = REPO / "backend" / "db.py"
    _db_text = _db_py_path.read_text(encoding="utf-8") if _db_py_path.is_file() else ""
    _mig_ranges = migration_line_ranges(_db_text)

    def in_migration(lineno: int) -> bool:
        return any(a <= lineno <= b for a, b in _mig_ranges)

    # 1. forbidden files ----------------------------------------------------
    for path in REPO.rglob("*"):
        if path.is_file() and path.name in FORBIDDEN_FILES:
            findings.append(f"forbidden file present: {path.relative_to(REPO)}")

    # 2. forbidden code patterns ----------------------------------------------
    for scan_dir in SCAN_DIRS:
        base = REPO / scan_dir
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix not in {".py", ".js", ".html", ".css", ".sh", ".md", ".yaml", ".yml", ".toml", ".bat"}:
                continue
            rel = path.relative_to(REPO).as_posix()
            if rel in ALLOWLIST_FILES or rel.startswith("tests/"):
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for lineno, line in enumerate(text.splitlines(), 1):
                if is_comment(line):
                    continue
                if scan_dir == "backend" and "user_storage" in line and in_migration(lineno):
                    continue  # legacy migration reads/drops old tables by design
                lowered = line.lower()
                # Documentation of the account-free state: English and Arabic negations
                # ("no login" / "without login" / "لا يوجد تسجيل دخول ولا إنشاء حساب").
                arabic_negation = any(
                    phrase in line
                    for phrase in (
                        "لا يوجد تسجيل الدخول", "لا يوجد تسجيل دخول", "ولا تسجيل الدخول",
                        "ولا تسجيل دخول", "لا يوجد إنشاء حساب", "ولا إنشاء حساب",
                        "لا يوجد حساب", "بلا تسجيل دخول", "بدون تسجيل دخول",
                    )
                )
                if re.search(r"login|signin|sign_in|sign out|signout|logout", lowered) and (
                        "without login" in lowered or "no login" in lowered or "no account" in lowered):
                    continue  # documentation of the account-free state
                if re.search(r"تسجيل الدخول|تسجيل دخول|إنشاء حساب", line) and arabic_negation:
                    continue  # documentation of the account-free state (Arabic)
                if re.search(r"\bprofile\b", lowered) and "user profile" not in lowered and "account profile" not in lowered:
                    continue  # terminal run profiles, not user profiles
                for pattern, label in PATTERNS:
                    if re.search(pattern, line, re.IGNORECASE):
                        findings.append(f"{label}: {rel}:{lineno}: {line.strip()[:110]}")

    # 3. env example must not mention removed vars --------------------------
    env_example = REPO / ".env.example"
    if env_example.is_file():
        text = env_example.read_text(encoding="utf-8")
        for var in ("AUTH_SECRET", "ALLOW_SIGNUP", "COOKIE_SECURE", "SESSION_TTL_SECONDS"):
            for lineno, line in enumerate(text.splitlines(), 1):
                if re.match(rf"^\s*{var}\s*=", line):
                    findings.append(f".env.example still sets {var} (line {lineno})")

    # 4. DB schema must not have users / user_storage -------------------------
    db_py = _db_text
    for table in ("CREATE TABLE IF NOT EXISTS users", "CREATE TABLE IF NOT EXISTS user_storage"):
        if table in db_py:
            findings.append(f"db.py still creates table: {table}")

    # 5. frontend must not contain account UI ---------------------------------
    for fe in ("frontend/index.html", "frontend/app.js", "frontend/app.css"):
        p = REPO / fe
        if not p.is_file():
            continue
        text = p.read_text(encoding="utf-8")
        for marker in ("auth-screen", "login", "register", "signup", "sign-up", "signout",
                       "sign-out", "logout", "password", "account"):
            if re.search(marker, text, re.IGNORECASE):
                # allow the documented comment about being account-free
                hits = [l for l in text.splitlines() if re.search(marker, l, re.IGNORECASE)
                        and not is_comment(l)
                        and not ("without login" in l.lower() or "no login" in l.lower() or "no account" in l.lower())]
                for h in hits:
                    findings.append(f"frontend marker '{marker}': {fe}: {h.strip()[:110]}")

    # 6. compose/Dockerfile must not reference auth --------------------------
    for infra in ("compose.yaml", "Dockerfile", "docker/entrypoint.sh", "runner/Dockerfile", "sandbox/Dockerfile"):
        p = REPO / infra
        if p.is_file():
            text = p.read_text(encoding="utf-8")
            for var in ("AUTH_SECRET", "ALLOW_SIGNUP", "COOKIE_SECURE", "SESSION_TTL"):
                if var in text:
                    findings.append(f"{infra} references {var}")

    if findings:
        print(f"ACCOUNT-REMOVAL SCAN: {len(findings)} FINDING(S)")
        for f in findings:
            print("  -", f)
        return 1
    print("ACCOUNT-REMOVAL SCAN: CLEAN — no account artifacts in the release tree")
    return 0


if __name__ == "__main__":
    sys.exit(main())
