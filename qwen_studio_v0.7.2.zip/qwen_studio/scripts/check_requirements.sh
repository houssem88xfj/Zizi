#!/bin/bash
# Pre-flight check: everything needed to run Qwen Studio on this machine.
set -uo pipefail
cd "$(dirname "$0")/.."
FAIL=0

say()  { printf '[%s] %s\n' "$1" "$2"; }

# 1. Python
if command -v python3 > /dev/null 2>&1; then
  V="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")')"
  MINOR="$(python3 -c 'import sys; print(sys.version_info.minor)')"
  if [ "$(python3 -c 'import sys; print(sys.version_info.major)')" = "3" ] && [ "$MINOR" -ge 11 ]; then
    say OK "Python $V"
  else
    say FAIL "Python 3.11+ required, found $V"; FAIL=1
  fi
else
  say FAIL "python3 not found"; FAIL=1
fi

# 2. Local model libraries (only relevant when LOCAL_INFERENCE=true)
LOCAL_INFERENCE="false"
[ -f .env ] && grep -qE '^LOCAL_INFERENCE=true' .env && LOCAL_INFERENCE="true"
if [ "$LOCAL_INFERENCE" = "true" ]; then
  if python3 -c "import torch" 2> /dev/null; then
    say OK "torch $(python3 -c 'import torch; print(torch.__version__)')"
    if python3 -c "import torch; assert torch.cuda.is_available()" 2> /dev/null; then
      say OK "CUDA GPU: $(python3 -c 'import torch; print(torch.cuda.get_device_name(0))')"
    else
      say WARN "no CUDA GPU visible - the model will run on CPU (slow for 14B; see docs/CPU_GUIDE.md)"
    fi
  else
    say FAIL "LOCAL_INFERENCE=true but torch is missing: pip install -r requirements-local-model.txt"; FAIL=1
  fi
  for mod in transformers accelerate safetensors; do
    if python3 -c "import $mod" 2> /dev/null; then say OK "$mod installed"; else
      say FAIL "$mod missing: pip install -r requirements-local-model.txt"; FAIL=1
    fi
  done
else
  say INFO "LOCAL_INFERENCE not enabled - model libraries not required"
fi

# 3. Weights
MODEL_DIR=""
[ -f .env ] && MODEL_DIR="$(grep -E '^LOCAL_MODEL_DIR=' .env | cut -d= -f2- | tr -d '\"')"
if [ "$LOCAL_INFERENCE" = "true" ]; then
  if [ -n "$MODEL_DIR" ] && [ -d "$MODEL_DIR" ]; then TARGET="$MODEL_DIR"; else
    TARGET="models/$(grep -E '^LOCAL_MODEL_NAME=' .env | cut -d= -f2- | tr -d '\"' || echo Qwen2.5-Coder-14B-Instruct)"
  fi
  if python3 scripts/verify_weights.py "$TARGET" > /tmp/qwen_weights_check.log 2>&1; then
    say OK "weights complete in $TARGET"
  else
    say FAIL "weights incomplete/missing in $TARGET (details: /tmp/qwen_weights_check.log)"; FAIL=1
    tail -5 /tmp/qwen_weights_check.log
  fi
fi

# 4. Port availability
for PORT in 8080 8100; do
  if command -v ss > /dev/null 2>&1 && ss -tln 2>/dev/null | grep -q ":$PORT "; then
    say WARN "port $PORT already in use (another instance running?)"
  else
    say OK "port $PORT free"
  fi
done

# 5. Docker (optional - only for sandboxed previews/publishing)
if command -v docker > /dev/null 2>&1 && docker info > /dev/null 2>&1; then
  say OK "docker reachable (sandbox previews available)"
else
  say INFO "docker not available - the platform runs, but sandboxed live previews need Docker"
fi

echo
if [ "$FAIL" = "0" ]; then echo "Pre-flight complete: ready to start (bash scripts/start.sh)."; else
  echo "Pre-flight found blocking problems - fix the FAIL items above."; fi
exit $FAIL
