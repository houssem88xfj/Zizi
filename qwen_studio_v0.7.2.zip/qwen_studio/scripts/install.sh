#!/bin/bash
# Qwen Studio installer: prepares a Python virtual environment and installs
# everything needed to run the platform locally.
#
#   bash scripts/install.sh                          # app only (external model API optional)
#   bash scripts/install.sh --with-model             # + torch/transformers; torch build auto-picked:
#                                                    #   NVIDIA GPU detected -> CUDA build, else CPU
#   bash scripts/install.sh --with-model --cpu       # force the CPU torch build
#   bash scripts/install.sh --with-model --cuda      # force the CUDA torch build
#                                                    #   (torch 2.6.0, cu124 index)
#   bash scripts/install.sh --with-model --gpu       # alias of --cuda
#
# Torch is pinned to 2.6.0, the newest release published on the official cu124 wheel
# index (https://download.pytorch.org/whl/cu124/torch/). The CUDA build runs on any
# NVIDIA driver >= 525 (CUDA 12.x minor-version compatibility); >= 550.54.14 recommended
# on Linux for CUDA 12.4 GA. BitsAndBytes needs PyTorch 2.4+ / Python 3.10+ /
# CUDA 11.8+ / compute capability 6.0+ (int8 needs 7.5+, e.g. T4) - all satisfied.
#
# The installer NEVER trusts hardware presence alone: after installing torch it runs
# scripts/check_torch.py, which calls torch.cuda.is_available() for real. A GPU install
# whose torch cannot see the GPU FAILS here instead of printing a fake success message.
#
# The installer never downloads model weights. Put the Qwen2.5-Coder-14B-Instruct
# safetensors files into models/Qwen2.5-Coder-14B-Instruct/ yourself.
set -euo pipefail
cd "$(dirname "$0")/.."
PROJECT_DIR="$(pwd)"
WITH_MODEL=false
TORCH_BUILD=""   # empty = auto-detect, otherwise "cpu" or "cuda"
for arg in "$@"; do
  case "$arg" in
    --with-model) WITH_MODEL=true ;;
    --cpu) TORCH_BUILD="cpu" ;;
    --cuda|--gpu) TORCH_BUILD="cuda" ;;
    *) echo "Unknown option: $arg"; exit 2 ;;
  esac
done
if [ -n "$TORCH_BUILD" ] && [ "$WITH_MODEL" = false ]; then
  echo "ERROR: --cpu/--cuda only make sense together with --with-model."; exit 2
fi

echo "== Qwen Studio installer =="
echo "project: $PROJECT_DIR"

# 1. Python version ------------------------------------------------------------
if ! command -v python3 > /dev/null 2>&1; then
  echo "ERROR: python3 not found. Install Python 3.11+ first (https://www.python.org/downloads/)."
  exit 1
fi
PY_VERSION="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
PY_MAJOR="$(python3 -c 'import sys; print(sys.version_info.major)')"
PY_MINOR="$(python3 -c 'import sys; print(sys.version_info.minor)')"
if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 11 ]; } then
  echo "ERROR: Python 3.11+ required, found $PY_VERSION."
  exit 1
fi
echo "[OK] Python $PY_VERSION"

# 2. Virtual environment ---------------------------------------------------------
if [ ! -d .venv ]; then
  python3 -m venv .venv
  echo "[OK] created virtual environment .venv"
else
  echo "[OK] reusing existing .venv"
fi
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip --quiet

# 3. Dependencies ----------------------------------------------------------------
echo "== installing application dependencies =="
pip install -r requirements.txt
if [ "$WITH_MODEL" = true ]; then
  # Torch build selection. Detection only PREFERS CUDA when an NVIDIA GPU is visible;
  # it never assumes a valid CUDA runtime exists - the real torch.cuda.is_available()
  # check below decides whether a --cuda install succeeded.
  if [ -z "$TORCH_BUILD" ]; then
    if command -v nvidia-smi > /dev/null 2>&1 && nvidia-smi -L > /dev/null 2>&1; then
      TORCH_BUILD="cuda"
      echo "== NVIDIA GPU detected -> installing the CUDA torch build =="
      echo "   (this is a preselection; the real torch.cuda.is_available() check decides)"
    else
      TORCH_BUILD="cpu"
      echo "== no NVIDIA GPU detected -> installing the CPU torch build =="
    fi
  else
    echo "== installing the $TORCH_BUILD torch build (explicitly requested) =="
  fi
  if [ "$TORCH_BUILD" = "cuda" ]; then
    TORCH_INDEX_URL="https://download.pytorch.org/whl/cu124"
  else
    TORCH_INDEX_URL="https://download.pytorch.org/whl/cpu"
  fi

  # Replace an existing torch ONLY when its build family differs from the request.
  # This keeps an existing compatible install untouched and never leaves two
  # conflicting torch builds in one environment. (torch CPU/CUDA builds carry local
  # version tags, so a plain `pip install` would silently keep the wrong build.)
  # A torch that is installed but cannot even be imported is reported as "broken"
  # and replaced through the same switch path.
  TORCH_STATE="$(python -c "import torch; print('cuda' if torch.version.cuda else 'cpu')" 2>/dev/null || echo missing)"
  if [ "$TORCH_STATE" = "missing" ] && pip show torch > /dev/null 2>&1; then
    TORCH_STATE="broken"
  fi
  case "$TORCH_STATE" in
    missing)
      echo "== torch not found in .venv -> installing torch 2.6.0 ($TORCH_BUILD build) =="
      pip install "torch==2.6.0" --index-url "$TORCH_INDEX_URL" || {
        echo "ERROR: torch installation failed. Install it manually (see docs/GPU_GUIDE.md)."; exit 1; }
      ;;
    "$TORCH_BUILD")
      echo "[OK] reusing the existing $TORCH_BUILD torch build (no reinstall, no duplicates)"
      ;;
    *)
      echo "== replacing the installed $TORCH_STATE torch build with the $TORCH_BUILD build =="
      pip uninstall -y torch
      pip install "torch==2.6.0" --index-url "$TORCH_INDEX_URL" || {
        echo "ERROR: torch installation failed. Install it manually (see docs/GPU_GUIDE.md)."; exit 1; }
      ;;
  esac
  pip install -r requirements-local-model.txt

  # Real verification (never a fake success message):
  #   0 OK / 1 CUDA requested but not visible / 2 torch missing / 3 model extra broken / 4 torch broken
  echo "== verifying the installed torch for real (torch.cuda.is_available()) =="
  set +e
  python scripts/check_torch.py --"$TORCH_BUILD" --check-model-extra
  TORCH_CHECK_RC=$?
  set -e
  if [ "$TORCH_CHECK_RC" -ne 0 ]; then
    if [ "$TORCH_BUILD" = "cuda" ]; then
      echo "ERROR: the CUDA torch install cannot see the GPU (check exit $TORCH_CHECK_RC)."
      echo "       Fix the driver/build as printed above, or rerun with --cpu for a CPU install:"
      echo "         bash scripts/install.sh --with-model --cpu"
    else
      echo "ERROR: the local-model extra failed its verification (check exit $TORCH_CHECK_RC)."
    fi
    exit 1
  fi
fi

# 4. Environment file --------------------------------------------------------------
if [ ! -f .env ]; then
  cp .env.example .env
  # Development-friendly defaults so the first run works without editing code.
  # Python is used instead of `sed -i` so the script also works on macOS/BSD sed.
  python3 - "$PROJECT_DIR" <<'PY'
import secrets, sys
from pathlib import Path
env = Path(sys.argv[1]) / ".env"
text = env.read_text(encoding="utf-8")
text = text.replace("APP_ENV=production", "APP_ENV=development", 1)
text = text.replace("REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARACTERS", secrets.token_urlsafe(48))
env.write_text(text, encoding="utf-8")
PY
  echo "[OK] created .env with generated secrets (development defaults)"
else
  echo "[OK] keeping existing .env"
fi

# 5. Model check --------------------------------------------------------------------
if [ "$WITH_MODEL" = true ]; then
  echo "== checking local weights =="
  python3 scripts/verify_weights.py || true
fi

echo
echo "Install complete. Next steps:"
echo "  1. (local model only) put the safetensors files into models/Qwen2.5-Coder-14B-Instruct/"
echo "     and set LOCAL_INFERENCE=true in .env"
echo "  2. bash scripts/start.sh"
echo "  3. open http://127.0.0.1:8080"
