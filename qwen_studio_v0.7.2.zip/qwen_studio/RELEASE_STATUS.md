# Release status — Qwen Studio 0.7.2 (single-user local workspace)

## What this release is

A **single-user, self-hosted local AI coding workspace**. There is no account system by
design: no login, registration, sessions, roles or billing. The app opens directly on the
workspace and binds to loopback unless remote access is explicitly enabled. Local inference
runs the operator-supplied Qwen2.5-Coder-14B-Instruct safetensors weights through the
bundled loopback engine; an external OpenAI-compatible endpoint remains an optional
fallback.

## Verified in the build environment (see VALIDATION.md for the full evidence)

- Release gate `scripts/verify_all.sh`: **all gates PASS** — 301 pytest tests, JS syntax,
  compileall, consistency (version 0.7.2 across app/health/CHANGELOG/VALIDATION/README),
  dependency pins, release-tree check, shell syntax. Final pre-release audit round (see
  the top of VALIDATION.md): weights exclusion now enforced by the packaging gate
  (`.gitignore`/`.gitattributes`/`check_release.py`), runner orphan containers reaped on
  timeout, static-publish containment hardened, client/runner/nginx timeout chain made
  coherent, live model-manager E2E 14/14 PASS against the real Hugging Face Hub, scripted
  agent E2E 7/7 PASS through the real `/api/chat` loop, live Playwright UI check PASS
  (real Hub manifest 27.5 GiB / 15 files; disk precheck honestly refuses). NOT TESTED
  here: Windows CMD, real GPU, Docker daemon, real-host nginx/TLS.
- **Model manager (0.7.2):** the studio UI's **Model** button downloads the official
  `Qwen/Qwen2.5-Coder-14B-Instruct` checkpoint from the Hugging Face Hub on explicit user
  request only — resumable across connection drops (ETag-validated HTTP Range into `.part`
  files, finished files never re-downloaded), progress percent/speed/remaining/ETA, disk
  precheck, SHA-256 verification of every LFS shard against the repository manifest plus
  shard completeness from `model.safetensors.index.json`, automatic `LOCAL_INFERENCE=true`
  binding (`.env` write + in-process engine start), existing-checkpoint path binding,
  retry, delete-with-confirmation. Verified for real in this environment: a genuine tiny
  Qwen2 checkpoint downloaded end-to-end through the production code path from
  huggingface.co, pause/resume mid-download with byte-exact resume offsets, checksum
  mismatch healing, executables/scripts refused by the manifest filter, the real engine
  loading the downloaded weights on CPU (`device=cpu`), standalone token generation from
  the downloaded weights, and the UI dialog exercised live in a browser. The full 14B
  download itself (~27.5 GiB, 6 shards) is listed by the real Hub API and refused cleanly
  when disk space is insufficient (7.8 GiB free here).
- Windows installer (0.7.2 patch): `install.bat` is pure CMD with correct delayed
  expansion (no stale `%VAR%` reads inside blocks), no PowerShell dependency, torch
  **pinned to 2.6.0** — the newest release on the official cu124 wheel index — across
  `install.sh` / `install.bat` / `Dockerfile`. Real execution in real CMD/Windows CI is
  NOT RUN here (no Windows); 18 structural contract tests pin the CMD semantics, and the
  identical Linux logic ran end-to-end for real (torch 2.6.0+cpu + full model extra +
  real verification PASS + engine smoke on the fresh install).
- Install path verified in this environment: the CPU torch install from the official CPU
  wheel index into a clean venv followed by `scripts/check_torch.py --cpu --check-model-extra`
  (real imports of torch, transformers, bitsandbytes, ...). The `--cuda` path was exercised
  as an honest control test WITHOUT a GPU: `check_torch.py --cuda` correctly FAILS with
  `torch.cuda.is_available() = False` instead of faking success. A real-GPU CUDA install
  remains NOT RUN (no GPU here).
- Docker dependency contract pinned by tests: the model extra resolves transformers'
  full runtime set (no `--no-deps`), `pip check` runs in both image stages, runner image
  pins match the application pins, compose passes GPU only to `app-gpu`, weights mount
  read-only and the internal inference port stays unpublished. **Image builds themselves
  are NOT RUN here (`docker: command not found`).**
- Real-engine benchmark `scripts/bench_local_model.py` against genuine
  Qwen2.5-0.5B-Instruct safetensors: **11/11 structural gates** (load, chat, code
  generation, function calling, agent tool call, malformed-history handling, streaming
  rejection, long context, RAM, restart). CPU-only environment: **no GPU here**.
- Deterministic agent full-cycle E2E through the real `/api/chat` tool loop: files written
  and a deliberate bug fixed **on disk** — ALL PASS.
- Terminal/preview API behavior with the runner offline: honest 503s, strict profile
  whitelist, preview cross-project isolation verified.
- Account-removal structural scan: **CLEAN**; all `/api/auth/*` routes answer 404.
- Security spot-checks: headers, Origin/Sec-Fetch-Site rejection, path-traversal block,
  rate limiter; compose mounts no Docker socket into the app service.
- Smoke test `scripts/smoke_test.py`: 4 PASS / 3 FAIL / 2 SKIP — the failures are the
  sandbox-dependent and real-model-dependent steps, impossible without Docker/14B here.

## NOT verified here — requires real hardware (be explicit before deploying)

- **CUDA on a real NVIDIA GPU:** the CUDA torch install, `torch.cuda.is_available() == True`
  on real hardware, CUDA bf16/int8/int4 execution and 14B VRAM behavior. Run on the GPU
  host: `bash scripts/install.sh --with-model --cuda` (or `check_torch.py --cuda` after a
  manual install) — it verifies for real and fails loudly when the GPU is not visible.
- **Windows `install.bat` in real CMD/Windows CI:** no Windows environment here (Linux, no
  wine). The installer's CMD semantics are pinned by `tests/test_install_windows_patch.py`
  (block-scoped delayed expansion, no stale variables, pip error checks, PowerShell-free,
  quoting/pin consistency) and the shared logic (`install.sh`, `check_torch.py`, pins) ran
  for real on Linux — but the .bat itself must be executed once on Windows:
  `scripts\install.bat --with-model --cpu` and `scripts\install.bat --with-model --cuda`.
- **Qwen2.5-Coder-14B-Instruct quality/VRAM/latency:** no GPU and no 14B weights in the
  build environment. Run on the GPU host: `python scripts/verify_weights.py`, then
  `python scripts/bench_local_model.py --model-dir models/Qwen2.5-Coder-14B-Instruct --json bench-14b.json`,
  then `python scripts/eval_agent.py`.
- **Docker Engine / gVisor sandbox execution:** image builds (`docker compose build`,
  in-image `pip check` + import smoke test), runner connection, live container terminal
  runs, no-network policy, container isolation and crash/restart handling, and
  `scripts/check_torch.py --cuda` inside `app-gpu`. `scripts/docker_check.sh` reports
  `docker: command not found` here.
- Nginx/TLS topology, wildcard DNS, Verdaccio live installs, production backup drills,
  independent penetration test and sandbox-escape testing.

## Release decision

Publishable as an open-source **single-user local workspace** under MIT. Not a certified
public hosted service: there is nothing to log into, so network exposure must be protected
by an authenticating TLS proxy plus server-side controls, the runner host must stay
dedicated and disposable, and gVisor is defense in depth — not a substitute for that
separation or independent security testing.

## First steps

1. Read `START_HERE_AR.md` (Arabic quick start) or `README.md`.
2. Local mode: put the 14B weights under `models/Qwen2.5-Coder-14B-Instruct/`, set
   `LOCAL_INFERENCE=true`, run `python3 scripts/verify_weights.py`, then
   `scripts/start.sh` — the workspace opens with no login.
3. Docker mode: install Docker + gVisor `runsc` on a dedicated Linux host, run
   `python3 deploy/prepare_env.py`, configure `.env`, then `./deploy/deploy.sh`.
4. On the GPU host run the benchmark and the agent evaluation above before trusting the
   deployment for real coding work.
