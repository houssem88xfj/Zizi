"""Local model download / verify / bind manager for Qwen Studio.

Adds a user-triggered, resumable downloader for the official
``Qwen/Qwen2.5-Coder-14B-Instruct`` checkpoint on the Hugging Face Hub, target
directory ``models/<LOCAL_MODEL_NAME>/`` (or a custom ``LOCAL_MODEL_DIR``).

Design rules:
- Nothing downloads automatically: a download only starts when the user presses
  the button (API call). The installers never fetch weights.
- Downloads use the official Hugging Face Hub URL scheme (``hf_hub_url``) with
  ETag-validated HTTP ``Range`` requests into ``<file>.part`` files that are
  atomically renamed on completion, so a dropped connection resumes from the
  saved offset instead of re-downloading finished files. Bytes are streamed
  with ``requests``/urllib3, which surfaces network bytes immediately and only
  loses the single in-flight chunk when a connection breaks.
- Only model artefacts are fetched (``.safetensors``, ``.json``, ``.txt``,
  ``.jinja``, ``.md`` plus ``LICENSE``/``NOTICE``). Executables, archives,
  scripts and binaries are never downloaded, and nothing is ever uploaded:
  the manager performs GET/HEAD requests only and never sends user files,
  project files or credentials to the Hub (public repositories need no token,
  so no token is read, stored or transmitted).
- After a successful download the files are verified locally (config parses,
  tokenizer present, every shard referenced by ``model.safetensors.index.json``
  exists, LFS SHA-256 checked during download). Verification also works
  offline for checkpoints that were placed on disk manually.
- A successful verification binds the model: ``LOCAL_INFERENCE=true`` (and,
  when needed, ``LOCAL_MODEL_DIR``) is written to ``.env`` and the bundled
  loopback engine is started in-process when possible. Clear states are
  reported: not installed / downloading / paused / incomplete / verifying /
  ready / loading / load failed.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests

from . import config as config_module

logger = logging.getLogger("qwen_studio.model_manager")

DEFAULT_REPO_ID = "Qwen/Qwen2.5-Coder-14B-Instruct"
# Tests and local mirrors can point the manager at another endpoint; the
# official Hugging Face Hub endpoint is also honoured via the HF_ENDPOINT env.
HUB_ENDPOINT: str | None = None
ENV_PATH: Path = config_module.BASE_DIR / ".env"

DOWNLOAD_CHUNK_BYTES = 1024 * 1024
# Byte-stream read granularity for the download loop. urllib3 surfaces the
# network bytes in chunks of this size as they arrive, so an interrupted
# transfer loses at most one in-flight chunk: everything already written to
# the .part file survives, and Range resume continues from that offset.
STREAM_CHUNK_BYTES = 64 * 1024
READ_TIMEOUT_SECONDS = 30.0
CONNECT_TIMEOUT_SECONDS = 10.0
MAX_ATTEMPTS_PER_FILE = 6
RETRY_BACKOFF_SECONDS = (2.0, 4.0, 8.0, 15.0, 30.0, 60.0)
# Headroom on top of the exact bytes still missing: filesystem block overhead
# plus the transient double-counting while a .part file is renamed into place.
DISK_MARGIN_FRACTION = 0.02
DISK_MARGIN_MIN_BYTES = 512 * 1024 * 1024

ALLOWED_EXTENSIONS = {".safetensors", ".json", ".txt", ".jinja", ".md"}
ALLOWED_BARE_NAMES = {"LICENSE", "NOTICE"}
FORBIDDEN_EXTENSIONS = {".bin", ".exe", ".dll", ".so", ".pyd", ".bat", ".cmd",
                        ".ps1", ".sh", ".py", ".whl", ".zip", ".tar", ".gz",
                        ".7z", ".rar", ".jar", ".pem", ".key", ".p12", ".pfx"}

# Required for the local engine to load a checkpoint (mirrors what
# inference/engine.py and transformers actually read from the directory).
REQUIRED_FILES = ("config.json",)
TOKENIZER_ALTERNATIVES = ("tokenizer.json", "vocab.json")


class ModelManagerError(Exception):
    """User-presentable failure with a suggested fix."""


class DownloadActiveError(ModelManagerError):
    pass


class NonRetryableDownloadError(ModelManagerError):
    """Download failure that cannot heal by retrying the same file."""


class _DownloadCancelled(Exception):
    """Internal control flow: the user cancelled mid-file."""


@dataclass
class RemoteFile:
    name: str
    size: int
    sha256: str | None = None


@dataclass
class DownloadState:
    """Mutable download state machine; guarded by ModelManager._lock."""
    phase: str = "idle"  # idle|fetching_manifest|downloading|verifying|done|paused|error
    repo_id: str = ""
    error: str | None = None
    suggestions: list[str] = field(default_factory=list)
    manifest: list[RemoteFile] = field(default_factory=list)
    completed: set[str] = field(default_factory=set)
    current_file: str | None = None
    downloaded_bytes: int = 0
    total_bytes: int = 0
    speed_bps: float = 0.0
    eta_seconds: float | None = None
    started_at: float | None = None
    updated_at: float | None = None
    cancelled: bool = False


def default_repo_id() -> str:
    return os.getenv("QWEN_MODEL_REPO_ID", "").strip() or DEFAULT_REPO_ID


def model_target_dir() -> Path:
    """Current model directory the engine uses (never creates directories)."""
    return Path(config_module.LOCAL_MODEL_DIR).resolve()


def model_name() -> str:
    return config_module.LOCAL_MODEL_NAME


def _hub_endpoint() -> str | None:
    if HUB_ENDPOINT:
        return HUB_ENDPOINT
    env_endpoint = os.getenv("HF_ENDPOINT", "").strip().rstrip("/")
    return env_endpoint or None


def _hub_url(repo_id: str, filename: str) -> str:
    """Official Hub resolve URL: {endpoint}/{repo_id}/resolve/main/{filename}.

    Built directly from the documented, stable URL scheme instead of
    ``hf_hub_url`` so the downloader stays correct across huggingface_hub
    major versions (its helper signature changed in 2.x). ``HfApi`` is still
    used for the manifest, which is the part that genuinely benefits from
    the library.
    """
    endpoint = (_hub_endpoint() or "https://huggingface.co").rstrip("/")
    return f"{endpoint}/{repo_id}/resolve/main/{filename}"


def _short(exc: Exception, limit: int = 180) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return text[:limit]


def _sanitize_manifest_name(name: str) -> str:
    """Reject anything that is not a plain relative path inside the target dir."""
    if not name or name.startswith(("/", "\\")) or "\x00" in name or "\\" in name:
        raise ModelManagerError(f"Refusing unsafe file name reported by the Hub: {name!r}.")
    parts = Path(name).parts
    if any(part in {"", ".", ".."} for part in parts) or any(part != part.strip() for part in parts):
        raise ModelManagerError(f"Refusing unsafe file name reported by the Hub: {name!r}.")
    return name


def _manifest_allowed(name: str) -> bool:
    lower = name.lower()
    if Path(lower).name == ".gitattributes":
        return False
    suffix = Path(lower).suffix
    if suffix in FORBIDDEN_EXTENSIONS:
        return False
    return suffix in ALLOWED_EXTENSIONS or Path(lower).name in {item.lower() for item in ALLOWED_BARE_NAMES}


def fetch_remote_manifest(repo_id: str) -> list[RemoteFile]:
    """File list + sizes (+ LFS SHA-256) from the official Hub API."""
    try:
        from huggingface_hub import HfApi  # lazy import; huggingface_hub ships with requirements.txt
    except ImportError as exc:  # pragma: no cover - guaranteed present via requirements.txt
        raise ModelManagerError(
            "The download feature needs huggingface_hub: pip install huggingface_hub"
        ) from exc
    try:
        api = HfApi(endpoint=_hub_endpoint())
        info = api.model_info(repo_id, files_metadata=True)
    except Exception as exc:  # noqa: BLE001 - surfaced as a user-presentable error
        raise ModelManagerError(
            f"Could not reach the Hugging Face Hub for repository {repo_id} ({_short(exc)}). "
            "Check the internet connection and that the repository name is correct, then try again."
        ) from exc
    files: list[RemoteFile] = []
    for sibling in info.siblings:
        raw = getattr(sibling, "rfilename", None)
        if not raw:
            continue
        name = _sanitize_manifest_name(raw)
        if not _manifest_allowed(name):
            logger.debug("Skipping non-model file reported by the Hub: %s", name)
            continue
        size = int(getattr(sibling, "size", 0) or 0)
        lfs = getattr(sibling, "lfs", None)
        sha = getattr(lfs, "sha256", None) if lfs is not None else None
        files.append(RemoteFile(name=name, size=size, sha256=sha))
    if not files:
        raise ModelManagerError(
            f"Repository {repo_id} contains no downloadable model files. "
            "Check QWEN_MODEL_REPO_ID; the default is Qwen/Qwen2.5-Coder-14B-Instruct."
        )
    return files


def _nearest_existing_ancestor(path: Path) -> Path:
    cursor = path
    while not cursor.exists():
        parent = cursor.parent
        if parent == cursor:
            break
        cursor = parent
    return cursor


def check_disk_space(target_dir: Path, required_bytes: int) -> tuple[bool, int]:
    """(enough_free, free_bytes) for the filesystem that will hold ``target_dir``."""
    anchor = _nearest_existing_ancestor(target_dir)
    free = shutil.disk_usage(anchor).free
    margin = max(DISK_MARGIN_MIN_BYTES, int(required_bytes * DISK_MARGIN_FRACTION))
    return free >= required_bytes + margin, free


def local_file_inventory(target_dir: Path) -> dict[str, int]:
    """name -> size for completed files in the model dir (.part/.tmp excluded)."""
    inventory: dict[str, int] = {}
    if not target_dir.is_dir():
        return inventory
    for path in target_dir.rglob("*"):
        if path.is_file():
            rel = path.relative_to(target_dir).as_posix()
            if rel.endswith(".part") or rel.endswith(".tmp"):
                continue
            try:
                inventory[rel] = path.stat().st_size
            except OSError:
                continue
    return inventory


def partial_file_list(target_dir: Path) -> list[str]:
    if not target_dir.is_dir():
        return []
    return sorted(p.relative_to(target_dir).as_posix()
                  for p in target_dir.rglob("*.part") if p.is_file())


def _shards_expected_by_index(index_path: Path) -> set[str]:
    try:
        payload = json.loads(index_path.read_text(encoding="utf-8"))
        weight_map = payload.get("weight_map") or {}
        return {str(value) for value in weight_map.values()}
    except (OSError, ValueError, TypeError, AttributeError):
        return set()


def verify_local(target_dir: Path, manifest: list[RemoteFile] | None = None,
                 repo_id: str | None = None) -> dict[str, Any]:
    """Offline file verification. Never touches the network.

    Checks: config.json parses and declares an architecture, tokenizer files
    are present, at least one safetensors shard exists, every shard referenced
    by model.safetensors.index.json is on disk, and (when a remote manifest is
    supplied) each file matches the published size exactly.
    """
    reasons: list[str] = []
    suggestions: list[str] = []
    inventory = local_file_inventory(target_dir)

    if not inventory:
        return {
            "valid": False,
            "state": "not_installed",
            "target_dir": str(target_dir),
            "missing": [],
            "corrupt": [],
            "partial": partial_file_list(target_dir),
            "files": {},
            "total_bytes": 0,
            "reasons": [f"No model files found in {target_dir}."],
            "suggestions": ["Download the model from the Model page, or point the model path "
                            "at an existing checkpoint directory."],
        }

    # 1) config.json must exist and describe a model architecture.
    config_path = target_dir / "config.json"
    architectures: list[str] = []
    if not config_path.is_file():
        reasons.append("config.json is missing.")
    else:
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
            architectures = list(payload.get("architectures") or [])
            if not architectures:
                reasons.append("config.json does not declare any model architectures.")
        except (OSError, ValueError) as exc:
            reasons.append(f"config.json is unreadable or not valid JSON ({_short(exc)}).")
            suggestions.append("Re-download the model; config.json is part of the official checkpoint.")

    # 2) tokenizer files.
    if not any((target_dir / candidate).is_file() for candidate in TOKENIZER_ALTERNATIVES):
        reasons.append("No tokenizer files found (tokenizer.json or vocab.json required).")
        suggestions.append("Resume the download so the tokenizer files are fetched.")

    # 3) weights present and complete.
    safetensors = sorted(name for name in inventory if name.endswith(".safetensors"))
    if not safetensors:
        reasons.append("No .safetensors weight files found.")
        suggestions.append("Download the model; weights are distributed as .safetensors shards.")
    index_name = "model.safetensors.index.json"
    if (target_dir / index_name).is_file():
        expected_shards = _shards_expected_by_index(target_dir / index_name)
        missing_shards = sorted(shard for shard in expected_shards if shard not in inventory)
        if missing_shards:
            reasons.append("Shard(s) referenced by model.safetensors.index.json are missing: "
                           + ", ".join(missing_shards))
            suggestions.append("Resume the download so every listed shard completes.")

    # 4) leftover partial files mean an interrupted download.
    partial = partial_file_list(target_dir)
    if partial:
        reasons.append("Interrupted download detected (partial file(s): " + ", ".join(partial) + ").")
        suggestions.append("Press Download again to resume from the saved progress.")

    # 5) when a remote manifest is known, sizes must match exactly.
    corrupt: list[str] = []
    missing: list[str] = []
    if manifest:
        for entry in manifest:
            size = inventory.get(entry.name)
            if size is None:
                missing.append(entry.name)
            elif entry.size and size != entry.size:
                corrupt.append(entry.name)
        if missing:
            reasons.append("File(s) missing from the repository manifest: " + ", ".join(missing))
            suggestions.append("Resume the download to fetch the missing file(s).")
        if corrupt:
            reasons.append("File size mismatch for: " + ", ".join(corrupt))
            suggestions.append("Delete the model files and download again to replace corrupted files.")

    valid = not reasons
    return {
        "valid": valid,
        "state": "ready" if valid else "incomplete",
        "target_dir": str(target_dir),
        "repo_id": repo_id,
        "architectures": architectures,
        "missing": missing,
        "corrupt": corrupt,
        "partial": partial,
        "files": inventory,
        "total_bytes": sum(inventory.values()),
        "reasons": reasons,
        "suggestions": suggestions,
    }


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(DOWNLOAD_CHUNK_BYTES)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _write_env_file(set_values: dict[str, str], comment_out: list[str]) -> list[str]:
    """Line-based .env editor that preserves unrelated content.

    Returns a human-readable list of applied changes. Keys listed in
    ``comment_out`` are turned into comments with the previous value kept, so
    the change stays reversible by hand.
    """
    path = Path(ENV_PATH)
    lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    changes: list[str] = []
    remaining_comment = list(comment_out)
    pending = dict(set_values)
    for index, line in enumerate(lines):
        stripped = line.strip()
        key = stripped.split("=", 1)[0].strip() if "=" in stripped else ""
        if key in pending and not stripped.startswith("#"):
            lines[index] = f"{key}={pending[key]}"
            changes.append(f"{key}={pending[key]}")
            pending.pop(key)
        elif key in remaining_comment and not stripped.startswith("#"):
            lines[index] = f"# disabled by model manager (local model enabled): {line}"
            changes.append(f"commented out {key} (previous value kept in the comment)")
            remaining_comment.remove(key)
    for key, value in pending.items():
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"{key}={value}")
        changes.append(f"{key}={value} (appended)")
    for key in remaining_comment:
        changes.append(f"{key} was already inactive; nothing to comment out")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return changes


def activate_runtime(target_dir: Path, model_name_value: str) -> dict[str, Any]:
    """Point the running process at the verified local model, best effort.

    Applies the same configuration a restart with ``LOCAL_INFERENCE=true``
    would produce, then starts the bundled loopback engine. Never raises:
    activation trouble is reported so the operator can simply restart.
    """
    result: dict[str, Any] = {"runtime_activated": False, "restart_required": False, "detail": ""}
    try:
        from inference.server import start_local_inference  # top-level sibling package

        from . import agent as agent_module
        from .app import agent as app_agent

        loopback = f"http://{config_module.LOCAL_INFERENCE_HOST}:{config_module.LOCAL_INFERENCE_PORT}/v1"
        config_module.LOCAL_INFERENCE = True
        config_module.MODEL_BASE_URL = loopback
        config_module.MODEL_NAME = model_name_value
        agent_module.MODEL_BASE_URL = loopback
        agent_module.MODEL_NAME = model_name_value
        # backend/app.py imported these config values by name at import time;
        # update its bindings too so /api/system/status reports the local engine
        # (model.local) without waiting for a restart.
        import backend.app as app_module
        app_module.LOCAL_INFERENCE = True
        if app_agent is not None:
            app_agent.client = None  # rebuilt lazily against the loopback engine
        start_local_inference(
            model_dir=str(target_dir),
            model_name=model_name_value,
            host=config_module.LOCAL_INFERENCE_HOST,
            port=config_module.LOCAL_INFERENCE_PORT,
            device=config_module.LOCAL_MODEL_DEVICE,
            quantization=config_module.LOCAL_MODEL_QUANTIZATION,
            max_context_tokens=config_module.LOCAL_MODEL_MAX_CONTEXT_TOKENS,
            max_new_tokens_cap=config_module.MODEL_MAX_TOKENS,
        )
        result["runtime_activated"] = True
        result["detail"] = f"Local inference engine started on {loopback}."
        return result
    except Exception as exc:  # noqa: BLE001 - never break the API on activation trouble
        result["restart_required"] = True
        result["detail"] = (
            f"Could not start the engine in the running process ({_short(exc, 220)}). "
            "LOCAL_INFERENCE=true was saved; restart Qwen Studio to load the model."
        )
        logger.warning("Local model runtime activation failed: %s", exc)
        return result


def bind_verified_model(target_dir: Path, model_name_value: str | None = None) -> dict[str, Any]:
    """Persist the binding in .env and activate the engine when possible."""
    model_name_value = model_name_value or model_name()
    default_dir = (config_module.BASE_DIR / "models" / model_name_value).resolve()
    set_values = {"LOCAL_INFERENCE": "true"}
    comment_out: list[str] = []
    if Path(target_dir).resolve() != default_dir:
        set_values["LOCAL_MODEL_DIR"] = str(Path(target_dir).resolve())
    base_url_env = os.getenv("MODEL_BASE_URL", "").strip()
    parsed = base_url_env.lower()
    if base_url_env and "example" not in parsed and "127.0.0.1" not in parsed and "localhost" not in parsed:
        # An explicit external endpoint would win over the local engine; keep the
        # previous value as a comment so switching back stays a one-line edit.
        comment_out.append("MODEL_BASE_URL")
    changes = _write_env_file(set_values, comment_out)
    binding = {
        "env_file": str(Path(ENV_PATH)),
        "env_changes": changes,
        "local_inference_enabled": True,
        "external_endpoint_commented": "MODEL_BASE_URL" in comment_out,
    }
    if comment_out:
        binding["previous_model_base_url"] = base_url_env
    binding.update(activate_runtime(target_dir, model_name_value))
    return binding


class ModelManager:
    """Single-user download state machine (one active download at a time)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state = DownloadState()
        self._thread: threading.Thread | None = None
        self._cancel_event = threading.Event()
        self._last_verify: dict[str, Any] | None = None
        self._last_binding: dict[str, Any] | None = None
        self._remote_cache: dict[str, Any] | None = None
        self._session_started_monotonic = 0.0
        self._session_base_bytes = 0

    # ------------------------------------------------------------------ status

    def status(self) -> dict[str, Any]:
        target_dir = model_target_dir()
        name = model_name()
        inventory = local_file_inventory(target_dir)
        partials = partial_file_list(target_dir)
        files_state = "present" if inventory else "not_installed"
        total_on_disk = sum(inventory.values())
        with self._lock:
            state = self._state
            progress = {
                "phase": state.phase,
                "repo_id": state.repo_id or default_repo_id(),
                "total_bytes": state.total_bytes,
                "downloaded_bytes": state.downloaded_bytes,
                "percent": round(100.0 * state.downloaded_bytes / state.total_bytes, 1)
                           if state.total_bytes else 0.0,
                "speed_bps": round(state.speed_bps, 1),
                "eta_seconds": state.eta_seconds,
                "current_file": state.current_file,
                "files_done": len(state.completed),
                "files_total": len(state.manifest),
                "error": state.error,
                "suggestions": list(state.suggestions),
                "started_at": state.started_at,
                "updated_at": state.updated_at,
            }
            remote_summary = None
            if self._remote_cache and self._remote_cache.get("repo_id") == state.repo_id:
                remote_summary = self._remote_cache
        engine_info = self._engine_status()
        try:
            disk_free = shutil.disk_usage(_nearest_existing_ancestor(target_dir)).free
        except OSError:
            disk_free = 0
        missing_required = self._missing_required(inventory, target_dir)
        derived = self._derive_state(files_state, progress, engine_info, inventory, partials,
                                     missing_required)
        return {
            "state": derived,
            "model_name": name,
            "repo_id": progress["repo_id"],
            "target_dir": str(target_dir),
            "files_state": files_state,
            "files_on_disk": len(inventory),
            "bytes_on_disk": total_on_disk,
            "disk_free_bytes": disk_free,
            "partial_files": partials,
            "required_files_missing": missing_required,
            "progress": progress,
            "remote": remote_summary,
            "engine": engine_info,
            "model_extra_installed": self._model_extra_installed(),
            "verify": self._last_verify,
            "binding": self._last_binding,
        }

    @staticmethod
    def _derive_state(files_state: str, progress: dict[str, Any],
                      engine_info: dict[str, Any] | None, inventory: dict[str, int],
                      partials: list[str], missing_required: list[str]) -> str:
        phase = progress["phase"]
        if phase in {"downloading", "fetching_manifest"}:
            return "downloading"
        if phase == "verifying":
            return "verifying"
        engine_enabled = bool(engine_info and engine_info.get("enabled"))
        if engine_enabled:
            if engine_info.get("error"):
                return "load_failed"
            if engine_info.get("loaded"):
                return "ready"
            if engine_info.get("loading"):
                return "loading"
        if phase == "done":
            return "ready"
        if phase == "paused":
            return "paused"
        if partials and not inventory:
            return "paused"
        if not inventory:
            return "not_installed"
        if partials or missing_required:
            return "incomplete"
        return "present"  # files look complete but verify has not confirmed them yet

    @staticmethod
    def _missing_required(inventory: dict[str, int], target_dir: Path) -> list[str]:
        missing = [name for name in REQUIRED_FILES if name not in inventory]
        if not any(name.endswith(".safetensors") for name in inventory):
            missing.append("<*.safetensors weights>")
        if not any((target_dir / candidate).is_file() for candidate in TOKENIZER_ALTERNATIVES):
            missing.append("tokenizer.json (or vocab.json)")
        index_path = target_dir / "model.safetensors.index.json"
        if index_path.is_file():
            missing.extend(sorted(shard for shard in _shards_expected_by_index(index_path)
                                  if shard not in inventory))
        return missing

    @staticmethod
    def _engine_status() -> dict[str, Any] | None:
        try:
            from inference.server import get_engine  # top-level sibling package
        except Exception:  # noqa: BLE001 - engine module is always present; defensive only
            return None
        engine = get_engine()
        return dict(engine.status) if engine is not None else None

    @staticmethod
    def _model_extra_installed() -> bool:
        import importlib.util
        return (importlib.util.find_spec("torch") is not None
                and importlib.util.find_spec("transformers") is not None)

    # ------------------------------------------------------------------ remote

    def remote_info(self, repo_id: str | None = None) -> dict[str, Any]:
        """Manifest + feasibility preview for the confirmation dialog (network)."""
        repo_id = repo_id or default_repo_id()
        manifest = fetch_remote_manifest(repo_id)
        target_dir = model_target_dir()
        inventory = local_file_inventory(target_dir)
        already = sum(entry.size for entry in manifest
                      if inventory.get(entry.name) == entry.size)
        missing_bytes = sum(entry.size for entry in manifest
                            if inventory.get(entry.name) != entry.size)
        enough, free = check_disk_space(target_dir, missing_bytes)
        payload = {
            "repo_id": repo_id,
            "target_dir": str(target_dir),
            "files": [{"name": entry.name, "size": entry.size,
                       "sha256_known": entry.sha256 is not None} for entry in manifest],
            "total_bytes": sum(entry.size for entry in manifest),
            "already_downloaded_bytes": already,
            "remaining_bytes": missing_bytes,
            "disk_free_bytes": free,
            "disk_ok": enough,
        }
        with self._lock:
            self._remote_cache = {key: payload[key] for key in
                                  ("repo_id", "total_bytes", "remaining_bytes", "disk_ok")}
            self._state.repo_id = repo_id
        return payload

    # ---------------------------------------------------------------- download

    def start_download(self) -> dict[str, Any]:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                raise DownloadActiveError(
                    "A download is already running. Cancel it first if you want to restart.")
            self._cancel_event.clear()
            state = self._state
            state.phase = "fetching_manifest"
            state.error = None
            state.suggestions = []
            state.cancelled = False
            state.repo_id = default_repo_id()
            state.started_at = time.time()
            state.updated_at = state.started_at
            self._thread = threading.Thread(target=self._run, name="model-download", daemon=True)
            self._thread.start()
        return {"started": True, "repo_id": state.repo_id}

    def cancel(self) -> dict[str, Any]:
        with self._lock:
            alive = self._thread is not None and self._thread.is_alive()
            if not alive:
                raise ModelManagerError("No download is running.")
            self._cancel_event.set()
            self._state.suggestions = ["Download paused. Press Download again to resume."]
        return {"cancel_requested": True}

    def _set_phase(self, phase: str, error: str | None = None,
                   suggestions: list[str] | None = None) -> None:
        with self._lock:
            state = self._state
            state.phase = phase
            state.error = error
            state.suggestions = suggestions or []
            state.updated_at = time.time()

    def _run(self) -> None:
        state = self._state
        repo_id = default_repo_id()
        state.repo_id = repo_id
        self._session_started_monotonic = time.monotonic()
        self._session_base_bytes = 0
        try:
            manifest = fetch_remote_manifest(repo_id)
            inventory = local_file_inventory(model_target_dir())
            with self._lock:
                state.manifest = manifest
                state.total_bytes = sum(entry.size for entry in manifest)
                state.completed = {entry.name for entry in manifest
                                   if inventory.get(entry.name) == entry.size}
                state.downloaded_bytes = sum(entry.size for entry in manifest
                                             if inventory.get(entry.name) == entry.size)
                self._session_base_bytes = state.downloaded_bytes
                state.phase = "downloading"
                state.updated_at = time.time()
            self._download_all(manifest)
            if self._cancel_event.is_set():
                self._set_phase("paused", None, ["Download paused. Press Download again to resume."])
                return
            self._set_phase("verifying")
            result = verify_local(model_target_dir(), manifest, repo_id)
            self._last_verify = result
            if not result["valid"]:
                self._set_phase(
                    "error",
                    "Download finished but verification failed: " + " ".join(result["reasons"]),
                    result["suggestions"])
                return
            binding = bind_verified_model(model_target_dir())
            self._last_binding = binding
            self._set_phase("done", None, [])
            logger.info("Model %s downloaded, verified and bound to the local engine.", repo_id)
        except ModelManagerError as exc:
            self._set_phase("error", str(exc),
                            ["Fix the reported problem, then press Download again to resume."])
        except Exception as exc:  # noqa: BLE001 - background thread: report, never crash silently
            logger.exception("Model download failed")
            self._set_phase("error", f"Unexpected download failure: {_short(exc)}",
                            ["Press Download again to resume from saved progress."])

    def _download_all(self, manifest: list[RemoteFile]) -> None:
        target_dir = model_target_dir()
        inventory = local_file_inventory(target_dir)
        remaining_bytes = sum(entry.size for entry in manifest
                              if inventory.get(entry.name) != entry.size)
        enough, free = check_disk_space(target_dir, remaining_bytes)
        if not enough:
            raise ModelManagerError(
                f"Not enough disk space: downloading needs about {remaining_bytes / (1024 ** 3):.1f} GiB "
                f"plus headroom, but only {free / (1024 ** 3):.1f} GiB is free at {target_dir}. "
                "Free up space (or delete an old model) and try again."
            )
        for entry in manifest:
            if self._cancel_event.is_set():
                return
            final_path = target_dir / entry.name
            if inventory.get(entry.name) == entry.size:
                if not entry.sha256:
                    with self._lock:
                        self._state.completed.add(entry.name)
                    continue
                if _sha256_file(final_path) == entry.sha256:
                    with self._lock:
                        self._state.completed.add(entry.name)
                    continue
                # Pre-existing file with the wrong content: replace it.
                final_path.unlink(missing_ok=True)
                inventory.pop(entry.name, None)
            self._download_one(entry, target_dir)
        with self._lock:
            self._state.current_file = None

    def _download_one(self, entry: RemoteFile, target_dir: Path) -> None:
        with self._lock:
            self._state.current_file = entry.name
        part_path = target_dir / f"{entry.name}.part"
        if part_path.is_file() and part_path.stat().st_size > entry.size:
            part_path.unlink()  # stale partial from an older manifest
        last_error: Exception | None = None
        for attempt in range(MAX_ATTEMPTS_PER_FILE):
            if self._cancel_event.is_set():
                return
            try:
                self._stream_to_part(entry, target_dir, part_path)
                self._finalize_file(entry, target_dir, part_path)
                return
            except _DownloadCancelled:
                return
            except NonRetryableDownloadError:
                raise
            except ModelManagerError as exc:
                # Checksum mismatch and similar: the .part was removed; re-fetch helps.
                last_error = exc
                logger.warning("Download of %s failed (attempt %d/%d): %s",
                               entry.name, attempt + 1, MAX_ATTEMPTS_PER_FILE, exc)
            except Exception as exc:  # noqa: BLE001 - network layer: retry with backoff
                last_error = exc
                logger.warning("Download of %s failed (attempt %d/%d): %s",
                               entry.name, attempt + 1, MAX_ATTEMPTS_PER_FILE, exc)
            delay = RETRY_BACKOFF_SECONDS[min(attempt, len(RETRY_BACKOFF_SECONDS) - 1)]
            if self._cancel_event.wait(delay):
                return  # cancelled during the backoff sleep
        raise ModelManagerError(
            f"Could not download {entry.name} after {MAX_ATTEMPTS_PER_FILE} attempts "
            f"({_short(last_error) if last_error else 'unknown error'}). Downloaded parts are "
            "kept; check the internet connection and press Download again to resume."
        )

    def _stream_to_part(self, entry: RemoteFile, target_dir: Path, part_path: Path) -> None:
        target_dir.mkdir(parents=True, exist_ok=True)
        metadata = self._head_metadata(entry)
        expected_size = metadata["size"]
        if expected_size and entry.size and expected_size != entry.size:
            raise NonRetryableDownloadError(
                f"Server metadata mismatch for {entry.name} (manifest says {entry.size} bytes, "
                f"server reports {expected_size}). The repository may have changed; press "
                "Download again to refresh the manifest and resume."
            )
        resume_from = part_path.stat().st_size if part_path.is_file() else 0
        if resume_from and expected_size and resume_from >= expected_size:
            return  # the whole file is already buffered in the .part file
        headers = {"Accept": "application/octet-stream",
                   # identity: the bytes on the wire must equal the bytes on disk,
                   # otherwise gzip'd text files (tokenizer/vocab/merges) would be
                   # stored decompressed and neither the size nor the Range offset
                   # would match the repository manifest anymore.
                   "Accept-Encoding": "identity"}
        if resume_from:
            headers["Range"] = f"bytes={resume_from}-"
            headers["If-Range"] = metadata["etag"]
        with self._lock:
            self._state.current_file = entry.name
        with requests.Session() as client:
            with client.get(metadata["location"], stream=True, headers=headers,
                            timeout=(CONNECT_TIMEOUT_SECONDS, READ_TIMEOUT_SECONDS)) as response:
                if response.status_code == 200 and resume_from:
                    # If-Range mismatch: the file changed on the Hub; restart cleanly.
                    resume_from = 0
                    part_path.unlink(missing_ok=True)
                response.raise_for_status()
                mode = "ab" if resume_from else "wb"
                with part_path.open(mode) as sink:
                    for chunk in response.iter_content(chunk_size=STREAM_CHUNK_BYTES):
                        if self._cancel_event.is_set():
                            raise _DownloadCancelled()
                        if not chunk:
                            continue
                        sink.write(chunk)
                        self._record_progress(len(chunk))
        if expected_size and part_path.stat().st_size != expected_size:
            raise ModelManagerError(
                f"Incomplete transfer for {entry.name}: got {part_path.stat().st_size} of "
                f"{expected_size} bytes. Saved progress is kept; press Download again to resume."
            )

    def _head_metadata(self, entry: RemoteFile) -> dict[str, Any]:
        """Resolve the final download URL + validating metadata for one file.

        Follows the Hub's redirect chain and reads the FINAL response: its URL,
        ETag and Content-Length describe exactly the object the GET below will
        receive, so Range/If-Range resume stays consistent. The Hub may return
        relative Location headers (e.g. /api/resolve-cache/...), so redirects
        are followed instead of hand-parsing Location.
        """
        url = _hub_url(self._state.repo_id, entry.name)
        response = requests.head(url, allow_redirects=True,
                                 timeout=(CONNECT_TIMEOUT_SECONDS, READ_TIMEOUT_SECONDS),
                                 headers={"Accept-Encoding": "identity"})
        response.raise_for_status()
        location = str(response.url)
        etag = response.headers.get("ETag") or response.headers.get("X-Linked-ETag") or ""
        size = int(response.headers.get("X-Linked-Size")
                   or response.headers.get("Content-Length") or 0)
        if not etag:
            raise NonRetryableDownloadError(
                f"The server did not return an ETag for {entry.name}; refusing a download "
                "that cannot be validated against the repository revision."
            )
        return {"location": location, "etag": etag, "size": size}

    def _record_progress(self, chunk: int) -> None:
        now = time.monotonic()
        with self._lock:
            state = self._state
            state.downloaded_bytes += chunk
            elapsed = max(now - self._session_started_monotonic, 1e-6)
            session_bytes = max(state.downloaded_bytes - self._session_base_bytes, 0)
            instant = session_bytes / elapsed
            state.speed_bps = 0.7 * (state.speed_bps or instant) + 0.3 * instant
            remaining = max(0, state.total_bytes - state.downloaded_bytes)
            state.eta_seconds = remaining / state.speed_bps if state.speed_bps > 1 else None
            state.updated_at = time.time()

    def _finalize_file(self, entry: RemoteFile, target_dir: Path, part_path: Path) -> None:
        final_path = target_dir / entry.name
        if entry.sha256:
            actual = _sha256_file(part_path)
            if actual != entry.sha256:
                part_path.unlink(missing_ok=True)
                raise ModelManagerError(
                    f"Checksum mismatch for {entry.name}: the downloaded data does not match the "
                    "SHA-256 published by the repository. The partial data was deleted; "
                    "press Download again to re-fetch this file."
                )
        os.replace(part_path, final_path)  # atomic on POSIX and Windows
        with self._lock:
            self._state.completed.add(entry.name)

    # ----------------------------------------------------------------- actions

    def verify(self) -> dict[str, Any]:
        result = verify_local(model_target_dir(), None, default_repo_id())
        self._last_verify = result
        return result

    def bind_existing_path(self, raw_path: str) -> dict[str, Any]:
        candidate = Path(raw_path).expanduser()
        resolved = candidate.resolve()
        if not resolved.is_dir():
            raise ModelManagerError(f"{resolved} is not an existing directory.")
        result = verify_local(resolved, None, default_repo_id())
        self._last_verify = result
        if not result["valid"]:
            raise ModelManagerError(
                "The directory does not contain a usable checkpoint: " + " ".join(result["reasons"])
            )
        binding = bind_verified_model(resolved)
        self._last_binding = binding
        return {"verified": result, "binding": binding}

    def delete_model_files(self, confirm: bool) -> dict[str, Any]:
        if not confirm:
            raise ModelManagerError(
                "Deletion requires confirm=true; the model files are removed permanently.")
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                raise DownloadActiveError(
                    "A download is running. Cancel it before deleting the model files.")
        target_dir = model_target_dir()
        models_root = (config_module.BASE_DIR / "models").resolve()
        protected = {models_root, config_module.BASE_DIR.resolve(),
                     Path(config_module.WORKSPACE_DIR).resolve(),
                     Path(config_module.PUBLISH_DIR).resolve()}
        anchor = Path(target_dir.anchor or "/").resolve()
        if not target_dir.is_dir():
            raise ModelManagerError(f"Nothing to delete: {target_dir} does not exist.")
        if target_dir in protected or target_dir == anchor:
            raise ModelManagerError(
                f"Refusing to delete {target_dir}: it is not a single model directory.")
        deleted_bytes = sum(path.stat().st_size for path in target_dir.rglob("*")
                            if path.is_file() and not path.is_symlink())
        shutil.rmtree(target_dir)
        changes = _write_env_file({"LOCAL_INFERENCE": "false"}, [])
        self._last_binding = None
        self._last_verify = None
        with self._lock:
            self._state = DownloadState(repo_id=default_repo_id())
            self._remote_cache = None
        engine = self._engine_status() or {}
        engine_still_loaded = bool(engine.get("loaded"))
        logger.info("Deleted model files at %s (%.1f MiB); LOCAL_INFERENCE reset to false in .env",
                    target_dir, deleted_bytes / (1024 * 1024))
        return {"deleted": True, "path": str(target_dir), "bytes_removed": deleted_bytes,
                "env_changes": changes,
                "engine_still_loaded": engine_still_loaded,
                "detail": ("Model files deleted and LOCAL_INFERENCE=false saved to .env."
                           + (" The running engine still holds the weights in memory; "
                              "restart Qwen Studio to fully unload them." if engine_still_loaded else ""))}


_manager_singleton = ModelManager()


def get_manager() -> ModelManager:
    return _manager_singleton
