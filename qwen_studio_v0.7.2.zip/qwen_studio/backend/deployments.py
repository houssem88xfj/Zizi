from __future__ import annotations

import shutil
import uuid
from urllib.parse import urlsplit
from pathlib import Path

from .config import PUBLISH_DIR, PUBLISH_DOMAIN
from .db import create_deployment, list_deployments
from .projects import project_path
from .sandbox_client import build_static_project

ALLOWED_SUFFIXES = {
    ".html", ".htm", ".css", ".js", ".mjs", ".json", ".txt", ".xml", ".webmanifest",
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico", ".woff", ".woff2",
    ".ttf", ".otf", ".mp4", ".webm", ".mp3", ".wav", ".pdf",
}
BLOCKED_NAMES = {
    ".git", ".qwen-project.json", "node_modules", ".venv", "venv", "__pycache__",
    ".env", ".env.local", ".env.production", "secrets.json", "credentials.json",
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "id_rsa", "id_ed25519",
}
MAX_FILES = 1000
MAX_BYTES = 100 * 1024 * 1024


def _copy_public_tree(source: Path, target: Path) -> tuple[int, int]:
    count = 0
    total = 0
    source_root = source.resolve()
    target.mkdir(parents=True, exist_ok=False)
    for item in source.rglob("*"):
        rel = item.relative_to(source)
        if any(part.startswith(".") or part.lower() in BLOCKED_NAMES for part in rel.parts):
            continue
        if item.is_symlink():
            continue
        # Defence in depth: rglob can descend through a symlinked *directory*
        # planted out of band; refuse anything that resolves outside the project.
        try:
            if not item.resolve().is_relative_to(source_root):
                continue
        except OSError:
            continue
        if item.is_dir():
            continue
        if item.suffix.lower() not in ALLOWED_SUFFIXES:
            continue
        size = item.stat().st_size
        count += 1
        total += size
        if count > MAX_FILES:
            raise ValueError(f"Static publish is limited to {MAX_FILES} files.")
        if total > MAX_BYTES:
            raise ValueError("Static publish exceeds 100 MB.")
        destination = target / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(item, destination)
    if not (target / "index.html").is_file():
        raise ValueError("Static deployment requires an index.html file at the project root.")
    return count, total


def publish_project(project_id: str, public_base_url: str) -> dict:
    source = project_path(project_id)
    deployment_id = uuid.uuid4().hex
    slug = f"site-{deployment_id}"
    target = PUBLISH_DIR / slug
    try:
        count, total = _copy_public_tree(source, target)
        create_deployment(project_id, deployment_id, slug)
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        raise
    return {
        "id": deployment_id,
        "project_id": project_id,
        "slug": slug,
        "url": f"{urlsplit(public_base_url).scheme}://{slug}.{PUBLISH_DOMAIN}/",
        "files": count,
        "bytes": total,
        "hosting": "local-static",
        "note": "Published on this server only; this is not an external CDN or production deployment provider.",
    }


def deployments_for_workspace() -> list[dict]:
    """Return the workspace deployments with the public URL each slug is served on.

    Published sites are only reachable on `<slug>.<PUBLISH_DOMAIN>` subdomains, so the
    frontend must link `url` (never a legacy `/published/...` app-origin path).
    """
    from urllib.parse import urlsplit
    from .config import PUBLIC_BASE_URL

    scheme = (urlsplit(PUBLIC_BASE_URL).scheme or "http").lower()
    result = []
    for row in list_deployments():
        item = dict(row)
        item["url"] = f"{scheme}://{item['slug']}.{PUBLISH_DOMAIN}/"
        result.append(item)
    return result


def publish_built_project(project_id: str, public_base_url: str) -> dict:
    """Build a package-based project in the isolated runner and publish only static output."""
    project_path(project_id)  # validate the project before asking the runner to stage files
    deployment_id = uuid.uuid4().hex
    slug = f"site-{deployment_id}"
    result = build_static_project(project_id, slug)
    target = PUBLISH_DIR / slug
    if not (target / "index.html").is_file():
        shutil.rmtree(target, ignore_errors=True)
        raise ValueError("Build runner did not create a valid static site.")
    try:
        create_deployment(project_id, deployment_id, slug)
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        raise
    return {
        "id": deployment_id,
        "project_id": project_id,
        "slug": slug,
        "url": f"{urlsplit(public_base_url).scheme}://{slug}.{PUBLISH_DOMAIN}/",
        "hosting": "local-static",
        "build": result,
        "note": "Built in an isolated runner and hosted on this app server; not an external cloud/CDN deployment.",
    }
