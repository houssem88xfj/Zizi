from __future__ import annotations

import asyncio
import ipaddress
import logging
import mimetypes
import re
import time
import threading
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from . import db
from .agent import CodingAgent
from .config import (
    MAX_FILE_BYTES, PUBLISH_DIR,
    SANDBOX_RUNNER_TOKEN, SANDBOX_RUNNER_URL,
    PUBLIC_BASE_URL, PUBLISH_BASE_URL, PUBLISH_DOMAIN, PREVIEW_BASE_URL, PREVIEW_DOMAIN, MODEL_BASE_URL, MODEL_API_KEY, MODEL_NAME, MODEL_MAX_TOKENS, MODEL_CONTEXT_CHAR_BUDGET,
    MAX_CONCURRENT_CHATS, validate_runtime_config,
    LOCAL_INFERENCE, LOCAL_MODEL_DIR, LOCAL_MODEL_NAME, LOCAL_INFERENCE_HOST, LOCAL_INFERENCE_PORT,
    LOCAL_MODEL_DEVICE, LOCAL_MODEL_QUANTIZATION, LOCAL_MODEL_MAX_CONTEXT_TOKENS,
)
from .model_manager import (
    DownloadActiveError,
    ModelManagerError,
    bind_verified_model,
    get_manager,
    model_name,
    model_target_dir,
)
from .db import recent_messages, save_message, get_deployment_by_slug
from .deployments import publish_project, publish_built_project, deployments_for_workspace
from .projects import create_project, delete_project, get_project, list_projects, project_path, touch_project
from .quotas import record_agent_usage, reserve_chat_quota, reserve_deployment_quota, reserve_tool_call_quota, usage_today
from .sandbox_client import (SandboxUnavailable, run_project_check, start_project_preview, stop_project_preview,
                             project_preview_status, fetch_preview)
from .tools import workspace_context, write_file

@asynccontextmanager
async def lifespan(application: FastAPI):
    db.init_db()
    validate_runtime_config()
    if LOCAL_INFERENCE:
        from inference.server import start_local_inference  # top-level sibling package
        start_local_inference(
            model_dir=str(LOCAL_MODEL_DIR),
            model_name=LOCAL_MODEL_NAME,
            host=LOCAL_INFERENCE_HOST,
            port=LOCAL_INFERENCE_PORT,
            device=LOCAL_MODEL_DEVICE,
            quantization=LOCAL_MODEL_QUANTIZATION,
            max_context_tokens=LOCAL_MODEL_MAX_CONTEXT_TOKENS,
            max_new_tokens_cap=MODEL_MAX_TOKENS,
        )
    yield


app = FastAPI(title="Qwen Studio", version="0.7.2", lifespan=lifespan)
# 0 = unlimited concurrency: keep a generous safety ceiling instead of a hard cap.
CHAT_EXECUTION_SLOTS = threading.BoundedSemaphore(MAX_CONCURRENT_CHATS if MAX_CONCURRENT_CHATS > 0 else 256)
agent = CodingAgent()
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/assets", StaticFiles(directory=FRONTEND_DIR), name="assets")
API_ATTEMPTS: dict[str, deque[float]] = defaultdict(deque)
CHAT_ATTEMPTS: dict[str, deque[float]] = defaultdict(deque)
_RATE_CLEANUP_LOCK = threading.Lock()
_RATE_CLEANUP_INTERVAL = 60.0
_last_rate_cleanup = 0.0
_FORWARDED_HEADERS_NOT_APPLIED: deque[float] = deque()
_FORWARDED_DIAGNOSTIC_WARNING_AT = 0.0
_FORWARDED_DIAGNOSTIC_LOCK = threading.Lock()
logger = logging.getLogger("qwen_studio.proxy_headers")

# Qwen Studio is a single-user local workspace without accounts, logins or session
# cookies. HSTS is only advertised when the configured public origin is HTTPS.
TLS_PUBLIC_ORIGIN = PUBLIC_BASE_URL.lower().startswith("https")


def _record_forwarded_headers_not_applied(scope: dict, forwarded_for: str | None,
                                          now: float | None = None) -> None:
    """Detect an XFF header that Uvicorn did not apply to the ASGI client address."""
    global _FORWARDED_DIAGNOSTIC_WARNING_AT
    if not forwarded_for:
        return
    peer = scope.get("client")
    if not peer or not peer[0]:
        return
    client_ip = str(peer[0]).strip()
    try:
        address = ipaddress.ip_address(client_ip)
    except ValueError:
        return
    if not (address.is_private or address.is_loopback):
        return
    forwarded_entries = [item.strip() for item in forwarded_for.split(",") if item.strip()]
    if not forwarded_entries or client_ip in {forwarded_entries[0], forwarded_entries[-1]}:
        return

    now = time.monotonic() if now is None else now
    with _FORWARDED_DIAGNOSTIC_LOCK:
        while _FORWARDED_HEADERS_NOT_APPLIED and now - _FORWARDED_HEADERS_NOT_APPLIED[0] > 60:
            _FORWARDED_HEADERS_NOT_APPLIED.popleft()
        _FORWARDED_HEADERS_NOT_APPLIED.append(now)
        if len(_FORWARDED_HEADERS_NOT_APPLIED) > 20 and now - _FORWARDED_DIAGNOSTIC_WARNING_AT >= 60:
            logger.warning(
                "X-Forwarded-For is present but not applied; check FORWARDED_ALLOW_IPS and APP_NET_GATEWAY"
            )
            _FORWARDED_DIAGNOSTIC_WARNING_AT = now


def _proxy_headers_status(now: float | None = None) -> str:
    now = time.monotonic() if now is None else now
    with _FORWARDED_DIAGNOSTIC_LOCK:
        while _FORWARDED_HEADERS_NOT_APPLIED and now - _FORWARDED_HEADERS_NOT_APPLIED[0] > 60:
            _FORWARDED_HEADERS_NOT_APPLIED.popleft()
        return "suspect" if len(_FORWARDED_HEADERS_NOT_APPLIED) > 20 else "ok"


@app.middleware("http")
async def diagnose_forwarded_headers(request: Request, call_next):
    # Uvicorn's ProxyHeadersMiddleware runs before the ASGI app. If it trusts the peer,
    # scope['client'] has already been rewritten to the forwarded public client address.
    _record_forwarded_headers_not_applied(
        request.scope, request.headers.get("x-forwarded-for")
    )
    return await call_next(request)


def _maybe_cleanup_rate_limit_state(now: float | None = None) -> None:
    """Expire old rate-limit entries and remove empty IP keys at most once per minute."""
    global _last_rate_cleanup
    now = time.monotonic() if now is None else now
    if now - _last_rate_cleanup < _RATE_CLEANUP_INTERVAL:
        return
    with _RATE_CLEANUP_LOCK:
        if now - _last_rate_cleanup < _RATE_CLEANUP_INTERVAL:
            return
        for mapping in (API_ATTEMPTS, CHAT_ATTEMPTS):
            for key, queue in list(mapping.items()):
                while queue and now - queue[0] > 60:
                    queue.popleft()
                if not queue:
                    mapping.pop(key, None)
        _last_rate_cleanup = now


class CreateProjectRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=500)


class SaveFileRequest(BaseModel):
    path: str = Field(min_length=1, max_length=500)
    content: str

    @field_validator("content")
    @classmethod
    def _content_within_limit(cls, value: str) -> str:
        # MAX_FILE_BYTES=0 (unlimited) disables the check entirely.
        if MAX_FILE_BYTES > 0 and len(value.encode("utf-8")) > MAX_FILE_BYTES:
            raise ValueError(f"File content exceeds MAX_FILE_BYTES ({MAX_FILE_BYTES} bytes).")
        return value


class ChatRequest(BaseModel):
    # Unlimited input length: the model context window is the physical limit.
    message: str = Field(min_length=1)
    project_id: str = Field(min_length=32, max_length=32)


class RunRequest(BaseModel):
    check: str = Field(pattern=r"^(auto|python_compile|pytest|npm_test|npm_build)$")
    target: str = Field(default=".", max_length=160)


class DeleteModelRequest(BaseModel):
    # Explicit user consent: the endpoint refuses to run without it.
    confirm: bool = False


class SetModelPathRequest(BaseModel):
    path: str = Field(min_length=1, max_length=500)


def _is_protected_project_component(value: str) -> bool:
    lowered = value.lower()
    protected_dirs = {".git", ".ssh", ".aws", ".azure", ".kube", ".venv", "venv",
                      "node_modules", "__pycache__", ".next", "dist", "build"}
    protected_files = {".qwen-project.json", ".npmrc", ".pypirc", ".netrc",
                       "credentials.json", "secrets.json", "id_rsa", "id_ed25519",
                       "dockerconfig.json"}
    return (lowered in protected_dirs or lowered in protected_files or lowered.startswith(".env")
            or Path(lowered).suffix in {".pem", ".key", ".p12", ".pfx"})


def _project_file(project_id: str, relative_path: str) -> Path:
    root = project_path(project_id).resolve()
    if not relative_path or relative_path.startswith(("/", "\\")):
        raise ValueError("A relative file path is required.")
    parts = Path(relative_path).parts
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Invalid file path.")
    if any(_is_protected_project_component(part) for part in parts):
        raise ValueError("This file or directory is protected and is not exposed.")
    lexical = root / relative_path
    cursor = root
    for part in Path(relative_path).parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("Symbolic links are not exposed.")
    path = lexical.resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise ValueError("Path escapes the project directory.") from exc
    if path.is_symlink():
        raise ValueError("Symbolic links are not exposed.")
    return path


def _file_tree(project_id: str, relative_dir: str = ".") -> list[dict]:
    folder = project_path(project_id) if relative_dir == "." else _project_file(project_id, relative_dir)
    if not folder.is_dir():
        raise FileNotFoundError("Directory not found.")
    items: list[dict] = []
    blocked = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".next"}
    root = project_path(project_id)
    for path in sorted(folder.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        if _is_protected_project_component(path.name) or path.name.lower() in blocked or path.is_symlink():
            continue
        rel = path.relative_to(root).as_posix()
        items.append({"name": path.name, "path": rel, "type": "directory" if path.is_dir() else "file",
                      "size": path.stat().st_size if path.is_file() else None})
        if len(items) >= 500:
            break
    return items


def _preview_response(project_id: str, relative_path: str):
    try:
        file_path = _project_file(project_id, relative_path)
        if not file_path.is_file():
            raise FileNotFoundError("Preview file not found.")
        if file_path.stat().st_size > 5_000_000:
            raise HTTPException(status_code=413, detail="Preview asset exceeds 5 MB.")
        media_type, _ = mimetypes.guess_type(file_path.name)
        allowed = {".html", ".htm", ".css", ".js", ".mjs", ".json", ".png", ".jpg", ".jpeg",
                   ".gif", ".svg", ".webp", ".ico", ".woff", ".woff2", ".ttf", ".txt", ".map"}
        if file_path.suffix.lower() not in allowed:
            raise HTTPException(status_code=415, detail="This file type is not available in preview.")
        response = FileResponse(file_path, media_type=media_type or "application/octet-stream",
                                content_disposition_type="inline")
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Disposition"] = "inline"
        response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "sandbox allow-scripts; default-src 'self' data: blob:; "
            "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' blob:; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'"
        )
        return response
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def _public_preview_file(project_id: str, relative_path: str):
    """Serve a project preview on its unguessable preview origin without app session cookies."""
    try:
        root = project_path(project_id).resolve()
        relative = relative_path or "index.html"
        if relative.startswith(("/", "\\")) or any(part in {"", ".", ".."} for part in Path(relative).parts):
            raise HTTPException(status_code=400, detail="Invalid preview path.")
        parts = Path(relative).parts
        if any(_is_protected_project_component(part) for part in parts):
            raise HTTPException(status_code=404, detail="Preview file not found.")
        lexical = root / relative
        cursor = root
        for part in parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise HTTPException(status_code=404, detail="Preview file not found.")
        file_path = lexical.resolve()
        file_path.relative_to(root)
        if not file_path.is_file():
            raise HTTPException(status_code=404, detail="Preview file not found.")
        if file_path.stat().st_size > 5_000_000:
            raise HTTPException(status_code=413, detail="Preview asset exceeds 5 MB.")
        allowed = {".html", ".htm", ".css", ".js", ".mjs", ".json", ".png", ".jpg", ".jpeg",
                   ".gif", ".svg", ".webp", ".ico", ".woff", ".woff2", ".ttf", ".txt", ".map"}
        if file_path.suffix.lower() not in allowed:
            raise HTTPException(status_code=415, detail="This file type is not available in preview.")
        media_type, _ = mimetypes.guess_type(file_path.name)
        response = FileResponse(file_path, media_type=media_type or "application/octet-stream",
                                content_disposition_type="inline")
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self' data: blob:; "
            "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' blob:; "
            "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'"
        )
        return response
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Project preview not found.") from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def _published_site_response(slug: str, relative_path: str):
    """Serve one published deployment from its dedicated subdomain origin."""
    if not re.fullmatch(r"site-[a-f0-9]{32}", slug):
        return Response(content="Published site not found.", status_code=404, media_type="text/plain")
    if not get_deployment_by_slug(slug):
        return Response(content="Published site not found.", status_code=404, media_type="text/plain")
    rel = relative_path or "index.html"
    parts = Path(rel).parts
    if rel.startswith(("/", "\\")) or any(part in {"..", "."} or part.startswith(".") for part in parts):
        return Response(content="File not found.", status_code=404, media_type="text/plain")
    root = (PUBLISH_DIR / slug).resolve()
    lexical = root / rel
    cursor = root
    for part in parts:
        cursor = cursor / part
        if cursor.is_symlink():
            return Response(content="File not found.", status_code=404, media_type="text/plain")
    path = lexical.resolve()
    try:
        path.relative_to(root)
    except ValueError:
        return Response(content="File not found.", status_code=404, media_type="text/plain")
    if not path.is_file() or path.is_symlink():
        return Response(content="File not found.", status_code=404, media_type="text/plain")
    if path.stat().st_size > 5_000_000:
        return Response(content="Asset too large.", status_code=413, media_type="text/plain")
    media, _ = mimetypes.guess_type(path.name)
    response = FileResponse(path, media_type=media or "application/octet-stream", content_disposition_type="inline")
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self' data:; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; "
        "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'"
    )
    return response


@app.middleware("http")
async def preview_subdomain_proxy(request: Request, call_next):
    """Route unguessable per-project preview subdomains to the private preview runner.

    Preview hosts are intentionally separate from the application origin so generated
    project code never shares the origin that serves the studio UI and API.
    """
    host = request.headers.get("host", "").split(":", 1)[0].lower()
    publish_suffix = "." + PUBLISH_DOMAIN
    if host == PUBLISH_DOMAIN:
        return Response(content="Published site not found.", status_code=404, media_type="text/plain")
    if host.endswith(publish_suffix):
        slug = host[:-len(publish_suffix)]
        if not re.fullmatch(r"site-[a-f0-9]{32}", slug):
            return Response(content="Published site not found.", status_code=404, media_type="text/plain")
        if request.url.path.startswith("/published/"):
            return Response(content="Published site not found.", status_code=404, media_type="text/plain")
        relative = request.url.path.lstrip("/") or "index.html"
        return await asyncio.to_thread(_published_site_response, slug, relative)

    suffix = "." + PREVIEW_DOMAIN
    if host.endswith(suffix):
        project_id = host[:-len(suffix)]
        if re.fullmatch(r"[a-f0-9]{32}", project_id):
            relative = request.url.path.lstrip("/") or "index.html"
            try:
                if ".." in relative.replace("\\", "/").split("/") or relative.startswith("/"):
                    return Response(content="Invalid preview path", status_code=400)
                try:
                    upstream = await asyncio.to_thread(fetch_preview, project_id, relative, request.url.query)
                except SandboxUnavailable:
                    return await asyncio.to_thread(_public_preview_file, project_id, relative)
                if upstream.status_code == 409:
                    return await asyncio.to_thread(_public_preview_file, project_id, relative)
                headers = {
                    "X-Content-Type-Options": "nosniff",
                    "Referrer-Policy": "no-referrer",
                    "Cache-Control": "no-store",
                    "Content-Security-Policy": (
                        "default-src 'self' data: blob:; "
                        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; "
                        "img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' blob:; "
                        "connect-src 'self' ws:; object-src 'none'; base-uri 'none'; form-action 'none'"
                    ),
                }
                if "content-type" in upstream.headers:
                    headers["Content-Type"] = upstream.headers["content-type"]
                # Preview content is intentionally unauthenticated and must never carry app cookies.
                return Response(content=upstream.content, status_code=upstream.status_code, headers=headers)
            except SandboxUnavailable as exc:
                return Response(content=str(exc), status_code=502, media_type="text/plain")
    # Browser mutation requests must originate from this exact application origin.
    # This remains a defence for the local workspace against cross-site and DNS-rebinding
    # style requests from other websites and is independent of user accounts.
    if request.url.path.startswith("/api/") and request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        fetch_site = request.headers.get("sec-fetch-site", "").lower()
        if fetch_site == "cross-site":
            return Response(content="Cross-origin mutation rejected.", status_code=403, media_type="text/plain")
        origin = request.headers.get("origin")
        if origin:
            from urllib.parse import urlsplit
            origin_parts = urlsplit(origin)
            request_host = request.headers.get("host", "").lower()
            forwarded_proto = request.headers.get("x-forwarded-proto", request.url.scheme).split(",", 1)[0].strip()
            if origin_parts.netloc.lower() != request_host or origin_parts.scheme.lower() != forwarded_proto.lower():
                return Response(content="Cross-origin mutation rejected.", status_code=403, media_type="text/plain")
    if request.url.path.startswith("/api/"):
        ip = request.client.host if request.client else "unknown"
        now = time.monotonic()
        _maybe_cleanup_rate_limit_state(now)
        queue = CHAT_ATTEMPTS[ip] if request.url.path == "/api/chat" else API_ATTEMPTS[ip]
        max_hits = 20 if request.url.path == "/api/chat" else 180
        while queue and now - queue[0] > 60:
            queue.popleft()
        if len(queue) >= max_hits:
            return Response(content="Rate limit exceeded. Retry shortly.", status_code=429, media_type="text/plain")
        queue.append(now)
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    is_preview_host = host.endswith(suffix)
    if not is_preview_host:
        response.headers.setdefault("X-Frame-Options", "DENY")
    if TLS_PUBLIC_ORIGIN:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


@app.get("/")
def home():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/health")
async def health():
    return {"status": "ok", "service": "qwen-studio", "version": "0.7.2"}


@app.get("/api/usage")
def api_usage():
    return usage_today()


@app.get("/api/system/status")
def api_system_status():
    configured = bool(MODEL_NAME and MODEL_BASE_URL)
    model = {"configured": configured, "connected": False, "name": MODEL_NAME}
    try:
        from openai import OpenAI
        client = OpenAI(base_url=MODEL_BASE_URL, api_key=MODEL_API_KEY, timeout=3.0, max_retries=0)
        client.models.list()
        model["connected"] = True
    except Exception as exc:
        model["error"] = str(exc)[:200]
    if LOCAL_INFERENCE:
        from inference.server import get_engine  # top-level sibling package
        engine = get_engine()
        model["local"] = engine.status if engine else {"enabled": True, "loaded": False, "loading": False}
    sandbox = {"configured": bool(SANDBOX_RUNNER_TOKEN), "connected": False}
    if SANDBOX_RUNNER_TOKEN:
        try:
            result = httpx.get(f"{SANDBOX_RUNNER_URL.rstrip('/')}/health", timeout=2.5)
            sandbox["connected"] = result.status_code == 200 and result.json().get("status") == "ok"
            sandbox["docker"] = result.json().get("docker")
        except Exception as exc:
            sandbox["error"] = str(exc)[:200]
    return {"model": model, "sandbox": sandbox, "proxy_headers": _proxy_headers_status()}


def _model_manager_error(exc: ModelManagerError) -> HTTPException:
    if isinstance(exc, DownloadActiveError):
        return HTTPException(status_code=409, detail=str(exc))
    return HTTPException(status_code=400, detail=str(exc))


@app.get("/api/model/status")
def api_model_status():
    """Local model files + download progress + engine state in one poll."""
    return get_manager().status()


@app.get("/api/model/remote")
def api_model_remote():
    """Repository manifest + disk feasibility preview (needs network)."""
    try:
        return get_manager().remote_info()
    except ModelManagerError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/api/model/download", status_code=202)
def api_model_download():
    """Start a (resumable) model download. Never runs without this explicit call."""
    try:
        return get_manager().start_download()
    except ModelManagerError as exc:
        raise _model_manager_error(exc) from exc


@app.post("/api/model/cancel")
def api_model_cancel():
    try:
        return get_manager().cancel()
    except ModelManagerError as exc:
        raise _model_manager_error(exc) from exc


@app.post("/api/model/verify")
def api_model_verify(bind: bool = False):
    """Verify the local checkpoint offline; optionally bind it when valid."""
    manager = get_manager()
    try:
        result = manager.verify()
        if bind and result["valid"]:
            return {"verified": result,
                    "binding": bind_verified_model(model_target_dir(), model_name())}
        return {"verified": result}
    except ModelManagerError as exc:
        raise _model_manager_error(exc) from exc


@app.post("/api/model/path")
def api_model_set_path(request: SetModelPathRequest):
    """Bind an existing checkpoint directory as the local model."""
    try:
        return get_manager().bind_existing_path(request.path)
    except ModelManagerError as exc:
        raise _model_manager_error(exc) from exc


@app.post("/api/model/delete")
def api_model_delete(request: DeleteModelRequest):
    try:
        return get_manager().delete_model_files(request.confirm)
    except ModelManagerError as exc:
        raise _model_manager_error(exc) from exc


@app.get("/api/projects")
def api_list_projects():
    return {"projects": list_projects()}


@app.post("/api/projects", status_code=201)
def api_create_project(request: CreateProjectRequest):
    try:
        return create_project(request.name, request.description)
    except PermissionError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}")
def api_get_project(project_id: str):
    try:
        return get_project(project_id)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc


@app.delete("/api/projects/{project_id}")
def api_delete_project(project_id: str):
    try:
        project_path(project_id)
        if SANDBOX_RUNNER_TOKEN:
            try:
                stop_project_preview(project_id)
            except SandboxUnavailable as exc:
                raise HTTPException(status_code=503, detail=(
                    "Could not stop this project's preview. The project was not deleted; "
                    "restore the sandbox runner and retry."
                )) from exc
        delete_project(project_id)
        db.delete_project_records(project_id)
        return {"status": "deleted", "project_id": project_id}
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc


@app.get("/api/projects/{project_id}/files")
def api_project_files(project_id: str, path: str = "."):
    try:
        return {"project_id": project_id, "path": path, "items": _file_tree(project_id, path)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.put("/api/projects/{project_id}/file")
def api_save_project_file(project_id: str, request: SaveFileRequest):
    try:
        root = project_path(project_id)
        with workspace_context(root, project_id):
            result = write_file({"path": request.path, "content": request.content})
        touch_project(project_id)
        return {"project_id": project_id, **result}
    except PermissionError as exc:
        raise HTTPException(status_code=413, detail=str(exc)) from exc
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}/file")
def api_project_file(project_id: str, path: str):
    try:
        file_path = _project_file(project_id, path)
        if not file_path.is_file():
            raise FileNotFoundError("File not found.")
        if MAX_FILE_BYTES > 0 and file_path.stat().st_size > MAX_FILE_BYTES:
            raise HTTPException(status_code=413, detail="File is too large to display.")
        return {"project_id": project_id, "path": path, "content": file_path.read_text(encoding="utf-8")}
    except UnicodeDecodeError as exc:
        raise HTTPException(status_code=415, detail="Only UTF-8 text files are supported.") from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}/preview")
def api_project_preview(project_id: str):
    return _preview_response(project_id, "index.html")


@app.get("/api/projects/{project_id}/preview-url")
def api_project_preview_url(project_id: str):
    try:
        project_path(project_id)
        parsed = __import__("urllib.parse", fromlist=["urlsplit"]).urlsplit(PREVIEW_BASE_URL)
        return {"preview_url": f"{parsed.scheme}://{project_id}.{parsed.netloc}/"}
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc


@app.post("/api/projects/{project_id}/preview/start")
def api_start_project_preview(project_id: str):
    try:
        project_path(project_id)
        reserve_tool_call_quota()
        result = start_project_preview(project_id)
        parsed = __import__("urllib.parse", fromlist=["urlsplit"]).urlsplit(PREVIEW_BASE_URL)
        preview_url = f"{parsed.scheme}://{project_id}.{parsed.netloc}/"
        return {**result, "preview_url": preview_url}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}/preview/status")
def api_project_preview_status(project_id: str):
    try:
        project_path(project_id)
        return project_preview_status(project_id)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}/preview/{relative_path:path}")
def api_project_preview_asset(project_id: str, relative_path: str):
    return _preview_response(project_id, relative_path)


@app.post("/api/projects/{project_id}/preview/restart")
def api_restart_project_preview(project_id: str):
    try:
        project_path(project_id)
        reserve_tool_call_quota()
        result = start_project_preview(project_id)
        parsed = __import__("urllib.parse", fromlist=["urlsplit"]).urlsplit(PREVIEW_BASE_URL)
        return {**result, "preview_url": f"{parsed.scheme}://{project_id}.{parsed.netloc}/"}
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/api/projects/{project_id}/preview/stop")
def api_stop_project_preview(project_id: str):
    try:
        project_path(project_id)
        result = stop_project_preview(project_id)
        return result
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/api/projects/{project_id}/run")
def api_run_project_check(project_id: str, request: RunRequest):
    try:
        source = project_path(project_id)
        check = request.check
        if check == "auto":
            # A build exercises npm projects; compileall covers Python trees
            # (and passes vacuously when the project contains no .py files).
            check = "npm_build" if (source / "package.json").is_file() else "python_compile"
        reserve_tool_call_quota()
        result = run_project_check(project_id, check, request.target)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return result


@app.post("/api/projects/{project_id}/publish", status_code=201)
def api_publish_project(project_id: str):
    try:
        source = project_path(project_id)
        reserve_deployment_quota()
        if (source / "package.json").is_file():
            return publish_built_project(project_id, PUBLISH_BASE_URL)
        return publish_project(project_id, PUBLISH_BASE_URL)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/deployments")
def api_list_deployments():
    return {"deployments": deployments_for_workspace()}


@app.get("/api/projects/{project_id}/messages")
def api_project_messages(project_id: str):
    try:
        project_path(project_id)
        return {"messages": recent_messages(project_id, limit=80)}
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc


@app.post("/api/chat")
def chat(request: ChatRequest):
    if not CHAT_EXECUTION_SLOTS.acquire(blocking=False):
        raise HTTPException(status_code=429, detail="Server busy, retry shortly")
    try:
        try:
            root = project_path(request.project_id)
            _, tool_budget = reserve_chat_quota()
            # Unlimited history when the char budget is 0 (MODEL_CONTEXT_CHAR_BUDGET=0).
            history = recent_messages(
                request.project_id, limit=12 if MODEL_CONTEXT_CHAR_BUDGET > 0 else None)
            save_message(request.project_id, "user", request.message)
            result = agent.chat(
                request.message, history, project_workspace=root,
                project_id=request.project_id,
                max_tool_calls=(min(32, tool_budget) if tool_budget is not None else None),
                tool_authorizer=lambda: reserve_tool_call_quota(),
            )
            save_message(request.project_id, "assistant", result.get("reply", ""))
            usage = result.get("usage", {})
            # Tool calls were reserved atomically immediately before execution. Record only token use here.
            record_agent_usage(0,
                               int(usage.get("prompt_tokens", 0)), int(usage.get("completion_tokens", 0)))
            touch_project(request.project_id)
            result["quota"] = usage_today()
            return result
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail="Project not found.") from exc
        except ValueError as exc:
            raise HTTPException(status_code=404, detail="Project not found.") from exc
        except PermissionError as exc:
            raise HTTPException(status_code=429, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Model gateway error: {str(exc)[:300]}") from exc
    finally:
        CHAT_EXECUTION_SLOTS.release()
