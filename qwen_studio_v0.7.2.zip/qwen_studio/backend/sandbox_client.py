from __future__ import annotations

import httpx

from .config import SANDBOX_RUNNER_TOKEN, SANDBOX_RUNNER_URL


class SandboxUnavailable(RuntimeError):
    pass


def _runner_post(path: str, payload: dict | None = None, timeout: float = 30.0) -> dict:
    if not SANDBOX_RUNNER_TOKEN:
        raise SandboxUnavailable("Sandbox runner is not configured. Set SANDBOX_RUNNER_TOKEN and start the runner service.")
    try:
        response = httpx.post(
            f"{SANDBOX_RUNNER_URL.rstrip('/')}/{path.lstrip('/')}",
            headers={"X-Runner-Token": SANDBOX_RUNNER_TOKEN},
            json=payload, timeout=timeout,
        )
    except httpx.RequestError as exc:
        raise SandboxUnavailable(f"Sandbox runner is unreachable: {exc}") from exc
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise SandboxUnavailable(f"Sandbox runner error ({response.status_code}): {detail}")
    return response.json()


def run_project_check(project_id: str, check: str, target: str = ".") -> dict:
    # The runner's SANDBOX_TIMEOUT_SECONDS may be raised up to 600 s by the
    # operator; the client must out-wait the runner's worst case, otherwise the
    # backend reports a misleading 503 while the runner is still working.
    return _runner_post("run", {"project_id": project_id, "profile": check, "target": target}, 720.0)


def start_project_preview(project_id: str) -> dict:
    # Worst runner-side pipeline: staging (~100 s) + dependency inspection + two
    # npm passes (2 x 180 s) + container start. 520 s covers it with margin.
    return _runner_post(f"preview/start/{project_id}", {}, 520.0)


def stop_project_preview(project_id: str) -> dict:
    return _runner_post(f"preview/stop/{project_id}", {}, 30.0)


def project_preview_status(project_id: str) -> dict:
    if not SANDBOX_RUNNER_TOKEN:
        return {"project_id": project_id, "running": False}
    try:
        response = httpx.get(
            f"{SANDBOX_RUNNER_URL.rstrip('/')}/preview/status/{project_id}",
            headers={"X-Runner-Token": SANDBOX_RUNNER_TOKEN}, timeout=10.0,
        )
    except httpx.RequestError as exc:
        raise SandboxUnavailable(f"Sandbox runner is unreachable: {exc}") from exc
    if response.status_code >= 400:
        raise SandboxUnavailable(f"Sandbox runner error ({response.status_code}): {response.text[:300]}")
    return response.json()



def fetch_preview(project_id: str, relative_path: str, query: str = "") -> httpx.Response:
    if not SANDBOX_RUNNER_TOKEN:
        raise SandboxUnavailable("Sandbox runner is not configured.")
    url = f"{SANDBOX_RUNNER_URL.rstrip('/')}/preview/{project_id}/{relative_path}"
    if query:
        url += "?" + query
    try:
        return httpx.get(url, headers={"X-Runner-Token": SANDBOX_RUNNER_TOKEN}, timeout=20.0)
    except httpx.RequestError as exc:
        raise SandboxUnavailable(f"Preview runner is unreachable: {exc}") from exc


def build_static_project(project_id: str, slug: str) -> dict:
    if not SANDBOX_RUNNER_TOKEN:
        raise SandboxUnavailable("Sandbox runner is not configured.")
    response = httpx.post(
        f"{SANDBOX_RUNNER_URL.rstrip('/')}/build-static",
        headers={"X-Runner-Token": SANDBOX_RUNNER_TOKEN},
        json={"project_id": project_id, "slug": slug},
        # Runner-side worst case: staging + two npm passes (180 s each) + build
        # (180 s) + publish copy (60 s). 520 s out-waits all of it.
        timeout=520.0,
    )
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise SandboxUnavailable(f"Static build runner error ({response.status_code}): {detail}")
    return response.json()
