from __future__ import annotations

import contextvars
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .config import MAX_FILE_BYTES, MAX_WORKSPACE_STORAGE_BYTES, WORKSPACE_DIR
from .sandbox_client import run_project_check

_ACTIVE_WORKSPACE: contextvars.ContextVar[Path | None] = contextvars.ContextVar("active_project_workspace", default=None)
_ACTIVE_PROJECT_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar("active_project_id", default=None)


def current_workspace() -> Path:
    configured = _ACTIVE_WORKSPACE.get() or WORKSPACE_DIR
    resolved = Path(configured).resolve()
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def current_project_id() -> str | None:
    return _ACTIVE_PROJECT_ID.get()


@contextmanager
def workspace_context(path: Path, project_id: str | None = None) -> Iterator[None]:
    resolved = Path(path).resolve()
    tokens = (
        _ACTIVE_WORKSPACE.set(resolved),
        _ACTIVE_PROJECT_ID.set(project_id),
    )
    try:
        yield
    finally:
        _ACTIVE_PROJECT_ID.reset(tokens[1])
        _ACTIVE_WORKSPACE.reset(tokens[0])


def _is_protected_path(relative: str) -> bool:
    parts = Path(relative).parts
    lowered = [part.lower() for part in parts]
    filename = lowered[-1] if lowered else ""
    blocked_dirs = {".git", ".ssh", ".aws", ".azure", ".kube", "node_modules", ".venv", "venv", "__pycache__", ".next", "dist", "build"}
    blocked_files = {".qwen-project.json", ".npmrc", ".pypirc", ".netrc", "id_rsa", "id_ed25519", "credentials.json", "secrets.json", "dockerconfig.json"}
    return (
        any(part in blocked_dirs for part in lowered)
        or filename in blocked_files
        or filename == ".env"
        or filename.startswith(".env.")
        or Path(filename).suffix.lower() in {".pem", ".key", ".p12", ".pfx"}
    )


def _safe_path(relative: str) -> Path:
    if not isinstance(relative, str) or not relative.strip():
        raise ValueError("A non-empty relative path is required.")
    if _is_protected_path(relative):
        raise ValueError("This path is protected and cannot be accessed by the agent.")
    base = current_workspace()
    lexical = base / relative
    cursor = base
    for part in Path(relative).parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("Symbolic links are not accessible to the agent.")
    candidate = lexical.resolve()
    try:
        candidate.relative_to(base)
    except ValueError as exc:
        raise ValueError("Path escapes the project workspace.") from exc
    return candidate


def _compute_workspace_storage_bytes() -> int:
    from .projects import list_projects, project_path, project_storage_size
    return sum(project_storage_size(project_path(item["id"])) for item in list_projects())


def _ensure_storage_quota(new_bytes: int, path: Path) -> int | None:
    """Reserve the write delta in the DB cache; the full tree is scanned only on cache miss."""
    from . import db
    db.get_or_init_workspace_storage(_compute_workspace_storage_bytes)
    old_size = path.stat().st_size if path.is_file() and not path.is_symlink() else 0
    delta = int(new_bytes) - old_size
    db.adjust_workspace_storage(delta, MAX_WORKSPACE_STORAGE_BYTES or None)
    return delta


def _rollback_storage_reservation(reservation: int | None) -> None:
    if reservation is not None:
        from . import db
        db.adjust_workspace_storage(-reservation)


def list_files(arguments: dict[str, Any]) -> dict[str, Any]:
    rel = arguments.get("path", ".")
    folder = _safe_path(rel)
    if not folder.exists() or not folder.is_dir():
        raise ValueError("Directory does not exist.")
    items = []
    for p in sorted(folder.iterdir(), key=lambda x: x.name.lower()):
        if _is_protected_path(p.name) or p.is_symlink():
            continue
        items.append({"name": p.name, "type": "directory" if p.is_dir() else "file",
                      "size": p.stat().st_size if p.is_file() else None})
    return {"path": rel, "items": items[:300]}


def read_file(arguments: dict[str, Any]) -> dict[str, Any]:
    rel = arguments.get("path")
    path = _safe_path(rel)
    if not path.is_file() or path.is_symlink():
        raise ValueError("File does not exist or is not accessible.")
    size = path.stat().st_size
    if MAX_FILE_BYTES > 0 and size > MAX_FILE_BYTES:
        raise ValueError(f"File too large to read ({size} bytes).")
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("Only UTF-8 text files are supported.") from exc
    return {"path": rel, "content": content}


def write_file(arguments: dict[str, Any]) -> dict[str, Any]:
    rel, content = arguments.get("path"), arguments.get("content")
    if not isinstance(content, str):
        raise ValueError("content must be a string.")
    encoded = content.encode("utf-8")
    if MAX_FILE_BYTES > 0 and len(encoded) > MAX_FILE_BYTES:
        raise ValueError(f"File too large to write (limit {MAX_FILE_BYTES} bytes).")
    path = _safe_path(rel)
    if path.is_symlink():
        raise ValueError("Writing through symbolic links is blocked.")
    reservation = _ensure_storage_quota(len(encoded), path)
    temp_name = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode="wb", dir=str(path.parent), prefix=".agent-write-", delete=False) as temp:
            temp.write(encoded)
            temp.flush()
            os.fsync(temp.fileno())
            temp_name = temp.name
        Path(temp_name).replace(path)
    except Exception:
        _rollback_storage_reservation(reservation)
        raise
    finally:
        if temp_name and Path(temp_name).exists():
            Path(temp_name).unlink(missing_ok=True)
    return {"path": rel, "bytes_written": len(encoded), "status": "written"}


def edit_file(arguments: dict[str, Any]) -> dict[str, Any]:
    rel = arguments.get("path")
    old_string = arguments.get("old_string")
    new_string = arguments.get("new_string")
    if not isinstance(old_string, str) or not old_string:
        raise ValueError("old_string must be a non-empty string.")
    if not isinstance(new_string, str):
        raise ValueError("new_string must be a string.")
    path = _safe_path(rel)
    if not path.is_file() or path.is_symlink():
        raise ValueError("The existing file must be a readable regular text file.")
    original = read_file({"path": rel})["content"]
    matches = original.count(old_string)
    if matches != 1:
        raise ValueError(f"edit_file requires exactly one match; found {matches}. No changes were made.")
    updated = original.replace(old_string, new_string, 1)
    result = write_file({"path": rel, "content": updated})
    return {**result, "replacements": 1, "status": "edited"}


def append_file(arguments: dict[str, Any]) -> dict[str, Any]:
    rel = arguments.get("path")
    content = arguments.get("content")
    if not isinstance(content, str) or not content:
        raise ValueError("content must be a non-empty string.")
    path = _safe_path(rel)
    if path.exists():
        if not path.is_file() or path.is_symlink():
            raise ValueError("append_file requires a regular text file.")
        existing = read_file({"path": rel})["content"]
    else:
        existing = ""
    return write_file({"path": rel, "content": existing + content})



def delete_file(arguments: dict[str, Any]) -> dict[str, Any]:
    rel = arguments.get("path")
    path = _safe_path(rel)
    if path.is_symlink() or not path.is_file():
        raise ValueError("delete_file requires an existing regular file.")
    size = path.stat().st_size
    from . import db
    db.get_or_init_workspace_storage(_compute_workspace_storage_bytes)
    db.adjust_workspace_storage(-size)
    try:
        path.unlink()
    except Exception:
        db.adjust_workspace_storage(size)
        raise
    return {"path": rel, "bytes_deleted": size, "status": "deleted"}

def run_check(arguments: dict[str, Any]) -> dict[str, Any]:
    project_id = current_project_id()
    if not project_id:
        raise PermissionError("Execution requires an active project context.")
    check = arguments.get("check")
    target = arguments.get("target", ".")
    if check not in {"python_compile", "pytest", "npm_test", "npm_build"}:
        raise ValueError("Unsupported check profile.")
    if not isinstance(target, str) or target.startswith(("/", "\\")) or ".." in Path(target).parts:
        raise ValueError("Invalid project-relative target.")
    return run_project_check(project_id, check, target)


TOOL_SCHEMAS = [
    {"type": "function", "function": {"name": "list_files", "description": "List files and directories in the current project.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Relative directory, default '.'"}}, "additionalProperties": False}}},
    {"type": "function", "function": {"name": "read_file", "description": "Read a UTF-8 project file.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"], "additionalProperties": False}}},
    {"type": "function", "function": {"name": "write_file", "description": "Create or replace a UTF-8 project file. Secret files and dependency directories are blocked.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"], "additionalProperties": False}}},
    {"type": "function", "function": {"name": "edit_file", "description": "Replace exactly one occurrence of old_string in an existing UTF-8 file. Prefer this for edits to existing files.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "old_string": {"type": "string"}, "new_string": {"type": "string"}}, "required": ["path", "old_string", "new_string"], "additionalProperties": False}}},
    {"type": "function", "function": {"name": "append_file", "description": "Append a small chunk to an existing or new UTF-8 file. Use small chunks for long content.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"], "additionalProperties": False}}},
    {"type": "function", "function": {"name": "delete_file", "description": "Delete a regular file inside the current project and release its storage quota.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"], "additionalProperties": False}}},
    {"type": "function", "function": {"name": "run_check", "description": "Run a restricted check in an isolated no-network container with resource limits.",
     "parameters": {"type": "object", "properties": {"check": {"type": "string", "enum": ["python_compile", "pytest", "npm_test", "npm_build"]}, "target": {"type": "string", "description": "Relative directory, default '.'"}}, "required": ["check"], "additionalProperties": False}}},
]


def execute_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    functions = {"list_files": list_files, "read_file": read_file, "write_file": write_file,
                 "edit_file": edit_file, "append_file": append_file, "delete_file": delete_file, "run_check": run_check}
    if name not in functions:
        raise ValueError(f"Unknown tool: {name}")
    return functions[name](arguments)
