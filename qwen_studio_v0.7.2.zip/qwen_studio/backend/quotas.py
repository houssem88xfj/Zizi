from __future__ import annotations
from datetime import datetime, timezone

from .config import MAX_DAILY_CHAT_REQUESTS, MAX_DAILY_DEPLOYMENTS, MAX_DAILY_TOOL_CALLS
from .db import add_usage, reserve_chat, reserve_deployment, reserve_tool_call, usage_snapshot


def today_key() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _limit_or_none(value: int) -> int | None:
    """0 (or any non-positive value) means unlimited; expose that as None."""
    return value if value > 0 else None


def usage_today() -> dict:
    data = usage_snapshot(today_key())
    limits = {
        "chat_requests": _limit_or_none(MAX_DAILY_CHAT_REQUESTS),
        "tool_calls": _limit_or_none(MAX_DAILY_TOOL_CALLS),
        "deployments": _limit_or_none(MAX_DAILY_DEPLOYMENTS),
    }
    data["limits"] = limits
    data["remaining"] = {
        key: (max(0, value - data[key]) if value is not None else None)
        for key, value in limits.items()
    }
    data["resets_at"] = "00:00 UTC" if any(value is not None for value in limits.values()) else "unlimited"
    return data


def reserve_chat_quota() -> tuple[dict, int | None]:
    """Reserve one chat request. Returns (snapshot, remaining_tool_calls_or_None).

    None means unlimited: the caller must not impose a per-request tool-call cap
    derived from the daily quota.
    """
    day = today_key()
    snapshot = reserve_chat(day, MAX_DAILY_CHAT_REQUESTS)
    if MAX_DAILY_TOOL_CALLS <= 0:
        return snapshot, None
    return snapshot, max(0, MAX_DAILY_TOOL_CALLS - snapshot["tool_calls"])


def record_agent_usage(tool_calls: int, input_tokens: int = 0, output_tokens: int = 0) -> None:
    add_usage(today_key(), tool_calls, input_tokens, output_tokens)


def reserve_deployment_quota() -> None:
    reserve_deployment(today_key(), MAX_DAILY_DEPLOYMENTS)


def reserve_tool_call_quota() -> None:
    reserve_tool_call(today_key(), MAX_DAILY_TOOL_CALLS)
