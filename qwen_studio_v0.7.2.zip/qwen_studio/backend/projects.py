from __future__ import annotations

import json
import re
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import MAX_PROJECTS, MAX_WORKSPACE_STORAGE_BYTES, WORKSPACE_DIR
from . import db

PROJECTS_DIR = (WORKSPACE_DIR / "projects").resolve()
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
PROJECT_ID_RE = re.compile(r"^[a-f0-9]{32}$")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_metadata(path: Path) -> dict[str, Any]:
    try:
        return json.loads((path / ".qwen-project.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("Project metadata is invalid.") from exc


def project_path(project_id: str) -> Path:
    if not isinstance(project_id, str) or not PROJECT_ID_RE.fullmatch(project_id):
        raise ValueError("Invalid project id.")
    path = (PROJECTS_DIR / project_id).resolve()
    try:
        path.relative_to(PROJECTS_DIR.resolve())
    except ValueError as exc:
        raise ValueError("Invalid project path.") from exc
    if not path.is_dir() or not (path / ".qwen-project.json").is_file():
        raise FileNotFoundError("Project not found.")
    return path


def list_projects() -> list[dict[str, Any]]:
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    indexed = db.list_project_index()
    results: list[dict[str, Any]] = []
    if indexed is not None:
        for row in indexed:
            try:
                metadata = _read_metadata(project_path(row["id"]))
                results.append(metadata)
            except (ValueError, FileNotFoundError):
                continue
        # The migration imports legacy .qwen-project.json records once. This fallback
        # repairs only a missing/empty index (rather than scanning on every normal list).
        if results:
            return sorted(results, key=lambda item: item.get("updated_at", ""), reverse=True)

    for folder in PROJECTS_DIR.iterdir():
        if not folder.is_dir() or not (folder / ".qwen-project.json").is_file():
            continue
        try:
            metadata = _read_metadata(folder)
            results.append(metadata)
            db.upsert_project_index(metadata)
        except ValueError:
            continue
    return sorted(results, key=lambda item: item.get("updated_at", ""), reverse=True)


def project_storage_size(folder: Path) -> int:
    """Count project files; exclude internal metadata and all symlinks."""
    total = 0
    for item in folder.rglob("*"):
        if item.name == ".qwen-project.json" or item.is_symlink():
            continue
        try:
            if item.is_file():
                total += item.stat().st_size
        except OSError:
            continue
    return total


def create_project(name: str, description: str) -> dict[str, Any]:
    clean_name = " ".join(name.split())
    if not clean_name or len(clean_name) > 80:
        raise ValueError("Project name must contain 1–80 characters.")
    if len(description) > 500:
        raise ValueError("Project description cannot exceed 500 characters.")
    if MAX_PROJECTS > 0 and len(list_projects()) >= MAX_PROJECTS:
        raise PermissionError(f"Project limit reached ({MAX_PROJECTS}).")

    project_id = uuid.uuid4().hex
    folder = PROJECTS_DIR / project_id
    folder.mkdir(parents=True, exist_ok=False)
    now = _now()
    metadata = {
        "id": project_id, "name": clean_name,
        "description": description.strip(), "created_at": now, "updated_at": now,
    }
    (folder / ".qwen-project.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (folder / "index.html").write_text(
        "<!doctype html>\n<html lang=\"en\">\n<head>\n"
        "<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "<title>New project</title><link rel=\"stylesheet\" href=\"./style.css\">\n"
        "</head>\n<body>\n<main><h1>Your project starts here</h1>\n"
        "<p>Ask the coding agent to build your app.</p></main>\n"
        "<script src=\"./app.js\"></script>\n</body>\n</html>\n", encoding="utf-8"
    )
    (folder / "style.css").write_text(
        "*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:system-ui,sans-serif;"
        "display:grid;place-items:center;background:#f5f7fb;color:#182033}main{max-width:680px;padding:3rem}\n",
        encoding="utf-8",
    )
    (folder / "app.js").write_text("// Your application JavaScript goes here.\n", encoding="utf-8")
    try:
        # Keep a warmed storage cache accurate when projects are created after first use.
        initial_bytes = project_storage_size(folder)
        db.adjust_workspace_storage(initial_bytes, MAX_WORKSPACE_STORAGE_BYTES or None)
        db.upsert_project_index(metadata)
    except PermissionError:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    return metadata


def get_project(project_id: str) -> dict[str, Any]:
    return _read_metadata(project_path(project_id))


def touch_project(project_id: str) -> None:
    folder = project_path(project_id)
    metadata = _read_metadata(folder)
    metadata["updated_at"] = _now()
    (folder / ".qwen-project.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    db.update_project_index(project_id, metadata["name"], metadata["updated_at"])


def delete_project(project_id: str) -> None:
    folder = project_path(project_id)
    if folder.parent.resolve() != PROJECTS_DIR.resolve():
        raise ValueError("Refusing to delete an invalid project path.")
    size = project_storage_size(folder)
    shutil.rmtree(folder)
    db.adjust_workspace_storage(-size)
    db.delete_project_index(project_id)
