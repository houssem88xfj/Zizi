from __future__ import annotations

import os
import logging
import re
from urllib.parse import urlsplit
from pathlib import Path
from dotenv import load_dotenv

from .domains import registrable_domain

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent
APP_ENV = os.getenv("APP_ENV", "development").strip().lower()
APP_BIND_ADDRESS = os.getenv("APP_BIND_ADDRESS", "127.0.0.1")
FORWARDED_ALLOW_IPS = os.getenv("FORWARDED_ALLOW_IPS", "172.28.0.1").strip()
SANDBOX_ALLOW_NETWORK_INSTALL = os.getenv("SANDBOX_ALLOW_NETWORK_INSTALL", "false").lower() == "true"
SANDBOX_NPM_REGISTRY_URL = os.getenv("SANDBOX_NPM_REGISTRY_URL", "").strip().rstrip("/")
if APP_ENV not in {"development", "test", "production"}:
    raise RuntimeError("APP_ENV must be development, test, or production.")
# Qwen Studio is a single-user local workspace: there are no accounts, no logins and
# no session cookies. The app binds to loopback unless the operator explicitly opts in
# to remote access with ALLOW_REMOTE_ACCESS=true (which still requires a TLS proxy).
ALLOW_REMOTE_ACCESS = os.getenv("ALLOW_REMOTE_ACCESS", "false").lower() == "true"
WORKSPACE_DIR = Path(os.getenv("WORKSPACE_DIR", "./workspace")).resolve()
WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)

# Local weights inference (no external model server needed when enabled).
LOCAL_INFERENCE = os.getenv("LOCAL_INFERENCE", "false").lower() == "true"
LOCAL_MODEL_NAME = os.getenv("LOCAL_MODEL_NAME", "Qwen2.5-Coder-14B-Instruct").strip()
_LOCAL_MODEL_DIR_ENV = os.getenv("LOCAL_MODEL_DIR", "").strip()
# An empty LOCAL_MODEL_DIR (the .env.example default) must fall back to
# models/<LOCAL_MODEL_NAME>, never to the process working directory.
LOCAL_MODEL_DIR = (
    Path(_LOCAL_MODEL_DIR_ENV).resolve()
    if _LOCAL_MODEL_DIR_ENV
    else (BASE_DIR / "models" / LOCAL_MODEL_NAME).resolve()
)
LOCAL_INFERENCE_HOST = os.getenv("LOCAL_INFERENCE_HOST", "127.0.0.1").strip()
LOCAL_INFERENCE_PORT = int(os.getenv("LOCAL_INFERENCE_PORT", "8100"))
LOCAL_MODEL_DEVICE = os.getenv("LOCAL_MODEL_DEVICE", "auto").strip().lower()
LOCAL_MODEL_QUANTIZATION = os.getenv("LOCAL_MODEL_QUANTIZATION", "auto").strip().lower()
# 0 = auto: use the model's own max_position_embeddings from config.json.
LOCAL_MODEL_MAX_CONTEXT_TOKENS = int(os.getenv("LOCAL_MODEL_MAX_CONTEXT_TOKENS", "0"))

_MODEL_BASE_URL_ENV = os.getenv("MODEL_BASE_URL", "").strip()
MODEL_BASE_URL = _MODEL_BASE_URL_ENV or "http://127.0.0.1:8000/v1"
MODEL_NAME = os.getenv("MODEL_NAME", "Qwen2.5-Coder-14B-Instruct").strip()
if LOCAL_INFERENCE and (not _MODEL_BASE_URL_ENV or "example" in MODEL_BASE_URL):
    # No explicit endpoint configured: default the gateway to the bundled loopback
    # engine so no external server is contacted. An explicit MODEL_BASE_URL wins.
    MODEL_BASE_URL = f"http://{LOCAL_INFERENCE_HOST}:{LOCAL_INFERENCE_PORT}/v1"
    MODEL_NAME = LOCAL_MODEL_NAME
# Token limits use 0 = unlimited (no application-side cap). The physical limit stays
# the loaded model's context window; the engine fills whatever the window allows.
MODEL_MAX_TOKENS = int(os.getenv("MODEL_MAX_TOKENS", "0"))
MODEL_TEMPERATURE = float(os.getenv("MODEL_TEMPERATURE", "0.2"))
MODEL_CONTEXT_CHAR_BUDGET = int(os.getenv("MODEL_CONTEXT_CHAR_BUDGET", "0"))
MODEL_API_KEY = os.getenv("MODEL_API_KEY", "EMPTY")
MAX_TOOL_TURNS = int(os.getenv("MAX_TOOL_TURNS", "0"))
MAX_FILE_BYTES = int(os.getenv("MAX_FILE_BYTES", "0"))
# Workspace-wide guard rails. Single-user local workspace: every value 0 = unlimited.
# Positive values still protect the machine from runaway agent loops and accidental
# disk fills; unlimited is the shipped default because the operator owns the machine.
MAX_PROJECTS = int(os.getenv("MAX_PROJECTS", "0"))
MAX_DAILY_CHAT_REQUESTS = int(os.getenv("MAX_DAILY_CHAT_REQUESTS", "0"))
MAX_CONCURRENT_CHATS = int(os.getenv("MAX_CONCURRENT_CHATS", "0"))
MAX_DAILY_TOOL_CALLS = int(os.getenv("MAX_DAILY_TOOL_CALLS", "0"))
MAX_DAILY_DEPLOYMENTS = int(os.getenv("MAX_DAILY_DEPLOYMENTS", "0"))
MAX_WORKSPACE_STORAGE_BYTES = int(os.getenv("MAX_WORKSPACE_STORAGE_BYTES", "0"))
DATABASE_PATH = Path(os.getenv("DATABASE_PATH", str(WORKSPACE_DIR / "qwen_studio.sqlite3"))).resolve()
SANDBOX_RUNNER_URL = os.getenv("SANDBOX_RUNNER_URL", "http://sandbox-runner:8090")
SANDBOX_RUNNER_TOKEN = os.getenv("SANDBOX_RUNNER_TOKEN", "")
SANDBOX_VOLUME_NAME = os.getenv("SANDBOX_VOLUME_NAME", "qwen_workspace")
PUBLISH_DIR = Path(os.getenv("PUBLISH_DIR", str(WORKSPACE_DIR / "published"))).resolve()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://localhost:8080").rstrip("/")
PUBLISH_BASE_URL = os.getenv("PUBLISH_BASE_URL", "http://sites.localhost:8080").rstrip("/")
PUBLISH_DOMAIN = os.getenv("PUBLISH_DOMAIN", "sites.localhost").lower()
PREVIEW_BASE_URL = os.getenv("PREVIEW_BASE_URL", "http://preview.localhost:8080").rstrip("/")
PREVIEW_DOMAIN = os.getenv("PREVIEW_DOMAIN", "preview.localhost").lower()

PUBLISH_DIR.mkdir(parents=True, exist_ok=True)


def origins_share_parent_domain(public_url: str, preview_url: str, publish_url: str) -> bool:
    hosts = [urlsplit(value).hostname for value in (public_url, preview_url, publish_url)]
    parents = [registrable_domain(host) for host in hosts]
    return all(parents) and len(set(parents)) == 1


def warn_if_shared_origin_parent_domain() -> bool:
    if APP_ENV == "production" and origins_share_parent_domain(
        PUBLIC_BASE_URL, PREVIEW_BASE_URL, PUBLISH_BASE_URL
    ):
        logging.getLogger("qwen_studio.security").warning(
            "PUBLIC_BASE_URL, PREVIEW_BASE_URL and PUBLISH_BASE_URL share the same registrable parent domain; "
            "use a separate registered domain for previews and published sites so generated project code "
            "cannot share the application origin."
        )
        return True
    return False


def validate_runtime_config() -> None:
    """Fail closed on unsafe settings before accepting requests."""
    # 0 means unlimited for every knob below; positive values keep sane ranges.
    if MAX_TOOL_TURNS < 0 or MAX_TOOL_TURNS > 200:
        raise RuntimeError("MAX_TOOL_TURNS must be 0 (unlimited) or between 1 and 200.")
    if MODEL_MAX_TOKENS < 0 or (0 < MODEL_MAX_TOKENS < 256) or MODEL_MAX_TOKENS > 131072:
        raise RuntimeError("MODEL_MAX_TOKENS must be 0 (unlimited) or between 256 and 131072.")
    if MODEL_TEMPERATURE < 0 or MODEL_TEMPERATURE > 1:
        raise RuntimeError("MODEL_TEMPERATURE must be between 0 and 1.")
    if MODEL_CONTEXT_CHAR_BUDGET < 0 or (0 < MODEL_CONTEXT_CHAR_BUDGET < 8000) or MODEL_CONTEXT_CHAR_BUDGET > 2000000:
        raise RuntimeError("MODEL_CONTEXT_CHAR_BUDGET must be 0 (unlimited) or between 8000 and 2000000.")
    if not MODEL_NAME:
        raise RuntimeError("MODEL_NAME must not be empty.")
    if LOCAL_MODEL_DEVICE not in {"auto", "cuda", "cpu"}:
        raise RuntimeError("LOCAL_MODEL_DEVICE must be auto, cuda, or cpu.")
    if LOCAL_MODEL_QUANTIZATION not in {"auto", "none", "bf16", "fp16", "int8", "int4"}:
        raise RuntimeError("LOCAL_MODEL_QUANTIZATION must be auto, none, bf16, fp16, int8, or int4.")
    if LOCAL_MODEL_MAX_CONTEXT_TOKENS < 0 or LOCAL_MODEL_MAX_CONTEXT_TOKENS > 1048576:
        raise RuntimeError("LOCAL_MODEL_MAX_CONTEXT_TOKENS must be 0 (auto from model config) or between 1024 and 1048576.")
    if 0 < LOCAL_MODEL_MAX_CONTEXT_TOKENS and 0 < MODEL_MAX_TOKENS and LOCAL_MODEL_MAX_CONTEXT_TOKENS < MODEL_MAX_TOKENS:
        raise RuntimeError("LOCAL_MODEL_MAX_CONTEXT_TOKENS must be >= MODEL_MAX_TOKENS when both are set.")
    if not (1 <= LOCAL_INFERENCE_PORT <= 65535):
        raise RuntimeError("LOCAL_INFERENCE_PORT must be between 1 and 65535.")
    if LOCAL_INFERENCE_HOST not in {"127.0.0.1", "localhost", "::1"}:
        raise RuntimeError("LOCAL_INFERENCE_HOST must stay on loopback; the engine has no authentication.")
    if MAX_CONCURRENT_CHATS < 0 or MAX_CONCURRENT_CHATS > 256:
        raise RuntimeError("MAX_CONCURRENT_CHATS must be 0 (unlimited) or between 1 and 256.")
    if APP_BIND_ADDRESS not in {"127.0.0.1", "localhost", "::1"} and not ALLOW_REMOTE_ACCESS:
        raise RuntimeError(
            "Qwen Studio is a single-user local workspace and binds to loopback by default. "
            "To listen on a non-loopback address set ALLOW_REMOTE_ACCESS=true and put a "
            "TLS-authenticating reverse proxy in front of the app."
        )
    if APP_ENV != "production":
        return

    if not SANDBOX_RUNNER_TOKEN or len(SANDBOX_RUNNER_TOKEN) < 32 or SANDBOX_RUNNER_TOKEN.startswith("REPLACE_WITH"):
        raise RuntimeError("Set SANDBOX_RUNNER_TOKEN to a random value of at least 32 characters.")
    if SANDBOX_ALLOW_NETWORK_INSTALL:
        npm_registry = urlsplit(SANDBOX_NPM_REGISTRY_URL)
        if (npm_registry.scheme != "http" or npm_registry.hostname != "npm-proxy"
                or npm_registry.port != 4873 or npm_registry.username or npm_registry.password
                or npm_registry.path not in {"", "/"} or npm_registry.query or npm_registry.fragment):
            raise RuntimeError("SANDBOX_ALLOW_NETWORK_INSTALL requires SANDBOX_NPM_REGISTRY_URL=http://npm-proxy:4873 on the internal npm proxy network.")

    public = urlsplit(PUBLIC_BASE_URL)
    preview = urlsplit(PREVIEW_BASE_URL)
    publish = urlsplit(PUBLISH_BASE_URL)
    if public.scheme != "https" or not public.hostname or public.username or public.password or public.path not in {"", "/"} or public.query or public.fragment:
        raise RuntimeError("PUBLIC_BASE_URL must be an HTTPS origin, e.g. https://studio.example.com.")
    if preview.scheme != "https" or not preview.hostname or preview.username or preview.password or preview.path not in {"", "/"} or preview.query or preview.fragment:
        raise RuntimeError("PREVIEW_BASE_URL must be an HTTPS origin, e.g. https://preview.example.com.")
    if publish.scheme != "https" or not publish.hostname or publish.username or publish.password or publish.path not in {"", "/"} or publish.query or publish.fragment:
        raise RuntimeError("PUBLISH_BASE_URL must be an HTTPS origin, e.g. https://sites.example.com.")
    if publish.hostname.lower() != PUBLISH_DOMAIN.lower():
        raise RuntimeError("PUBLISH_DOMAIN must equal the hostname in PUBLISH_BASE_URL.")
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+", PUBLISH_DOMAIN):
        raise RuntimeError("PUBLISH_DOMAIN must be a bare DNS domain suitable for per-site wildcard subdomains.")
    if preview.hostname.lower() != PREVIEW_DOMAIN.lower():
        raise RuntimeError("PREVIEW_DOMAIN must equal the hostname in PREVIEW_BASE_URL.")
    if public.hostname.lower() == preview.hostname.lower():
        raise RuntimeError("Use a separate hostname for previews so generated code cannot share the app origin.")
    if publish.hostname.lower() in {public.hostname.lower(), preview.hostname.lower()}:
        raise RuntimeError("Use a separate hostname for published sites, app, and previews.")
    warn_if_shared_origin_parent_domain()
    model = urlsplit(MODEL_BASE_URL)
    if model.scheme not in {"https", "http"} or not model.hostname or model.username or model.password:
        raise RuntimeError("MODEL_BASE_URL must be a valid HTTP(S) URL without embedded credentials.")
    if model.scheme == "http":
        import ipaddress
        host = model.hostname.lower()
        internal_names = {"localhost", "host.docker.internal", "sandbox-runner"}
        try:
            is_private_host = ipaddress.ip_address(host).is_private
        except ValueError:
            is_private_host = host.endswith((".internal", ".local"))
        if host not in internal_names and not is_private_host:
            raise RuntimeError("Use HTTPS for an external MODEL_BASE_URL; HTTP is allowed only for private/internal hosts.")
    limits = (MAX_PROJECTS, MAX_DAILY_CHAT_REQUESTS, MAX_DAILY_TOOL_CALLS,
              MAX_DAILY_DEPLOYMENTS, MAX_WORKSPACE_STORAGE_BYTES, MAX_FILE_BYTES)
    if any(value < 0 for value in limits):
        raise RuntimeError("Quotas and file-size limits must be 0 (unlimited) or positive integers.")
