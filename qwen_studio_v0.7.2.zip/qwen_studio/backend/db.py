from __future__ import annotations

import json
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .config import DATABASE_PATH

SCHEMA_MIGRATIONS = (
    "project_index_import_v1",
    "single_user_workspace_v1",
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect() -> sqlite3.Connection:
    Path(DATABASE_PATH).parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=15, isolation_level=None)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    connection.execute("PRAGMA busy_timeout = 15000")
    return connection


@contextmanager
def db_session() -> Iterator[sqlite3.Connection]:
    connection = connect()
    try:
        yield connection
    finally:
        connection.close()


NEW_SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_daily (
    day TEXT PRIMARY KEY,
    chat_requests INTEGER NOT NULL DEFAULT 0,
    tool_calls INTEGER NOT NULL DEFAULT 0,
    deployments INTEGER NOT NULL DEFAULT 0,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat_project ON chat_messages(project_id, id);
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at DESC);
CREATE TABLE IF NOT EXISTS workspace_storage (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    bytes_used INTEGER NOT NULL DEFAULT 0 CHECK(bytes_used >= 0),
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS schema_migrations (
    migration_key TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS deployments (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'published'
);
"""


def _table_columns(db: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {row["name"] for row in db.execute(f"PRAGMA table_info({table})").fetchall()}
    except sqlite3.OperationalError:
        return set()


def _has_legacy_user_schema(db: sqlite3.Connection) -> bool:
    """Detect a pre-0.7.1-single-user database (projects keyed by owner_id)."""
    return "owner_id" in _table_columns(db, "projects")


def _backup_database_file() -> Path:
    """Copy the live SQLite database (plus WAL/SHM sidecars) to a timestamped backup."""
    database = Path(DATABASE_PATH)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = database.with_name(f"{database.name}.backup-{timestamp}")
    counter = 1
    while backup.exists():
        backup = database.with_name(f"{database.name}.backup-{timestamp}-{counter}")
        counter += 1
    shutil.copy2(database, backup)
    for suffix in ("-wal", "-shm"):
        sidecar = database.with_name(database.name + suffix)
        if sidecar.exists():
            shutil.copy2(sidecar, backup.with_name(backup.name + suffix))
    return backup


def _migrate_legacy_single_user(db: sqlite3.Connection) -> None:
    """Rewrite a multi-user 0.7.0/0.7.1 database into the single-workspace schema.

    A file-level backup is created before any change. All existing projects,
    chat history, deployments, and usage counters are preserved and merged into
    the single local workspace; the users table (credentials) is dropped.
    The whole rewrite runs inside one transaction: on any error it rolls back
    and the legacy schema stays untouched.
    """
    for stray in ("projects_new", "chat_messages_new", "usage_daily_new",
                  "deployments_new", "workspace_storage_new"):
        db.execute(f"DROP TABLE IF EXISTS {stray}")
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute(
            """
            CREATE TABLE projects_new (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        db.execute(
            "INSERT OR IGNORE INTO projects_new(id, name, created_at, updated_at) "
            "SELECT id, name, created_at, updated_at FROM projects"
        )
        db.execute(
            """
            CREATE TABLE chat_messages_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('user','assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        db.execute(
            "INSERT INTO chat_messages_new(project_id, role, content, created_at) "
            "SELECT project_id, role, content, created_at FROM chat_messages ORDER BY id"
        )
        db.execute(
            """
            CREATE TABLE usage_daily_new (
                day TEXT PRIMARY KEY,
                chat_requests INTEGER NOT NULL DEFAULT 0,
                tool_calls INTEGER NOT NULL DEFAULT 0,
                deployments INTEGER NOT NULL DEFAULT 0,
                input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        db.execute(
            "INSERT OR IGNORE INTO usage_daily_new(day, chat_requests, tool_calls, deployments, input_tokens, output_tokens) "
            "SELECT day, SUM(chat_requests), SUM(tool_calls), SUM(deployments), SUM(input_tokens), SUM(output_tokens) "
            "FROM usage_daily GROUP BY day"
        )
        db.execute(
            """
            CREATE TABLE deployments_new (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                slug TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'published'
            )
            """
        )
        db.execute(
            "INSERT OR IGNORE INTO deployments_new(id, project_id, slug, created_at, status) "
            "SELECT id, project_id, slug, created_at, status FROM deployments"
        )
        db.execute(
            """
            CREATE TABLE workspace_storage_new (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                bytes_used INTEGER NOT NULL DEFAULT 0 CHECK(bytes_used >= 0),
                updated_at TEXT NOT NULL
            )
            """
        )
        storage_row = db.execute(
            "SELECT COALESCE(SUM(bytes_used), 0) AS total FROM user_storage"
        ).fetchone()
        db.execute(
            "INSERT OR REPLACE INTO workspace_storage_new(id, bytes_used, updated_at) VALUES(1, ?, ?)",
            (int(storage_row["total"]) if storage_row else 0, now_iso()),
        )
        db.execute("DROP TABLE IF EXISTS usage_daily")
        db.execute("DROP TABLE IF EXISTS chat_messages")
        db.execute("DROP TABLE IF EXISTS user_storage")
        db.execute("DROP TABLE IF EXISTS deployments")
        db.execute("DROP TABLE IF EXISTS users")
        db.execute("DROP TABLE projects")
        db.execute("ALTER TABLE projects_new RENAME TO projects")
        db.execute("ALTER TABLE chat_messages_new RENAME TO chat_messages")
        db.execute("ALTER TABLE usage_daily_new RENAME TO usage_daily")
        db.execute("ALTER TABLE deployments_new RENAME TO deployments")
        db.execute("ALTER TABLE workspace_storage_new RENAME TO workspace_storage")
        db.execute("CREATE INDEX IF NOT EXISTS idx_chat_project ON chat_messages(project_id, id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at DESC)")
        db.execute(
            "INSERT OR IGNORE INTO schema_migrations(migration_key,applied_at) VALUES('single_user_workspace_v1', ?)",
            (now_iso(),),
        )
        db.commit()
    except Exception:
        db.rollback()
        raise


def _strip_legacy_owner_ids() -> None:
    """Remove the retired owner_id field from on-disk project metadata files."""
    try:
        from .projects import PROJECTS_DIR
    except ImportError:
        return
    if not PROJECTS_DIR.is_dir():
        return
    for folder in PROJECTS_DIR.iterdir():
        metadata_file = folder / ".qwen-project.json"
        if not folder.is_dir() or not metadata_file.is_file() or metadata_file.is_symlink():
            continue
        try:
            metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
            if metadata.pop("owner_id", None) is None:
                continue
            metadata_file.write_text(
                json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except (OSError, ValueError, TypeError):
            continue


def init_db() -> None:
    with db_session() as db:
        legacy = _has_legacy_user_schema(db)
        if legacy:
            _backup_database_file()
            _migrate_legacy_single_user(db)
        else:
            db.executescript(NEW_SCHEMA)
    if legacy:
        # Metadata rewrite happens after the DB migration commits successfully.
        _strip_legacy_owner_ids()
    with db_session() as db:
        applied = {
            row["migration_key"]
            for row in db.execute("SELECT migration_key FROM schema_migrations").fetchall()
        }
        if "project_index_import_v1" not in applied:
            # Import legacy file metadata exactly once so normal list operations are indexed.
            try:
                from .projects import PROJECTS_DIR
                if PROJECTS_DIR.is_dir():
                    for folder in PROJECTS_DIR.iterdir():
                        metadata_file = folder / ".qwen-project.json"
                        if not folder.is_dir() or not metadata_file.is_file() or metadata_file.is_symlink():
                            continue
                        try:
                            metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
                            required = (metadata.get("id"), metadata.get("name"),
                                        metadata.get("created_at"), metadata.get("updated_at"))
                            if all(isinstance(value, str) and value for value in required):
                                try:
                                    db.execute(
                                        "INSERT OR IGNORE INTO projects(id,name,created_at,updated_at) VALUES(?,?,?,?)",
                                        required,
                                    )
                                except sqlite3.IntegrityError:
                                    continue
                        except (OSError, ValueError, TypeError):
                            continue
                db.execute(
                    "INSERT OR IGNORE INTO schema_migrations(migration_key,applied_at) VALUES(?,?)",
                    ("project_index_import_v1", now_iso()),
                )
            except ImportError:
                pass


def usage_snapshot(day: str) -> dict:
    with db_session() as db:
        row = db.execute("SELECT * FROM usage_daily WHERE day=?", (day,)).fetchone()
    if not row:
        return {"chat_requests": 0, "tool_calls": 0, "deployments": 0, "input_tokens": 0, "output_tokens": 0}
    return dict(row)


def reserve_chat(day: str, max_requests: int) -> dict:
    with db_session() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO usage_daily(day) VALUES(?)", (day,))
        row = db.execute("SELECT chat_requests FROM usage_daily WHERE day=?", (day,)).fetchone()
        if max_requests > 0 and row["chat_requests"] >= max_requests:
            db.rollback()
            raise PermissionError("Daily AI request limit reached. Try again tomorrow.")
        db.execute("UPDATE usage_daily SET chat_requests=chat_requests+1 WHERE day=?", (day,))
        db.commit()
        return usage_snapshot(day)


def add_usage(day: str, tool_calls: int = 0, input_tokens: int = 0, output_tokens: int = 0) -> None:
    with db_session() as db:
        db.execute("INSERT OR IGNORE INTO usage_daily(day) VALUES(?)", (day,))
        db.execute(
            "UPDATE usage_daily SET tool_calls=tool_calls+?, input_tokens=input_tokens+?, output_tokens=output_tokens+? WHERE day=?",
            (max(0, tool_calls), max(0, input_tokens), max(0, output_tokens), day),
        )


def reserve_deployment(day: str, max_deployments: int) -> None:
    with db_session() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO usage_daily(day) VALUES(?)", (day,))
        row = db.execute("SELECT deployments FROM usage_daily WHERE day=?", (day,)).fetchone()
        if max_deployments > 0 and row["deployments"] >= max_deployments:
            db.rollback()
            raise PermissionError("Daily deployment limit reached.")
        db.execute("UPDATE usage_daily SET deployments=deployments+1 WHERE day=?", (day,))
        db.commit()


def save_message(project_id: str, role: str, content: str) -> None:
    with db_session() as db:
        db.execute(
            "INSERT INTO chat_messages(project_id,role,content,created_at) VALUES(?,?,?,?)",
            (project_id, role, content[:20000], now_iso()),
        )


def recent_messages(project_id: str, limit: int | None = 16) -> list[dict]:
    with db_session() as db:
        # SQLite LIMIT -1 means no upper bound (unlimited history when limit=None).
        rows = db.execute(
            "SELECT role,content FROM chat_messages WHERE project_id=? ORDER BY id DESC LIMIT ?",
            (project_id, -1 if limit is None else limit),
        ).fetchall()
    return [{"role": row["role"], "content": row["content"]} for row in reversed(rows)]


def delete_project_records(project_id: str) -> None:
    with db_session() as db:
        db.execute("DELETE FROM chat_messages WHERE project_id=?", (project_id,))
        # Published static copies are intentionally retained as independent public deployments.


def reserve_tool_call(day: str, max_tool_calls: int) -> None:
    with db_session() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO usage_daily(day) VALUES(?)", (day,))
        row = db.execute("SELECT tool_calls FROM usage_daily WHERE day=?", (day,)).fetchone()
        if max_tool_calls > 0 and row["tool_calls"] >= max_tool_calls:
            db.rollback()
            raise PermissionError("Daily tool-call limit reached.")
        db.execute("UPDATE usage_daily SET tool_calls=tool_calls+1 WHERE day=?", (day,))
        db.commit()


def create_deployment(project_id: str, deployment_id: str, slug: str) -> None:
    with db_session() as db:
        db.execute(
            "INSERT INTO deployments(id,project_id,slug,created_at,status) VALUES(?,?,?,?,'published')",
            (deployment_id, project_id, slug, now_iso()),
        )


def list_deployments() -> list[dict]:
    with db_session() as db:
        rows = db.execute(
            "SELECT id,project_id,slug,created_at,status FROM deployments ORDER BY created_at DESC"
        ).fetchall()
    return [dict(row) for row in rows]


def get_deployment_by_slug(slug: str):
    with db_session() as db:
        row = db.execute(
            "SELECT id,project_id,slug,created_at,status FROM deployments WHERE slug=? AND status='published'",
            (slug,),
        ).fetchone()
    return dict(row) if row else None


# Project index helpers. None means the schema is not initialized (legacy/direct unit use).
def list_project_index() -> list[dict] | None:
    with db_session() as db:
        try:
            rows = db.execute(
                "SELECT id,name,created_at,updated_at FROM projects ORDER BY updated_at DESC"
            ).fetchall()
        except sqlite3.OperationalError:
            return None
    return [dict(row) for row in rows]


def upsert_project_index(project: dict) -> None:
    with db_session() as db:
        try:
            db.execute(
                "INSERT INTO projects(id,name,created_at,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(id) DO UPDATE SET name=excluded.name,"
                "created_at=excluded.created_at,updated_at=excluded.updated_at",
                (project["id"], project["name"], project["created_at"], project["updated_at"]),
            )
        except sqlite3.OperationalError:
            return
        except sqlite3.IntegrityError:
            # Direct project-module use without an initialized application DB is supported.
            return


def update_project_index(project_id: str, name: str, updated_at: str) -> None:
    with db_session() as db:
        try:
            db.execute(
                "UPDATE projects SET name=?,updated_at=? WHERE id=?",
                (name, updated_at, project_id),
            )
        except sqlite3.OperationalError:
            return


def delete_project_index(project_id: str) -> None:
    with db_session() as db:
        try:
            db.execute("DELETE FROM projects WHERE id=?", (project_id,))
        except sqlite3.OperationalError:
            return


def get_or_init_workspace_storage(compute_bytes) -> int:
    """Initialize cached storage once; compute_bytes runs only on cache miss."""
    with db_session() as db:
        try:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT bytes_used FROM workspace_storage WHERE id=1").fetchone()
            if row:
                value = int(row["bytes_used"])
            else:
                value = max(0, int(compute_bytes()))
                db.execute(
                    "INSERT INTO workspace_storage(id,bytes_used,updated_at) VALUES(1,?,?)",
                    (value, now_iso()),
                )
            db.commit()
            return value
        except sqlite3.OperationalError:
            db.rollback()
            # Supports importing/testing modules before app startup calls init_db.
            return 0


def workspace_storage_if_initialized() -> int | None:
    with db_session() as db:
        try:
            row = db.execute("SELECT bytes_used FROM workspace_storage WHERE id=1").fetchone()
        except sqlite3.OperationalError:
            return None
    return int(row["bytes_used"]) if row else None


def adjust_workspace_storage(delta: int, max_bytes: int | None = None) -> int | None:
    """Atomically reserve/release bytes. None means storage cache is not initialized."""
    with db_session() as db:
        try:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT bytes_used FROM workspace_storage WHERE id=1").fetchone()
            if not row:
                db.rollback()
                return None
            updated = max(0, int(row["bytes_used"]) + int(delta))
            if max_bytes is not None and updated > max_bytes:
                db.rollback()
                raise PermissionError("Workspace storage quota reached.")
            db.execute(
                "UPDATE workspace_storage SET bytes_used=?,updated_at=? WHERE id=1",
                (updated, now_iso()),
            )
            db.commit()
            return updated
        except sqlite3.OperationalError:
            db.rollback()
            return None
