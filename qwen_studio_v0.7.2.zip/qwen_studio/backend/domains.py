"""Small, dependency-free registrable-domain helper for origin-isolation warnings.

The built-in public-suffix list is intentionally partial. It covers common multi-label
suffixes used by this deployment; it is not a replacement for the full Public Suffix List.
"""
from __future__ import annotations

import ipaddress


_COMMON_MULTI_LABEL_SUFFIXES = frozenset({
    "com.dz", "org.dz", "net.dz", "gov.dz", "edu.dz", "art.dz", "pol.dz",
    "co.uk", "org.uk", "ac.uk", "gov.uk",
    "com.au", "net.au", "org.au", "co.nz", "co.za", "com.br", "com.tr",
    "com.eg", "com.sa", "com.ma", "co.jp", "co.in", "com.cn", "com.mx",
    "com.ar", "co.il", "com.sg", "com.hk",
})


def registrable_domain(hostname: str | None) -> str | None:
    """Return a best-effort registrable domain, or None for IPs/localhost/invalid hosts.

    If the last two labels are a known multi-label public suffix, the registrable
    domain is the last three labels. Otherwise it is the last two labels.
    """
    if not isinstance(hostname, str) or not hostname.strip():
        return None
    host = hostname.strip().rstrip(".").lower()
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    try:
        ipaddress.ip_address(host)
        return None
    except ValueError:
        pass

    if host == "localhost" or host.endswith(".localhost"):
        return None

    try:
        ascii_host = host.encode("idna").decode("ascii")
    except UnicodeError:
        return None
    labels = ascii_host.split(".")
    if len(labels) < 2 or any(not label or len(label) > 63 for label in labels):
        return None
    if any(not all(ch.isalnum() or ch == "-" for ch in label) for label in labels):
        return None

    suffix = ".".join(labels[-2:])
    if suffix in _COMMON_MULTI_LABEL_SUFFIXES:
        return ".".join(labels[-3:]) if len(labels) >= 3 else None
    return ".".join(labels[-2:])
